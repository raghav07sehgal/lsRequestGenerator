export const ntiPv: any = [
    { label: "FTTN", value: "FTTN" },
    { label: "FTTN-BP", value: "FTTN-BP" },
    { label: "FTTPIP", value: "FTTPIP" },
    { label: "FTTP-GPON", value: "FTTP-GPON" },
    { label: "RGPON", value: "RGPON" },
    { label: "FTTP-EGPON", value: "FTTP-EGPON" },
    { label: "FTTC-EGPON", value: "FTTC-EGPON" },
    { label: "IP-RT", value: "IP-RT" },
    { label: "IP-CO", value: "IP-CO" },
    { label: "IP-RT-BP", value: "IP-RT-BP" },
    { label: "IP-CO-BP", value: "IP-CO-BP" },
    { label: "FTTB-C", value: "FTTB-C" },
    { label: "FTTB-F", value: "FTTB-F" },
    { label: "FTTC-GPON", value: "FTTC-GPON" },
]

export const ntiCm: any = [
    { label: "FTTN", value: "FTTN" },
    { label: "FTTN-BP", value: "FTTN-BP" },
    { label: "FTTPIP", value: "FTTPIP" },
    { label: "FTTP-GPON", value: "FTTP-GPON" },
    { label: "RGPON", value: "RGPON" },
    { label: "FTTP-EGPON", value: "FTTP-EGPON" },
    { label: "FTTC-EGPON", value: "FTTC-EGPON" },
    { label: "IP-RT", value: "IP-RT" },
    { label: "IP-CO", value: "IP-CO" },
    { label: "IP-RT-BP", value: "IP-RT-BP" },
    { label: "IP-CO-BP", value: "IP-CO-BP" },
    { label: "FTTB-C", value: "FTTB-C" },
    { label: "FTTB-F", value: "FTTB-F" },
    { label: "FTTC-GPON", value: "FTTC-GPON" }
]