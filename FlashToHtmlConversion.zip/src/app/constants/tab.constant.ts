export const tabSelection: any = [
    { label: "omsMessage", title: "OMS Messages" },
    { label: "fnt", title: "F&T" },
    { label: "l1-upc-alcatel", title: "L1 Assignment/UPC-Alcatel" },
    { label: "l1-upc-ericson", title: "L1 Assignment/UPC-Ericson" },
    { label: "mpc-alcatel", title: "MPC Alcatel" },
    { label: "mpc-ericson", title: "MPC Ericson" },
    { label: "cin", title: "CIN" },
    // { label: "log", title: "Log" },
    { label: "mps", title: "MPS" },
    { label: "aseolsMessages", title: "A SEoL S Messages" },
    // { label: "ilt", title: "ILT" },
    { label: "star", title: "STAR" },
    { label: "wll", title: "WLL" },
    { label: "wllft", title: "WLL_FT" },
    // { label: "jbbossasim", title: "Jbbos SA Sim" },
    // { label: "webServices", title: "WebServices" },
]

export const omsTabSelection: any = [
    { label: "hsia", title: "HSIA", disabled: false },
    { label: "wifi", title: "WIFI", disabled: false },
    { label: "voip", title: "VOIP", disabled: true },
    { label: "iptv", title: "IPTV", disabled: true },
    { label: "wireless", title: "WIRELESS", disabled: true },
    { label: "directv", title: "DIRECTV", disabled: true },
    { label: "wire", title: "WIRE", disabled: true },
    { label: "wap", title: "WAP", disabled: true },
    { label: "ott", title: "OTT", disabled: true },
]

export const cmTabSelected: any = [
    { label: "wlld", title: "WLLD" },
    { label: "wsim", title: "WSIM" },
    { label: "wnad", title: "WNAD" },
    { label: "owa", title: "OWA" },
    { label: "wllv", title: "WLLV" },
]

export const wllTabSelected: any = [
    { label: "csiIn", title: "CSI IN" },
    { label: "csiScMan", title: "CSI SC-Man" },
    { label: "csiScInquire", title: "CSI SC-Inquire" },
    { label: "csiNsm", title: "CSi NSM" },
    { label: "csiGears", title: "CSI GEARS" },
    { label: "csiCc", title: "CSI CC" },
    { label: "csfobpm", title: "CSFOBPM" },
    { label: "csiPom", title: "CSI POM" },
    { label: "csiTorch", title: "CSI-TORCH" },
];

export const pvTabSelected: any = [
    { label: "wlld", title: "WLLD" },
    { label: "wsim", title: "WSIM" },
    { label: "wnad", title: "WNAD" },
    { label: "owa", title: "OWA" },
    { label: "wllv", title: "WLLV" },
    { label: "csiIn", title: "CSI IN" },
];

export const wllTabArr: any = [
    { label: "wlld", title: "WLLD" },
    { label: "wsim", title: "WSIM" },
    { label: "wnad", title: "WNAD" },
    { label: "owa", title: "OWA" },
    { label: "wllv", title: "WLLV" },
    { label: "wllv2", title: "WLLV-2" },
    { label: "wllv3", title: "WLLV-3" },
]

export const fntTabSelection: any = [
    { label: "hsia", title: "HSIA" },
    { label: "wifi", title: "WIFI" },
    { label: "cvoip", title: "CVOIP" },
    { label: "iptv", title: "IPTV" },
    { label: "wireless", title: "WIRELESS" },
    { label: "direcTv", title: "DIRECTV" },
    { label: "wap", title: "WAP" },
    { label: "ott", title: "OTT" },
]

export const cmTabSelection: any = [
    { label: "hsia", title: "HSIA" },
    { label: "wifi", title: "WIFI" },
    { label: "voip", title: "VOIP" },
    { label: "iptv", title: "IPTV" },
    { label: "wireless", title: "WIRELESS" },
    { label: "direcTv", title: "DIRECTV" },
    { label: "wire", title: "WIRE" },
    { label: "wap", title: "WAP" },
    { label: "ott", title: "OTT" },
]

export const iptvTabSelection: any = [
    { label: "main", title: "Main" },
    { label: "gps", title: "GPs" },
    { label: "stbs", title: "STBs" }
]

export const starTabSelection: any = [
    { label: "main", title: "Main" },
    { label: "tdar", title: "TDAR" },
    { label: "tdarFnt", title: "TDAR F&T" },
    { label: "isaacTdar", title: "ISAAC-TDAR" },
]

export const dtvmTabSelection: any = [
    { label: "dtcp", title: "DTCP" },
    { label: "attdv", title: "ATTDV" },
    { label: "dtt", title: "DTT" },
    { label: "dtvbvp", title: "DTVBVP" },
    { label: "dtwb", title: "DTWB" },
    { label: "dtacrd", title: "DTACRD" },
    { label: "addsrv", title: "ADDSRV" },
    { label: "dtota", title: "DTOTA" },
]

export const dtcpTabSelection: any = [
    { label: "dtstb", title: "DTSTB" },
    { label: "dtstb", title: "DTSTB" },
    { label: "dtstb", title: "DTSTB" },
    { label: "dtstb", title: "DTSTB" },
    { label: "dtstb", title: "DTSTB" },
]

export const dtotaTabSelection: any = [
    { label: "dtotal", title: "DTOTAL" },
    { label: "dtotaa", title: "DTOTAA" },
]

export const attdvTabSelection: any = [
    { label: "dtgp", title: "DTGP" },
    { label: "dtgp", title: "DTGP" },
    { label: "dtgp", title: "DTGP" },
    { label: "dtgp", title: "DTGP" },
    { label: "dtgp", title: "DTGP" }
];

export const starMainTabs: any = [
    { label: "lineItem1", title: "LineItem1", disabled: true },
    { label: "lineItem2", title: "LineItem2", disabled: true },
    { label: "lineItem3", title: "LineItem3", disabled: true },
    { label: "lineItem4", title: "LineItem4", disabled: true },
    { label: "lineItem5", title: "LineItem5", disabled: true },
    { label: "lineItem6", title: "LineItem6", disabled: true },
    { label: "lineItem7", title: "LineItem7", disabled: true },
    { label: "lineItem8", title: "LineItem8", disabled: true },
    { label: "extlineItem1", title: "ExtLineItem1", disabled: true },
    { label: "extlineItem2", title: "ExtLineItem2", disabled: true },
]

export const starIsaacTabs: any = [
    { label: "lineItemDetails1", title: "LineItemDetails1", disabled: true },
    { label: "lineItemDetails2", title: "LineItemDetails2", disabled: true },
    { label: "lineItemDetails3", title: "LineItemDetails3", disabled: true },
    { label: "lineItemDetails4", title: "LineItemDetails4", disabled: true },
]

export const voipTabSelection: any = [
    { label: "line1", title: "Line1", disabled: false },
    { label: "line2", title: "Line2", disabled: false },
    { label: "line3", title: "Line3", disabled: false },
    { label: "legacytn1", title: "Legacy TN1", disabled: false },
    { label: "legacytn2", title: "Legacy TN2", disabled: false },
    { label: "line4", title: "Line4", disabled: true },
    { label: "line5", title: "Line5", disabled: true },
    { label: "line6", title: "Line6", disabled: true },
    { label: "line7", title: "Line7", disabled: true },
    { label: "line8", title: "Line8", disabled: true },
    { label: "line9", title: "Line", disabled: true },
    { label: "line10", title: "Line10", disabled: true },
]

export const cvoipTabSelection: any = [
    { label: "line1", title: "Line1", disabled: false },
    { label: "line2", title: "Line2", disabled: true },
    { label: "line3", title: "Line3", disabled: true },
    { label: "line4", title: "Line4", disabled: true },
    { label: "line5", title: "Line5", disabled: true },
    { label: "line6", title: "Line6", disabled: true },
]

export const tabValue1: any = [
    { id: 1, name: 'HSIA' },
    { id: 2, name: 'WIFI' },
    { id: 3, name: 'VOIP' },
    { id: 4, name: 'IPTV' },
    { id: 5, name: 'WIRELESS' },
    { id: 6, name: 'DIRECTV' },
    { id: 7, name: 'WIRE' },
    { id: 8, name: 'WAP' },
    { id: 9, name: 'OTT' },
];