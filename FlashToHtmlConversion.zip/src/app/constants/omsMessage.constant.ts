export const VhoDropdownValues: any = [
    { label: "AUS2TX", value: "aus2tx" },
    { label: "BCVLOH", value: "bcvloh" },
    { label: "BKF2CA", value: "bkf2ca" },
    { label: "BRHMAL", value: "brhmal" },
    { label: "BTRGLA", value: "btrgla" },
    { label: "CHRLNC", value: "chrlnc" },
    { label: "CICRIL", value: "cicril" },
    { label: "CLMASC", value: "clmasc" }
]

export const subTypeDropdownValues: any = [
    { label: "R (Consumer)", value: "R" },
    { label: "H (Consumer Home Office)", value: "H" },
    { label: "9 (Consumer Small Office)", value: "9" },
    { label: "S (Consumer Employee)", value: "S" },
    { label: "E (Enterprise)", value: "E" },
]

export const timeZOneDropdownValues: any = [
    { label: "-5", value: "-5" },
    { label: "-6", value: "-6" },
    { label: "-7", value: "-7" },
    { label: "-8", value: "-8" },
]

export const salesChannelDropdownValues: any = [
    { label: "CS - OMS", value: "CS" },
    { label: "TE - OMS", value: "TE" },
    { label: "COR - MobilityCSI", value: "COR" },
    { label: "SYSX - MobilityCSI", value: "SYSX" },
    { label: "WEB - AMSS", value: "WEB" },
    { label: "ITV - AMSS", value: "ITV" },
]

export const uvOrderActionTypeDropdown: any = [
    { label: "UVPR", value: "uvpr" },
    { label: "NA", value: "na" },
]

export const cidrDropdown: any = [
    { label: "29", value: "29" },
    { label: "28", value: "28" },
    { label: "27", value: "27" },
    { label: "26", value: "26" },
]

export const portOutDestinationDropdown: any = [
    { label: "None", value: "None" },
    { label: "TDM", value: "TDM" },
    { label: "CLEC", value: "CLEC" },
    { label: "Wireless", value: "Wireless" },
]

export const oldFeatureSetDropdown: any = [
    { label: "Standard Feature Set", value: "Standard Feature Set" },
    { label: "BusinessFS", value: "BusinessFS" },
]

export const accountTypeDropdown: any = [
    { label: "S", value: "S" },
    { label: "F", value: "F" },
]

export const currentSpidDropdown: any = [
    { label: "", value: "" },
    { label: "516C", value: "516C" },
    { label: "5200", value: "5200" },
    { label: "7606", value: "7606" },
    { label: "1111", value: "1111" },
]

export const newSpidDropdown: any = [
    { label: "", value: "" },
    { label: "5200", value: "5200" },
    { label: "9300", value: "9300" },
    { label: "9417", value: "9417" },
    { label: "9533", value: "9533" },
    { label: "0132", value: "0132" },
    { label: "0822", value: "0822" },
    { label: "0988", value: "0988" },
    { label: "1111", value: "1111" },
]

export const tnTypeDropdown: any = [
    { label: "NATIVE", value: "NATIVE" },
    { label: "ICP", value: "ICP" },
    { label: "PORTINGIN", value: "PORTINGIN" },
    { label: "PORTINGOUT", value: "PORTINGOUT" },
]

export const tnSubTypeDropdown: any = [
    { label: "NATIVE", value: "NATIVE" },
    { label: "NA", value: "NA" },
    { label: "PTO", value: "PTO" },
    { label: "FPI", value: "FPI" },
    { label: "PTO_RTNN", value: "PTO_RTNN" },
    { label: "REUSETN", value: "REUSETN" },
    { label: "DISCONNECT", value: "DISCONNECT" },
]

export const CompletionIndicatorDropdown: any = [
    { label: "NA", value: "NA" },
    { label: "IP", value: "IP" },
    { label: "CO", value: "CO" },
    { label: "PC", value: "PC" },
    { label: "PI", value: "PI" },
    { label: "ER", value: "ER" },
]
export const ipTypeDropdown: any = [
    { label: "Dynamic", value: "Dynamic" },
    { label: "Static", value: "Static" },
]

export const compIndDropdown: any = [
    { label: "NA", value: "NA" },
    { label: "IP", value: "IP" },
    { label: "CO", value: "CO" },
    { label: "PC", value: "PC" },
    { label: "PI", value: "PI" },
    { label: "ER", value: "ER" },
]

export const installTypeDropdownValues: any = [
    { label: "Tech", value: "tech" },
    { label: "CSI", value: "csi" },
    { label: "None", value: "none" },
]

export const techDispatchDropdownValues: any = [
    { label: "Install", value: "install" },
    { label: "Repair", value: "repair" },
    { label: "None", value: "none" },
]

export const TotalBandwidthDropdownValues: any = [
    { label: "32.0", value: "32.0" },
    { label: "18.0", value: "18.0" },
    { label: "24.0", value: "24.0" },
    { label: "90.0", value: "90.0" },
    { label: "55.0", value: "55.0" },
    { label: "25.0", value: "25.0" },
    { label: "19.0", value: "19.0" },
    { label: "13.0", value: "13.0" },
    { label: "75.0", value: "75.0" },
    { label: "100.0", value: "100.0" },
]

export const loopIndicationDropdownValues: any = [
    { label: "", value: "" },
    { label: "UN", value: "UN" },
    { label: "PU", value: "PU" },
    { label: "SU", value: "SU" },
    { label: "BU", value: "BU" },
    { label: "CU", value: "CU" },
]

export const classOfServiceDropdownValues: any = [
    { label: "Residential", value: "residential" },
    { label: "Business", value: "business" },
]

export const modelDropdwnValues: any = [
    { label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" },
    { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
    { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" },
    { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
    { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" },
    { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
    { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" },
    { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
    { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
    { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
    { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" },
    { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
    { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
    { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
    { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" },
    { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
    { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
    { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }]

export const OrderActionReasonCodeDropdown: any = [
    { label: "", value: "" },
    { label: "NP - Non Payment", value: "nonPayment" },
    { label: "TR - F&T Move", value: "fntMove" }
];

export const OrderActionDropdown: any = [
    { label: "PR", value: "pr" },
    { label: "CH", value: "ch" },
    { label: "CE", value: "ce" },
    { label: "CW", value: "cw" },
    { label: "SU", value: "su" },
    { label: "RS", value: "rs" },
    { label: "SS", value: "ss" },
    { label: "SR", value: "sr" }
];

export const unifydeunifyIndDropdown: any = [
    { label: "Y", value: "false" },
    { label: "N", value: "true" },
    { label: "invalid", value: "invalid" },
]

export const deviceDropdown: any = [
    { label: "WAP2.1: Cisco IPN7105", data1: "Cisco", data2: "IPN7105" },
    { label: "WAP2.1: Motorola VIP2500", data1: "Motorola", data2: "VIP2500" },
    { label: "WAP2.0: Motorola VAP2400", data1: "Motorola", data2: "VAP2400" }
];

export const SubTypeDropdown: any = [
    { label: "NA", value: "na" },
    { label: "AM", value: "am" },
    { label: "CA", value: "ca" },
];

export const WllOrdRefDropdown: any = [
    { label: "A", value: "A" },
    { label: "B", value: "B" },
    { label: "C", value: "C" },
    { label: "D", value: "D" },
    { label: "E", value: "E" },
    { label: "F", value: "F" },
    { label: "G", value: "G" },
    { label: "H", value: "H" }
];

export const WllOrdActionStatusDropdown: any = [
    { label: "DE", value: "DE" },
    { label: "NE", value: "NE" },
    { label: "DO", value: "DO" },
    { label: "NO", value: "NO" },
]

export const RgResetDropdown: any = [
    { label: "RESET", value: "reset" },
    { label: "Do not Reset", value: "doNotReset" },
];

export const CreationAppDropdown: any = [
    { label: "OMS", value: "oms" },
    { label: "UROCK", value: "urock" },
    { label: "ETRACS", value: "etracs" },
    { label: "SOE", value: "soe" },
    { label: "PHX", value: "phx" },
];

export const ReferenceDropdown: any = [
    { label: "A", value: "a" },
    { label: "B", value: "b" },
    { label: "C", value: "c" },
    { label: "D", value: "d" },
    { label: "E", value: "e" },
    { label: "F", value: "f" },
    { label: "G", value: "g" },
    { label: "H", value: "h" },
    { label: "I", value: "i" },
    { label: "J", value: "j" },
    { label: "K", value: "k" },
    { label: "L", value: "l" },
    { label: "M", value: "m" },
    { label: "N", value: "n" },
    { label: "O", value: "o" },
];

export const actionDropdownValue: any = [
    { value: "i", label: "I" },
    { value: "m", label: "M" },
    { value: "r", label: "R" },
    { value: "d", label: "D" },
    { value: "c", label: "C" },
    { value: "", label: "" },
]

export const RadioOptionsValues1: any = [
    { title: "ReceiveNADSwapRequest", value: "receiveNADSwapRequest" },
    { title: "ReceiveNADSwapCompletionRequest", value: "receiveNADSwapCompletionRequest" },
    { title: "RetrieveNADInformationRequest", value: "retrieveNADInformationRequest" },
]

export const instantHSIAOnIndicator: any = [

]

export const infoValue: any = [
    { id: 1, name: 'ML JBBOS' },
    { id: 2, name: 'Related Product Info' },
];

export const wllv2: any = [
    { id: 1, name: 'Add WLLV2' },
];

export const wllv3: any = [
    { id: 1, name: 'Add WLLV3' },
];

export const tnValue: any = [
    { id: 1, name: 'ReuseTN' },
];

export const legacyTnValue1: any = [
    { id: 1, name: 'Legacy TN 1' },
];

export const legacyTnValue2: any = [
    { id: 1, name: 'Legacy TN 2' },
];

export const tnValue1: any = [
    { id: 1, name: 'Line 2' },
]

export const tnValue2: any = [
    { id: 1, name: 'Line 3' },
]

export const ntiValue: any = [
    { id: 1, name: 'IPDSL - VDSL NTI Change' },
    { id: 2, name: 'VDSL/IPDSL - GPON NTI Change' },
];

export const PrimaryRadioOptions: any = [
    { title: "Line1", value: "line1", selected: true },
    { title: "Line3", value: "line3" },
    { title: "Line2", value: "line2" },
]

export const reasonCodesDropdown: any = [
    { value: "SWX", label: "SWX" },
    { value: "DMG", label: "DMG" },
    { value: "DEF", label: "DEF" },
    { value: "SWP", label: "SWP" },
    { value: "SWR", label: "SWR" },
];