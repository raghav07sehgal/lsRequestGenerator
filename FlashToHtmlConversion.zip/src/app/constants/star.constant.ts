export const modeDropdown: any = [
    { label: "Initiate", value: "Initiate" },
    { label: "Process", value: "Process" },
    { label: "Swap", value: "Swap" },
    { label: "Closeout", value: "Closeout" }
]

export const lineItemDropdown: any = [
    { label: "0", value: "0" },
    { label: "1", value: "1" },
    { label: "2", value: "2" },
    { label: "3", value: "3" },
    { label: "4", value: "4" },
    { label: "5", value: "5" },
    { label: "6", value: "6" },
    { label: "7", value: "7" },
    { label: "8", value: "8" },
]

export const issacLineItemDropdown: any = [
    { label: "0", value: "0" },
    { label: "1", value: "1" },
    { label: "2", value: "2" },
    { label: "3", value: "3" },
    { label: "4", value: "4" },
]

export const extLineItemDropdown: any = [
    { label: "Select", value: "Select" },
    { label: "ext1", value: "ext1" },
    { label: "ext2", value: "ext2" },
]

export const OrderLineItemActionDropdown: any = [
    { label: "Add", value: "Add" },
    { label: "Deleted", value: "Deleted" },
    { label: "Updated", value: "Updated" },
    { label: "New", value: "New" },
    { label: "Existing", value: "Existing" },
    { label: "Sysadded", value: "Sysadded" },
]

export const IrdActionDropdown: any = [
    { label: "Install", value: "Install" },
    { label: "Service Swap", value: "Service Swap" },
    { label: "Doa Swap", value: "Doa Swap" },
    { label: "iv Retest", value: "iv Retest" },
    { label: "No Action Taken", value: "No Action Taken" },
]

export const productNameDropdown: any = [
    { label: "DIRECTV C51-100", value: "DIRECTV C51-100" },
    { label: "DIRECTV C41-100", value: "DIRECTV C41-100" },
    { label: "DIRECTV HR20-100", value: "DIRECTV HR20-100" },
    { label: "DIRECTV HR44-700", value: "DIRECTV HR44-700" },
    { label: "DIRECTV COM46-100", value: "DIRECTV COM46-100" },
    { label: "DIRECTV H25-100", value: "DIRECTV H25-100" },
    { label: "DIRECTV H24-100", value: "DIRECTV H24-100" },
    { label: "DIRECTV C41W-100", value: "DIRECTV C41W-100" },
    { label: "DIRECTV WVBR0-01", value: "DIRECTV WVBR0-01" },
    { label: "BASE S30", value: "BASE S30" },
]

export const productLineDropdown: any = [
    { label: "IRD - CLIENT", value: "IRD - CLIENT" },
    { label: "IRD - KA/KU", value: "IRD - KA/KU" },
    { label: "IRD - ADVANCED WHOLE-HOME DVR", value: "IRD - ADVANCED WHOLE-HOME DVR" },
    { label: "IRD - HD/DVR COMBO", value: "IRD - HD/DVR COMBO" },
    { label: "IRD - WIRELESS CLIENT", value: "IRD - WIRELESS CLIENT" },
    { label: "WIRELESS VIDEO BRIDGE", value: "WIRELESS VIDEO BRIDGE" },
    { label: "HOME SECURITY BASE", value: "HOME SECURITY BASE" },
]

export const LineItemStatusDropdown: any = [
    { label: "Open", value: "Open" },
    { label: "Closed", value: "Closed" },
]

export const accessCardStatusDropdown: any = [
    { label: "ACTV", value: "ACTV" },
    { label: "DCRD", value: "DCRD" },
]

export const categoryDropdown: any = [
    { label: "New", value: "New" },
    { label: "Added", value: "Added" },
    { label: "SysAdded", value: "SysAdded" },
]

export const equipmentOwnershipDropdown: any = [
    { label: "LEASE", value: "LEASE" },
    { label: "OWNED", value: "OWNED" }
]

export const lineItemActionDropdown: any = [
    { label: "Add", value: "Add" }
]

export const equipOwnTypeDropdown: any = [
    { label: "Own", value: "Own" }
]

export const actionTypeDropdown: any = [
    { label: "Activate", value: "Activate" }
]

export const shippingIndicatorDropdown: any = [
    { label: "Tech", value: "tech" },
    { label: "Customer", value: "customer" },
    { label: "None", value: "none" },
]

export const customerLineDropdown: any = [
    { label: "NA", value: "NA" },
    { label: "MDU_DTH", value: "MDU_DTH" },
    { label: "MDU_BULK", value: "MDU_BULK" },
]

export const propContrTypDropdown: any = [
    { label: "", value: "" },
    { label: "NA", value: "NA" },
    { label: "NDPL", value: "NDPL" },
    { label: "DPL", value: "DPL" },
]

export const OwnershipDropdown: any = [
    { label: "Leased", value: "Leased" },
    { label: "Purchased", value: "Purchased" }
]

export const SapOrdStatDropdown: any = [
    { label: "N/A", value: "N/A" },
    { label: "Unknown", value: "Unknown" },
    { label: "Created", value: "Created" },
    { label: "DropShipped", value: "DropShipped" },
    { label: "Shipped", value: "Shipped" },
    { label: "Delivered", value: "Delivered" },
    { label: "NotDelivered", value: "NotDelivered" },
]

export const actionTypeTdarDropdown: any = [
    { label: "A", value: "A" },
    { label: "U", value: "U" },
    { label: "O", value: "O" },
    { label: "M", value: "M" },
]

export const productLineTdarDropdown: any = [
    { label: "IRD - STANDARD", value: "IRD - STANDARD" },
    { label: "IRD - HD/DVR COMBO", value: "IRD - HD/DVR COMBO" },
    { label: "IRD - WIRELESS CLIENT", value: "IRD - WIRELESS CLIENT" },
    { label: "RVU CLIENT TV", value: "RVU CLIENT TV" },
    { label: "IRD - 4K CLIENT", value: "IRD - 4K CLIENT" },
    { label: "IRD - DVR", value: "IRD - DVR" },
    { label: "IRD - CLIENT", value: "IRD - CLIENT" },
    { label: "IRD - KA/KU", value: "IRD - KA/KU" },
    { label: "IRD - GENIE LITE", value: "IRD - GENIE LITE" },
    { label: "IRD - ADVANCED WHOLE-HOME DVR", value: "IRD - ADVANCED WHOLE-HOME DVR" },
    { label: "WIRELESS VIDEO BRIDGE", value: "WIRELESS VIDEO BRIDGE" },
    { label: "ANTENNA", value: "ANTENNA" },
    { label: "IRD - GENIE SERVER", value: "IRD - GENIE SERVER" },
    { label: "GENIE LITE HD DVR KIT", value: "GENIE LITE HD DVR KIT" },
]

export const modelNumTdarDropdown: any = [
    { label: "HR54-100", value: "HR54-100" },
    { label: "null", value: "" },
    { label: "H21-100", value: "H21-100" },
    { label: "HR34-100", value: "HR34-100" },
    { label: "HR44-100", value: "HR44-100" },
    { label: "H24-100", value: "H24-100" },
    { label: "H25-100", value: "H25-100" },
    { label: "H44-100", value: "H44-100" },
    { label: "C31-100", value: "C31-100" },
    { label: "C41-100", value: "C41-100" },
    { label: "C61-100", value: "C61-100" },
    { label: "D12-100", value: "D12-100" },
    { label: "R16-100", value: "R16-100" },
    { label: "H23-100", value: "H23-100" },
    { label: "HR20-100", value: "HR20-100" },
    { label: "HR21-100", value: "HR21-100" },
    { label: "HR22-100", value: "HR22-100" },
    { label: "HR23-100", value: "HR23-100" },
    { label: "HR24-100", value: "HR24-100" },
    { label: "R22-100", value: "R22-100" },
    { label: "THR22-100", value: "THR22-100" },
    { label: "C51-700", value: "C51-700" },
    { label: "C61-500", value: "C61-500" },
    { label: "C61-700", value: "C61-700" },
    { label: "R15-100", value: "R15-100" },
    { label: "R15-300", value: "R15-300" },
    { label: "R15-500", value: "R15-500" },
    { label: "R16-300", value: "R16-300" },
    { label: "R16-500", value: "R16-500" },
    { label: "R22-200", value: "R22-200" },
    { label: "HR10-250", value: "HR10-250" },
    { label: "HR20-100", value: "HR20-100" },
    { label: "HR20-700", value: "HR20-700" },
    { label: "HR21-200", value: "HR21-200" },
    { label: "HR21-700", value: "HR21-700" },
    { label: "HR23-700", value: "HR23-700" },
    { label: "HR24-200", value: "HR24-200" },
    { label: "HR24-500", value: "HR24-500" },
    { label: "H20-600", value: "H20-600" },
    { label: "H20-999", value: "H20-999" },
]

export const purchaseTermTdarDropdown: any = [
    { label: "BYOE", value: "BYOE" },
    { label: "Rent", value: "Rent" },
    { label: "Purchase", value: "Purchase" },
]

export const stbTypeTdarDropdown: any = [
    { label: "DTVSDonly", value: "DTVSDonly" },
    { label: "DTVHDDVR", value: "DTVHDDVR" },
    { label: "DTVWirelessGenie", value: "DTVWirelessGenie" },
    { label: "DTVRVU", value: "DTVRVU" },
    { label: "DTV4KGenie", value: "DTV4KGenie" },
    { label: "DTVSDDVR", value: "DTVSDDVR" },
    { label: "DTVGenieMini", value: "DTVGenieMini" },
    { label: "DTVHDonly", value: "DTVHDonly" },
    { label: "DTVGenieLite", value: "DTVGenieLite" },
    { label: "DTVGenie", value: "DTVGenie" },
    { label: "WirelessBrdg", value: "WirelessBrdg" },
    { label: "DTAntenna", value: "DTAntenna" },
]

export const BaseProgramDtvDropdown: any = [
    { label: "BasicChoice", value: "BasicChoice" },
    { label: "Family", value: "Familyr" },
    { label: "Select", value: "Select" },
    { label: "Entertainment", value: "Entertainment" },
    { label: "Choice", value: "Choice" },
    { label: "PreferredChoice", value: "PreferredChoice" },
    { label: "PreferredXTRA", value: "PreferredXTRA" },
    { label: "XTRA", value: "XTRA" },
    { label: "Ultimate", value: "Ultimate" },
    { label: "Premier", value: "Premier" },
    { label: "MAS LATINO", value: "MAS LATINO" },
    { label: "OPTIMO MAS", value: "OPTIMO MAS" },
    { label: "MAS ULTRA", value: "MAS ULTRA" },
    { label: "LO MAXIMO", value: "LO MAXIMO" },
]

export const sWMIndicatorDropdown: any = [
    { label: "MULTI-SWITCH SWM 8", value: "MULTI-SWITCH SWM 8" },
    { label: "MULTI-SWITCH SWM 16", value: "MULTI-SWITCH SWM 16" },
    { label: "MULTI-SWITCH SWM 32", value: "MULTI-SWITCH SWM 32" },
    { label: "Y", value: "Y" },
    { label: "N", value: "N" },
    { label: "Null", value: "" },
]

export const D2LiteEligibilityDropdown: any = [
    { label: "Eligible", value: "Eligible" },
    { label: "Not Eligible", value: "Not Eligible" },
    { label: "d2liteEligibleUnconfirmed  ", value: "d2liteEligibleUnconfirmed  " },
    { label: "d2liteEligibleRestricted ", value: "d2liteEligibleRestricted " },
    { label: "d2liteEligibleConfirmed ", value: "d2liteEligibleConfirmed " },
    { label: "d2liteActive ", value: "d2liteActive " },
    { label: "d2liteNotEligibleUnconfirmed", value: "d2liteNotEligibleUnconfirmed" },
    { label: "Null", value: "" },
]

export const partnerNameDropdown: any = [
    { label: "NA", value: "NA" },
    { label: "Centurylink", value: "Centurylink" },
    { label: "Quest", value: "Quest" },
]

export const supersedeDropdown: any = [
    { label: "NA", value: "NA" },
    { label: "2BAN", value: "2BAN" },
]