export const uspIndicatorDropdown: any = [
    { label: "Yes", value: "yes" },
    { label: "No", value: "no" }
]

export const uspIndicatorDropdown2: any = [
    { label: "No", value: "no" },
    { label: "Yes", value: "yes" },
]

export const shortToggleDropdown: any = [
    { label: "Y", value: "y" },
    { label: "N", value: "n" }
]

export const shortToggleDropdown2: any = [
    { label: "NA", value: "na" },
    { label: "Y", value: "y" },
    { label: "N", value: "n" }
]

export const sevenTeenMHzFeature: any = [
    { label: "Allow", value: "allow" },
    { label: "Disallow", value: "disallow" },
]

export const titleDropdownValue: any = [
    { label: "Mr", value: "mr" },
    { label: "Mrs", value: "mrs" },
    { label: "Ms", value: "ms" },
]

export const trueFalseDropdownValue: any = [
    { label: "true", value: "true" },
    { label: "false", value: "false" },
]

export const numberDropdownValue: any = [
    { label: "0", value: "0" },
    { label: "1", value: "1" },
    { label: "2", value: "2" },
    { label: "3", value: "3" },
    { label: "4", value: "4" },
    { label: "5", value: "5" },
    { label: "6", value: "6" },
    { label: "7", value: "7" },
    { label: "8", value: "8" },
    { label: "9", value: "9" },
]

export const alphabetDropdown: any = [
    { label: "A", value: "A" },
    { label: "B", value: "B" },
    { label: "C", value: "C" },
    { label: "D", value: "D" },
    { label: "E", value: "E" },
    { label: "F", value: "F" },
    { label: "G", value: "G" },
    { label: "H", value: "H" },
    { label: "I", value: "I" },
    { label: "J", value: "J" },
    { label: "K", value: "K" },
    { label: "L", value: "L" },
    { label: "M", value: "M" },
    { label: "N", value: "N" },
    { label: "O", value: "O" },
]