export const spidDropdown: any = [
    { label: "6061", value: "6061" },
    { label: "6214", value: "6214" },
    { label: "7606", value: "7606" },
    { label: "8712", value: "8712" },
    { label: "7608", value: "7608" },
    { label: "7070", value: "7070" },
    { label: "8935", value: "8935" },
    { label: "9533", value: "9533" },
    { label: "9300", value: "9300" },
    { label: "9417", value: "9417" },
]

export const wllftActionDropdown: any = [
    { label: "D", value: "D" },
    { label: "C", value: "C" },
]

export const ipTypeDropdown: any = [
    { label: "Dynamic", value: "true" },
    { label: "Static", value: "false" },
]

export const ipQuantityDropdown: any = [
    { label: "2", value: "2" },
    { label: "4", value: "4" },
]

export const dataSpeedDropdown: any = [
    { label: "fast", value: "fast" },
    { label: "dummy", value: "dummy" },
]

export const dataCapDropdown: any = [
    { label: "dummy", value: "dummy" }
]

export const cellRankDropdown: any = [
    { label: "1", value: "1" },
    { label: "2", value: "2" },
    { label: "3", value: "3" },
]

export const transitionTypeDropdown: any = [
    { label: "Reserve", value: "Reserve" },
    { label: "Release", value: "Release" },
    { label: "Assign", value: "Assign" },
]

export const dvCodeDropdown: any = [
    { label: "D", value: "D" },
    { label: "V", value: "V" },
    { label: "A", value: "A" },
]