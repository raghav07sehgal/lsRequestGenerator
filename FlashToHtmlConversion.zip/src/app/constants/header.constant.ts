export const EnvDropdownValues: any = [
    { label: "ST1", value: "st1" },
    { label: "ST2", value: "st2" },
    { label: "ST3", value: "st3" },
    { label: "ST4", value: "st4" },
    { label: "ST5", value: "st5" },
    { label: "ST6", value: "st6" },
    { label: "ST7", value: "st7" },
    { label: "ST8", value: "st8" },
    { label: "ST9", value: "st9" },
    { label: "ST10", value: "st10" },
    { label: "ST12", value: "st12" },
    { label: "IT1", value: "it1" },
    { label: "IT2", value: "it2" },
    { label: "IT3", value: "it3" },
    { label: "IT4", value: "it4" },
    { label: "IT5", value: "it5" },
    { label: "IT6", value: "it6" },
    { label: "IT7", value: "it7" },
    { label: "IT8", value: "it8" },
    { label: "IT9", value: "it9" },
    { label: "IT10", value: "it10" },
    { label: "POC1", value: "poc1" }
]

export const NtiDropdownValues: any = [
    { label: "FTTN (RT)", value: "FTTN" },
    { label: "FTTN (CO)", value: "FTTN" },
    { label: "FTTN-BP (RT)", value: "FTTN-BP" },
    { label: "FTTN-BP (CO)", value: "FTTN-BP" },
    { label: "FTTPIP", value: "FTTPIP" },
    { label: "FTTP-GPON", value: "FTTP-GPON" },
    { label: "RGPON", value: "RGPON" },
    { label: "FTTP-EGPON", value: "FTTP-EGPON" },
    { label: "FTTC-EGPON", value: "FTTC-EGPON" },
    { label: "IP-RT", value: "IP-RT" },
    { label: "IP-CO", value: "IP-CO" },
    { label: "IP-RT-BP", value: "IP-RT-BP" },
    { label: "IP-CO-BP", value: "IP-CO-BP" },
    { label: "FTTB-C", value: "FTTB-C" },
    { label: "FTTB-F", value: "FTTB-F" },
    { label: "NA", value: "NA" },
    { label: "FTTC-GPON", value: "FTTC-GPON" },
]

export const ModelDropdownValues: any = [
    { label: "Model0", value: "model0" },
    { label: "Model2", value: "model2" },
    { label: "Model3", value: "model3" },
    { label: "Model4", value: "model4" },
    { label: "Model5", value: "model5" },
    { label: "Model6", value: "model6" },
    { label: "Model7", value: "model7" },
    { label: "Model8", value: "model8" },
    { label: "Model9", value: "model9" }
]

export const WireCentreDropdownValues: any = [
    { label: "", value: "" },
    { label: "RENONVPP", value: "renonvpp" },
    { label: "ORLDLFLC", value: "ordlflc" },
    { label: "BTRGLASB", value: "btrglasb" },
    { label: "ATLNGATH", value: "atlngath" },
    { label: "BTRGLAS", value: "btrglas" },
    { label: "COBGAA", value: "cobgaa" },
    { label: "COBEPAK", value: "cobepak" },
    { label: "DKABGABA", value: "dkabgaba" },
    { label: "FUltGAA", value: "fultgaa" },
    { label: "ATLNGASS", value: "atlngass" },
    { label: "BRWCLA11", value: "brwcla11" },
    { label: "AUSTTXCR", value: "austtxcr" },
    { label: "CCBHFLMA", value: "ccbhflma" },
    { label: "FKLNPARK", value: "fklnpark" },
    { label: "FULTHOGA", value: "fulthoga" }
]

export const RadioOptionsValues: any = [
    { title: "Mannual Assignment", value: "mannualAssignment", selected: true },
    { title: "PortPool L3 IOM1", value: "portpoolL3Iom1" },
    // { title: "NTI ChangeL3toL2", value: "ntiChangeL3toL2" },
    // { title: "PortPool L2", value: "portpoolL2" },
    { title: "PortPool L3 IOM3", value: "portpoolL3Iom3" },
    // { title: "NTI ChangeL2toL3", value: "ntiChangeL2toL3" },
]

export const RadioOptionsValues2: any = [
    { title: "wll Data", value: "wllData", selected: true },
    { title: "wll Voice", value: "wllVoice" },
]

export const RadioOptionsValues3: any = [
    { title: "confirm HLR", value: "confirmHlr", selected: true },
    { title: "Inq Msg Cap", value: "inqMsgCap" },
    { title: "Inq Ota", value: "inqOta" },
    { title: "Inq Subs Det", value: "inqSubsDet" },
]