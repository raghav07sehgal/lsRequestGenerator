export const pgsDropdown: any = [
    { label: "73RMD (ARAM-D)", value: "73RMD" },
    { label: "73XMC (VSEM-C)", value: "73XMC" },
    { label: "73XMD (VSEM-D)", value: "73XMD" }
]

export const ltsDropdown: any = [
    { label: "DZV8 (EVLT-F, 17Mhz=N, Vector=N)", value: "DZV8" },
    { label: "DZJK (EVLT-K, 17Mhz=N, Vector=N)", value: "DZJK" },
    { label: "DZ7K (EVLT-K, 17Mhz=Y, Vector=N)", value: "DZ7K" },
    { label: "DZJV (EVLT-N, 17Mhz=N, Vector=N)", value: "DZJV" },
    { label: "DZ7N (EVLT-N, 17Mhz=Y, Vector=N)", value: "DZ7N" },
    { label: "DZUC (EVLT-N, 17Mhz=N, Vector=Y)", value: "DZUC" },
    { label: "DZUB (EVLT-N, 17Mhz=Y, Vector=Y)", value: "DZUB" },
    { label: "DZJK (VSEM-C, 17Mhz=N, Vector=N)", value: "DZJK" },
    { label: "DZ7K (VSEM-C, 17Mhz=Y, Vector=N)", value: "DZ7K" },
    { label: "DZJV (VSEM-D, 17Mhz=N, Vector=N)", value: "DZJV" },
    { label: "DZ7N (VSEM-D, 17Mhz=Y, Vector=N)", value: "DZ7N" },
    { label: "DZ7C (VSEM-D, 17Mhz=Y, Vector=Y)", value: "DZ7C" },
    { label: "DZCN (VSEM-D, 17Mhz=N, Vector=Y)", value: "DZCN" },
    { label: "DZEQ (EBLT-Q IPDSLAM)", value: "DZEQ" }
]

export const fttnActionDropdown: any = [
    { label: "L1 Assignment", value: "L1 Assignment" },
    { label: "Port Change", value: "Port Change" }
]

export const IPCOBPTypeDropdown: any = [
    { label: "Dry Loop", value: "Dry Loop" },
    { label: "Lineshare POTS Primary", value: "Lineshare1" },
    { label: "Lineshare POTS Both", value: "Lineshare2" },
    { label: "Regular", value: "Regular" }
]

export const regionDropdown: any = [
    { label: "Midwest", value: "Midwest" },
    { label: "Southeast", value: "Southeast" },
    { label: "Southwest", value: "Southwest" },
    { label: "West", value: "West" },
]