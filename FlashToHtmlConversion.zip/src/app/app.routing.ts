import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';

const APP_ROUTES: Routes = [
    { path: '', component: AppComponent }
];

export const AppRoutingModule: any = RouterModule.forRoot(APP_ROUTES);