export interface Header {
    banValue: string,
    enviornment: string,
    nti: string,
    wireCenter: string,
    model: string,
    poolVal: string,
    circuitId: string,
    wllFtRadioSelect: string
}