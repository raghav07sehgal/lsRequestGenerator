import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AseolsMessageModule } from 'app/modules/aseols-message/aseols-message.module';
import { AssignmentAlcatelModule } from 'app/modules/AssignmentAlcatel/AssignmentAlcatel.module';
import { AssignmentEricsonModule } from 'app/modules/AssignmentEricson/AssignmentEricson.module';
import { CinModule } from 'app/modules/Cin/Cin.module';
import { FntModule } from 'app/modules/fnt/fnt.module';
import { MpcAlcatelModule } from 'app/modules/MpcAlcatel/MpcAlcatel.module';
import { MpcEricsonModule } from 'app/modules/MpcEricson/MpcEricson.module';
import { MpsModule } from 'app/modules/Mps/Mps.module';
import { OmsMessageModule } from 'app/modules/oms-message/oms-message.module';
import { StarModule } from 'app/modules/star/star.module';
import { WllFtModule } from 'app/modules/wll-ft/wll-ft.module';
import { WllModule } from 'app/modules/wll/wll.module';
import { HeaderComponent } from './header.component';

const routes: Routes = [
  {
    path: '', component: HeaderComponent,
    children: [
      { path: 'oms', loadChildren: () => OmsMessageModule },
      { path: 'fnt', loadChildren: () => FntModule },
      { path: 'assignEricson', loadChildren: () => AssignmentEricsonModule },
      { path: 'assignAlcatel', loadChildren: () => AssignmentAlcatelModule },
      { path: 'mpcAlcatel', loadChildren: () => MpcAlcatelModule },
      { path: 'mpcEricson', loadChildren: () => MpcEricsonModule },
      { path: 'mps', loadChildren: () => MpsModule },
      { path: 'star', loadChildren: () => StarModule },
      { path: 'aseolsMessages', loadChildren: () => AseolsMessageModule },
      { path: 'cin', loadChildren: () => CinModule },
      { path: 'wllft', loadChildren: () => WllFtModule },
      { path: 'wll', loadChildren: () => WllModule },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HeaderRoutingModule { }