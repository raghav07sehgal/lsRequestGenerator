import { Action } from '@ngrx/store';
import { Header } from './header.model'

export const ADD_HEADER_VALUE = 'ADD_HEADER_VALUE';
export const ADD_WLL_FT_VALUE = 'ADD_WLL_FT_VALUE';
export const ADD_OMS_VALUE = 'ADD_OMS_VALUE';

export function addHeaderReducer(state: Header[] = [], action) {
    switch (action.type) {
        case ADD_HEADER_VALUE:
            return [...state, action.payload];
        case ADD_WLL_FT_VALUE:
            return [...state, action.payload];
        case ADD_OMS_VALUE:
            return [...state, action.payload];
        default:
            return state;
    }
}