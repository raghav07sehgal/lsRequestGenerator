import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { tabSelection } from 'app/constants/tab.constant';
import {
  EnvDropdownValues,
  NtiDropdownValues,
  RadioOptionsValues,
  ModelDropdownValues,
  WireCentreDropdownValues
} from '../../constants/header.constant'
import { Store } from '@ngrx/store';
import { Header } from './header.model';
import { HeaderState } from './header.state'
import { Observable } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  dropdownValues1: any[] = EnvDropdownValues;
  dropdownValues2: any[] = NtiDropdownValues;
  dropdownValues3: any[] = ModelDropdownValues;
  dropdownValues4: any[] = WireCentreDropdownValues;
  tabs: any[] = tabSelection;
  dropdownTitle1: string = "ENV";
  dropdownTitle2: string = "NTI";
  dropdownTitle3: string = "Model";
  dropdownTitle4: string = "Wire Centre"
  dropdownType: string = "datalist"
  selectedEnv: any;
  selectedNti: any;
  selectedModel: any;
  selectedWireCentre: any;
  selectValue: any;

  radioValues: any[] = RadioOptionsValues;
  banValue: string = '';
  circuitId: string = 'A6/MCXX/<ban>//SB';
  textTitle1: string = "BAN";
  textTitle2: string = "CircuitId";

  circuitIdSuffix: string;
  portPoolNTI: String = "";
  selectedPool: any;
  circuitArr: any[] = this.circuitId.split(/\//);
  selectedNtiVal: any;
  nadModels: any[];
  @ViewChild("myDomeElem", { static: true }) myDomeElem: ElementRef;

  headerData: Observable<Header[]>;

  constructor(private router: Router,
    private store: Store<HeaderState>) {
    this.headerData = this.store.select(state => state.header);
  }

  ngOnInit() {
    this.router.navigateByUrl('/oms');
  }

  ngAfterViewInit() {
    this.selectedEnv = this.dropdownValues1[0].label;
    this.selectedNti = this.dropdownValues2[0].label;
    this.selectedNtiVal = this.dropdownValues2[0].value;
    this.selectedModel = this.dropdownValues3[0].value;

    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        enviornment: this.selectedEnv,
        nti: this.selectedNti,
        model: this.selectedModel,
        circuitId: this.circuitId,
        wireCenter: this.selectedWireCentre
      }
    });
  }

  selectedTab(id, tabSelection): any {
    //call your service which makes http call to get content for your selected tab
    let indexNo = id.nextId.replace(/[^0-9]/g, '');
    if (tabSelection[indexNo].label === "omsMessage") {
      this.router.navigateByUrl('/oms');
    } else if (tabSelection[indexNo].label === "fnt") {
      this.router.navigateByUrl('/fnt');
    } else if (tabSelection[indexNo].label === "l1-upc-ericson") {
      this.router.navigateByUrl('/assignEricson');
    } else if (tabSelection[indexNo].label === "l1-upc-alcatel") {
      this.router.navigateByUrl('/assignAlcatel');
    } else if (tabSelection[indexNo].label === "mpc-alcatel") {
      this.router.navigateByUrl('/mpcAlcatel');
    } else if (tabSelection[indexNo].label === "mpc-ericson") {
      this.router.navigateByUrl('/mpcEricson');
    } else if (tabSelection[indexNo].label === "mps") {
      this.router.navigateByUrl('/mps');
    } else if (tabSelection[indexNo].label === "cin") {
      this.router.navigateByUrl('/cin');
    } else if (tabSelection[indexNo].label === "aseolsMessages") {
      this.router.navigateByUrl('/aseolsMessages');
    } else if (tabSelection[indexNo].label === "star") {
      this.router.navigateByUrl('/star');
    } else if (tabSelection[indexNo].label === "wllft") {
      this.router.navigateByUrl('/wllft');
    } else {
      this.router.navigateByUrl('/wll');
    }
  }

  changedCircuitValue(val) {
    this.circuitId = val;
  }

  changedBanValue(val) {
    this.banValue = val;
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        banValue: this.banValue
      }
    });

    this.updateCircuitId();
  }

  envChange(value) {
    this.selectedEnv = value;
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        enviornment: this.selectedEnv
      }
    });
  }

  ntiChange(value) {
    this.selectedNti = value;
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        nti: this.selectedNti
      }
    });
    this.usePortPool();
    this.getNADModel();
  }

  modelChange(value) {
    this.selectedModel = value;
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        model: this.selectedModel
      }
    });
  }

  wireCenterChange(value) {
    this.selectedWireCentre = value;
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        wireCenter: this.selectedWireCentre
      }
    });
  }

  radioValueChange(value) {
    this.selectedPool = value;
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        poolVal: this.selectedPool
      }
    });
    this.usePortPool();
  }

  usePortPool() {
    this.setCircuitIdSuffix();
    this.setNtiToPortPool();
  }

  //Set Circuit Id Suffix
  setCircuitIdSuffix() {
    if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model1")) {
      this.circuitIdSuffix = "SB1";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model2")) {
      this.circuitIdSuffix = "SB2";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model3")) {
      this.circuitIdSuffix = "SB3";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model4")) {
      this.circuitIdSuffix = "SB4";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model5")) {
      this.circuitIdSuffix = "SB5";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model6")) {
      this.circuitIdSuffix = "SB6";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model7")) {
      this.circuitIdSuffix = "SB7";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model8")) {
      this.circuitIdSuffix = "SB8";
    } else if ((this.selectedNti == "FTTP-GPON") && (this.selectedModel == "Model9")) {
      this.circuitIdSuffix = "SB9";
    } else {
      this.circuitIdSuffix = "SB";
    }
  }

  //Set NTI to sent to PortPool
  setNtiToPortPool() {
    if ((this.selectedNti == "FTTN (CO)") || (this.selectedNti == "FTTN-BP (CO)")) {
      this.portPoolNTI = "IP-CO";
    } else if (this.selectedNti == "RGPON") {
      this.portPoolNTI = "FTTC-RGPON";
    } else {
      this.portPoolNTI = this.selectedNti;
    }

    if (this.selectedPool == "portpoolL2") {
      if ((this.selectedNti == "FTTN (CO)") || (this.selectedNti == "FTTN-BP (CO)")) {
        this.circuitId = "CO/FTTN/" + this.circuitArr[2] + "//" + this.circuitIdSuffix;
      } else if (this.selectedNti == "RGPON") {
        this.circuitId = "ST/POOL/" + this.circuitArr[2] + "//SB";
      } else {
        this.circuitId = "ST/POOL/" + this.circuitArr[2] + "//" + this.circuitIdSuffix;
      }
      this.selectedWireCentre = this.dropdownValues4[1].label;
      //get wire center from port pool table
      this.getWireCenter(this.portPoolNTI);
    } else if (this.selectedPool == "portpoolL3Iom1") {
      this.circuitId = "L3/IOM1/" + this.circuitArr[2] + "//" + this.circuitIdSuffix;
      this.selectedWireCentre = this.dropdownValues4[1].label;
      //get wire center from port pool table
      this.getWireCenter(this.portPoolNTI);
    } else if (this.selectedPool == "portpoolL3Iom3") {
      this.circuitId = "L3/IOM3/" + this.circuitArr[2] + "//" + this.circuitIdSuffix;
      this.selectedWireCentre = this.dropdownValues4[1].label;
      //get wire center from port pool table
      this.getWireCenter(this.portPoolNTI);
    } else if (this.selectedPool == "ntiChangeL3toL2") {
      this.circuitId = "L3/NTIC/" + this.circuitArr[2] + "//" + this.circuitIdSuffix;
      this.getWireCenter(this.portPoolNTI);
      this.selectedWireCentre = this.dropdownValues4[1].label;
    } else if (this.selectedPool == "ntiChangeL2toL3") {
      this.circuitId = "L2/NTIC/" + this.circuitArr[2] + "//" + this.circuitIdSuffix;
      this.getWireCenter(this.portPoolNTI);
      this.selectedWireCentre = this.dropdownValues4[1].label;
    } else {
      this.circuitId = "A6/MCXX/" + this.circuitArr[2] + "//" + this.circuitIdSuffix;
      this.selectedWireCentre = this.dropdownValues4[0].label;

    }
    this.updateCircuitId();
  }

  getWireCenter(portPoolNTI: String): void {
    console.log("portPoolNTI", portPoolNTI);
    let webserviceRequestXml;
    // requesting port pool wirecenter from websim.
    webserviceRequestXml = `<req: wireCenterRetrievalRequest xmlns: req = 'http://att.com/websim/dynamicnumbergenerator/request' >`;
    webserviceRequestXml += `<req: environment> ${this.selectedEnv}< /req:environment>`;
    webserviceRequestXml += `< req: nti > ${portPoolNTI}< /req:nti>`;
    webserviceRequestXml += `< /req:wireCenterRetrievalRequest>`;
    this.selectValue = this.dropdownValues4[1].label;
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        wireCenter: this.selectValue
      }
    });
    // writeLog("requesting port pool wirecenter from websim.");
    // var webserviceRequest: XML = <req: wireCenterRetrievalRequest xmlns: req="http://att.com/websim/dynamicnumbergenerator/request" >
    //   <req: environment> { env.text } < /req:environment>
    //     < req: nti > { portPoolNTI } < /req:nti>
    //       < /req:wireCenterRetrievalRequest>

    // getWC.wireCenterRetrieval.send(webserviceRequest);
  }

  updateCircuitId(): void {
    let circuitArray = this.circuitId.split(/\//);
    this.circuitId = circuitArray[0] + "/" + circuitArray[1] + "/" + this.banValue + "/" + circuitArray[3] + "/" + circuitArray[4];
    this.store.dispatch({
      type: 'ADD_HEADER_VALUE',
      payload: <Header>{
        circuitId: this.circuitId,
      }
    });
  }

  updateAccountId(): void {
    // accountIdAs.text = this.banValue;
    // accountIDAs.text = this.banValue;
    // //ilt_CustInfo_AcctId.text = this.banValue;
    // AddressIDAs.text = this.banValue;
  }

  // getWireCenterResult(event: ResultEvent): void {
  //   writeLog("wirecenter response from websim: " + event.result);
  //   try {
  //     var X: XML = new XML(event.result);
  //     WireCenter.text = X.*:: wireCenter[0];

  //     if (WireCenter.text.length == 0) {
  //       rPopup.setResult("No Port Pool resources found for selected Environment and NTI combination");
  //       rPopup.open(this, false);
  //     }
  //   }
  //   catch (error: Error) {
  //     rPopup.setResult("No Port Pool resources found for selected Environment and NTI combination");
  //     rPopup.open(this, false);
  //   }
  // }

  wiringComp() {
    var wiringAction: String;
    var wiring_component: String;

    wiring_component = "<bbnmsOrder:component>\n"
      + "<bbnmsOrder:assignedProductId>" + this.banValue.slice(0, 8) + "96</bbnmsOrder:assignedProductId>\n"
      + "<bbnmsOrder:serviceType>WIRING</bbnmsOrder:serviceType>\n"
      + wiringAction
      + "<bbnmsOrder:attributeList>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>APID</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + this.banValue.slice(0, 8) + "96</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>versionID</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>1</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>relationID</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>12345678</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>isSendToTeLS</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>None</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>offerSalesMode</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Lead</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>Parent Product Type</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>C1</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "</bbnmsOrder:attributeList>\n"
      + "</bbnmsOrder:component>";

    return wiring_component;

  }

  getNADModel() {
    if (this.selectedNtiVal == 'FTTN') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNtiVal == 'FTTN-BP') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNtiVal == 'FTTPIP') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNtiVal == 'RGPON') {
      this.nadModels = [{ label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else if (this.selectedNtiVal == 'FTTP-GPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNtiVal == 'FTTC-GPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNtiVal == 'FTTC-EGPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else if (this.selectedNtiVal == 'FTTP-EGPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    }
    //updating speeds for ipdslam
    else if ((this.selectedNtiVal == 'IP-CO') || (this.selectedNtiVal == 'IP-RT')) {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3700HGV-B (RG)", data1: "3700HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" }, { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" },
      { label: "5111NV (IG IPDSLAM)", data1: "5111NV-030", data2: "IG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    }
    //updating speeds for ipdslam bp
    else if ((this.selectedNtiVal == 'IP-CO-BP') || (this.selectedNtiVal == 'IP-RT-BP')) {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if ((this.selectedNtiVal == "FTTB-C") || (this.selectedNtiVal == "FTTB-F")) {
      this.nadModels = [{ label: "NVG595 (FBG)", data1: "NVG595", data2: "FBG", data3: "ARRIS" }];
    } else if (this.selectedNtiVal == "FTTP-RGPON") {
      this.nadModels = [{ label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" },
      { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3700HGV-B (RG)", data1: "3700HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" },
      { label: "5111NV (IG IPDSLAM)", data1: "5111NV-030", data2: "IG", data3: "2Wire" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" },
      { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "NVG595 (FBG)", data1: "NVG595", data2: "FBG", data3: "ARRIS" },
      { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    }
  }

}
