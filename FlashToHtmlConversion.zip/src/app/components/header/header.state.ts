import { Header } from './header.model';

export interface HeaderState {
    readonly header: Header[];
}