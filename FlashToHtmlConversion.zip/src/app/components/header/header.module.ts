import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';

import { HeaderRoutingModule } from './header-routing.module';
import { HeaderComponent } from './header.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { HeaderService } from './header.service';
import { StoreModule } from '@ngrx/store';
import { addHeaderReducer } from './header.reducer';

@NgModule({
  declarations: [
    HeaderComponent,
  ],
  imports: [
    CommonModule,
    HeaderRoutingModule,
    FormsModule,
    // NgbModule.forRoot(),
    NgbModule,
    SharedModule,
    StoreModule.forRoot({ header: addHeaderReducer })
  ],
  exports: [
    HeaderComponent,
  ],
  providers: [
    HeaderService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: []
})

export class HeaderModule { }