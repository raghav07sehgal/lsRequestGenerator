import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { OrderActionDropdown, wllv2, wllv3 } from 'app/constants/omsMessage.constant';
import { CheckboxItem } from '../checkBox-value/checkBox-value.component';
import { RadioOptionsValues3 } from 'app/constants/header.constant'
import { attdvTabSelection, dtcpTabSelection, dtvmTabSelection, dtotaTabSelection } from 'app/constants/tab.constant';
import { actionDropdownValue, techDispatchDropdownValues, installTypeDropdownValues } from 'app/constants/omsMessage.constant';
import { actionTypeTdarDropdown, BaseProgramDtvDropdown, customerLineDropdown, D2LiteEligibilityDropdown, lineItemDropdown, modeDropdown, modelNumTdarDropdown, OwnershipDropdown, partnerNameDropdown, productLineTdarDropdown, propContrTypDropdown, purchaseTermTdarDropdown, SapOrdStatDropdown, shippingIndicatorDropdown, stbTypeTdarDropdown, sWMIndicatorDropdown } from 'app/constants/star.constant';
import { shortToggleDropdown, uspIndicatorDropdown, trueFalseDropdownValue } from 'app/constants/global.constant';
import { cellRankDropdown, dataCapDropdown, dataSpeedDropdown, dvCodeDropdown, ipQuantityDropdown, ipTypeDropdown, spidDropdown, transitionTypeDropdown, wllftActionDropdown } from 'app/constants/wllFt.constant';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';

@Component({
  selector: 'app-tab-container',
  templateUrl: './tab-container.component.html',
  styleUrls: ['./tab-container.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TabContainerComponent implements OnInit {
  @Input() title: string;
  @Input() inputCss: string;
  @Input() tabSelect: string;

  dropdownTitle1: string = "Action";
  dropdownTitle2: string = "move ind";
  dropdownTitle3: string = "IPType";
  dropdownTitle4: string = "IPQuantity";
  dropdownTitle5: string = "DataSpeed";
  dropdownTitle6: string = "DataCap";
  dropdownTitle7: string = "SelfInstall";
  dropdownTitle8: string = "CellRank";
  dropdownTitle9: string = "Current SPID";
  dropdownTitle10: string = "New SPID";
  dropdownTitle11: string = "Mode";
  dropdownTitle12: string = "DVCode";
  dropdownTitle13: string = "Cell Sec-1 Rank";
  dropdownTitle14: string = "transitionType";
  dropdownTitle14a: string = "transitionType2";
  dropdownTitle14b: string = "transitionType3";
  dropdownTitle15: string = "Cell Sec-2 Rank";
  dropdownTitle16: string = "Cell Sec-3 Rank";
  dropdownTitle17: string = "AM Action";
  dropdownTitle18: string = "portOreqResVid";
  dropdownTitle19: string = "CSPID";
  dropdownTitle20: string = "PortInType";
  dropdownTitle21: string = "Removal Type";
  dropdownTitle22: string = "Block Int Calling";
  dropdownTitle23: string = "Enable Voice Mail";
  dropdownTitle24: string = "Int Calling Feature";
  dropdownTitle25: string = "Usage Plan";
  dropdownTitle26: string = "PortOutDest";
  dropdownTitle27: string = "DisplayName";
  dropdownTitle28: string = "DisplayInd";
  dropdownTitle29: string = "Error Code";
  dropdownTitle30: string = "Description";
  dropdownTitle31: string = "Status Code";
  dropdownTitle32: string = "Return Code";
  dropdownTitle33: string = "Status";
  dropdownTitle34: string = "Reason Code";
  dropdownTitle35: string = "Reason Desc";
  dropdownTitle36: string = "IMEIType";
  dropdownTitle37: string = "responseType";
  dropdownTitle38: string = "Type";
  dropdownTitle39: string = "Code";
  dropdownTitle40: string = "Error Desc";
  dropdownTitle41: string = "ServingMme";
  dropdownTitle42: string = "mnetSubId";
  dropdownTitle43: string = "skipPassword";
  dropdownTitle44: string = "scscfName";
  dropdownTitle45: string = "IMEI";
  dropdownTitle46: string = "homeMTA";
  dropdownTitle47: string = "RoamingClass";
  dropdownTitle48: string = "mindMSI";
  dropdownTitle49: string = "AutoDialAsgn";
  dropdownTitle50: string = "APNList";
  dropdownTitle51: string = "acwbd";
  dropdownTitle52: string = "AutoDialFwdDn";
  dropdownTitle53: string = "ProfileId";
  dropdownTitle54: string = "otalMSI";
  dropdownTitle55: string = "AdvConfAsgn";
  dropdownTitle56: string = "ICCID";
  dropdownTitle57: string = "callidProv";
  dropdownTitle58: string = "CalFwdDet";
  dropdownTitle59: string = "CallWaiting";
  dropdownTitle60: string = "CallBlockDet";
  dropdownTitle61: string = "Customer Line"
  dropdownTitle62: string = "Technician Dispatch Indicator"
  dropdownTitle63: string = "Shipping Indicator"
  dropdownTitle64: string = "Property Contract type"
  dropdownTitle65: string = "Adult Contract Restriction"
  dropdownTitle66: string = "Installation Type"
  dropdownTitle67: string = "Supersede"
  dropdownTitle68: string = "Ownership"
  dropdownTitle69: string = "Is Active"
  dropdownTitle70: string = "SapOrdStatus"
  dropdownTitle71: string = "ActionType"
  dropdownTitle72: string = "STB Type"
  dropdownTitle73: string = "Purchase Terms"
  dropdownTitle74: string = "Product Line"
  dropdownTitle75: string = "Old Value"
  dropdownTitle76: string = "Model Number"
  dropdownTitle77: string = "Base programming"
  dropdownTitle78: string = "HD Access Indicator"
  dropdownTitle79: string = "DTgenrePackage"
  dropdownTitle80: string = "mpeg4RegieoIndicator"
  // dropdownTitle81: string = "CountyFIPS"
  dropdownTitle82: string = "genieGen1Indicator"
  dropdownTitle83: string = "D2LiteEligibility"
  dropdownTitle84: string = "SWMIndicator"
  dropdownTitle85: string = "MRVIndicator"
  dropdownTitle86: string = "DealerRestrictedProperty"
  dropdownTitle87: string = "4kService"
  dropdownTitle88: string = "Partner Name";
  dropdownTitle89: string = "AddSrv Action"
  dropdownTitle90: string = "AddIns Action";
  dropdownTitle91: string = "Whole Home DVR";
  dropdownTitle92: string = "Relocate Receiver Count";
  dropdownTitle93: string = "Relocate Dish Count";
  dropdownTitle94: string = "OldCustLine";
  dropdownTitle95: string = "PropContrTyp"
  dropdownTitle96: string = "OldPropContTyp"
  dropdownTitle97: string = "dtvActTyp"
  dropdownTitle98: string = "OldDtvActType"
  dropdownTitle99: string = "MDUCOnnectedProperty"
  dropdownTitle100: string = "Visually Impaired"
  dropdownTitle101: string = "deviceType"

  dropdownValues1: any[] = actionDropdownValue;
  dropdownValues2: any[] = shortToggleDropdown;
  dropdownValues3: any[] = ipTypeDropdown;
  dropdownValues4: any[] = ipQuantityDropdown;
  dropdownValues5: any[] = dataSpeedDropdown;
  dropdownValues6: any[] = dataCapDropdown;
  dropdownValues7: any[] = trueFalseDropdownValue;
  dropdownValues8: any[] = cellRankDropdown;
  dropdownValues9: any[] = spidDropdown;
  dropdownValues10: any[] = spidDropdown;
  dropdownValues11: any[] = modeDropdown;
  dropdownValues12: any[] = dvCodeDropdown;
  dropdownValues13: any[] = cellRankDropdown;
  dropdownValues14: any[] = transitionTypeDropdown;
  dropdownValues14a: any[] = transitionTypeDropdown;
  dropdownValues14b: any[] = transitionTypeDropdown;
  dropdownValues15: any[] = cellRankDropdown;
  dropdownValues16: any[] = cellRankDropdown;
  dropdownValues17: any[] = OrderActionDropdown;
  dropdownValues18: any[] = OrderActionDropdown;
  dropdownValues19: any[] = OrderActionDropdown;
  dropdownValues20: any[] = OrderActionDropdown;
  dropdownValues21: any[] = OrderActionDropdown;
  dropdownValues22: any[] = OrderActionDropdown;
  dropdownValues23: any[] = OrderActionDropdown;
  dropdownValues24: any[] = OrderActionDropdown;
  dropdownValues25: any[] = OrderActionDropdown;
  dropdownValues26: any[] = OrderActionDropdown;
  dropdownValues27: any[] = OrderActionDropdown;
  dropdownValues28: any[] = OrderActionDropdown;
  dropdownValues29: any[] = OrderActionDropdown;
  dropdownValues30: any[] = OrderActionDropdown;
  dropdownValues31: any[] = OrderActionDropdown;
  dropdownValues32: any[] = OrderActionDropdown;
  dropdownValues33: any[] = OrderActionDropdown;
  dropdownValues34: any[] = OrderActionDropdown;
  dropdownValues35: any[] = OrderActionDropdown;
  dropdownValues36: any[] = OrderActionDropdown;
  dropdownValues37: any[] = OrderActionDropdown;
  dropdownValues38: any[] = OrderActionDropdown;
  dropdownValues39: any[] = OrderActionDropdown;
  dropdownValues40: any[] = OrderActionDropdown;
  dropdownValues41: any[] = OrderActionDropdown;
  dropdownValues42: any[] = OrderActionDropdown;
  dropdownValues43: any[] = OrderActionDropdown;
  dropdownValues44: any[] = OrderActionDropdown;
  dropdownValues45: any[] = OrderActionDropdown;
  dropdownValues46: any[] = OrderActionDropdown;
  dropdownValues47: any[] = OrderActionDropdown;
  dropdownValues48: any[] = OrderActionDropdown;
  dropdownValues49: any[] = OrderActionDropdown;
  dropdownValues50: any[] = OrderActionDropdown;
  dropdownValues51: any[] = OrderActionDropdown;
  dropdownValues52: any[] = OrderActionDropdown;
  dropdownValues53: any[] = OrderActionDropdown;
  dropdownValues54: any[] = OrderActionDropdown;
  dropdownValues55: any[] = OrderActionDropdown;
  dropdownValues56: any[] = OrderActionDropdown;
  dropdownValues57: any[] = OrderActionDropdown;
  dropdownValues58: any[] = OrderActionDropdown;
  dropdownValues59: any[] = OrderActionDropdown;
  dropdownValues60: any[] = OrderActionDropdown;
  dropdownValues61: any[] = customerLineDropdown;
  dropdownValues62: any[] = techDispatchDropdownValues;
  dropdownValues63: any[] = shippingIndicatorDropdown;
  dropdownValues64: any[] = OrderActionDropdown;
  dropdownValues65: any[] = shortToggleDropdown;
  dropdownValues66: any[] = installTypeDropdownValues;
  dropdownValues67: any[] = OrderActionDropdown;
  dropdownValues68: any[] = OwnershipDropdown;
  dropdownValues69: any[] = shortToggleDropdown;
  dropdownValues70: any[] = SapOrdStatDropdown;
  dropdownValues71: any[] = actionTypeTdarDropdown;
  dropdownValues72: any[] = stbTypeTdarDropdown;
  dropdownValues73: any[] = purchaseTermTdarDropdown;
  dropdownValues74: any[] = productLineTdarDropdown;
  dropdownValues75: any[] = shortToggleDropdown;
  dropdownValues76: any[] = modelNumTdarDropdown;
  dropdownValues77: any[] = BaseProgramDtvDropdown;
  dropdownValues78: any[] = shortToggleDropdown;
  dropdownValues79: any[] = OrderActionDropdown;
  dropdownValues80: any[] = shortToggleDropdown;
  // dropdownValues81: any[] = shortToggleDropdown;
  dropdownValues82: any[] = shortToggleDropdown;
  dropdownValues83: any[] = D2LiteEligibilityDropdown;
  dropdownValues84: any[] = sWMIndicatorDropdown;
  dropdownValues85: any[] = shortToggleDropdown;
  dropdownValues86: any[] = shortToggleDropdown;
  dropdownValues87: any[] = shortToggleDropdown;
  dropdownValues88: any[] = partnerNameDropdown;
  dropdownValues89: any[] = actionDropdownValue;
  dropdownValues90: any[] = actionDropdownValue;
  dropdownValues91: any[] = uspIndicatorDropdown;
  dropdownValues92: any[] = lineItemDropdown;
  dropdownValues93: any[] = lineItemDropdown;
  dropdownValues94: any[] = OrderActionDropdown;
  dropdownValues95: any[] = propContrTypDropdown;
  dropdownValues96: any[] = OrderActionDropdown;
  dropdownValues97: any[] = OrderActionDropdown;
  dropdownValues98: any[] = OrderActionDropdown;
  dropdownValues99: any[] = shortToggleDropdown;
  dropdownValues100: any[] = shortToggleDropdown;
  dropdownValues101: any[] = shortToggleDropdown;

  selectedAddSrvAction: any;
  selectedAddInsAction: any;
  SelectedWholeHomeDvr: any;
  selectedRelocateReceiverCount: any;
  selectedRelocateDishCount: any;
  selectedVisuallyImpaired: any;
  selectedProductLine: any;
  selectedCustomerLine: any;
  selectedPropertyContractType: any;
  selectedIsActive: any;
  selectedOldValue: any;
  selectedDtvActTyp: any;
  selectedOldDtvActTyp: any;
  selectedOldCustLine: any;
  selectedPropContrTyp: any;
  selectedOldPropContTyp: any;
  selectedAction: any;
  selectedPartenerName: any;
  selectedAdultContractRestriction: any;
  selectedD2LiteEligibility: any;
  selectedMDUCOnnectedProperty: any;
  selectedDealerRestrictedProperty: any;
  selectedMRVIndicator: any;
  selectedSWMIndicator: any;
  selected4kService: any;
  selectedmpeg4RegieoIndicator: any;
  selectedgenieGen1Indicator: any;
  selectedReasonCode: any;
  selectedInstallationType: any;
  selectedTechnicianDispatchIndicator: any
  selectedShippingIndicator: any;
  selectedBaseProgramming: any;
  selectedHDAccessIndicator: any;
  selectedTransitiontype1: any;
  selectedTransitiontype2: any;
  selectedTransitiontype3: any;
  selectedCellSec1Rank: any;
  selectedCellSec2Rank: any;
  selectedCellSec3Rank: any;
  selectedDVCode: any;
  selectedMode: any;
  selectedMoveInd: any;
  selectedCellRank: any;
  selectedSelfInstall: any;
  selectedDataSpeed: any;
  selectedIPQuantity: any;
  selectedIPType: any;
  selectedDataCap: any;
  selectedPortInType: any;
  selectedCurrentSPID: any;
  selectedNewSPID: any;

  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';
  textValue6: any = '';
  textValue7: any = '';
  textValue8: any = '';
  textValue9: any = '';
  textValue10: any = '';
  textValue11: any = '';
  textValue12: any = '';
  textValue13: any = '';
  textValue14: any = '';
  textValue15: any = '';
  textValue16: any = '';
  textValue17: any = '';
  textValue18: any = '';
  textValue19: any = '';
  textValue20: any = '';
  textValue21: any = '';
  textValue22: any = '';
  textValue23: any = '';
  textValue24: any = '';
  textValue25: any = '';
  textValue26: any = '';
  textValue27: any = '';
  textValue28: any = '';
  textValue29: string = "NA";
  textValue30: any = '';
  textValue31: any = '';
  textValue32: any = '';
  textValue33: any = '';
  textValue34: any = '';
  textValue35: any = '';
  textValue36: any = '';
  textValue37: any = '';
  textValue38: any = '';
  textValue39: any = '';
  textValue40: any = '130';
  textValue22a: any = '';
  imsiCodeText: any = "";
  getMsgIdText: any = "";

  textTitle1: any = 'WSIM TN';
  textTitle2: any = 'Device Id';
  textTitle3: any = 'PrimaryCellSIte';
  textTitle4: any = 'Caller Id Name';
  textTitle5: any = 'IMEI';
  textTitle6: any = 'BAN';
  textTitle7: any = 'SIMICCID';
  textTitle8: any = 'CellSector id 1';
  textTitle9: any = 'CellSector id 2';
  textTitle10: any = 'CellSector id 3';
  textTitle11: any = 'TN';
  textTitle12: any = 'WLL SIM TN Number';
  textTitle13: any = 'Old WSIM TN';
  textTitle14: any = 'Old TN';
  textTitle15: any = 'Latitude';
  textTitle16: any = 'Longitude';
  textTitle17: any = 'PortIn TN';
  textTitle18: any = 'WLL Voice TN Number';
  textTitle19: any = 'Old WLL TN';
  textTitle20: any = 'Subscriber TN';
  textTitle21: any = 'SIM';
  textTitle22: any = 'IMSI';
  textTitle23: any = 'SIM ICCID';
  textTitle24: any = 'CellId';
  textTitle25: any = 'requestVersionId';
  textTitle26: any = 'PortOut TN';
  textTitle27: any = 'requestNumber';
  textTitle28: any = 'NPANXX';
  textTitle29: string = "Contract Id";
  textTitle30: string = "serial number";
  textTitle31: string = "access card Id";
  textTitle32: string = "apid";
  textTitle33: string = "mac address";
  textTitle34: string = "receiver id";
  textTitle35: string = "Partner Id";
  textTitle36: string = "dealerCode"
  textTitle37: string = "OldDealerCode"
  textTitle38: string = "dealerAcType"
  textTitle39: string = "OldDealerAcType"
  textTitle40: string = "CountyFIPS"

  tabType: string = "star";
  dtvmTabs: any[] = dtvmTabSelection;
  dtcpTabs: any[] = dtcpTabSelection;
  attdvTabs: any[] = attdvTabSelection;
  dtotaTabs: any[] = dtotaTabSelection;

  myDate: any;
  radioValues: any[] = RadioOptionsValues3;
  isInclude: boolean = false;

  inputCls1: string = "h5";
  inputCls2: string = "h2";
  inputCls3: string = "h6";
  checkBoxClass: string = "d-inline-flex";
  checkBox1: any;

  public checkBoxModel = {
    id: 0,
    name: "",
    roles: []
  };

  checkOption1 = new Array<any>();
  checkOption2 = new Array<any>();

  constructor(private store: Store<HeaderState>) {
    this.checkOption1 = wllv2.map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption2 = wllv3.map(x => new CheckboxItem(x.id, x.name, false));
  }

  ngOnInit(): void {
    this.store.select(state => state['header']).subscribe((data) => {
      let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
      if (storeObj['banValue']?.length) {
        this.textValue32 = storeObj['banValue'];
      }
    })
    
    this.dropdownValues65.reverse();
    if (this.tabSelect == "starTdarFnt") {
      this.dtvmTabs = dtvmTabSelection.filter(val => val.label != "dtacrd" && val.label != "dtota")
    } else if (this.tabSelect == "wllft") {
      this.dropdownValues1 = wllftActionDropdown
    }

  }

  onCheckChange(e) {
    console.log("event", e);

    this.isInclude = e.target.checked;
  }

  selectedTab(id, tabSelection): any { }

  dropdownChange(val, title) {
    if (title == "AddIns Action") {
      this.selectedAddInsAction = val;
    } else if (title == "Whole Home DVR") {
      this.SelectedWholeHomeDvr = val;
    } else if (title == "Relocate Receiver Count") {
      this.selectedRelocateReceiverCount = val;
    } else if (title == "AddSrv Action") {
      this.selectedAddSrvAction = val;
    } else if (title == "Relocate Dish Count") {
      this.selectedRelocateDishCount = val;
    } else if (title == "Visually Impaired") {
      this.selectedVisuallyImpaired = val;
    } else if (title == "Product Line") {
      this.selectedProductLine = val;
    } else if (title == "Customer Line") {
      this.selectedCustomerLine = val;
    } else if (title == "Property Contract Type") {
      this.selectedPropertyContractType = val;
    } else if (title == "Is Active") {
      this.selectedIsActive = val;
    } else if (title == "Old Value") {
      this.selectedOldValue = val;
    } else if (title == "dtvActTyp") {
      this.selectedDtvActTyp = val;
    } else if (title == "OldDtvActType") {
      this.selectedOldDtvActTyp = val;
    } else if (title == "PropContrTyp") {
      this.selectedPropContrTyp = val;
    } else if (title == "OldCustLine") {
      this.selectedOldCustLine = val;
    } else if (title == "OldPropContTyp") {
      this.selectedOldPropContTyp = val;
    } else if (title == "Action") {
      this.selectedAction = val;
    } else if (title == "Partner Name") {
      this.selectedPartenerName = val;
    } else if (title == "Adult Contract Restriction") {
      this.selectedAdultContractRestriction = val;
    } else if (title == "D2LiteEligibility") {
      this.selectedD2LiteEligibility = val;
    } else if (title == "MDUCOnnectedProperty") {
      this.selectedMDUCOnnectedProperty = val;
    } else if (title == "DealerRestrictedProperty") {
      this.selectedDealerRestrictedProperty = val;
    } else if (title == "MRVIndicator") {
      this.selectedMRVIndicator = val;
    } else if (title == "SWMIndicator") {
      this.selectedSWMIndicator = val;
    } else if (title == "4kService") {
      this.selected4kService = val;
    } else if (title == "mpeg4RegieoIndicator") {
      this.selectedmpeg4RegieoIndicator = val;
    } else if (title == "genieGen1Indicator") {
      this.selectedgenieGen1Indicator = val;
    } else if (title == "Reason Code") {
      this.selectedReasonCode = val;
    } else if (title == "Installation Type") {
      this.selectedInstallationType = val;
    } else if (title == "Technician Dispatch Indicator") {
      this.selectedTechnicianDispatchIndicator = val;
    } else if (title == "Shipping Indicator") {
      this.selectedShippingIndicator = val;
    } else if (title == "Base programming") {
      this.selectedBaseProgramming = val;
    } else if (title == "HD Access Indicator") {
      this.selectedHDAccessIndicator = val;
    } else if (title == "transitionType") {
      this.selectedTransitiontype1 = val;
    } else if (title == "transitionType2") {
      this.selectedTransitiontype2 = val;
    } else if (title == "transitionType3") {
      this.selectedTransitiontype3 = val;
    } else if (title == "Cell Sec-1 Rank") {
      this.selectedCellSec1Rank = val;
    } else if (title == "Cell Sec-2 Rank") {
      this.selectedCellSec2Rank = val;
    } else if (title == "Cell Sec-3 Rank") {
      this.selectedCellSec3Rank = val;
    } else if (title == "DVCode") {
      this.selectedDVCode = val;
    } else if (title == "Mode") {
      this.selectedMode = val;
    } else if (title == "move ind") {
      this.selectedMoveInd = val;
    } else if (title == "CellRank") {
      this.selectedCellRank = val;
    } else if (title == "SelfInstall") {
      this.selectedSelfInstall = val;
    } else if (title == "DataSpeed") {
      this.selectedDataSpeed = val;
    } else if (title == "IPQuantity") {
      this.selectedIPQuantity = val;
    } else if (title == "IPType") {
      this.selectedIPType = val;
    } else if (title == "DataCap") {
      this.selectedDataCap = val;
    } else if (title == "PortInType") {
      this.selectedPortInType = val;
    } else if (title == "Current SPID") {
      this.selectedCurrentSPID = val;
    } else if (title == "New SPID") {
      this.selectedNewSPID = val;
    }
  }

}
