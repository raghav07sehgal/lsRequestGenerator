import { formatDate } from '@angular/common';
import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { NgbActiveModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { OrderActionDropdown, SubTypeDropdown, WllOrdActionStatusDropdown, WllOrdRefDropdown } from 'app/constants/omsMessage.constant';
import { OmsMessageService } from 'app/modules/oms-message/oms-message.service';

@Component({
  selector: 'app-related-product-modal',
  templateUrl: './related-product-modal.component.html',
  styleUrls: ['./related-product-modal.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class RelatedProductModalComponent implements OnInit {

  @Input() title;
  @Input() content;

  dropdownTitle1: string = "WllOrdActType";
  dropdownTitle2: string = "WllOrdActSubType";
  dropdownTitle3: string = "WllOrdRef";
  dropdownTitle4: string = "WllOrdActionStatus";
  dropdownTitle5: string = "WllVoiceOrdActType";
  dropdownTitle6: string = "WllVoiceOrdActSubType";
  dropdownTitle7: string = "WllVoiceOrdRef";
  dropdownTitle8: string = "WllVoiceOrdActStatus";
  dropdownTitle9: string = "TdarOrdActType";
  dropdownTitle10: string = "TdarOrdActSubType";
  dropdownTitle11: string = "TdarOrdRef";
  dropdownTitle12: string = "TdarOrdActionStatus";
  dropdownTitle13: string = "UverseOrdActType";
  dropdownTitle14: string = "UverseOrdActSubType";
  dropdownTitle15: string = "UverseOrdRef";
  dropdownTitle16: string = "UverseOrdActionStatus";

  dropdownValues1: any[] = OrderActionDropdown;
  dropdownValues2: any[] = SubTypeDropdown;
  dropdownValues3: any[] = WllOrdRefDropdown;
  dropdownValues4: any[] = WllOrdActionStatusDropdown;
  dropdownValues5: any[] = OrderActionDropdown;
  dropdownValues6: any[] = SubTypeDropdown;
  dropdownValues7: any[] = WllOrdRefDropdown;
  dropdownValues8: any[] = WllOrdActionStatusDropdown;
  dropdownValues9: any[] = OrderActionDropdown;
  dropdownValues10: any[] = SubTypeDropdown;
  dropdownValues11: any[] = WllOrdRefDropdown;
  dropdownValues12: any[] = WllOrdActionStatusDropdown;
  dropdownValues13: any[] = OrderActionDropdown;
  dropdownValues14: any[] = SubTypeDropdown;
  dropdownValues15: any[] = WllOrdRefDropdown;
  dropdownValues16: any[] = WllOrdActionStatusDropdown;

  textTitle1: string = "WllOrdNumber *";
  textTitle2: string = "WllOrigOrdNum";
  textTitle3: string = "WllWorkOrdId";
  textTitle4: string = "WllPrevWorkOrdId";
  textTitle5: string = "WllVoicOrderNumber *";
  textTitle6: string = "WllVoiceOrigOrderNum";
  textTitle7: string = "WllVoiceWorkOrdId";
  textTitle8: string = "WllVoicePrevWorkOrdId";
  textTitle9: string = "TdarOrderNumber *";
  textTitle10: string = "TdarOrigOrderNum";
  textTitle11: string = "TdarWorkOrdId";
  textTitle12: string = "TdarPrevWorkOrdId";
  textTitle13: string = "UverseOrderNumber *";
  textTitle14: string = "UverseOrigOrderNum";
  textTitle15: string = "UverseWorkOrdId";
  textTitle16: string = "UversePrevWorkOrdId";

  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';
  textValue6: any = '';
  textValue7: any = '';
  textValue8: any = '';
  textValue9: any = '';
  textValue10: any = '';
  textValue11: any = '';
  textValue12: any = '';
  textValue13: any = '';
  textValue14: any = '';
  textValue15: any = '';
  textValue16: any = '';

  dropdownDisable1: boolean = true;

  myDate: any;
  wlldueDate: NgbDateStruct;
  WllVoicedueDate: NgbDateStruct;
  TdardueDate: NgbDateStruct;
  UversedueDate: NgbDateStruct;

  constructor(public activeModal: NgbActiveModal,
    public omsService: OmsMessageService,
    private store: Store<HeaderState>) {
    // this.myDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
  }

  ngOnInit(): void {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        let selectedEnv = storeObj['enviornment'];
      })
  }

  send() {
    this.omsService.sendOrderXml(this.content)
      .subscribe(val => {
        console.log("val", val);
      })
  }

}
