import { Component, Input, OnInit } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { OrderActionDropdown, OrderActionReasonCodeDropdown, SubTypeDropdown } from 'app/constants/omsMessage.constant';
import { alphabetDropdown, shortToggleDropdown, shortToggleDropdown2 } from 'app/constants/global.constant';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { title } from 'process';

@Component({
  selector: 'order-info',
  templateUrl: './order-info.component.html',
  styleUrls: ['./order-info.component.css']
})
export class OrderInfoComponent implements OnInit {
  @Input() headingTitle: string;
  @Input() tabType: string;
  @Input() tabHeight: string;
  @Input() scrollHeight: string;
  @Input() cond: string;
  @Input() disableContainer: any;

  orderInfoForm: FormGroup;

  myDate1: any;
  myDate2: any;
  myDate3: any;
  myDate4: any;
  myDate5: any;
  myDate6: any;

  model: NgbDateStruct;
  model1: NgbDateStruct;
  model2: NgbDateStruct;
  model3: NgbDateStruct;
  model4: NgbDateStruct;
  model5: NgbDateStruct;
  model6: NgbDateStruct;
  model7: NgbDateStruct;
  model8: NgbDateStruct;

  textTitle1: string = "Orig Ord Id";
  textTitle2: string = "Order Id";
  textTitle3: string = "Order Number";
  textTitle4: string = "OriginalOrderActionId";
  textTitle5: string = "Work Order Id";
  textTitle6: string = "Prev Work Order Id";
  textTitle7: string = "ExactOrderNumber";
  textTitle8: string = "ProjectOrderNumber";
  textTitle9: string = "Account Id(customer ban)";
  textTitle10: string = "Project OrderNumber Suffix";
  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';
  textValue6: any = '';
  textValue7: any = '';
  textValue8: any = '';
  textValue9: any = '';
  textValue10: any = '';

  dropdownTitle1: string = "Ord Sub Type";
  dropdownTitle2: string = "Ord Ref";
  dropdownTitle3: string = "OrderActionType";
  dropdownTitle4: string = "OrderActionSubType";
  dropdownTitle5: string = "Reference";
  dropdownTitle6: string = "OrderActionRef"
  dropdownTitle7: string = "NFFLIndicator"
  dropdownTitle8: string = "Order Action"
  dropdownTitle9: string = "Creation Application"
  dropdownTitle10: string = "SubType";
  dropdownValues1: any[] = SubTypeDropdown;
  dropdownValues2: any[] = OrderActionDropdown;
  dropdownValues3: any[] = OrderActionDropdown;
  dropdownValues4: any[] = SubTypeDropdown;
  dropdownValues5: any[] = OrderActionDropdown;
  dropdownValues6: any[] = alphabetDropdown;
  dropdownValues7: any[] = shortToggleDropdown2;
  dropdownValues8: any[] = OrderActionDropdown;
  dropdownValues9: any[] = OrderActionDropdown;
  dropdownValues10: any[] = OrderActionDropdown;
  dropdownValues11: any[] = OrderActionDropdown;

  selectedOrdSubType: any;
  selectedOrdRef: any;
  selectedOrderActionType: any;
  selectedOrderActionSubType: any;
  selectedReference: any;
  selectedOrderActionRef: any;
  selectedNFFLIndicator: any;
  selectedOrderAction: any;
  selectedCreationApplication: any;
  selectedSubType: any;

  constructor(private fb: FormBuilder, private store: Store<HeaderState>) {

  }

  ngOnInit(): void {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        let wllFtRadioSelect = storeObj['wllFtRadioSelect'];

        if (this.headingTitle == "Voice order Info" && wllFtRadioSelect == "wllVoice") {
          this.disableContainer = true;
        } else if (this.headingTitle == "Data Order Info" && wllFtRadioSelect == "wllData") {
          this.disableContainer = true;
        } else {
          this.disableContainer = false;
        }
      })

  }

  dropDownChange(evt, title) {
    if (title == "Ord Sub Type") {
      this.selectedOrdSubType = evt;
    } else if (title == "Ord Ref") {
      this.selectedOrdRef = evt;
    } else if (title == "OrderActionType") {
      this.selectedOrderActionType = evt;
    } else if (title == "OrderActionSubType") {
      this.selectedOrderActionSubType = evt;
    } else if (title == "Reference") {
      this.selectedReference = evt;
    } else if (title == "OrderActionRef") {
      this.selectedOrderActionRef = evt;
    } else if (title == "NFFLIndicator") {
      this.selectedNFFLIndicator = evt;
    } else if (title == "Order Action") {
      this.selectedOrderAction = evt;
    } else if (title == "Creation Application") {
      this.selectedCreationApplication = evt;
    } else if (title == "SubType") {
      this.selectedSubType = evt;
    }
  }

}