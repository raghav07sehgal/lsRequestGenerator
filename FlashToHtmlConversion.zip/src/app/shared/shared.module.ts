import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DropdownValueComponent } from './dropdown-value/dropdown-value.component';
import { RadioButtonComponent } from './radio-button/radio-button.component';
import { TextBoxValueComponent } from './text-box-value/text-box-value.component';
import { CheckBoxValueComponent } from './checkBox-value/checkBox-value.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ServiceFspComponent } from './serviceFsp/serviceFsp.component';
import { OrderInfoComponent } from './order-info/order-info.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CmPvComponent } from './cm-pv/cm-pv.component';
import { TabContainerComponent } from './tab-container/tab-container.component';
import { AlcatelEricsonComponent } from './alcatelEricson/alcatelEricson.component';
import { LineItemComponent } from './line-item/line-item.component';
import { CustomerInfoComponent } from './customerInfo/customerInfo.component';
import { SubContainerComponent } from './subComponent/subContainer.component';
import { CmPvOrderComponent } from './cm-pvOrder/cm-pv-Order.component';
import { SubModuleComponent } from './sub-module/sub-module.component';
import { ModelBoxComponent } from './model-box/model-box.component';
import { OmsMessageService } from 'app/modules/oms-message/oms-message.service';
import { RelatedProductModalComponent } from './related-product-modal/related-product-modal.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        NgbModule,
        ReactiveFormsModule
    ],
    declarations: [
        DropdownValueComponent,
        RadioButtonComponent,
        TextBoxValueComponent,
        CheckBoxValueComponent,
        ServiceFspComponent,
        OrderInfoComponent,
        CmPvComponent,
        TabContainerComponent,
        AlcatelEricsonComponent,
        LineItemComponent,
        CustomerInfoComponent,
        SubContainerComponent,
        CmPvOrderComponent,
        SubModuleComponent,
        ModelBoxComponent,
        RelatedProductModalComponent,
    ],
    exports: [
        DropdownValueComponent,
        RadioButtonComponent,
        TextBoxValueComponent,
        CheckBoxValueComponent,
        ServiceFspComponent,
        OrderInfoComponent,
        CmPvComponent,
        TabContainerComponent,
        AlcatelEricsonComponent,
        LineItemComponent,
        CustomerInfoComponent,
        SubContainerComponent,
        CmPvOrderComponent,
        SubModuleComponent,
        ModelBoxComponent,
    ],
    providers: [
        OmsMessageService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class SharedModule { }