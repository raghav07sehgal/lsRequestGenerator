import { formatDate } from '@angular/common';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ntiPv } from 'app/constants/fnt.constant';
import { VhoDropdownValues } from 'app/constants/omsMessage.constant';
import { CheckboxItem } from 'app/shared/checkBox-value/checkBox-value.component';

@Component({
  selector: 'cmpv-order',
  templateUrl: './cm-pv-Order.component.html',
  styleUrls: ['./cm-pv-Order.component.css']
})
export class CmPvOrderComponent implements OnInit {
  @Input() orderType: string;

  title: string = "NAD Component";
  iadTitle: string = "IAD Device";
  tabType: string = "fnt";

  textTitle1: string = "Order Number";
  textTitle2: string = "CircuitId";
  textValue1: any = '';
  textValue2: any = '';

  dropdownTitle1: string = "UVOrderActionType";
  dropdownTitle2: string = "SubType";
  dropdownTitle3: string = "Install Type";
  dropdownTitle4: string = "Reference";
  dropdownTitle5: string = "Tech Dispatch";
  dropdownTitle6: string = "NTI";
  dropdownTitle7: string = "17MHzFeature";
  dropdownTitle8: string = "vectoringFeature";
  dropdownTitle9: string = "Total Bandwidth";
  dropdownTitle10: string = "Loop Indication";
  dropdownTitle11: string = "ABF Ind";
  dropdownValues1: any[] = VhoDropdownValues;
  dropdownValues2: any[] = VhoDropdownValues;
  dropdownValues3: any[] = VhoDropdownValues;
  dropdownValues4: any[] = VhoDropdownValues;
  dropdownValues5: any[] = VhoDropdownValues;
  dropdownValues6: any[] = ntiPv;
  dropdownValues7: any[] = VhoDropdownValues;
  dropdownValues8: any[] = VhoDropdownValues;
  dropdownValues9: any[] = VhoDropdownValues;
  dropdownValues10: any[] = VhoDropdownValues;
  dropdownValues11: any[] = VhoDropdownValues;

  myDate: any;
  nadModels: any[];
  selectValue6: any;

  checkBoxClass: string = "d-inline-flex";

  public checkBoxModel = {
    id: 0,
    name: "",
    roles: []
  };
  private checkBoxValue = [
    { id: 1, name: 'ABF Ind' },
  ];
  checkOption1 = new Array<any>();


  constructor() {
    this.myDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.checkOption1 = this.checkBoxValue.map(x => new CheckboxItem(x.id, x.name, false));
  }

  ngOnInit() {
    this.nadModels = this.getNADModel(this.dropdownValues6[0].label);
  }

  onCheckChange(value) {
    this.checkBoxModel.roles = value;
  }

  ntiChange(val) {
    this.nadModels = this.getNADModel(val);
  }

  getNADModel(val) {
    if (val == 'FTTN') {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" }, { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (val == 'FTTN-BP') {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" }, { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (val == 'FTTPIP') {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" }, { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (val == 'RGPON') {
      return [{ label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else if (val == 'FTTP-GPON') {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" }, { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (val == 'FTTC-GPON') {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" }, { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (val == 'FTTC-EGPON') {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else if (val == 'FTTP-EGPON') {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    }
    //updating speeds for ipdslam
    else if ((val == 'IP-CO') || (val == 'IP-RT')) {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3700HGV-B (RG)", data1: "3700HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" }, { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" },
      { label: "5111NV (IG IPDSLAM)", data1: "5111NV-030", data2: "IG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" }, { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    }
    //updating speeds for ipdslam bp
    else if ((val == 'IP-CO-BP') || (val == 'IP-RT-BP')) {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" }, { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if ((val == "FTTB-C") || (val == "FTTB-F")) {
      return [{ label: "NVG595 (FBG)", data1: "NVG595", data2: "FBG", data3: "ARRIS" }];
    } else if (val == "FTTP-RGPON") {
      return [{ label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else {
      return [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" },
      { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3700HGV-B (RG)", data1: "3700HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" },
      { label: "5111NV (IG IPDSLAM)", data1: "5111NV-030", data2: "IG", data3: "2Wire" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" },
      { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "NVG595 (FBG)", data1: "NVG595", data2: "FBG", data3: "ARRIS" },
      { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    }

  }
}

