import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

export class CheckboxItem {
  value: string;
  label: string;
  checked: boolean;

  constructor(value: any, label: any, checked?: boolean) {
    this.value = value;
    this.label = label;
    this.checked = checked ? checked : false;
  }
}

@Component({
  selector: 'app-checkBox',
  templateUrl: './checkBox-value.component.html',
  styleUrls: ['./checkBox-value.component.css']
})

export class CheckBoxValueComponent {
  @Input() options: CheckboxItem[];
  @Input() selectedValues: string[];
  @Input() customClass: string;
  @Input() isDisabled: boolean = false;

  @Output() toggle = new EventEmitter<any[]>();

  constructor() { }

  ngOnInit() { }

  onToggle() {
    // const checkedOptions = this.options.filter(x => x.checked);
    this.selectedValues = this.options.filter(x => x.checked).map(x => x.label);
    this.toggle.emit(this.selectedValues);
  }


}
