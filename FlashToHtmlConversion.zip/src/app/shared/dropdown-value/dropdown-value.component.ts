import { Component, Input, Output, EventEmitter } from '@angular/core';

export class DropdownValue {
  value: string;
  label: string;

  constructor(value: string, label: string) {
    this.value = value;
    this.label = label;
  }
}

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown-value.component.html',
  styleUrls: ['./dropdown-value.component.css']
})
export class DropdownValueComponent {

  @Input() values: DropdownValue[];
  @Input() value: string[];
  @Input() title: string;
  @Input() type: string;
  @Input() selected: string;
  @Input() disableDropdown: boolean;

  @Output() valueChange = new EventEmitter();
  @Output() listChange = new EventEmitter();

  constructor() { }

  ngOnInit() {
    if (this.selected == undefined) {
      if (this.values && this.values.length) {
        this.selected = this.values[0].label;
      }
    }
  }

  SelectItem(value: any) {
    this.valueChange.emit(value);
  }

  selectListName(value) {
    this.listChange.emit(value);
  }

}
