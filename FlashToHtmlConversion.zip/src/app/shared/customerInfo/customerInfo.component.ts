import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { titleDropdownValue, trueFalseDropdownValue } from 'app/constants/global.constant';
import {
  subTypeDropdownValues,
  timeZOneDropdownValues,
  VhoDropdownValues,
  classOfServiceDropdownValues
} from 'app/constants/omsMessage.constant';

@Component({
  selector: 'customer-info',
  templateUrl: './customerInfo.component.html',
  styleUrls: ['./customerInfo.component.css']
})
export class CustomerInfoComponent implements OnInit {
  @Input() tabSelect: string;
  @Input() title: string;
  @Input() tabCss: string;
  @Input() contCss: string;

  dropdownValues1: any[] = titleDropdownValue;
  dropdownValues2: any[] = subTypeDropdownValues;
  dropdownValues3: any[] = trueFalseDropdownValue;
  dropdownValues4: any[] = classOfServiceDropdownValues;
  dropdownValues5: any[] = timeZOneDropdownValues;
  dropdownValues6: any[] = VhoDropdownValues;
  dropdownValues7: any[] = trueFalseDropdownValue;

  dropdownTitle1: string = "Title"
  dropdownTitle2: string = "SubType"
  dropdownTitle3: string = "UBIndicator"
  dropdownTitle4: string = "ClassOfService"
  dropdownTitle5: string = "TimeZone"
  dropdownTitle6: string = "Credit Risk Class"
  dropdownTitle7: string = "CurrentCustInd";

  selectedTitle: any;
  selectedUBIndicator: any;
  selectedSubType: any;
  selectedTimeZone: any;
  selectedCurrentCustInd: any;
  selectedClassOfService: any;
  selectedCreditRiskClass: any;

  textValue1: string = "Alpha";
  textValue2: string = "Beta";
  textValue3: string = "9119119119";
  textValue4: string = "1191191191";
  textValue5: string = "ATT";
  textValue6: string = "1081081081";
  textValue7: string = "abc123";
  textValue8: string = "abc123";
  textValue9: string = "abc123";
  textValue10: string = "abc123";
  textValue11: string = "Alpha";
  textValue12: string = "Beta";
  textValue13: string = "9119119119";
  textValue14: string = "1191191191";
  textValue15: string = "ATT";
  textValue16: string = "1081081081";
  textValue17: string = "abc123";
  textValue18: string = "abc123";
  textValue19: string = "abc123";
  textValue20: string = "abc123";
  textValue21: string = "abc123";

  textTitle1: string = "First Name";
  textTitle2: string = "Last Name";
  textTitle3: string = "Contact Phone";
  textTitle4: string = "Secondary Phone";
  textTitle5: string = "Seller Name";
  textTitle6: string = "Seller TN";
  textTitle7: string = "Seller ID";
  textTitle8: string = "BAN";
  textTitle9: string = "Account Id";
  textTitle10: string = "Name";
  textTitle11: string = "Type";
  textTitle12: string = "timeZoneOffset"
  textTitle13: string = "classOfService"
  textTitle14: string = "LocalContactName"
  textTitle15: string = "Local Contact phone"
  textTitle16: string = "reserveProjectId"
  textTitle17: string = "Old Local Contact Name"
  textTitle18: string = "Old Local Phone Name"
  textTitle19: string = "FTTB Build Cli";
  textTitle20: string = "PhoneNumber";
  textTitle21: string = "Primary Phone";

  disableText1: boolean;
  disableText2: boolean;
  disableText3: boolean;
  disableText4: boolean;
  disableText5: boolean = true;
  disableText6: boolean = true;
  disableText7: boolean = true;

  disableDropdown1: boolean;

  constructor() {
    this.selectedUBIndicator = this.dropdownValues3[1].label;
    this.dropdownValues7.reverse();
  }

  ngOnInit() {
    if (this.title == 'New Customer Info') {
      this.disableText1 = true;
      this.disableText2 = true;
      this.disableText3 = true;
      this.disableText4 = true;
      this.disableDropdown1 = true;
    }
    if (this.tabSelect == 'wllft' && this.title == 'Customer Info') {
      this.textValue1 = "Sheldon";
      this.textValue2 = "Cooper";
      this.textValue3 = "9876543210";
      this.textValue21 = "1234567890";
    }
    this.selectedTitle = this.dropdownValues1[0].label;
    this.selectedSubType = this.dropdownValues2[0].value;
    this.selectedUBIndicator = this.dropdownValues3[0].label;
    this.selectedClassOfService = this.dropdownValues4[0].label;
    this.selectedTimeZone = this.dropdownValues5[0].label;
    this.selectedCreditRiskClass = this.dropdownValues6[0].label;
    this.selectedCurrentCustInd = this.dropdownValues7[0].label;
  }

  dropDownChange(evt, title) {
    if (title == "Title") {
      this.selectedTitle = evt;
    } else if (title == "SubType") {
      this.selectedSubType = evt;
    } else if (title == "UBIndicator") {
      this.selectedUBIndicator = evt;
    } else if (title == "ClassOfService") {
      this.selectedClassOfService = evt;
    } else if (title == "TimeZone") {
      this.selectedTimeZone = evt;
    } else if (title == "Credit Risk Class") {
      this.selectedCreditRiskClass = evt;
    } else if (title == "CurrentCustInd") {
      this.selectedCurrentCustInd = evt;
    }
  }

}

