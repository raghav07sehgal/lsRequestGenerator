import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

export class radioValues {
  value: string;
  title: string;

  constructor(value: string, title: string) {
    this.value = value;
    this.title = title;
  }
}

@Component({
  selector: 'app-radio-button',
  templateUrl: './radio-button.component.html',
  styleUrls: ['./radio-button.component.css']
})
export class RadioButtonComponent {

  @Input() values: radioValues[];
  @Output() valueChange = new EventEmitter();

  constructor() { }

  ngOnInit() { }

  radioChecked(value) {
    this.valueChange.emit(value);
  }

}
