import { Component, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { select, Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { EnvDropdownValues } from 'app/constants/header.constant';
import { OmsMessageService } from 'app/modules/oms-message/oms-message.service';

import beautify from 'xml-beautifier';

@Component({
  selector: 'app-model-box',
  templateUrl: './model-box.component.html',
  styleUrls: ['./model-box.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ModelBoxComponent implements OnInit {
  @Input() title;
  @Input() content;
  @Input() fileName;
  @Input() type;
  @Input() btnType;

  dropdownTitle1: string = "Env";
  dropdownValues1: any[] = [];

  dropdownDisable1: boolean = true;
  xmlValue: any;

  constructor(public activeModal: NgbActiveModal,
    public omsService: OmsMessageService,
    private store: Store<HeaderState>) { }

  ngOnInit(): void {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        let selectedEnv = storeObj['enviornment'];
        this.dropdownValues1 = [{ label: selectedEnv, value: selectedEnv?.toLowerCase() }];
      })
    beautify(this.content)
    this.xmlValue = this.content;
  }

  send(xml) {
    if (this.btnType == "genPubRg") {
      this.omsService.genPubRgXml(xml)
        .subscribe(val => {
          console.log("output--->>>>>", val);
          this.xmlValue = `WebSIM Response:\n\n${val}`;
        },
          err => this.xmlValue = <any>err)
    } else {
      this.omsService.sendOrderXml(xml)
        .subscribe(val => {
          console.log("output--->>>>>", val);
          this.xmlValue = `OMS Queue Response:\n\n${val}`;
        },
          err => this.xmlValue = <any>err)
    }
    this.title = "Activity Result";
    this.type = "template5";
  }

  clear() {
    this.xmlValue = "";
  }

  saveXml() { }

}
