import { formatDate } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  actionDropdownValue,
  CompletionIndicatorDropdown, currentSpidDropdown, legacyTnValue1, legacyTnValue2, newSpidDropdown, OrderActionDropdown,
  OrderActionReasonCodeDropdown, portOutDestinationDropdown, tnSubTypeDropdown, tnTypeDropdown, tnValue, tnValue1, tnValue2
} from 'app/constants/omsMessage.constant';
import {
  accessCardStatusDropdown, actionTypeDropdown, categoryDropdown, equipmentOwnershipDropdown,
  equipOwnTypeDropdown, IrdActionDropdown, lineItemActionDropdown, LineItemStatusDropdown,
  OrderLineItemActionDropdown, productLineDropdown, productNameDropdown
} from 'app/constants/star.constant';
import { shortToggleDropdown2, uspIndicatorDropdown2 } from 'app/constants/global.constant'
import { CheckboxItem } from '../checkBox-value/checkBox-value.component';
import { HeaderState } from 'app/components/header/header.state';
import { Store } from '@ngrx/store';
import { OmsMessageService } from 'app/modules/oms-message/oms-message.service';

@Component({
  selector: 'line-item',
  templateUrl: './line-item.component.html',
  styleUrls: ['./line-item.component.css']
})
export class LineItemComponent implements OnInit {
  @Input() tabType: any;
  @Input() title: string;
  @Input() compClass: string;

  textTitle1: string = "";
  textTitle2: string = "Receiver Id";
  textTitle3: string = "SerialNum";
  textTitle4: string = "Access Card Id";
  textTitle5: string = "Mac Address";
  textTitle6: string = "BTN";
  textTitle7: string = "NPA";
  textTitle8: string = "TN";
  textTitle9: string = "FirstWord";
  textTitle10: string = "RemaningWords";
  textTitle11: string = "repLineTn";

  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';
  textValue6: any = '';
  textValue7: any = '210';
  textValue8: any = '';
  textValue9: any = 'XYZ';
  textValue10: any = 'ABC';
  textValue11: any = '';
  textValue12: any = '';
  tnTextBoxValue: any;

  disableText9: boolean = true;
  disableText10: boolean = true;

  dropdownTitle1: string = "LineItemAction";
  dropdownTitle2: string = "Product Name";
  dropdownTitle3: string = "Product Line";
  dropdownTitle4: string = "EquipOwnType ";
  dropdownTitle5: string = "ActionType";
  dropdownTitle6: string = "OrderLineItemAction";
  dropdownTitle7: string = "Ird Action";
  dropdownTitle10: string = "LineItemStatus";
  dropdownTitle11: string = "Access Card Status";
  dropdownTitle12: string = "Category";
  dropdownTitle13: string = "Equipment Ownership";
  dropdownTitle14: string = "Action"
  dropdownTitle15: string = "CompletionIndicator"
  dropdownTitle16: string = "NLT Choice"
  dropdownTitle17: string = "PortIn Type"
  dropdownTitle18: string = "TN Type"
  dropdownTitle19: string = "TN Sub Type"
  dropdownTitle20: string = "RG Port 1"
  dropdownTitle21: string = "old NLT"
  dropdownTitle22: string = "New SPID"
  dropdownTitle23: string = "portOutDestination"
  dropdownTitle24: string = "old Rg Port"
  dropdownTitle25: string = "isFlexibleCNAM"
  dropdownTitle26: string = "CurrentSPID"
  dropdownTitle28: string = "NLT"
  dropdownTitle29: string = "Move"
  dropdownTitle30: string = "RG Port"

  dropdownValues1: any[] = lineItemActionDropdown;
  dropdownValues2: any[] = productNameDropdown;
  dropdownValues3: any[] = productLineDropdown;
  dropdownValues4: any[] = equipOwnTypeDropdown;
  dropdownValues5: any[] = actionTypeDropdown;
  dropdownValues6: any[] = OrderLineItemActionDropdown;
  dropdownValues7: any[] = IrdActionDropdown;
  dropdownValues10: any[] = LineItemStatusDropdown;
  dropdownValues11: any[] = accessCardStatusDropdown;
  dropdownValues12: any[] = categoryDropdown;
  dropdownValues13: any[] = equipmentOwnershipDropdown;
  dropdownValues14: any[] = actionDropdownValue;
  dropdownValues15: any[] = CompletionIndicatorDropdown;
  dropdownValues16: any[] = uspIndicatorDropdown2;
  dropdownValues17: any[] = shortToggleDropdown2;
  dropdownValues18: any[] = tnTypeDropdown;
  dropdownValues19: any[] = tnSubTypeDropdown;
  dropdownValues20: any[] = uspIndicatorDropdown2;
  dropdownValues21: any[] = uspIndicatorDropdown2;
  dropdownValues22: any[] = newSpidDropdown;
  dropdownValues23: any[] = portOutDestinationDropdown;
  dropdownValues24: any[] = uspIndicatorDropdown2;
  dropdownValues25: any[] = uspIndicatorDropdown2;
  dropdownValues26: any[] = currentSpidDropdown;
  dropdownValues28: any[] = OrderActionDropdown;
  dropdownValues29: any[] = OrderActionDropdown;
  dropdownValues30: any[] = OrderActionDropdown;
  dropdownValues31: any[] = OrderActionDropdown;
  dropdownValues32: any[] = OrderActionDropdown;

  SelectedLineItemAction: string = this.dropdownValues1[0].label;
  SelectedProductName: string = this.dropdownValues2[0].label;
  SelectedProductLine: string = this.dropdownValues3[0].label;
  SelectedEquipOwnType: string = this.dropdownValues4[0].label;
  SelectedActionType: string = this.dropdownValues5[0].label;
  SelectedOrderLineItemAction: string = this.dropdownValues6[0].label;
  SelectedIrdAction: string = this.dropdownValues7[0].label;
  SelectedLineItemStatus: string = this.dropdownValues10[0].label;
  SelectedAccessCardStatus: string = this.dropdownValues11[0].label;
  SelectedCategory: string = this.dropdownValues12[0].label;
  SelectedEquipmentOwnership: string = this.dropdownValues13[0].label;
  SelectedAction: string = this.dropdownValues14[0].label;
  SelectedCompletionIndicator: string = this.dropdownValues15[0].label;
  SelectedNLTChoice: string = this.dropdownValues16[0].label;
  SelectedPortInType: string = this.dropdownValues17[0].label;
  SelectedTNType: string = this.dropdownValues18[0].label;
  SelectedTNSubType: string = this.dropdownValues19[0].label;
  SelectedRGPort1: string = this.dropdownValues20[0].label;
  SelectedoldNLT: string = this.dropdownValues21[0].label;
  SelectedNewSPID: string = this.dropdownValues22[0].label;
  SelectedportOutDestination: string = this.dropdownValues23[0].label;
  SelectedoldRgPort: string = this.dropdownValues24[0].label;
  SelectedisFlexibleCNAM: string = this.dropdownValues25[0].label;
  SelectedCurrentSPID: string = this.dropdownValues26[0].label;
  SelectedNLT: string = this.dropdownValues28[0].label;
  SelectedMove: string = this.dropdownValues29[0].label;
  SelectedRGPort: string = this.dropdownValues30[0].label;

  disableDropdown16: boolean = true;
  disableDropdown20: boolean = true;
  disableDropdown21: boolean = true;
  disableDropdown23: boolean = true;
  disableDropdown24: boolean = true;
  disableDropdown25: boolean = true;

  myDate: any;
  extCheck: boolean;

  checkBoxClass: string = "d-inline-flex";

  tnCheckOption1 = new Array<any>();
  tnCheckOption2 = new Array<any>();

  ntiVal: any;
  enviornmentVal: any;

  selectValue19: any;
  selectValue22: any;
  selectValue26: any;

  constructor(private route: ActivatedRoute, private store: Store<HeaderState>,
    public omsService: OmsMessageService
  ) {
    // this.myDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.tnCheckOption1 = tnValue.map(x => new CheckboxItem(x.id, x.name, false));
    this.textValue5 = `11:${this.textValue1}`
  }

  ngOnInit(): void {
    if (this.title == "line2") {
      this.tnCheckOption2 = tnValue1.map(x => new CheckboxItem(x.id, x.name, false));
    } else if (this.title == "line3") {
      this.tnCheckOption2 = tnValue2.map(x => new CheckboxItem(x.id, x.name, false));
    } else if (this.title == "legacytn1") {
      this.tnCheckOption2 = legacyTnValue1.map(x => new CheckboxItem(x.id, x.name, false));
    } else if (this.title == "legacytn2") {
      this.tnCheckOption2 = legacyTnValue2.map(x => new CheckboxItem(x.id, x.name, false));
    }

    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.ntiVal = storeObj['nti'];
        this.enviornmentVal = storeObj['enviornment'];
      })
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.tn1TypeMapping();
    }, 0);
  }

  GetUniqueLineItemId() {
    this.textValue1 = Math.floor(Math.random() * (999999 - 100000)) + 100000000000000;
    this.textValue5 = `11:${this.textValue1}`
  }

  dropDownChange(evt, title) {
    if (title == "LineItemAction") {
      this.SelectedLineItemAction = evt;
    } else if (title == "Product Name") {
      this.SelectedProductName = evt;
    } else if (title == "Product Line") {
      this.SelectedProductLine = evt;
    } else if (title == "EquipOwnType") {
      this.SelectedEquipOwnType = evt;
    } else if (title == "ActionType") {
      this.SelectedActionType = evt;
    } else if (title == "OrderLineItemAction") {
      this.SelectedOrderLineItemAction = evt;
    } else if (title == "Ird Action") {
      this.SelectedIrdAction = evt;
    } else if (title == "LineItemStatus") {
      this.SelectedLineItemStatus = evt;
    } else if (title == "Access Card Status") {
      this.SelectedAccessCardStatus = evt;
    } else if (title == "Category") {
      this.SelectedCategory = evt;
    } else if (title == "Equipment Ownership") {
      this.SelectedEquipmentOwnership = evt;
    } else if (title == "Action") {
      this.SelectedIrdAction = evt;
    } else if (title == "CompletionIndicator") {
      this.SelectedCompletionIndicator = evt;
    } else if (title == "NLT Choice") {
      this.SelectedNLTChoice = evt;
    } else if (title == "PortIn Type") {
      this.SelectedPortInType = evt;
    } else if (title == "TN Type") {
      this.SelectedTNType = evt;
      this.tn1TypeMapping();
    } else if (title == "TN Sub Type") {
      this.SelectedTNSubType = evt;
      this.tn1TypeMapping();
    } else if (title == "RG Port 1") {
      this.SelectedRGPort1 = evt;
    } else if (title == "old NLT") {
      this.SelectedoldNLT = evt;
    } else if (title == "New SPID") {
      this.SelectedNewSPID = evt;
    } else if (title == "portOutDestination") {
      this.SelectedportOutDestination = evt;
    } else if (title == "old Rg Port") {
      this.SelectedoldRgPort = evt;
    } else if (title == "isFlexibleCNAM") {
      this.SelectedisFlexibleCNAM = evt;
    } else if (title == "CurrentSPID") {
      this.SelectedCurrentSPID = evt;
    } else if (title == "NLT") {
      this.SelectedNLT = evt;
    } else if (title == "Move") {
      this.SelectedMove = evt;
    } else if (title == "RG Port") {
      this.SelectedRGPort = evt;
    }
  }

  tn1TypeMapping() {
    if (this.SelectedTNType == "NATIVE") {
      if (this.SelectedTNSubType == "NATIVE") {
        this.selectValue26 = this.dropdownValues26[1].label;
        this.selectValue22 = this.dropdownValues22[0].label;
        this.textValue7 = '210';
        this.disableDropdown23 = true;
      } else if (this.SelectedTNSubType == "REUSETN") {
        this.selectValue26 = this.dropdownValues26[1].label;
        this.selectValue22 = this.dropdownValues22[0].label;
        this.textValue7 = '220';
        this.disableDropdown23 = true;
      } else if (this.SelectedTNSubType == "DISCONNECT") {
        this.selectValue26 = this.dropdownValues26[0].label;
        this.selectValue22 = this.dropdownValues22[0].label;
        this.textValue7 = '';
        this.disableDropdown23 = false;
      } else {
        this.disableDropdown23 = true;
      }
    } else if (this.SelectedTNType == "ICP") {
      this.selectValue19 = this.dropdownValues19[1].label;
      this.selectValue26 = this.dropdownValues26[1].label;
      this.selectValue22 = this.dropdownValues22[0].label;
      this.textValue7 = '230';
      this.disableDropdown23 = true;
    } else if (this.SelectedTNType == "PORTINGOUT") {
      this.selectValue19 = this.dropdownValues19[1].label;
      this.selectValue26 = this.dropdownValues26[0].label;
      this.selectValue22 = this.dropdownValues22[1].label;
      this.textValue7 = '';
      this.disableDropdown23 = true;
    } else {
      if (this.SelectedTNSubType == "PTO") {
        this.selectValue26 = this.dropdownValues26[2].label;
        this.selectValue22 = this.dropdownValues22[0].label;
        this.textValue7 = '410';
      } else if (this.SelectedTNSubType == "FPI") {
        this.selectValue26 = this.dropdownValues26[2].label;
        this.selectValue22 = this.dropdownValues22[0].label;
        this.textValue7 = '510';
      } else {
        this.selectValue26 = this.dropdownValues26[2].label;
        this.selectValue22 = this.dropdownValues22[0].label;
        this.textValue7 = '610';
      }
      this.disableDropdown23 = true;
    }
  }

  getTnXml() {
    let xml = `<soapenv:Envelope xmlns:soapenv = "http://schemas.xmlsoap.org/soap/envelope/" xmlns:req = "http://att.com/websim/dynamicnumbergenerator/request" >`
      + `<soapenv:Header/>`
      + `<soapenv:Body>`
      + `<req:dynamicNumberGeneratorRequest>`
      + `<req:environment>${this.enviornmentVal}</req:environment>`
      + `<req:npa>${this.textValue7}</req:npa>`
      + `<req:type>TN</req:type>`
      + `</req:dynamicNumberGeneratorRequest>`
      + `</soapenv:Body>`
      + `</soapenv:Envelope>`;
    return xml;
  }

  getTn() {
    let xml = this.getTnXml();
    this.omsService.getTnNumber(xml)
      .subscribe(val => {
        console.log("genTN Number--->>>>>", val);
        let output = val.match("<dynamicNumber>(.*?)</dynamicNumber>");
        if (output != null) {
          this.textValue8 = output[1];
        } else {
          this.textValue8 = "";
        }
      });
  }

}