import { Component, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { accountTypeDropdown, actionDropdownValue, cidrDropdown, compIndDropdown, CompletionIndicatorDropdown, deviceDropdown, ipTypeDropdown, oldFeatureSetDropdown, OrderActionDropdown, PrimaryRadioOptions, RgResetDropdown, salesChannelDropdownValues } from 'app/constants/omsMessage.constant';
import { cvoipTabSelection, iptvTabSelection, voipTabSelection } from 'app/constants/tab.constant';
import { CheckboxItem } from '../checkBox-value/checkBox-value.component';
import { numberDropdownValue, uspIndicatorDropdown, shortToggleDropdown, uspIndicatorDropdown2 } from 'app/constants/global.constant';
import * as moment from 'moment';
import { HeaderState } from 'app/components/header/header.state';
import { Store } from '@ngrx/store';
import { LineItemComponent } from '../line-item/line-item.component';
import { NtiDropdownValues } from 'app/constants/header.constant';

@Component({
  selector: 'app-sub-module',
  templateUrl: './sub-module.component.html',
  styleUrls: ['./sub-module.component.css'],
  // encapsulation:ViewEncapsulation.None
})
export class SubModuleComponent implements OnInit {
  @Input() title: string;
  @Input() containerClass: any;
  @Input() tabType: any;

  @ViewChild(LineItemComponent) voipLine: LineItemComponent;

  dropdownTitle1: string = "Action";
  dropdownTitle2: string = "# of CPE's";
  dropdownTitle3: string = "notRequired";
  dropdownTitle5: string = "SD indicator Flag";
  dropdownTitle6: string = "CompInd";
  dropdownTitle7: string = "Speed";
  dropdownTitle8: string = "Ip Type";
  dropdownTitle9: string = "CIDR";
  dropdownTitle10: string = "InsideWireTypeSurvey";
  dropdownTitle11: string = "IPDSLAM I/R";
  dropdownTitle12: string = "WalledGarden";
  dropdownTitle13: string = "RGReset";
  dropdownTitle14: string = "OTTM Action";
  dropdownTitle15: string = "isUpgradeIndicator";
  dropdownTitle16: string = "WSPMC Action";
  dropdownTitle17: string = "WSPBAN Action";
  dropdownTitle18: string = "CWSCTAN Action";
  dropdownTitle19: string = "Wireless Customer Ind";
  dropdownTitle20: string = "Device";
  dropdownTitle21: string = "WiringCVOIP";
  dropdownTitle22: string = "WiringHSIA";
  dropdownTitle23: string = "WiringVideoBasic";
  dropdownTitle24: string = "DropWire";
  dropdownTitle25: string = "MoveNAD";
  dropdownTitle26: string = "MoveNID";
  dropdownTitle27: string = "New Device";
  dropdownTitle28: string = "# of GPs"
  dropdownTitle29: string = "CompletionIndicator"
  dropdownTitle30: string = "Basic Service Level"
  dropdownTitle31: string = "HD Service"
  dropdownTitle32: string = "HD Streams"
  dropdownTitle33: string = "SD Streams"
  dropdownTitle34: string = "HDSDStreamChangeInd"
  dropdownTitle35: string = "# of STBs"
  dropdownTitle36: string = "Sales Channel";
  dropdownTitle37: string = "AutoAttendent";
  dropdownTitle38: string = "FeatureSet";
  dropdownTitle39: string = "OldAutoAttend";
  dropdownTitle40: string = "OldFeatureSet";
  dropdownTitle41: string = "Account Type";
  dropdownTitle42: string = "Move";
  dropdownTitle43: string = "# of OTT Services"

  dropdownValues1: any[] = actionDropdownValue;
  dropdownValues2: any[] = numberDropdownValue;
  dropdownValues3: any[] = actionDropdownValue;
  dropdownValues4: any[] = actionDropdownValue;
  dropdownValues5: any[] = uspIndicatorDropdown;
  dropdownValues6: any[] = compIndDropdown;
  dropdownValues7: any[];
  dropdownValues8: any[] = ipTypeDropdown;
  dropdownValues9: any[] = cidrDropdown;
  dropdownValues10: any[] = uspIndicatorDropdown;
  dropdownValues11: any[] = shortToggleDropdown;
  dropdownValues12: any[] = uspIndicatorDropdown2;
  dropdownValues13: any[] = RgResetDropdown;
  dropdownValues14: any[] = OrderActionDropdown;
  dropdownValues15: any[] = OrderActionDropdown;
  dropdownValues16: any[] = OrderActionDropdown;
  dropdownValues17: any[] = OrderActionDropdown;
  dropdownValues18: any[] = OrderActionDropdown;
  dropdownValues19: any[] = OrderActionDropdown;
  dropdownValues20: any[] = deviceDropdown;
  dropdownValues21: any[] = numberDropdownValue;
  dropdownValues22: any[] = numberDropdownValue;
  dropdownValues23: any[] = numberDropdownValue;
  dropdownValues24: any[];
  dropdownValues25: any[];
  dropdownValues26: any[];
  dropdownValues27: any[] = deviceDropdown;
  dropdownValues28: any[] = numberDropdownValue;
  dropdownValues29: any[] = CompletionIndicatorDropdown;
  dropdownValues30: any[] = OrderActionDropdown;
  dropdownValues31: any[] = OrderActionDropdown;
  dropdownValues32: any[] = OrderActionDropdown;
  dropdownValues33: any[] = OrderActionDropdown;
  dropdownValues34: any[] = OrderActionDropdown;
  dropdownValues35: any[] = numberDropdownValue;
  dropdownValues36: any[] = salesChannelDropdownValues;
  dropdownValues37: any[] = OrderActionDropdown;
  dropdownValues38: any[] = OrderActionDropdown;
  dropdownValues39: any[] = uspIndicatorDropdown2;
  dropdownValues40: any[] = oldFeatureSetDropdown;
  dropdownValues41: any[] = accountTypeDropdown;
  dropdownValues42: any[] = OrderActionDropdown;
  dropdownValues43: any[] = numberDropdownValue;

  dropdownDisable3: boolean = true;
  dropdownDisable9: boolean = true;
  dropdownDisable10: boolean = true;
  dropdownDisable11: boolean = true;
  dropdownDisable16: boolean = true;
  dropdownDisable17: boolean = true;
  dropdownDisable18: boolean = true;
  dropdownDisable27: boolean = true;

  changedDropdownValues1: any;
  changedDropdownValues6: any;
  changedDropdownValues29: any;

  textTitle1: string = "First Name";
  textTitle2: string = "Last Name";
  textTitle3: string = "Business Name";
  textTitle4: string = "NonProductCatalogData Remarks";
  textTitle5: string = "Biz Name";
  textValue1: any = "Peter";
  textValue2: any = "Parker";
  textValue3: any = "";
  textValue4: any = "CVOIP Order";
  textValue5: any = "";

  selectedPool: any;
  selectedRgReset: any;
  selectedWalledGarden: any;
  selectedAction: any;
  selectedCompInd: any;
  selectedSpeed: any;
  selectedIpType: any;
  selectedCidr: any;
  selectDropdownDevice: any;
  selectDropdownDeviceData1: any;
  selectDropdownDeviceData2: any;
  selectDropdownNewDevice: any;
  selectedWapChange: boolean = false;
  selectedMove: any;
  selectedSalesChannel: any;
  selectedIPDSLAMIR: any;
  selectedOTTMAction: any;
  selectedOTTServices: any
  selectedMoveNAD: any;
  selectedMoveNID: any;
  selectedWiringCVOIP: any;
  selectedWiringHSIA: any;
  seelctedWiringVideoBasic: any;
  selectedDropWire: any;
  selectedCompletionIndicator: any;
  selectedWirelessCustomerInd: any;
  selectedHDService: any;
  selectedGps: any;
  selectedSTBs: any;
  selectedHDStreams: any;
  selectedSDStreams: any;
  selectDropdownNewDeviceData1: any;
  selectDropdownNewDeviceData2: any;

  radioValues: any[] = PrimaryRadioOptions;

  voipTabs: any[] = voipTabSelection;
  cvoipTabs: any[] = cvoipTabSelection;
  iptvTabs: any[] = iptvTabSelection;

  containerClass1: string = "wh2";
  containerClass2: string = "wh3";
  containerClass3: string = "h1";
  checkBoxClass: string = "d-inline-flex";

  public checkBoxModel = {
    id: 0,
    name: "",
    roles: []
  };
  private checkBoxValue = [
    { id: 1, name: 'Unified Wireless' },
    { id: 2, name: 'OTT ' },
    { id: 3, name: 'WAP Swap' },
    { id: 4, name: 'WIFI' },
    { id: 5, name: 'IPTV' },
    { id: 6, name: 'WIRELESS' },
    { id: 7, name: 'DIRECTV' },
    { id: 8, name: 'WAP' },
    { id: 9, name: 'HSIA' },
    { id: 10, name: 'CVOIP' },
    { id: 11, name: 'BVOIP' },
    { id: 12, name: 'Line2' },
  ];
  checkOption1 = new Array<any>();
  checkOption2 = new Array<any>();
  checkOption3 = new Array<any>();
  checkOption4 = new Array<any>();
  checkOption5 = new Array<any>();
  checkOption6 = new Array<any>();
  checkOption7 = new Array<any>();
  checkOption8 = new Array<any>();
  checkOption9 = new Array<any>();
  checkOption10 = new Array<any>();
  checkOption11 = new Array<any>();
  checkOption12 = new Array<any>();

  selectedCvoip: any = false;
  selectedVoip: any = false;

  tabType1: string = "fnt";
  tabType2: string = "oms";

  ottChecked: boolean = false;

  ntiVal: any;
  enviornmentVal: any;
  omsOrderAction: any;

  constructor(private store: Store<HeaderState>) {
    this.checkOption1 = this.checkBoxValue.filter(x => x.id == 1).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption2 = this.checkBoxValue.filter(x => x.id == 2).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption3 = this.checkBoxValue.filter(x => x.id == 3).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption4 = this.checkBoxValue.filter(x => x.id == 4).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption5 = this.checkBoxValue.filter(x => x.id == 5).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption6 = this.checkBoxValue.filter(x => x.id == 6).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption7 = this.checkBoxValue.filter(x => x.id == 7).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption8 = this.checkBoxValue.filter(x => x.id == 8).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption9 = this.checkBoxValue.filter(x => x.id == 9).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption10 = this.checkBoxValue.filter(x => x.id == 10).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption11 = this.checkBoxValue.filter(x => x.id == 11).map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption12 = this.checkBoxValue.filter(x => x.id == 12).map(x => new CheckboxItem(x.id, x.name, false));
  }

  ngOnInit() {
    this.dropdownValues2 = this.dropdownValues2.filter(x => x.label != 7 && x.label != 8 && x.label != 9)
    this.dropdownValues28 = this.dropdownValues28.filter(x => x.label != 9)
    this.dropdownValues35 = this.dropdownValues35.filter(x => x.label != 0 && x.label != 9)
    this.dropdownValues43 = this.dropdownValues43.filter(x => x.label != 7 && x.label != 8 && x.label != 9)

    let getSpeedVal;
    this.store.select(state => state['header'])
      .subscribe(async (data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.omsOrderAction = storeObj['orderAction'];
        this.changeOrderAction();
        this.enviornmentVal = storeObj['enviornment'];
        let ntiValArr = NtiDropdownValues.filter(val => {
          return val.label == storeObj['nti'];
        });

        this.ntiVal = ntiValArr[0]?.value;
        getSpeedVal = await this.gethsiaSpeed();
        if (getSpeedVal && getSpeedVal.length) {
          this.dropdownValues7 = getSpeedVal.map(val => {
            return { label: val, value: val }
          });
          this.selectedSpeed = this.dropdownValues7[0].label;
        }
      });

    this.initSelectValue();


  }

  initSelectValue() {
    this.selectedIpType = this.dropdownValues8[0].label;
    this.selectedCidr = this.dropdownValues9[0].label;
    this.selectedWalledGarden = this.dropdownValues12[0].label;
    this.selectedRgReset = this.dropdownValues13[0].label;
    this.selectDropdownDevice = this.dropdownValues20[0];
    this.selectDropdownNewDevice = this.dropdownValues27[0];
    let filterNumberArr = numberDropdownValue.filter((v, i) => i < 2);
    this.dropdownValues24 = filterNumberArr;
    this.dropdownValues25 = filterNumberArr;
    this.dropdownValues26 = filterNumberArr;
    this.selectedWiringCVOIP = this.dropdownValues21[0].label;
    this.selectedWiringHSIA = this.dropdownValues22[0].label;
    this.seelctedWiringVideoBasic = this.dropdownValues23[0].label;
    this.selectedDropWire = this.dropdownValues24[0].label;
    this.selectedMoveNAD = this.dropdownValues25[0].label;
    this.selectedMoveNID = this.dropdownValues26[0].label;
  }

  changeOrderAction() {
    if (this.omsOrderAction == "CH") {
      this.changedDropdownValues1 = this.dropdownValues1[2].label;
      this.changedDropdownValues6 = this.dropdownValues6[2].label;
      this.changedDropdownValues29 = this.dropdownValues29[2].label;
    } else {
      this.changedDropdownValues1 = this.dropdownValues1[0].label;
      this.changedDropdownValues6 = this.dropdownValues6[0].label;
      this.changedDropdownValues29 = this.dropdownValues29[0].label;
    }
    this.selectedAction = this.changedDropdownValues1;
    this.selectedCompInd = this.changedDropdownValues6;
    this.selectedCompletionIndicator = this.changedDropdownValues29;
  }

  gethsiaSpeed() {
    let speed;
    if ((this.ntiVal == 'IP-RT') || (this.ntiVal == 'IP-CO')) {
      speed = ["Hsia5x1", "Hsia10x1", "Hsia18", "Max", "Elite", "Pro", "Express", "Basic"];
    }
    // add express speed to ipdslam bp
    else if ((this.ntiVal == 'IP-RT-BP') || (this.ntiVal == 'IP-CO-BP')) {
      speed = ["Hsia5x1", "Hsia10x1", "Hsia25x2", "Hsia24", "Hsia18", "Max", "Elite", "Pro", "Express"];
    } else if (this.ntiVal == 'FTTN') {
      speed = ["Hsia5x1", "Hsia10x1", "Hsia25x5", "Hsia50x10", "Hsia75", "Hsia45", "Hsia24", "Hsia18", "Max", "Elite", "Pro", "Express", "Basic"];
    } else if (this.ntiVal == 'FTTN-BP') {
      speed = ["Hsia5x1", "Hsia10x1", "Hsia25x5", "Hsia50x10", "Hsia75x20", "Hsia100x20", "Hsia75", "Hsia45", "Hsia24", "Hsia18", "Max", "Elite", "Pro", "Express"];
    } else if ((this.ntiVal == 'FTTB-F') || (this.ntiVal == 'FTTB-C')) {
      speed = ["12M3M", "12M12M", "25M5M", "25M25M", "50M10M", "50M50M", "75M15M", "75M75M", "100M20M", "100M100M", "150M30M", "150M150M", "200M40M", "200M200M", "250M50M", "250M250M", "300M75M", "300M300M", "500M100M", "1000M200M", "500M500M", "1000M1000M"];
    } else if (this.ntiVal == 'FTTP-GPON' || this.ntiVal == 'FTTC-GPON') {
      speed = ["Hsia5x5", "Hsia10x1", "Hsia10x10", "Hsia25x5", "Hsia25x25", "Hsia50x10", "Hsia50x50", "Hsia75x75", "Hsia75x20", "Hsia150g", "Hsia500g", "Hsia50g", "Hsia100g", "Hsia1000g", "Hsia300g", "Hsia75", "Hsia45", "Hsia24", "Hsia18", "25m5mg", "50m10mg", "100m20mg", "200m40mg", "300m75mg", "500m100mg", "1000m200mg", "25m25mg", "50m50mg", "75m75mg", "100m100mg", "200m200mg", "300m300mg", "500m500mg", "1000m1000mg"];
    } else if (this.ntiVal == 'FTTP-EGPON' || this.ntiVal == 'FTTC-EGPON' || this.ntiVal == 'RGPON') {
      speed = ["Hsia25x5", "Hsia50x10", "Hsia24", "Hsia18", "Max", "Elite", "Pro", "Express", "Basic", "25m5mg", "50m10mg", "100m20mg", "200m40mg", "300m75mg", "500m100mg", "1000m200mg", "25m25mg", "50m50mg", "100m100mg", "200m200mg", "300m300mg", "500m500mg", "1000m1000mg"];
    } else {
      speed = ["Hsia24", "Hsia18", "Max", "Elite", "Pro", "Express", "Basic"];
    }
    return speed;
  }

  onCheckChange(val) {
    if (val.indexOf("WAP Swap") != -1) {
      this.dropdownDisable27 = false;
      this.selectedWapChange = true;
    } else if (val.indexOf("Unified Wireless") != -1) {
      this.dropdownDisable16 = false;
      this.dropdownDisable17 = false;
      this.dropdownDisable18 = false;
    } else if (val.indexOf("OTT ") != -1) {
      this.ottChecked = true;
    } else if (val.indexOf("CVOIP") != -1) {
      this.selectedCvoip = true;
    } else {
      this.dropdownDisable16 = true;
      this.dropdownDisable17 = true;
      this.dropdownDisable18 = true;
      this.dropdownDisable27 = true;
      this.ottChecked = false;
    }
  }

  radioValueChange(value) {
    this.selectedPool = value;
  }

  onDropdownChange(val, title) {
    if (title == "RGReset") {
      this.selectedRgReset = val;
    } else if (title == "WalledGarden") {
      this.selectedWalledGarden = val;
    } else if (title == "Action") {
      this.selectedAction = val;
    } else if (title == "CompInd") {
      this.selectedCompInd = val;
    } else if (title == "Speed") {
      this.selectedSpeed = val;
    } else if (title == "Ip Type") {
      this.selectedIpType = val;
    } else if (title == "CIDR") {
      this.selectedCidr = val;
    } else if (title == "Device") {
      this.selectDropdownDevice = val;
      deviceDropdown.map(val => {
        if (val.label == this.selectDropdownDevice) {
          this.selectDropdownDeviceData1 = val.data1;
          this.selectDropdownDeviceData2 = val.data2;
        }
      })
    } else if (title == "New Device") {
      this.selectDropdownNewDevice = val;
      deviceDropdown.map(val => {
        if (val.label == this.selectDropdownDevice) {
          this.selectDropdownNewDeviceData1 = val.data1;
          this.selectDropdownNewDeviceData2 = val.data2;
        }
      })
    } else if (title == "Move") {
      this.selectedMove = val;
    } else if (title == "Sales Channel") {
      this.selectedSalesChannel = val;
    } else if (title == "IPDSLAM I/R") {
      this.selectedIPDSLAMIR = val;
    } else if (title == "OTTM Action") {
      this.selectedOTTMAction = val;
    } else if (title == "# of OTT Services") {
      this.selectedOTTServices = val;
    } else if (title == "MoveNAD") {
      this.selectedMoveNAD = val;
    } else if (title == "MoveNID") {
      this.selectedMoveNID = val;
    } else if (title == "WiringCVOIP") {
      this.selectedWiringCVOIP = val;
    } else if (title == "WiringHSIA") {
      this.selectedWiringHSIA = val;
    } else if (title == "WiringVideoBasic") {
      this.seelctedWiringVideoBasic = val;
    } else if (title == "DropWire") {
      this.selectedDropWire = val;
    } else if (title == "CompletionIndicator") {
      this.selectedCompletionIndicator = val;
    } else if (title == "Wireless Customer Ind") {
      this.selectedWirelessCustomerInd = val;
    } else if (title == "HD Service") {
      this.selectedHDService = val;
    } else if (title == "# of GPs") {
      this.selectedGps = val;
    } else if (title == "# of STBs") {
      this.selectedSTBs = val;
    } else if (title == "HD Streams") {
      this.selectedHDStreams = val;
    } else if (title == "SD Streams") {
      this.selectedSDStreams = val;
    }
  }

  NotifyWAPActivationResponse(ban: String, make: String, model: String): String {
    let date = moment().format()

    return '<soapenv: Envelope xmlns: soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns: type= "http://www.att.com/bbnms/ml/g2/notify/xml/ws/v1/types" >'
      + ' <soapenv: Header />'
      + '<soapenv: Body >'
      + '<typ: NotifyWAPActivationRequest >'
      + `<typ: BAN>${ban}</typ:BAN>`
      + '< typ: MacAddress>00 - 60 - 1D - F6 - 7E-5C</typ:MacAddress>'
      + `< typ: Make>${make}</typ:Make>`
      + `< typ: Model>${model}</typ:Model>`
      + `< typ: TimeStamp>${date}< /typ:TimeStamp>`
      + '< /typ:NotifyWAPActivationRequest>'
      + '< /soapenv:Body>'
      + '< /soapenv:Envelope>';
  }

  NonProductCatalogDataList(remarks: String): String {
    var nonProductCatalogDataList: String;

    nonProductCatalogDataList = "<m2:nonProductCatalogDataList>\n"
      + "<m2:nonProductCatalogData>\n"
      + "<m2:name>ospFirstName</m2:name>\n"
      + "<m2:value>My</m2:value>\n"
      + "</m2:nonProductCatalogData>\n"
      + "<m2:nonProductCatalogData>\n"
      + "<m2:name>ospLastName</m2:name>\n"
      + "<m2:value>Comcast</m2:value>\n"
      + "</m2:nonProductCatalogData>\n"
      + "<m2:nonProductCatalogData>\n"
      + "<m2:name>departmentName</m2:name>\n"
      + "<m2:value>Department007</m2:value>\n"
      + "</m2:nonProductCatalogData>\n"
      + "<m2:nonProductCatalogData>\n"
      + "<m2:name>departmentPhone</m2:name>\n"
      + "<m2:value>4045551234</m2:value>\n"
      + "</m2:nonProductCatalogData>\n"
      + "<m2:nonProductCatalogData>\n"
      + "<m2:name>remarks</m2:name>\n"
      + "<m2:value>" + remarks + "</m2:value>\n"
      + "</m2:nonProductCatalogData>\n"
      + "</m2:nonProductCatalogDataList>\n";

    return nonProductCatalogDataList;
  }

}