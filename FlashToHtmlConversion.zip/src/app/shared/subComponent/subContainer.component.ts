import { Component, OnInit, Input, Output, EventEmitter, ViewChild, SimpleChange } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { Header } from 'app/components/header/header.model';
import { HeaderState } from 'app/components/header/header.state';
import { shortToggleDropdown, uspIndicatorDropdown } from 'app/constants/global.constant';
import { RadioOptionsValues1, reasonCodesDropdown, VhoDropdownValues, actionDropdownValue } from 'app/constants/omsMessage.constant';
import { supersedeDropdown } from 'app/constants/star.constant';
import { dtcpTabSelection } from 'app/constants/tab.constant';
import { OmsMessageComponent } from 'app/modules/oms-message/oms-message.component';
import { CheckboxItem } from '../checkBox-value/checkBox-value.component';
import { ModelBoxComponent } from '../model-box/model-box.component';
import { SubModuleComponent } from '../sub-module/sub-module.component';
import { TabContainerComponent } from '../tab-container/tab-container.component';

@Component({
  selector: 'sub-container',
  templateUrl: './subContainer.component.html',
  styleUrls: ['./subContainer.component.css']
})
export class SubContainerComponent implements OnInit {
  @Input() nadValue: any[];
  @Input() title: string;
  @Input() tabType: string;
  @Input() contClass: string;
  @Input() scrollCss: string;

  // @ViewChild(OmsMessageComponent) omsMessage:OmsMessageComponent;
  @ViewChild(SubModuleComponent) hsia: SubModuleComponent;
  @ViewChild(TabContainerComponent) tabContainer: TabContainerComponent;

  dropdownValues1: any[];
  dropdownValues2: any[] = uspIndicatorDropdown;
  dropdownValues3: any[] = actionDropdownValue;
  dropdownValues4: any[] = reasonCodesDropdown;
  dropdownValues5: any[];
  dropdownValues6: any[] = uspIndicatorDropdown;
  dropdownValues7: any[] = uspIndicatorDropdown;
  dropdownValues8: any[] = shortToggleDropdown;
  dropdownValues9: any[] = VhoDropdownValues;
  dropdownValues10: any[] = VhoDropdownValues;
  dropdownValues11: any[] = supersedeDropdown;

  dropdownTitle1: string = "Model"
  dropdownTitle2: string = "USP Indicator"
  dropdownTitle3: string = "Action"
  dropdownTitle4: string = "Reason Codes"
  dropdownTitle5: string = "Primary Model"
  dropdownTitle6: string = "internal WAP ind"
  dropdownTitle7: string = "Record Only"
  dropdownTitle8: string = "CC"
  dropdownTitle9: string = "LUStatus"
  dropdownTitle10: string = "instantHSIAOnIndicator"
  dropdownTitle11: string = "Supersede"

  disabledDropdown7: boolean = true;
  disabledDropdown9: boolean = true;
  check3Disabled: boolean = true;

  textValue1: string = "";
  textTitle1: string = "CCID";
  disableText1: any = true;

  dtvmTitle: string = "dtvm";
  inputCss: string = "wh-auto";
  containerClass: string = "h4";
  checkBoxClass: string = "d-inline-flex";

  selectedInternalWapInd: any;
  selectedModel: any;
  selectedModelData1: any;
  selectedModelData2: any;
  selectedSuperSede: any;
  selectedCC: any;
  selectedLUStatus: any;
  selectedAction: any;
  selectedUSPIndicator: any;
  selectedPrimaryModel: any;
  selectedPrimaryModelData1: any;
  selectedPrimaryModelData2: any;
  selectedModelData3: any;
  selectedNadSwap: any;

  dropdownDisable1: boolean = true;
  dropdownDisable3: boolean = true;
  dropdownDisable11: boolean = true;

  public checkBoxModel = {
    id: 0,
    name: "",
    roles: []
  };
  private checkBoxValue1 = [
    { id: 1, name: 'retainedServicesProcessIndicator' },
  ];
  private checkBoxValue2 = [
    { id: 1, name: 'Stacked Order' },
  ];
  private checkBoxValue3 = [
    { id: 1, name: 'NAD Swap' },
  ];
  checkOption1 = new Array<any>();
  checkOption2 = new Array<any>();
  checkOption3 = new Array<any>();

  radioValues1: any[] = RadioOptionsValues1;
  configChecked: boolean = false;
  selectedretainedServicesProcessIndicator: boolean = false;

  relatedOrderInfo_DTV: any;
  retainedServicesList: any;

  AddSrvAction: any;
  AddSrvAddInsAction: any;
  AddSrvWholeHomeDVR: any;
  AddSrvRelocateReceiverCount: any;
  AddSrvRelocateDishCount: any;
  AddSrvVisuallyImpaired: any;

  DtsbProductLine: any;
  DtstbIsActive: any;
  DtstbOldValue: any;
  DtstContractId: any;

  dtvmCustomerLine: any;
  dtvmPropertyContractType: any;
  dtvmDtvActType: any;
  dtvmOldCustLine: any;
  dtvmDealerCode: any;
  dtvmPropContrTyp: any;
  dtvmOldDealerCode: any;
  dtvmDealerAcType: any;
  dtvmOldDtvActType: any;
  dtvmOldDealerActType: any;
  dtvmOldPropContType: any;
  dtvmContractId: any;
  dtvmAdultContractRestriction: any;

  dtgpContractId: any;
  dtcpContractId: any;
  attdvContractId: any;

  dtacrdIsInclude: any;
  dtacrdAction: any;
  dtacrdPrdoductLine: any;

  dtvbvpPartnerName: any;
  dtvbvpPartnerId: any;
  dtvbvpAction: any;

  dttAction: any;
  dttCountyFIPS: any;
  dttD2LiteEligibility: any;
  dttmMDUConnectedProperty: any;
  dttDealerRestrictedPropertyIndicator: any;
  dttMRVIndicator: any;
  dttSWMIndicator: any;
  dtt4kService: any;
  dttmpeg4RegionIndicator: any;
  dttgenieGen1Indicator: any;
  dtvmReasonCode: any;
  dtvmAction: any;
  dtvmIstallationType: any;
  dtvmTechDispatchIndicator: any;
  dtvmShippingIndicator: any;
  dtwbAction: any;
  dtvAttDv: any;
  BaseProgramDtv: any;
  dtvHDAccessIndicator: any;

  nadModels: any;
  selectedNti: any;
  omsOrderAction: any;

  changedDropdownValues3: any;

  constructor(private modalService: NgbModal, private store: Store<HeaderState>) {
    this.checkOption1 = this.checkBoxValue1.map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption2 = this.checkBoxValue2.map(x => new CheckboxItem(x.id, x.name, false));
    this.checkOption3 = this.checkBoxValue3.map(x => new CheckboxItem(x.id, x.name, false));
  }

  ngOnInit() {
    this.dropdownValues8.reverse();
    this.getTabData();

    this.selectedSuperSede = "NA"
    // this.selectedInternalWapInd = this.dropdownValues6[0].label;
    // this.selectedModel = this.dropdownValues1[0].label;
    // this.selectedCC = this.dropdownValues11[0].label;
    // this.selectedLUStatus = this.dropdownValues9[0].label;
    // this.selectedAction = this.dropdownValues3[0].label;

    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        // this.CircuitIdVal = storeObj['circuitId'];
        this.selectedNti = storeObj['nti'];
        // this.enviornmentVal = storeObj['enviornment']
        this.omsOrderAction = storeObj['orderAction'];
        if (this.omsOrderAction == "CH") {
          this.check3Disabled = false;
          this.changedDropdownValues3 = this.dropdownValues3[2].label;
        } else {
          this.check3Disabled = true;
          this.changedDropdownValues3 = this.dropdownValues3[0].label;
        }
      })
    this.getNADModel();
    this.dropdownValues1 = this.nadModels;
    this.dropdownValues5 = this.nadModels;
    this.selectedModelData1 = this.dropdownValues1[0].data1;
    this.selectedModelData2 = this.dropdownValues1[0].data2;
    this.selectedPrimaryModelData1 = this.dropdownValues5[0].data1;
    this.selectedPrimaryModelData2 = this.dropdownValues5[0].data2;

    this.selectedUSPIndicator = this.dropdownValues2[1].label;
    this.selectedInternalWapInd = this.dropdownValues6[1].label;
  }

  // ngOnChanges() {
  //   this.dropdownValues1 = this.nadValue
  // }

  ngOnChanges(changes: { [property: string]: SimpleChange }) {
    // Extract changes to the input property by its name
    let change: SimpleChange = changes['data'];

    // Whenever the data in the parent changes, this method gets triggered. You 
    // can act on the changes here. You will have both the previous value and the 
    // current value here.
  }

  ccChange() {
    // if ((this.selectedCC == "Y") && (this.selectedOrder == "CW")) {
    //   this.disableText1 = false;
    //   // LUStatus.selectedIndex = 0;
    //   this.disabledDropdown9 = true;
    // } else
    if (this.selectedCC == "Y") {
      this.disableText1 = false;
      this.disabledDropdown9 = false;
    } else {
      this.disableText1 = true;
      this.disabledDropdown9 = true;
    }
  }

  getTabData() {
    //addsrv
    this.AddSrvAction = this.tabContainer?.selectedAddSrvAction
    this.AddSrvAddInsAction = this.tabContainer?.selectedAddInsAction
    this.AddSrvWholeHomeDVR = this.tabContainer?.SelectedWholeHomeDvr;
    this.AddSrvRelocateReceiverCount = this.tabContainer?.selectedRelocateReceiverCount;
    this.AddSrvRelocateDishCount = this.tabContainer?.selectedRelocateDishCount
    this.AddSrvVisuallyImpaired = this.tabContainer?.selectedVisuallyImpaired;

    //dtstb
    this.DtsbProductLine = this.tabContainer?.selectedProductLine;
    this.DtstbIsActive = this.tabContainer?.selectedIsActive;
    this.DtstbOldValue = this.tabContainer?.selectedOldValue;
    this.DtstContractId = this.tabContainer?.textValue29;

    //dtvm
    this.dtvmCustomerLine = this.tabContainer?.selectedCustomerLine
    this.dtvmPropertyContractType = this.tabContainer?.selectedPropertyContractType;
    this.dtvmDtvActType = this.tabContainer?.selectedDtvActTyp;
    this.dtvmOldCustLine = this.tabContainer?.selectedOldCustLine;
    this.dtvmDealerCode = this.tabContainer?.textValue36;
    this.dtvmPropContrTyp = this.tabContainer?.selectedPropContrTyp
    this.dtvmOldDealerCode = this.tabContainer?.textValue37
    this.dtvmDealerAcType = this.tabContainer?.textValue38;
    this.dtvmOldDtvActType = this.tabContainer?.selectedOldDtvActTyp;
    this.dtvmOldDealerActType = this.tabContainer?.textValue39;
    this.dtvmOldPropContType = this.tabContainer?.selectedOldPropContTyp;
    this.dtvmContractId = this.tabContainer?.textValue29;
    this.dtvmAdultContractRestriction = this.tabContainer?.selectedAdultContractRestriction;
    this.dtvmReasonCode = this.tabContainer?.selectedReasonCode;
    this.dtvmAction = this.tabContainer?.selectedAction;
    this.dtvmIstallationType = this.tabContainer?.selectedInstallationType;
    this.dtvmTechDispatchIndicator = this.tabContainer?.selectedTechnicianDispatchIndicator;
    this.dtvmShippingIndicator = this.tabContainer?.selectedShippingIndicator

    //dtgp
    this.dtgpContractId = this.tabContainer?.textValue29;

    //dtcp
    this.dtcpContractId = this.tabContainer?.textValue29;

    //attdv
    this.attdvContractId = this.tabContainer?.textValue29;

    //dtacrd
    this.dtacrdIsInclude = this.tabContainer?.isInclude;
    this.dtacrdAction = this.tabContainer?.selectedAction;
    this.dtacrdPrdoductLine = this.tabContainer?.selectedProductLine;

    //dtvbvp
    this.dtvbvpPartnerName = this.tabContainer?.selectedPartenerName;
    this.dtvbvpAction = this.tabContainer?.selectedAction;
    this.dtvbvpPartnerId = this.tabContainer?.textValue35;

    //dtt
    this.dttAction = this.tabContainer?.selectedAction;
    this.dttCountyFIPS = this.tabContainer?.textValue40;
    this.dttD2LiteEligibility = this.tabContainer?.selectedD2LiteEligibility;
    this.dttmMDUConnectedProperty = this.tabContainer?.selectedMDUCOnnectedProperty;
    this.dttDealerRestrictedPropertyIndicator = this.tabContainer?.selectedDealerRestrictedProperty;
    this.dttMRVIndicator = this.tabContainer?.selectedMRVIndicator;
    this.dttSWMIndicator = this.tabContainer?.selectedSWMIndicator;
    this.dtt4kService = this.tabContainer?.selected4kService;
    this.dttmpeg4RegionIndicator = this.tabContainer?.selectedmpeg4RegieoIndicator;
    this.dttgenieGen1Indicator = this.tabContainer?.selectedgenieGen1Indicator;

    //dtwb
    this.dtwbAction = this.tabContainer?.selectedAction;

    //attdv
    this.dtvAttDv = this.tabContainer?.selectedAction;
    this.BaseProgramDtv = this.tabContainer?.selectedBaseProgramming;
    this.dtvHDAccessIndicator = this.tabContainer?.selectedHDAccessIndicator;
  }

  onCheckChange(value) {
    if (value.indexOf('Stacked Order') != -1) {
      this.configChecked = true
    } else if (value.indexOf('retainedServicesProcessIndicator') != -1) {
      this.selectedretainedServicesProcessIndicator = true;
    } else if (value.indexOf('NAD Swap') != -1) {
      this.selectedNadSwap = true;
    } else {
      this.configChecked = false;
      this.selectedNadSwap = false;
      this.selectedretainedServicesProcessIndicator = false;
    }
    this.checkBoxModel.roles = value;
  }

  getNADModel() {
    if (this.selectedNti == 'FTTN') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNti == 'FTTN-BP') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNti == 'FTTPIP') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNti == 'RGPON') {
      this.nadModels = [{ label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else if (this.selectedNti == 'FTTP-GPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNti == 'FTTC-GPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" }, { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if (this.selectedNti == 'FTTC-EGPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else if (this.selectedNti == 'FTTP-EGPON') {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    }
    //updating speeds for ipdslam
    else if ((this.selectedNti == 'IP-CO') || (this.selectedNti == 'IP-RT')) {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" }, { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3700HGV-B (RG)", data1: "3700HGV-B GATEWAY", data2: "RG", data3: "2Wire" }, { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" }, { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" },
      { label: "5111NV (IG IPDSLAM)", data1: "5111NV-030", data2: "IG", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    }
    //updating speeds for ipdslam bp
    else if ((this.selectedNti == 'IP-CO-BP') || (this.selectedNti == 'IP-RT-BP')) {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" }, { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" }, { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" }, { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" }, { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    } else if ((this.selectedNti == "FTTB-C") || (this.selectedNti == "FTTB-F")) {
      this.nadModels = [{ label: "NVG595 (FBG)", data1: "NVG595", data2: "FBG", data3: "ARRIS" }];
    } else if (this.selectedNti == "FTTP-RGPON") {
      this.nadModels = [{ label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" }, { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" }];
    } else {
      this.nadModels = [{ label: "NVG589 (UVRG-X)", data1: "NVG589", data2: "UVRG-X", data3: "Motorola" },
      { label: "NM55 (MODEM-B)", data1: "NM55", data2: "MODEM-B", data3: "Motorola" },
      { label: "5031NV-030 (IG)", data1: "5031NV-030", data2: "IG", data3: "2Wire" },
      { label: "3801HGV-B (RG)", data1: "3801HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3800HGV-B (RG)", data1: "3800HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3700HGV-B (RG)", data1: "3700HGV-B GATEWAY", data2: "RG", data3: "2Wire" },
      { label: "3600HGV (IG)", data1: "3600HGV GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "NVG510 (IG IPDSLAM)", data1: "NVG510", data2: "IG", data3: "Motorola" },
      { label: "5111NV (IG IPDSLAM)", data1: "5111NV-030", data2: "IG", data3: "2Wire" },
      { label: "2210-02-1ATT (VDSL Modem)", data1: "2210-02-1ATT", data2: "VDSL", data3: "Motorola" },
      { label: "5168NV-110 (UVRG)", data1: "5168NV-110", data2: "UVRG", data3: "2Wire" },
      { label: "i3812V (iNID)", data1: "i3812V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "i3802V (iNID)", data1: "i3802V GATEWAY", data2: "iNID", data3: "2Wire" },
      { label: "NVG595 (FBG)", data1: "NVG595", data2: "FBG", data3: "ARRIS" },
      { label: "NVG599 (UVRG-X)", data1: "NVG599", data2: "UVRG-X", data3: "Motorola" },
      { label: "5268AC (UVRG-X)", data1: "5268AC", data2: "UVRG-X", data3: "2Wire" },
      { label: "2701HGV-B GATEWAY (IG)", data1: "2701HGV-B GATEWAY", data2: "IG", data3: "2Wire" },
      { label: "2310-51 (VDSL)", data1: "2310-51", data2: "VDSL", data3: "Motorola" },
      { label: "NVG3150 (UVRG-X)", data1: "NVG3150", data2: "UVRG-X", data3: "Motorola" },
      { label: "BGW210-700 (ARRIS)", data1: "BGW210-700", data2: "UVRG-X", data3: "ARRIS" },
      { label: "BGW210-700 (Motorola)", data1: "BGW210-700", data2: "UVRG-X", data3: "Motorola" }];
    }
  }

  dropdownChange(val, title) {
    if (title == "internal WAP ind") {
      this.selectedInternalWapInd = val;
    } else if (title == "Model") {
      this.selectedModel = val;
      this.selectedModelData1 = this.dropdownValues1[0].data1;
      this.selectedModelData2 = this.dropdownValues1[0].data2;
      this.selectedModelData3 = this.dropdownValues1[0].data3;
    } else if (title == "Supersede") {
      this.selectedSuperSede = val;
    } else if (title == "CC") {
      this.selectedCC = val;
    } else if (title == "LUStatus") {
      this.selectedLUStatus = val;
    } else if (title == "Action") {
      this.selectedAction = val;
    } else if (title == "USP Indicator") {
      this.selectedUSPIndicator = val;
    } else if (title == "Primary Model") {
      this.selectedPrimaryModel = val;
      this.selectedPrimaryModelData2 = this.dropdownValues5[0].data2;
    }
  }

  NAD_Comp(ban: String, apid: String, reference: String, circuit: String, completion: String,
    install: String, dispatch: String, nadType: String, modelNumber: String,
    primaryModelNumber: String, action: String, move: String, recordOnlyAttribute: String,
    isPrimaryReq: Boolean, Uspindicator: String): String {
    // NAD_Comp(ban:String, apid:String, reference:String, circuit:String, completion:String,
    //   install:String, dispatch:String, modelNumber:String,
    //   primaryModelNumber:String, action:String, move:String):String {

    var nad_Component: String;
    var manufacturer: String;
    var primaryManufacturer: String;

    //oms-message
    // let orderAction = this.omsMessage.selectedOrder;

    if (modelNumber == "2210-02-1ATT" || modelNumber == "NM55") {
      manufacturer = "Motorola";
    } else if (modelNumber.substr(0, 3) == "NVG595") {
      manufacturer = "ARRIS";
    } else if (modelNumber.substr(0, 3) == "NVG") {
      manufacturer = "Motorola";
    } else if (modelNumber.substr(0, 3) == "BGW") {
      manufacturer = "ARRIS";
    } else {
      manufacturer = "2Wire";
    }

    if (primaryModelNumber == "2210-02-1ATT" || primaryModelNumber == "NM55") {
      primaryManufacturer = "Motorola";
    } else if (primaryModelNumber.substr(0, 3) == "NVG595") {
      primaryManufacturer = "ARRIS";
    } else if (primaryModelNumber.substr(0, 3) == "NVG") {
      primaryManufacturer = "Motorola";
    } else if (primaryModelNumber.substr(0, 3) == "BGW") {
      primaryManufacturer = "ARRIS";
    } else {
      primaryManufacturer = "2Wire";
    }

    var rgreset: String;

    // if (orderAction == 'CW') {
    //   rgreset="<bbnmsOrder:attribute>\n"
    //     + "<bbnmsOrder:name>rgReset</bbnmsOrder:name>\n"
    //     + "<bbnmsOrder:value>" + this.hsia.selectedRgReset + "</bbnmsOrder:value>\n"
    //     + "</bbnmsOrder:attribute>\n";
    // } else {
    //   rgreset="";
    // }
    var primaryNAD: String;

    if (isPrimaryReq == true) {
      primaryNAD = "<bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:name>primarymaterialCode</bbnmsOrder:name>\n"
        + "<bbnmsOrder:value>100000611</bbnmsOrder:value>\n"
        + "</bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:name>primarymodelNumber</bbnmsOrder:name>\n"
        + "<bbnmsOrder:value>" + primaryModelNumber + "</bbnmsOrder:value>\n"
        + "</bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:name>primarymanufacturer</bbnmsOrder:name>\n"
        + "<bbnmsOrder:value>" + primaryManufacturer + "</bbnmsOrder:value>\n"
        + "</bbnmsOrder:attribute>\n";
    } else {
      primaryNAD = "";
    }

    nad_Component = "<bbnmsOrder:component>\n"
      + "<bbnmsOrder:assignedProductId>" + apid + "</bbnmsOrder:assignedProductId>\n"
      + "<bbnmsOrder:serviceType>RG</bbnmsOrder:serviceType>\n"
      + action
      + "<bbnmsOrder:attributeList>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>APID</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + apid + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>versionID</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + (reference.charCodeAt(0) - 64) + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>relationID</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>2000006</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>amssDisplaySequence</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>2900</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>amssRefresh</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>No</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + rgreset
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>actualMaterialCode</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>000000000100000283</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>actualMaterialDescription</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Generic RG BOM</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>availableForSelfInstall</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>NA</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>criticalFullfillment</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>No</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>DefaultDisplayOrder</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>100</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>sapOrderNumber</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>0002070395</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>sapOrderStatus</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Shipped</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>EligibleForBundleDiscount</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>N</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>fttxInput</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>FTTX</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>fulfillmentIndicator</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Yes</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>installationType</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + install + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + primaryNAD
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>materialCode</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>100000610</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>modelNumber</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + modelNumber + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>manufacturer</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + manufacturer + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>USPIndicator</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + Uspindicator + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>internalWAPIndicator</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + this.selectedInternalWapInd + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>NADExist</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>UNKNOWN</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>rgId</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + circuit + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>NADKitType</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>UNKNOWN</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>RGReplacementFlag</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>No</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>nadType</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + nadType + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>numAtaPorts</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>2</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>ProdType</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>RG</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>purchaseTerms</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Rent</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>RMA</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Y</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>reasonCode</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Unknown</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + recordOnlyAttribute
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>completionIndicator</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + completion + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>offerSalesMode</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Lead</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>shipmentType</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>NotApplicable</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>shippingDate</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>2008-10-25T00:00:00</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>shippingIndicator</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Tech</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>technicianDispatchIndicator</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + dispatch + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>hideComponent</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Yes</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>inventoryComponentType</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>RG</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>isSendToTeLS</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>Child</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>removeComponent</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>No</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>moveIndicator</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + move + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "</bbnmsOrder:attributeList>\n"
      + "</bbnmsOrder:component>\n";

    return nad_Component;
  }

  SetStackedOrderData_DTV() {
    this.relatedOrderInfo_DTV = "<bbnmsOrder:relatedOrderInfoList>\n"
      + "<bbnmsOrder:relatedOrderInfo>\n"
      + "<bbnmsOrder:orderNumber>123455</bbnmsOrder:orderNumber>\n"
      + "<bbnmsOrder:originalOrderActionId>3423232</bbnmsOrder:originalOrderActionId>\n"
      + "<bbnmsOrder:orderActionType>PR</bbnmsOrder:orderActionType>\n"
      + "<bbnmsOrder:orderActionSubType>NA</bbnmsOrder:orderActionSubType>\n"
      + "<bbnmsOrder:orderActionReferenceNumber>12345A</bbnmsOrder:orderActionReferenceNumber>\n"
      + "<bbnmsOrder:orderCreationDate>T01:01:01.0Z</bbnmsOrder:orderCreationDate>\n"
      + "<bbnmsOrder:orderActionReasonCode>aa</bbnmsOrder:orderActionReasonCode>\n"
      + "<bbnmsOrder:dueDate>T22:59:59.0Z</bbnmsOrder:dueDate>\n"
      + "<bbnmsOrder:orderRanking>1</bbnmsOrder:orderRanking>\n"
      + "</bbnmsOrder:relatedOrderInfo>\n"
      + "<bbnmsOrder:relatedOrderInfo>\n"
      + "<bbnmsOrder:orderNumber>1234552</bbnmsOrder:orderNumber>\n"
      + "<bbnmsOrder:originalOrderActionId>1234552</bbnmsOrder:originalOrderActionId>\n"
      + "<bbnmsOrder:orderActionType>PR</bbnmsOrder:orderActionType>\n"
      + "<bbnmsOrder:orderActionSubType>NA</bbnmsOrder:orderActionSubType>\n"
      + "<bbnmsOrder:orderActionReferenceNumber>1234552A</bbnmsOrder:orderActionReferenceNumber>\n"
      + "<bbnmsOrder:orderCreationDate>T02:02:02.0Z</bbnmsOrder:orderCreationDate>\n"
      + "<bbnmsOrder:orderActionReasonCode>aa</bbnmsOrder:orderActionReasonCode>\n"
      + "<bbnmsOrder:dueDate>T23:59:59.0Z</bbnmsOrder:dueDate>\n"
      + "<bbnmsOrder:orderRanking>2</bbnmsOrder:orderRanking>\n"
      + "</bbnmsOrder:relatedOrderInfo>\n"
      + "</bbnmsOrder:relatedOrderInfoList>";

    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = "Stacked Order";
    modalRef.componentInstance.type = "template4";
    modalRef.componentInstance.content = this.relatedOrderInfo_DTV;
  }

  SetDslRetainedServicesList() {
    this.retainedServicesList = "<bbnmsOrder:dslRetainedServicesList>\n"
      + "<bbnmsOrder:dslRetainedServices>\n"
      + "<bbnmsOrder:retainedServiceId>ALL</bbnmsOrder:retainedServiceId>\n"
      + "<bbnmsOrder:retainedServiceType>ADSL</bbnmsOrder:retainedServiceType>\n"
      + "</bbnmsOrder:dslRetainedServices>\n"
      + "</bbnmsOrder:dslRetainedServicesList>\n";

    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = "retained ServicesProviderIndicator";
    modalRef.componentInstance.type = "template4";
    modalRef.componentInstance.content = this.retainedServicesList;
  }
}

