import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Store } from '@ngrx/store';
import { VhoDropdownValues } from 'app/constants/omsMessage.constant';
import { HeaderState } from 'app/components/header/header.state';

@Component({
  selector: 'service-fsp',
  templateUrl: './serviceFsp.component.html',
  styleUrls: ['./serviceFsp.component.css']
})
export class ServiceFspComponent implements OnInit {
  @Input() tabType: string;
  @Input() tabContent: string;
  @Input() scrollContent: string;
  @Input() apid: string;
  @Input() title: string;
  @Input() cmPvType: string;

  textValue1: string = "";
  textValue2: string = "SAM";
  textValue3: string = "123456";
  textValue4: string = "BARKER";
  textValue5: string = "";
  textValue6: string = "123";
  textValue7: string = "Peachtree";
  textValue8: string = "ST";
  textValue9: string = "Atlanta";
  textValue10: string = "GA";
  textValue11: string = "30308";
  textValue11a: string = "1234"
  textValue12: string = "";
  textValue13: string = "";
  textValue14: string = "AUS2TX";
  textValue15: string = "623";
  textValue16: string = "623";
  textValue17: string = "623";
  textValue18: string = "BARKER";
  textValue19: string = "1234";
  textValue20: string = "DEKALB";

  textTitle1: string = "Living Unit Address Id";
  textTitle2: string = "TAR Code";
  textTitle3: string = "PrimaryNpanxx";
  textTitle4: string = "Rate Centre Code";
  textTitle5: string = "Address Id";
  textTitle6: string = "House Number";
  textTitle7: string = "Street Name";
  textTitle8: string = "Street Throughfare";
  textTitle9: string = "City"
  textTitle10: string = "State"
  textTitle11: string = "Postal Code"
  textTitle12: string = "FTTB Building Clli"
  textTitle13: string = "EMT Clli"
  textTitle14: string = "VHO Code";
  textTitle15: string = "DMACode";
  textTitle16: string = "PriNpanxx";
  textTitle17: string = "StreetThrFare";
  textTitle18: string = "RateCenCode";
  textTitle19: string = "postalCodePlus4";
  textTitle20: string = "Country";

  disableText2: boolean = true;

  dropdownValues1: any[] = VhoDropdownValues;
  dropdownTitle1: string = "VHO Code"
  datalist1: string = "datalist";
  selectValue: any = VhoDropdownValues[0].label;

  headerTitle: any = "Service Fsp";

  cvoipTarCode_CM: String;
  cvoipTarCode_PV: String;
  constructor(private store: Store<HeaderState>,) { }

  ngOnInit() {
    if (this.title != undefined) {
      this.headerTitle = this.title
    }
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        if (storeObj['banValue']) {
          this.textValue1 = "LS" + storeObj['banValue'];
          this.textValue5 = storeObj['banValue'];
        }
      })

    if (this.cmPvType == "WLL PV") {
      this.textValue1 = "";
      this.textValue2 = "";
      this.textValue3 = "";
      this.textValue4 = "";
      this.textValue5 = "";
      this.textValue6 = "";
      this.textValue7 = "";
      this.textValue8 = "";
      this.textValue9 = "";
      this.textValue10 = "";
      this.textValue11 = "";
      this.textValue11a = ""
      this.textValue12 = "";
      this.textValue13 = "";
      this.textValue14 = "";
      this.textValue15 = "";
      this.textValue16 = "";
      this.textValue17 = "";
      this.textValue18 = "";
      this.textValue19 = "";
      this.textValue20 = "";
    }
  }

  ngOnChange() {
    console.log(this.apid);
  }

  ServiceFSP(fspPrimaryNpanxx: String, fspWireCenter: String, fttbBuilding: String, emt: String, fspCcid: String, fspLivingUnitAddressId: String,
    fspRateCenterCode: String, fspVhoCode: String, fspTarCode: String, fspHouseNumber: String, fspStreetName: String, fspStreetThoroughfare: String,
    fspCity: String, fspState: String, fspPostalCode: String, fspPostalCodePlus4: String, fspFirstName: String, fspLastName: String,
    fspAddressID: String): String {
    var serviceFSP: String;
    var fbsCllis: String;

    // update to accomodate fbs building clli changes
    if ((fttbBuilding.length > 0) && (this.textValue12.length == 0)) {
      fbsCllis = "<bbnmsOrder:fttbBuildingClli>" + fttbBuilding + "</bbnmsOrder:fttbBuildingClli>\n"
      //	+"<bbnmsOrder:emtClli>"+emt+"</bbnmsOrder:emtClli>\n";
    }
    else if ((this.textValue12.length > 0) && (fttbBuilding.length == 0)) {

      fbsCllis = "<bbnmsOrder:fttbBuildingClli>" + this.textValue12 + "</bbnmsOrder:fttbBuildingClli>\n"
    }
    else {
      fbsCllis = "";
    }

    serviceFSP = "<bbnmsOrder:addressInfo>\n"
      + "<bbnmsOrder:addressType>ServiceFSP</bbnmsOrder:addressType>\n"
      + "<bbnmsOrder:primaryNpanxx>" + fspPrimaryNpanxx + "</bbnmsOrder:primaryNpanxx>\n"
      + "<bbnmsOrder:clli8>" + fspWireCenter + "</bbnmsOrder:clli8>\n"
      + fbsCllis
      + "<bbnmsOrder:region>southeast</bbnmsOrder:region>\n"
      + fspCcid
      + "<bbnmsOrder:livingUnitAddressId>" + fspLivingUnitAddressId + "</bbnmsOrder:livingUnitAddressId>\n"
      + "<bbnmsOrder:rateCenterCode>" + fspRateCenterCode + "</bbnmsOrder:rateCenterCode>\n"
      + "<bbnmsOrder:vhoCode>" + fspVhoCode + "</bbnmsOrder:vhoCode>\n"
      + fspTarCode
      + "<bbnmsOrder:fieldedAddress>\n"
      + "<bbnmsOrder:houseNumber>" + fspHouseNumber + "</bbnmsOrder:houseNumber>\n"
      + "<bbnmsOrder:streetName>" + fspStreetName + "</bbnmsOrder:streetName>\n"
      + "<bbnmsOrder:streetThoroughfare>" + fspStreetThoroughfare + "</bbnmsOrder:streetThoroughfare>\n"
      + "<bbnmsOrder:city>" + fspCity + "</bbnmsOrder:city>\n"
      + "<bbnmsOrder:state>" + fspState + "</bbnmsOrder:state>\n"
      + "<bbnmsOrder:postalCode>" + fspPostalCode + "</bbnmsOrder:postalCode>\n"
      + "<bbnmsOrder:postalCodePlus4>" + fspPostalCodePlus4 + "</bbnmsOrder:postalCodePlus4>\n"
      + "<bbnmsOrder:county>Fulton</bbnmsOrder:county>\n"
      + "<bbnmsOrder:country>USA</bbnmsOrder:country>\n"
      + "<bbnmsOrder:structureType>BLDG</bbnmsOrder:structureType>\n"
      + "<bbnmsOrder:structureValue>2</bbnmsOrder:structureValue>\n"
      + "<bbnmsOrder:levelType>FLR</bbnmsOrder:levelType>\n"
      + "<bbnmsOrder:levelValue>1</bbnmsOrder:levelValue>\n"
      + "<bbnmsOrder:unitType>APT</bbnmsOrder:unitType>\n"
      + "<bbnmsOrder:unitValue>1123</bbnmsOrder:unitValue>\n"
      + "<bbnmsOrder:originalStreetDirection>South</bbnmsOrder:originalStreetDirection>\n"
      + "<bbnmsOrder:originalStreetNameSuffix>suffix</bbnmsOrder:originalStreetNameSuffix>\n"
      + "<bbnmsOrder:cassAddressLines>\n"
      + "<bbnmsOrder:addressLine>" + fspFirstName + " " + fspLastName + "</bbnmsOrder:addressLine>\n"
      + "<bbnmsOrder:addressLine>" + fspHouseNumber + " " + fspStreetName + " " + fspStreetThoroughfare + "</bbnmsOrder:addressLine>\n"
      + "<bbnmsOrder:addressLine>" + fspCity + " " + fspState + "  " + fspPostalCode + "-" + fspPostalCodePlus4 + "</bbnmsOrder:addressLine>\n"
      + "</bbnmsOrder:cassAddressLines>\n"
      + "<bbnmsOrder:cassAdditionalInfo>String</bbnmsOrder:cassAdditionalInfo>\n"
      + "<bbnmsOrder:additionalInfo>String</bbnmsOrder:additionalInfo>\n"
      + "<bbnmsOrder:countryCode>String</bbnmsOrder:countryCode>\n"
      + "<bbnmsOrder:cityCode>String</bbnmsOrder:cityCode>\n"
      + "<bbnmsOrder:serviceLocationName>String</bbnmsOrder:serviceLocationName>\n"
      + "<bbnmsOrder:addressId>" + fspAddressID + "</bbnmsOrder:addressId>\n"
      + "<bbnmsOrder:aliasName>String</bbnmsOrder:aliasName>\n"
      + "<bbnmsOrder:attention>String</bbnmsOrder:attention>\n"
      + "</bbnmsOrder:fieldedAddress>\n"
      + "</bbnmsOrder:addressInfo>\n";

    return serviceFSP;
  }

  setTarCode() {
    //set TAR Code for ServiceFSP
    if (this.textTitle2.length > 0) {
      this.cvoipTarCode_CM = "<bbnmsOrder:tarCode>" + this.textTitle2 + "</bbnmsOrder:tarCode>\n";
    }
    else {
      this.cvoipTarCode_CM = "";
    }
    if (this.textTitle2.length > 0) {
      this.cvoipTarCode_PV = "<bbnmsOrder:tarCode>" + this.textTitle2 + "</bbnmsOrder:tarCode>\n";
    }
    else {
      this.cvoipTarCode_PV = "";
    }
  }

}

