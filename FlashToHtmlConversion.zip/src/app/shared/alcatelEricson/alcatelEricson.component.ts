import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { fttnActionDropdown, IPCOBPTypeDropdown, ltsDropdown, pgsDropdown, regionDropdown } from 'app/constants/alcatel.constant';
import { alphabetDropdown } from 'app/constants/global.constant';
import { NtiDropdownValues } from 'app/constants/header.constant';
import { VhoDropdownValues } from 'app/constants/omsMessage.constant';
import { ModelBoxComponent } from '../model-box/model-box.component';

@Component({
  selector: 'alcatel-ericson',
  templateUrl: './alcatelEricson.component.html',
  styleUrls: ['./alcatelEricson.component.css']
})
export class AlcatelEricsonComponent implements OnInit {
  @Input() title: string;
  @Input() containerCls: string;
  @Input() tabSelect: string;
  @Input() disableContainer: boolean;
  @Input() WebSim: string;

  textTitle1: string = "ONU";
  textTitle2: string = "OLT";
  textTitle3: string = "Rack";
  textTitle4: string = "Shelf";
  textTitle5: string = "Slot";
  textTitle6: string = "Port";
  textTitle7: string = "Cable Name";
  textTitle8: string = "Pair";
  textTitle9: string = "SOAC Order #";
  textTitle10: string = "OLTTID";
  textTitle11: string = "SFU";
  textTitle12: string = "TRE";
  textTitle13: string = "Port 1";
  textTitle14: string = "Port 2";
  textTitle15: string = "Primary Pair";
  textTitle16: string = "Secondary Pair";
  textTitle17: string = "MDU";
  textTitle18: string = "MDU Slot";
  textTitle19: string = "MDU Port";
  textTitle20: string = "DPU Node";
  textTitle21: string = "OLTID";
  textTitle22: string = "DPU Port Acc Id";
  textTitle23: string = "OLTAccessId";
  textTitle24: string = "CM Ckt Id";
  textTitle25: string = "Order Number";
  textTitle26: string = "IF2";
  textTitle27: string = "Old Ont AID";
  textTitle28: string = "Old OLTTID";
  textTitle29: string = "Old MDU Slot";
  textTitle30: string = "Old MDU Port";
  textTitle31: string = "Old Slot";
  textTitle32: string = "Old Port";
  textTitle33: string = "Old SFU";

  textValue1: string = "";
  textValue2: string = "";
  textValue3: string = "";
  textValue4: string = "";
  textValue5: string = "";
  textValue6: string = "";
  textValue7: string = "";
  textValue8: string = "";
  textValue9: string = "";
  textValue10: string = "";
  textValue11: string = "";
  textValue12: string = "I";
  textValue13: string = "";
  textValue14: string = "";
  textValue15: string = "";
  textValue16: string = "";
  textValue17: string = "";
  textValue18: string = "";
  textValue19: string = "";
  textValue20: string = "";
  textValue21: string = "";
  textValue22: string = "";
  textValue23: string = "";
  textValue24: string = "";
  textValue25: string = "";
  textValue26: string = "";
  textValue27: string = "";
  textValue28: string = "";
  textValue29: string = "";
  textValue30: string = "";
  textValue31: string = "";
  textValue32: string = "";
  textValue33: string = "";

  toolTip7: any = "example: 2224FN"

  dropdownValues1: any[] = pgsDropdown;
  dropdownValues2: any[] = ltsDropdown;
  dropdownValues3: any[] = fttnActionDropdown;
  dropdownValues4: any[] = alphabetDropdown;
  dropdownValues5: any[] = regionDropdown;
  dropdownValues6: any[] = IPCOBPTypeDropdown;
  dropdownValues7: any[] = NtiDropdownValues;

  dropdownTitle1: string = "PGS"
  dropdownTitle2: string = "LTS"
  dropdownTitle3: string = ""
  dropdownTitle4: string = "Suffix"
  dropdownTitle5: string = "Region"
  dropdownTitle6: string = "Type"
  dropdownTitle7: string = "Old NTI";

  selectedType: any;
  selectedSuffix: any;
  selectedPgs: any;
  selectedLts: any;
  selectedRegion: any;
  selectedOldNti: any;
  selectedAction: any;

  ntiValue: any;
  circuitId: any;
  banValue: any;
  wireCenter: any;

  SOAC_Assignment: String
  SOAC_Circuit: String;
  SOAC_Circuit2: String;
  pattern: RegExp = /(\/)/g;
  assignmentLines: String;

  constructor(private store: Store<HeaderState>,
    private modalService: NgbModal) { }

  ngOnInit() {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.ntiValue = storeObj['nti'];
        this.circuitId = storeObj['circuitId'];
        this.banValue = storeObj['banValue'];
        this.wireCenter = storeObj['wireCenter'];
      });
    this.selectedPgs = this.dropdownValues1[0].label;
    this.selectedLts = this.dropdownValues2[0].label;
    this.selectedAction = this.dropdownValues3[0].label;
    this.selectedSuffix = this.dropdownValues4[0].label;
    this.selectedRegion = this.dropdownValues5[0].label;
    this.selectedType = this.dropdownValues6[0].label;
    this.selectedOldNti = this.dropdownValues7[0].label;
    this.SOAC_Circuit = this.circuitId;
    this.SOAC_Circuit2 = this.circuitId;
    if (this.title == 'FTTN CO DSLAM/IP-CO' || this.title == "FTTNBP CO DSLAM") {
      this.textValue12 = "L";
    }
  }

  selectedDropdownChange(title, val) {
    if (title == "Type") {
      if (val == "Lineshare POTS Primary") {
        this.selectedType = "Lineshare1";
      } else if (val == "Lineshare POTS Both") {
        this.selectedType = "Lineshare2";
      } else {
        this.selectedType = val;
      }
    } else if (title == "Suffix") {
      this.selectedSuffix = val;
    } else if (title == "Region") {
      this.selectedRegion = val;
    } else if (title == "Old NTI") {
      this.selectedOldNti = val;
    } else if (title == "LTS") {
      this.selectedLts = val;
    } else if (title == "PGS") {
      this.selectedPgs = val;
    } else {
      this.selectedAction = val
    }
  }

  createL1Assignment(title) {
    console.log(title);

    let xml, fileName;
    const modalRef = this.modalService.open(ModelBoxComponent);

    if (title == 'IP-CO-BP') {
      if (this.selectedSuffix == 'L1 Assignment') {
        fileName = `SendFiberServiceFacilityAssignmentNotification_ ${this.WebSim}.xml`;
      } else {
        fileName = `SendFiberServiceFacilityUpdateNotification_ ${this.WebSim}.xml`;
      }
      xml = this.IPDSLAMBP_CO_L1_Assignment(this.selectedAction);
    } else if (title == 'FTTNBP CO DSLAM') {
      if (this.selectedSuffix == 'L1 Assignment') {
        fileName = `SendFiberServiceFacilityAssignmentNotification_ ${this.WebSim}.xml`;
      } else {
        fileName = `SendFiberServiceFacilityUpdateNotification_ ${this.WebSim}.xml`;
      }
      this.textValue12 = "L";
      xml = this.FTTNBP_CO_L1_Assignment(this.selectedAction)
    } else if (title == 'RGPON') {
      if (this.tabSelect == 'mpcAlcatel') {
        fileName = `${this.banValue}_MPC_RGPON.xml`;
        xml = this.RGPON_MPC()
      } else {
        fileName = `rgpon_ ${this.WebSim}.xml`;
        xml = this.RGPON_L1_Assignment()
      }
    } else if (title == 'FTTPIP') {
      if (this.tabSelect == 'mpcAlcatel') {
        fileName = `${this.banValue}_fttpip_MPC.xml`;
        xml = this.FTTPIP_MPC()
      } else {
        fileName = `fttpip_ ${this.WebSim}.xml`;
        xml = this.FTTPIP_L1_Assignment_Granite();
      }
    } else if (title == 'FTTP-GPON') {
      if (this.tabSelect == 'mpcAlcatel') {
        fileName = `${this.banValue}_MPC_GPON.xml`;
        xml = this.GPON_MPC()
      } else {
        fileName = `gpon_ ${this.WebSim}.xml`;
        xml = this.GPON_L1_Assignment()
      }
    } else if (title == 'FTTN CO DSLAM/IP-CO') {
      if (this.tabSelect == 'mpcAlcatel') {
        fileName = `${this.banValue}_MPC.xml`;
        xml = this.FTTN_CO_MPC()
      } else {
        if (this.selectedSuffix == 'L1 Assignment') {
          fileName = `SendFiberServiceFacilityAssignmentNotification_ ${this.WebSim}.xml`;
        } else {
          fileName = `SendFiberServiceFacilityUpdateNotification_ ${this.WebSim}.xml`;
        }
        xml = this.FTTN_CO_L1_Assignment(this.selectedAction)
      }
      this.textValue12 = "L";
    } else if (title == 'FTTC-GPON') {
      if (this.tabSelect == 'mpcAlcatel') {
        fileName = `${this.banValue}_fttcgpon_MPC.xml`;
        xml = this.FTTCGPON_MPC();
      } else {
        fileName = `fttcgpon_ ${this.WebSim}.xml`;
        xml = this.FTTCGPON_L1_Assignment_Granite();
      }
    } else if (title == 'QNI g.Fast') {
      fileName = `gpon_ ${this.WebSim}.xml`;
      xml = this.GFAST_L1_Assignment()
    } else if (title == 'FX TO GPON') {
      fileName = `fxgpon_ ${this.WebSim}.xml`;
      xml = this.FXGPON_L1_Assignment()
    } else if (title == 'FTTN-BP Remote DSLAM/IP-RT') {
      if (this.selectedSuffix == 'L1 Assignment') {
        fileName = `SendFiberServiceFacilityAssignmentNotification_ ${this.WebSim}.xml`;
      } else {
        fileName = `SendFiberServiceFacilityUpdateNotification_ ${this.WebSim}.xml`;
      }
      xml = this.FTTNBP_L1_Assignment(this.selectedAction);
    } else if (title == 'FTTN Remote DSLAM/IP-RT') {
      if (this.selectedSuffix == 'L1 Assignment') {
        fileName = `SendFiberServiceFacilityAssignmentNotification_ ${this.WebSim}.xml`;
      } else {
        fileName = `SendFiberServiceFacilityUpdateNotification_ ${this.WebSim}.xml`;
      }
      xml = this.FTTN_L1_Assignment(this.selectedAction);
    } else if (title == 'FTTP-EGPON') {
      if (this.tabSelect == 'mpcEricson') {
        fileName = `${this.banValue}_MPC_EFTTP.xml`;
        xml = this.EFTTP_MPC()
      } else {
        fileName = `efttp_ ${this.WebSim}.xml`;
        xml = this.EFTTP_L1_Assignment();
      }
    } else if (title == 'FTTC-EGPON') {
      if (this.tabSelect == 'mpcEricson') {
        fileName = `${this.banValue}_MPC_EFTTC.xml`;
        xml = this.EFTTC_MPC()
      } else {
        fileName = `efttc_ ${this.WebSim}.xml`;
        xml = this.EFTTC_L1_Assignment();
      }
    } else if (title == 'FTTN/FTTN-BP Remote DSLAM/IP-RT') {
      fileName = `${this.banValue}_MPC.xml`;
      xml = this.FTTN_MPC();
    }
    modalRef.componentInstance.title = "Complete XML Generation"
    modalRef.componentInstance.type = "template2";
    modalRef.componentInstance.content = xml;
    modalRef.componentInstance.fileName = fileName;
  }

  //IP-CO-BP Function
  IPDSLAMBP_CO_L1_Assignment(action): String {
    this.SOAC_Circuit = this.SOAC_Circuit.replace(this.pattern, ".");
    this.SOAC_Circuit2 = this.SOAC_Circuit2.replace(this.pattern, ".");
    this.SOAC_Circuit2 = this.SOAC_Circuit2.replace("..", ".2.");

    if (this.selectedType == "Dry Loop") {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA   1 W MOUNTAIN/LOC UNIT 307</item>\n"
        + "<item>     /RZ 13</item>\n"
        + "<item>IOE  NR/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue13 + "</item>\n"
        + "<item>     /ECLI FYVLARHIO0A010103081</item>\n"
        + "<item>G2   WC 479 442</item>\n"
        + "<item>IF1  /CA 9/PR 202/DF F13-00-</item>\n"
        + "<item>     03U07-1-02/PRQ Y/BP 2/OBP</item>\n"
        + "<item>     860/TEA RB 21 W MOUNTAIN;</item>\n"
        + "<item>     PXJ/BCF BP 2 TEA RB 21 W</item>\n"
        + "<item>     MOUNTAIN/TPR 430302/RMTE</item>\n"
        + "<item>     4702308-2,EAC 1</item>\n"
        + "<item>IF2  /CA 21WM/PR 860/BP 71/TEA I</item>\n"
        + "<item>     1-0.1 W MOUNTAIN; CIW/RMTE</item>\n"
        + "<item>     428610-1,4702308-2</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit2 + "</item>\n"
        + "<item>FA   1 W MOUNTAIN/LOC UNIT 307</item>\n"
        + "<item>     /RZ 13</item>\n"
        + "<item>IOE  NR/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue14 + "</item>\n"
        + "<item>     /ECLI FYVLARHIO0A010103081</item>\n"
        + "<item>G2   WC 479 442</item>\n"
        + "<item>IF1  /CA 9/PR 1354/DF F23-16-</item>\n"
        + "<item>     03L04-3-04/PRQ Y/BP 104/OBP</item>\n"
        + "<item>     876/TEA RB 21 W MOUNTAIN;</item>\n"
        + "<item>     PXJ/BCF BP 104 TEA RB 21 W</item>\n"
        + "<item>     MOUNTAIN/TPR 430302/RMTE</item>\n"
        + "<item>     4702308-2,EAC 1</item>\n"
        + "<item>IF2  /CA 21WM/PR 876/BP 87/TEA I</item>\n"
        + "<item>     1-0.1 W MOUNTAIN; CIW/RMTE</item>\n"
        + "<item>     428610-1,4702308-2</item>\n"
        + "</assignmentLines>\n";
    } else if (this.selectedType == "Lineshare1") {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA   712 ROCKWOOD TR/RZ 13</item>\n"
        + "<item>IOE  AA31-0-11-22/EXK 479 442/TN</item>\n"
        + "<item>     479 521-8656/LPS/DF F13-07-</item>\n"
        + "<item>     06L14-4-07/TRE " + this.textValue12 + "-</item>\n"
        + "<item>     " + this.textValue5 + "-" + this.textValue13 + "/ECLI</item>\n"
        + "<item>     FYVLARHIOOA010105031</item>\n"
        + "<item>G2   WC 479 442</item>\n"
        + "<item>IF1  /CA 28/PR 1101/DF F13-08-</item>\n"
        + "<item>     07U01-1-01/PRQ Y/BP 1/OBP</item>\n"
        + "<item>     102/TEA FB 600 E PROSPECT;</item>\n"
        + "<item>     EXJ/TPR 526302/RMTE 28,1241-</item>\n"
        + "<item>     1250 BZ D434149-1,D435037-1,</item>\n"
        + "<item>     4065736-1</item>\n"
        + "<item>IF2  /CA 600P/PR 102/BP 2/TEA F</item>\n"
        + "<item>     712 ROCKWOOD TR; CDW/RMTE</item>\n"
        + "<item>     D433586-2</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit2 + "</item>\n"
        + "<item>FA   712 ROCKWOOD TR/RZ 13</item>\n"
        + "<item>IOE  NR/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue14 + "</item>\n"
        + "<item>     /ECLI FYVLARHIOOA010105031</item>\n"
        + "<item>G2   WC 479 442</item>\n"
        + "<item>IF1  /CA 28/PR 1128/DF F13-08-</item>\n"
        + "<item>     07U01-2-03/PRQ Y/BP 28/OBP</item>\n"
        + "<item>     104/TEA FB 600 E PROSPECT;</item>\n"
        + "<item>     PXJ/BCF BP 28 TEA FB 600 E</item>\n"
        + "<item>     PROSPECT/TPR 526302/RMTE 28,</item>\n"
        + "<item>     D435037-1,4065736-1</item>\n"
        + "<item>IF2  /CA 600P/PR 104/BP 4/TEA F</item>\n"
        + "<item>     712 ROCKWOOD TR; CDW/RMTE</item>\n"
        + "<item>     D433586-2</item>\n"
        + "</assignmentLines>\n";
    } else if (this.selectedType == "Lineshare2") {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA   712 ROCKWOOD TR/RZ 13</item>\n"
        + "<item>IOE  AA31-0-11-22/EXK 479 442/TN</item>\n"
        + "<item>     479 521-8656/LPS/DF F13-07-</item>\n"
        + "<item>     06L14-4-07/TRE " + this.textValue12 + "-</item>\n"
        + "<item>     " + this.textValue5 + "-" + this.textValue13 + "/ECLI</item>\n"
        + "<item>     FYVLARHIOOA010105031</item>\n"
        + "<item>G2   WC 479 442</item>\n"
        + "<item>IF1  /CA 28/PR 1101/DF F13-08-</item>\n"
        + "<item>     07U01-1-01/PRQ Y/BP 1/OBP</item>\n"
        + "<item>     102/TEA FB 600 E PROSPECT;</item>\n"
        + "<item>     EXJ/TPR 526302/RMTE 28,1241-</item>\n"
        + "<item>     1250 BZ D434149-1,D435037-1,</item>\n"
        + "<item>     4065736-1</item>\n"
        + "<item>IF2  /CA 600P/PR 102/BP 2/TEA F</item>\n"
        + "<item>     712 ROCKWOOD TR; CDW/RMTE</item>\n"
        + "<item>     D433586-2</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit2 + "</item>\n"
        + "<item>FA   712 ROCKWOOD TR/RZ 13</item>\n"
        + "<item>IOE  AA31-0-09-23/EXK 479 442/TN</item>\n"
        + "<item>     479 521-8657/LPS/DF F13-07-</item>\n"
        + "<item>     06L14-4-07/TRE " + this.textValue12 + "-</item>\n"
        + "<item>     " + this.textValue5 + "-" + this.textValue14 + "/ECLI</item>\n"
        + "<item>     FYVLARHIOOA010105031</item>\n"
        + "<item>G2   WC 479 442</item>\n"
        + "<item>IF1  /CA 28/PR 1128/DF F13-08-</item>\n"
        + "<item>     07U01-2-03/PRQ Y/BP 28/OBP</item>\n"
        + "<item>     104/TEA FB 600 E PROSPECT;</item>\n"
        + "<item>     EXJ/BCF BP 28 TEA FB 600 E</item>\n"
        + "<item>     PROSPECT/TPR 526302/RMTE 28,</item>\n"
        + "<item>     D435037-1,4065736-1</item>\n"
        + "<item>IF2  /CA 600P/PR 104/BP 4/TEA F</item>\n"
        + "<item>     712 ROCKWOOD TR; CDW/RMTE</item>\n"
        + "<item>     D433586-2</item>\n"
        + "</assignmentLines>\n";
    } else if (this.selectedType == "Regular") {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA   400 HUMMER DR/LOC FLR 1; UNIT</item>\n"
        + "<item>     C/RT 5113/RZ 13</item>\n"
        + "<item>*IOE  AA03-0-17-25/EXK 217 524/TN</item>\n"
        + "<item>     217 381-0207/LPS/DF F30-02-</item>\n"
        + "<item>     021F/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue13 + "</item>\n"
        + "<item>*ITIE  /CA SLA01/PR 4</item>\n"
        + "<item>ITIE  /CA SLA01/PR 4368</item>\n"
        + "<item>G2   WC 217 522/CT</item>\n"
        + "<item>IF1  /CA 2/PR 1208/DF F30-01-004V</item>\n"
        + "<item>     /PRQ N/BP 8/TEA IT 222 S</item>\n"
        + "<item>     COLLEGE; CIW/TPR 511404/RMTE</item>\n"
        + "<item>     JORDAN BLDG/RMKP LIGHTSPEED</item>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit2 + "</item>\n"
        + "<item>FA   400 HUMMER DR/LOC FLR 1; UNIT</item>\n"
        + "<item>     C/RT 5113/RZ 13</item>\n"
        + "<item>*IOE  AA03-0-17-25/EXK 217 524/TN</item>\n"
        + "<item>      217 381-0207/LPS/DF F30-02-</item>\n"
        + "<item>      021F/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue14 + "</item>\n"
        + "<item>*ITIE  /CA SLA01/PR 4</item>\n"
        + "<item>ITIE  /CA SLA01/PR 4368</item>\n"
        + "<item>G2   WC 217 522/CT</item>\n"
        + "<item>IF1  /CA 2/PR 1208/DF F30-01-004V</item>\n"
        + "<item>     /PRQ N/BP 8/TEA IT 222 S</item>\n"
        + "<item>     COLLEGE; CIW/TPR 511404/RMTE</item>\n"
        + "<item>     JORDAN BLDG/RMKP LIGHTSPEED</item>\n"
        + "</assignmentLines>\n";
    } else {
      this.assignmentLines = "";
    }

    this.SOAC_Assignment = this.csinmAssignment(action, this.assignmentLines);

    /* var soacAssignmentXML:XML = new XML(SOAC_Assignment); */
    return this.SOAC_Assignment;
  }

  //FTTNBP CO DSLAM Function
  FTTNBP_CO_L1_Assignment(action: String): String {
    this.SOAC_Circuit = this.SOAC_Circuit.replace(this.pattern, ".");
    this.SOAC_Circuit2 = this.SOAC_Circuit2.replace(this.pattern, ".");
    this.SOAC_Circuit2 = this.SOAC_Circuit2.replace("..", ".2.");

    this.assignmentLines = "<SoacServiceOrder>\n"
      + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
      + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
      + "</SoacServiceOrder>\n"
      + "<assignmentLines>\n"
      + "<item>---ASGM</item>\n"
      + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
      + "<item>FA   400 HUMMER DR/LOC FLR 1; UNIT</item>\n"
      + "<item>     C/RT 5113/RZ 13</item>\n"
      + "<item>*IOE AA03-0-17-25/EXK 217 524/TN</item>\n"
      + "<item>     217 381-0207/LPS/DF F30-02-</item>\n"
      + "<item>     021F/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue13 + "</item>\n"
      + "<item>*ITIE /CA SLA01/PR 3692</item>\n"
      + "<item>ITIE /CA SLA01/PR 4368 </item>\n"
      + "<item>G2  WC 217 522/CT</item>\n"
      + "<item>IF1  /CA 2/PR 1208/DF F30-01-004V</item>\n"
      + "<item>     /PRQ N/BP 8/TEA IT 222 S </item>\n"
      + "<item>     COLLEGE; CIW/TPR 511404/RMTE</item>\n"
      + "<item>     JORDAN BLDG/RMKP LIGHTSPEED</item>\n"
      + "<item>G1  CLS " + this.SOAC_Circuit2 + "</item>\n"
      + "<item>FA  400 HUMMER DR/LOC FLR 1; UNIT</item>\n"
      + "<item>     C/RT 5113/RZ 13</item>\n"
      + "<item>*IOE AA03-0-17-25/EXK 217 524/TN</item>\n"
      + "<item>     217 381-0207/LPS/DF F30-02-</item>\n"
      + "<item>     021F/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue14 + "</item>\n"
      + "<item>*ITIE  /CA SLA01/PR 3692</item>\n"
      + "<item>ITIE  /CA SLA01/PR 4368 </item>\n"
      + "<item>G2  WC 217 522/CT</item>\n"
      + "<item>IF1  /CA 2/PR 1208/DF F30-01-004V</item>\n"
      + "<item>     /PRQ N/BP 8/TEA IT 222 S </item>\n"
      + "<item>     COLLEGE; CIW/TPR 511404/RMTE</item>\n"
      + "<item>     JORDAN BLDG/RMKP LIGHTSPEED</item>\n"
      + "</assignmentLines>\n"

    this.SOAC_Assignment = this.csinmAssignment(action, this.assignmentLines);

    return this.SOAC_Assignment;

  }

  //RGPON "MPC" Function
  RGPON_MPC() {
    var Granite_Assignment;
    var slotName: String = this.textValue5;

    if (slotName.length == 1) {
      slotName = "0" + slotName;
    }

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi:schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>14.0 < /schema_version>`
      + `< GroupREC >`
      + `<path>`
      + `<item>`
      + `<ID>${this.circuitId} / VDSL < /ID>`
      + `< category > VDSL < /category>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< AsideSite >`
      + `<siteType>REMOTE TERM < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 MDU < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > I 1498 ARAPAHO CEV TERM B PFP < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< state > TX < /state>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>SFU < /siteType>`
      + `< name > 2309 TRELLIS PL < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > 233 TRELLIS PL EW BLDG 36 MDU < /parentSiteName>`
      + `< street > TRELLIS PL < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > 233 TRELLIS PL EW BLDG 36 MDU < /elementName>`
      + `< elementCategory > ONU < /elementCategory>`
      + `< slotName > LP - ${this.textValue29} / COMBO - ${this.textValue29} - ${this.textValue30} < /slotName>`
      + `< portName > VDSL - ${this.textValue18} - ${this.textValue19} < /portName>`
      + `< portAccessId > ONTVDSL - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue17} - ${this.textValue29} - ${this.textValue30} < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > VDSL < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > NID < /elementName>`
      + `< elementCategory > NID < /elementCategory>`
      + `< slotName > 1 < /slotName>`
      + `< portName > VDSL - 1 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > VDSL < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > 00D09E - 190711009414 < /elementName>`
      + `< elementCategory > RG < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > PHYSICAL - 1 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > COPPER < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTC < /NTI>`
      + `< NTIModifier > RGPON < /NTIModifier>`
      + `< taperCode > TaperCode < /taperCode>`
      + `< requestID > C01 - ${this.banValue} - 01 < /requestID>`
      + `< versionNumber > 2 < /versionNumber>`
      + `< workInstructions_GRP >`
      + `<item>`
      + `<instruction>TDW < /instruction>`
      + `< seq1 > 1 < /seq1>`
      + `< seq2 > 2 < /seq2>`
      + `< /item>`
      + `< /workInstructions_GRP>`
      + `< IPAddressType > Dynamic < /IPAddressType>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>${this.circuitId} / VDSL < /ID>`
      + `< category > VDSL < /category>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > Design < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< AsideSite >`
      + `<siteType>REMOTE TERM < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 MDU < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > I 1498 ARAPAHO CEV TERM B PFP < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< state > TX < /state>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>SFU < /siteType>`
      + `< name > 2309 TRELLIS PL < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > 233 TRELLIS PL EW BLDG 36 MDU < /parentSiteName>`
      + `< street > TRELLIS PL < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > 233 TRELLIS PL EW BLDG 36 MDU < /elementName>`
      + `< elementCategory > ONU < /elementCategory>`
      + `< slotName > LP - ${this.textValue18} / COMBO - ${this.textValue18} - ${this.textValue19} < /slotName>`
      + `< portName > VDSL - ${this.textValue18} - ${this.textValue19} < /portName>`
      + `< portAccessId > ONTVDSL - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue17} - ${this.textValue18} - ${this.textValue19} < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > VDSL < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > NID < /elementName>`
      + `< elementCategory > NID < /elementCategory>`
      + `< slotName > 1 < /slotName>`
      + `< portName > VDSL - 1 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > VDSL < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > 00D09E - 190711009414 < /elementName>`
      + `< elementCategory > RG < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > PHYSICAL - 1 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > COPPER < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTC < /NTI>`
      + `< NTIModifier > RGPON < /NTIModifier>`
      + `< taperCode > TaperCode < /taperCode>`
      + `< requestID > C01 - ${this.banValue} - 01 < /requestID>`
      + `< versionNumber > 2 < /versionNumber>`
      + `< workInstructions_GRP >`
      + `<item>`
      + `<instruction>TDW < /instruction>`
      + `< seq1 > 1 < /seq1>`
      + `< seq2 > 2 < /seq2>`
      + `< /item>`
      + `< /workInstructions_GRP>`
      + `< IPAddressType > Dynamic < /IPAddressType>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>${this.circuitId} / GPON < /ID>`
      + `< category > GPON < /category>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< AsideSite >`
      + `<siteType>CO < /siteType>`
      + `< name > ${this.wireCenter} < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< servingWireCenterCLLI > ${this.wireCenter} < /servingWireCenterCLLI>`
      + `< parentSiteName > DALLAS TEXAS < /parentSiteName>`
      + `< sBCISPoolName > RCSNTXHV LIGHTSPEED HSIA LAN < /sBCISPoolName>`
      + `< latitude > 32.9492 < /latitude>`
      + `< longitude > -96.7292 < /longitude>`
      + `< street > 201 NORTH GREENVILLE AVENUE / 20 < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>REMOTE TERM < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 MDU < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > I 1498 ARAPAHO CEV TERM B PFP < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< state > TX < /state>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Channel < /objectType>`
      + `< elementName > 231LS / PON / ${this.wireCenter}OL0 / 1 < /elementName>`
      + `< elementCategory > PON < /elementCategory>`
      + `< channelName > 9 < /channelName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > 233 TRELLIS PL EW BLDG 36 MDU < /elementName>`
      + `< elementCategory > ONU < /elementCategory>`
      + `< slotName > PON FIBER < /slotName>`
      + `< portName > PON FIBER < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > COPPER < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>231LS / PON / ${this.wireCenter} OL0 / 1 - 1 - ${this.textValue5} - ${this.textValue6} < /ID>`
      + `< category > PON ACCESS < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > L < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< AsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > I 1498 ARAPAHO CEV TERM B PFP < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< street > I 1498 ARAPAHO CEV TERM B PFP < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>REMOTE TERM < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 MDU < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > I 1498 ARAPAHO CEV TERM B PFP < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< state > TX < /state>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > I 1498 ARAPAHO CEV TERM B PFP SPL - 15 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > SPT2936PB / ${this.wireCenter} < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 113 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > I 1498 ARAPAHO CEV TERM B PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 113 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > I 1498 ARAPAHO CEV TERM B PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > APN - 648 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > PON1498A / ${this.wireCenter} < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 1296 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>6 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > 233 TRELLIS PL EW BLDG 36 MDU < /elementName>`
      + `< elementCategory > ONU < /elementCategory>`
      + `< slotName > MAIN - A < /slotName>`
      + `< portName > PON FIBER < /portName>`
      + `< portAccessId > PON FIBER < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > ONTVDSL 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTC < /NTI>`
      + `< NTIModifier > RGPON < /NTIModifier>`
      + `< taperCode > TaperCode < /taperCode>`
      + `< versionNumber > 2 < /versionNumber>`
      + `< workInstructions_GRP >`
      + `<item>`
      + `<instruction>POD < /instruction>`
      + `< seq1 > 5 < /seq1>`
      + `< seq2 > 6 < /seq2>`
      + `< /item>`
      + `< item >`
      + `<instruction>PNT < /instruction>`
      + `< seq1 > 6 < /seq1>`
      + `< /item>`
      + `< item >`
      + `<instruction>POX < /instruction>`
      + `< seq1 > 2 < /seq1>`
      + `< seq2 > 3 < /seq2>`
      + `< /item>`
      + `< /workInstructions_GRP>`
      + `< IPAddressType > Dynamic < /IPAddressType>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>231LS / PON / ${this.wireCenter} OL0 / 1 - 1 - ${this.textValue5} - ${this.textValue6} < /ID>`
      + `< category > PON NETWORK < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > L < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< AsideSite >`
      + `<siteType>CO < /siteType>`
      + `< name > ${this.wireCenter} < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< servingWireCenterCLLI > ${this.wireCenter} < /servingWireCenterCLLI>`
      + `< parentSiteName > DALLAS TEXAS < /parentSiteName>`
      + `< sBCISPoolName > RCSNTXHV LIGHTSPEED HSIA LAN < /sBCISPoolName>`
      + `< latitude > 32.9492 < /latitude>`
      + `< longitude > -96.7292 < /longitude>`
      + `< street > 201 NORTH GREENVILLE AVENUE / 20 < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > I 1498 ARAPAHO CEV TERM B PFP < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< street > I 1498 ARAPAHO CEV TERM B PFP < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< state > TX < /state>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ${this.textValue10} < /elementName>`
      + `< elementCategory > OLT < /elementCategory>`
      + `< slotName > LP - $$$} < /slotName>`
      + `< portName > ${this.textValue6} < /portName>`
      + `< portAccessId > 1 - 1 - ${this.textValue5} - ${this.textValue6} < /portAccessId>`
      + `< status > Pending < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > FOT 020270.09.11 < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 00 FRONT < /slotName>`
      + `< portName > 71 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > OSP 020270.10.01 < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 00 FRONT < /slotName>`
      + `< portName > 63 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > RN028 / ${this.wireCenter} < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 63 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > I 1498 ARAPAHO CEV TERM B PFP SPL - 15 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NT PORT < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > MAIN FROM CO TO PFP < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< /item>`
      + `< componentList_GRP >`
      + `<item>`
      + `<componentType>ONU < /componentType>`
      + `< vendor > ALCATEL < /vendor>`
      + `< model > M300 < /model>`
      + `< deviceID > ONU - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue17} < /deviceID>`
      + `< serialNo > 210711005126 < /serialNo>`
      + `< status > IE - In Effect < /status>`
      + `< inServiceDate > 20070705 < /inServiceDate>`
      + `< dueDate > 20070705 < /dueDate>`
      + `< orderedDate > 20070705 < /orderedDate>`
      + `< purchaseDate > 20070705 < /purchaseDate>`
      + `< scheduleDate > 20070705 < /scheduleDate>`
      + `< installedDate > 20070705 < /installedDate>`
      + `< decommissionDate > 20070705 < /decommissionDate>`
      + `< UVerseTechnology > Lightspeed < /UVerseTechnology>`
      + `< /item>`
      + `< item >`
      + `<componentType>OLT < /componentType>`
      + `< vendor > ALCATEL < /vendor>`
      + `< model > 7342 < /model>`
      + `< deviceID > ${this.textValue10} < /deviceID>`
      + `< serialNo > 210711005126 < /serialNo>`
      + `< status > IE - In Effect < /status>`
      + `< inServiceDate > 20070705 < /inServiceDate>`
      + `< dueDate > 20070705 < /dueDate>`
      + `< orderedDate > 20070705 < /orderedDate>`
      + `< purchaseDate > 20070705 < /purchaseDate>`
      + `< scheduleDate > 20070705 < /scheduleDate>`
      + `< installedDate > 20070705 < /installedDate>`
      + `< decommissionDate > 20070705 < /decommissionDate>`
      + `< UVerseTechnology > Lightspeed < /UVerseTechnology>`
      + `< /item>`
      + `< /componentList_GRP>`
      + `< /path>`
      + `< /GroupREC>`
      + `< transactionType > MTC < /transactionType>`
      + `< /QueryNetworkInventoryResponse>;`

    return Granite_Assignment;

  }

  //FTTPIP "MPC" Function 
  FTTPIP_MPC() {
    var Granite_Assignment;

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns: xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi: schemaLocation="http://granite.it.att.com/qni/v2" >`
      + `<schema_version>14.0 < /schema_version>`
      + `< GroupREC >`
      + `<path>`
      + `<item>`
      + `<ID>101LS / PON / ${this.textValue10} / 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /ID>`
      + `< category > PON ACCESS < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< graniteID > 34617 < /graniteID>`
      + `< AsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 PFP < /name>`
      + `< status > IE - In Effect < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< graniteLUId > 27973 < /graniteLUId>`
      + `< graniteID > 27973 < /graniteID>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>SFU < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 < /name>`
      + `< status > IE - In Effect < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< parentSiteName > 233 TRELLIS PL EW BLDG 36 FST < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< graniteID > 27971 < /graniteID>`
      + `< NTI_GRP >`
      + `<item>`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > BPON < /NTIModifier>`
      + `< /item>`
      + `< /NTI_GRP>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S SPL - 5 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > SPT1501 / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 65 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 065 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > APN - 175 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > PON1806R / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 175 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>6 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>7 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > APN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>8 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > ONT < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > 01 < /portName>`
      + `< portAccessId > ETH1 - 1 < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > BPON < /NTIModifier>`
      + `< requestID > C01 - ${this.banValue} - 01 < /requestID>`
      + `< workInstructions_GRP >`
      + `<item>`
      + `<instruction>POD < /instruction>`
      + `< seq1 > 7 < /seq1>`
      + `< seq2 > 8 < /seq2>`
      + `< /item>`
      + `< item >`
      + `<instruction>PNT < /instruction>`
      + `< seq1 > 8 < /seq1>`
      + `< /item>`
      + `< item >`
      + `<instruction>POX < /instruction>`
      + `< seq1 > 3 < /seq1>`
      + `< seq2 > 4 < /seq2>`
      + `< /item>`
      + `< /workInstructions_GRP>`
      + `< inServiceDate > 25 - Mar - 2008 < /inServiceDate>`
      + `< orderedDate > 25 - Mar - 2008 < /orderedDate>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>${this.circuitId} / BPON < /ID>`
      + `< category > BPON DATA < /category>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< graniteID > 34636 < /graniteID>`
      + `< AsideSite >`
      + `<siteType>CO < /siteType>`
      + `< name > ${this.wireCenter} < /name>`
      + `< status > Live < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< servingWireCenterCLLI > ${this.wireCenter} < /servingWireCenterCLLI>`
      + `< parentSiteName > DALLAS TEXAS < /parentSiteName>`
      + `< sBCISPoolName > RCSNTX LIGHTSPEED HSIA LAN < /sBCISPoolName>`
      + `< street > 123 < /street>`
      + `< city > DALLAS < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< graniteLUId > 13388 < /graniteLUId>`
      + `< graniteID > 13388 < /graniteID>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>SFU < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 < /name>`
      + `< status > IE - In Effect < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< parentSiteName > 233 TRELLIS PL EW BLDG 36 FST < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< graniteID > 27971 < /graniteID>`
      + `< NTI_GRP >`
      + `<item>`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > BPON < /NTIModifier>`
      + `< /item>`
      + `< /NTI_GRP>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Channel < /objectType>`
      + `< elementName > 101LS / GE1 / ${this.wireCenter}LANX / ${this.textValue10} < /elementName>`
      + `< elementCategory > ENET < /elementCategory>`
      + `< channelName > 1 < /channelName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Channel < /objectType>`
      + `< elementName > 101LS / PON / ${this.textValue10} / 1 - 1 - ${this.textValue5} - ${this.textValue6} < /elementName>`
      + `< elementCategory > PON NETWORK < /elementCategory>`
      + `< channelName > 1 < /channelName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Channel < /objectType>`
      + `< elementName > 101LS / PON / ${this.textValue10} / 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > PON ACCESS < /elementCategory>`
      + `< channelName > 1 < /channelName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > ONT < /elementCategory>`
      + `< slotName > 3 < /slotName>`
      + `< portName > DATA - 1 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > 10 / 100BASET < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > BPON < /NTIModifier>`
      + `< inServiceDate > 25 - Mar - 2008 < /inServiceDate>`
      + `< orderedDate > 25 - Mar - 2008 < /orderedDate>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>101LS / PON / ${this.textValue10} / 1 - 1 - ${this.textValue5} - ${this.textValue6} < /ID>`
      + `< category > PON NETWORK < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< graniteID > 34616 < /graniteID>`
      + `< AsideSite >`
      + `<siteType>CO < /siteType>`
      + `< name > ${this.wireCenter} < /name>`
      + `< status > Live < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< servingWireCenterCLLI > ${this.wireCenter} < /servingWireCenterCLLI>`
      + `< parentSiteName > DALLAS TEXAS < /parentSiteName>`
      + `< sBCISPoolName > RCSNTX LIGHTSPEED HSIA LAN < /sBCISPoolName>`
      + `< street > 123 < /street>`
      + `< city > DALLAS < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< graniteLUId > 13388 < /graniteLUId>`
      + `< graniteID > 13388 < /graniteID>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 PFP < /name>`
      + `< status > IE - In Effect < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< graniteLUId > 27973 < /graniteLUId>`
      + `< graniteID > 27973 < /graniteID>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ${this.textValue10} < /elementName>`
      + `< elementCategory > OLT < /elementCategory>`
      + `< slotName > LP - ${this.textValue5} < /slotName>`
      + `< portName > ${this.textValue6} < /portName>`
      + `< portAccessId > 1 - 1 - ${this.textValue5} - ${this.textValue6} < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > FOT 020270.09.11 < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 00 FRONT < /slotName>`
      + `< portName > 71 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > OSP 020270.10.01 < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 00 FRONT < /slotName>`
      + `< portName > 63 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > RN028 / DLLSTXRN < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 63 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > I 1498 ARAPAHO CEV TERM B PFP SPL - 15 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NT PORT < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > BPON < /NTIModifier>`
      + `< inServiceDate > 28 - Mar - 2008 < /inServiceDate>`
      + `< dueDate > 28 - Mar - 2008 < /dueDate>`
      + `< orderedDate > 25 - Mar - 2008 < /orderedDate>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>101LS / PON / ${this.textValue10} / 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /ID>`
      + `< category > PON ACCESS < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< graniteID > 34617 < /graniteID>`
      + `< AsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 PFP < /name>`
      + `< status > IE - In Effect < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< graniteLUId > 27973 < /graniteLUId>`
      + `< graniteID > 27973 < /graniteID>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>SFU < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 < /name>`
      + `< status > IE - In Effect < /status>`
      + `< nPATTA > 214331 < /nPATTA>`
      + `< parentSiteName > 233 TRELLIS PL EW BLDG 36 FST < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< graniteID > 27971 < /graniteID>`
      + `< NTI_GRP >`
      + `<item>`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > BPON < /NTIModifier>`
      + `< /item>`
      + `< /NTI_GRP>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S SPL - 5 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > SPT1501 / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 65 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 065 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > APN - 175 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > PON1806R / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 175 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>6 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>7 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > APN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>8 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > ONT < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > 01 < /portName>`
      + `< portAccessId > ETH1 - 1 < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > BPON < /NTIModifier>`
      + `< requestID > C01 - ${this.banValue} - 01 < /requestID>`
      + `< workInstructions_GRP >`
      + `<item>`
      + `<instruction>POD < /instruction>`
      + `< seq1 > 7 < /seq1>`
      + `< seq2 > 8 < /seq2>`
      + `< /item>`
      + `< item >`
      + `<instruction>PNT < /instruction>`
      + `< seq1 > 8 < /seq1>`
      + `< /item>`
      + `< item >`
      + `<instruction>POX < /instruction>`
      + `< seq1 > 3 < /seq1>`
      + `< seq2 > 4 < /seq2>`
      + `< /item>`
      + `< /workInstructions_GRP>`
      + `< inServiceDate > 25 - Mar - 2008 < /inServiceDate>`
      + `< orderedDate > 25 - Mar - 2008 < /orderedDate>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< componentList_GRP >`
      + `<item>`
      + `<componentType>OLT < /componentType>`
      + `< componentCLLI > ${this.wireCenter}OLT < /componentCLLI>`
      + `< componentLocation > ${this.wireCenter} < /componentLocation>`
      + `< model > 7342 < /model>`
      + `< deviceID > ${this.textValue10} < /deviceID>`
      + `< status > Pending < /status>`
      + `< portName > 1 - 1 - ${this.textValue5} - ${this.textValue6} < /portName>`
      + `< /item>`
      + `< item >`
      + `<componentType>ONT < /componentType>`
      + `< componentLocation > 233 TRELLIS PL EW BLDG 36{ 27971 } </componentLocation>`
      + `< model > H - ONT - A < /model>`
      + `< deviceID > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /deviceID>`
      + `< status > IE - In Effect < /status>`
      + `< portName > DATA - 1 < /portName>`
      + `< /item>`
      + `< /componentList_GRP>`
      + `< /path>`
      + `< /GroupREC>`
      + `< transactionType > MTC < /transactionType>`
      + `< /QueryNetworkInventoryResponse>`

    return Granite_Assignment;
  }

  //FTTP-GPON Function
  GPON_L1_Assignment() {
    var Granite_Assignment;
    var slotName: String = this.textValue5;
    var portName: String = this.textValue6;
    var sfuportName: String = this.textValue11;
    if (slotName.length == 1) {
      slotName = "0" + slotName;
    }

    if (portName.length == 1) {
      portName = "0" + portName;
    }

    if (sfuportName.length == 1) {
      sfuportName = "0" + sfuportName;
    }

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi:schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>14.0</schema_version>\n`
      + `<GroupREC>\n`
      + `<path>\n`
      + `<item>\n`
      + `<ID>231LS/PON/${this.wireCenter}OL0/1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>TX</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S SPL-5</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT1501/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>65</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-065</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-175</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1806R/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>175</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>02</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>${slotName}</slotName>`
      + `<portName>${sfuportName}</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONT 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>C01-${this.banValue}-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>7</seq1>`
      + `<seq2>8</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>TX</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S SPL-5</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT1501/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>65</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-065</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-175</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1806R/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>175</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>02</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>${slotName}</slotName>`
      + `<portName>${sfuportName}</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONT 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>N01-${this.banValue}-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>7</seq1>`
      + `<seq2>8</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>TX</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue10}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>${slotName}</slotName>`
      + `<portName>${portName}</portName>`
      + `<portAccessId>1-1-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>FOT 020270.09.11</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>71</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}/GPON</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>TX</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>231LS/PON/${this.wireCenter}OL0/1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>PON</elementCategory>`
      + `<channelName>9</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>${slotName}</slotName>`
      + `<portName>${sfuportName}</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>ONT</componentType>`
      + `<vendor>ALCATEL</vendor>`
      + `<model>H-ONT-A</model>`
      + `<deviceID>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<vendor>ALCATEL</vendor>`
      + `<model>7342</model>`
      + `<deviceID>${this.textValue10}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>MTC</transactionType>`
      + `</QueryNetworkInventoryResponse>;`

    return Granite_Assignment;

  }

  //FTTN CO DSLAM/IP-CO Function
  FTTN_CO_L1_Assignment(action: String): String {
    this.SOAC_Circuit = this.SOAC_Circuit.replace(this.pattern, ".");

    if (this.selectedRegion == 'Midwest') {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA   100 WIS AV, MADISON, WI/LOC </item>\n"
        + "<item>     APT 704/RT 4121/RZ 13</item>\n"
        + "<item>IOE  00047-00020-13/EXK 608 251/TN </item>\n"
        + "<item>     608 819-0342/LPS/DF F01-07-</item>\n"
        + "<item>     D066/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue6 + "</item>\n"
        + "<item>     /ECLI MDSNWI11O0A020213051</item>\n"
        + "<item>     /LRN 608 957-0000</item>\n"
        + "<item>G2   WC 608 251</item>\n"
        + "<item>IF1  /CA 69/PR 1074/DF F01-06-052J</item>\n"
        + "<item>     /PRQ Y/BP 199/TEA IT100 </item>\n"
        + "<item>     WISCONSIN AV; CIW/TPR 412101</item>\n"
        + "<item>     /RMTE PLR 016B...(4)INWPN 100.</item>\n"
        + "<item>     ..0190439/RO ORD C0171R209174 </item>\n"
        + "<item>     DD 10-08-18</item>\n"
        + "</assignmentLines>\n";
    } else if (this.selectedRegion == 'Southeast') {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA   929 N WATERMAN RD, JKVL, FL/RT</item>\n"
        + "<item>      3111/RZ 13</item>\n"
        + "<item>IOE  AA05-0-18-03/EXK 904 396/TN</item>\n"
        + "<item>      904 399-0435/LPS/DF</item>\n"
        + "<item>      F16-07-03U07-1-04/GF</item>\n"
        + "<item>      " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue6 + "/ECLI</item>\n"
        + "<item>      JCVLFLSMO15010130101</item>\n"
        + "<item>ITIE /CA TM04/PR 135</item>\n"
        + "<item>ITIE /CA TM05/PR 367</item>\n"
        + "<item>G2   WC 904 396</item>\n"
        + "<item>IF1  /CA 2/PR 448/DF</item>\n"
        + "<item>      F16-10-03U10-2-23/PRQ Y/BP</item>\n"
        + "<item>      248/OBP 703/TEA S 3140 SAN</item>\n"
        + "<item>      JOSE BLVD; EXJ/TPR 311142</item>\n"
        + "<item>     /RMTE PROJ LIGHTSPEED DAVAR</item>\n"
        + "<item>      VFY IN PROGRESS 10-5-09 PAA</item>\n"
        + "<item>     /RO ORD NYFHL2C7 DD 10-07-08</item>\n"
        + "<item>IF2  /CA 3140S/PR 703/ENC F 921 N</item>\n"
        + "<item>      WATERMAN RD; CBW/RMTE PLS AS</item>\n"
        + "<item>      BUILT MCN 051110/RMKP</item>\n"
        + "<item>      LIGHTSPEED BBP</item>\n"
        + "</assignmentLines>\n";
    } else if (this.selectedRegion == 'Southwest') {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA   570 NARROWS DR/RT 2010/RZ 13</item>\n"
        + "<item>IOE  NR/TRE " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue6 + "</item>\n"
        + "<item>     /ECLI GRFYARMAO0A010102101</item>\n"
        + "<item>G2   WC 501 825</item>\n"
        + "<item>IF1  /CA 2/PR 258/DF FH1001/PRQ Y</item>\n"
        + "<item>     /BP 108/OBP 194/TEA FB 1 </item>\n"
        + "<item>     STARK RD; PXJ/BCF BP 108 </item>\n"
        + "<item>     TEA FB 1 STARK RD/TPR 201001</item>\n"
        + "<item>     /RMTE D431030,4643730-1,</item>\n"
        + "<item>     4879372-3</item>\n"
        + "<item>IF2  /CA 1STARK/PR 194/BP 19/TEA </item>\n"
        + "<item>     FB 1353 SPUR 517; PDW</item>\n"
        + "</assignmentLines>\n";
    } else {
      this.assignmentLines = "<SoacServiceOrder>\n"
        + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
        + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
        + "</SoacServiceOrder>\n"
        + "<assignmentLines>\n"
        + "<item>---ASGM</item>\n"
        + "<item>G1    CLS " + this.SOAC_Circuit + "</item>\n"
        + "<item>FA    1152 AYALA DR/LOC APT 4</item>\n"
        + "<item>RT    4405</item>\n"
        + "<item>IOE   02008-01851-30/EXK 408 522</item>\n"
        + "<item>      /TN 408-530-9290/LPS/TRE </item>\n"
        + "<item>      " + this.textValue12 + "-" + this.textValue5 + "-" + this.textValue6 + "/ECLI </item>\n"
        + "<item>      SNVACA01O6E010142301</item>\n"
        + "<item>G2    WC 408 737</item>\n"
        + "<item>IF1   /CA 45/PR 2408/PRQ Y/BP 483</item>\n"
        + "<item>      /OBP 340/TEA 107 S MARY AV; </item>\n"
        + "<item>      EXJ/TPR 440501/RMTE </item>\n"
        + "<item>      LIGHTSPEED/RZ 5</item>\n"
        + "<item>IF2   /CA 2509/PR 340/BP O-W+BK-S</item>\n"
        + "<item>      /OPC O-BK+Y-BR/TEA SB 1124 </item>\n"
        + "<item>      AYALA DR; EXJ/RMTE NEW SPLC </item>\n"
        + "<item>      CASE NO ACCESS 2509&amp;1124A R </item>\n"
        + "<item>      SPLCDED 2GTHR</item>\n"
        + "<item>IF3   /CA 1124A/PR 294/BP O-BK+Y-</item>\n"
        + "<item>      BR/TEA R 1152 AYALA DR; CDW</item>\n"
        + "</w1:assignmentLines>\n";
    }

    this.SOAC_Assignment = this.csinmAssignment(action, this.assignmentLines);

    // var soacAssignmentXML: XML = new XML(this.SOAC_Assignment);

    return this.SOAC_Assignment;
  }

  //FTTC-GPON Function
  FTTCGPON_L1_Assignment_Granite() {
    var Granite_Assignment;

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns="http://granite.it.att.com/qni/v2">`
      + `<schema_version>RJUN</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>A2/MCXX/2345123//SW/GPON</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>GPON</bandwidth>`
      + `<topology>P</topology>`
      + `<orderNumber>2456123</orderNumber>`
      + `<status>Design</status>`
      + `<BAN>234512311</BAN>`
      + `<graniteID>104641</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>MCISMIMN</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>UPPER PENINSULA MI</parentSiteName>`
      + `<street>@ HOBAN ST</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>15715</graniteLUId>`
      + `<graniteID>15715</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>HARBOR RD MDU</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD PFP</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62536</graniteLUId>`
      + `<graniteID>62536</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</elementName>`
      + `<elementCategory>PON NETWORK</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>GPON</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}-1</elementName>`
      + `<elementCategory>PON ACCESS</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>GPON</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue1}</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>LT/COMBO-7367-1</slotName>`
      + `<portName>COMBO</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<dueDate>29-Jul-2015</dueDate>`
      + `<orderedDate>20-Jul-2015</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<graniteID>104594</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>MCISMIMN</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>UPPER PENINSULA MI</parentSiteName>`
      + `<street>@ HOBAN ST</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>15715</graniteLUId>`
      + `<graniteID>15715</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>HARBOR RD PFP</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>MCISMIMN</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62535</graniteLUId>`
      + `<graniteID>62535</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue2}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>LT-01</slotName>`
      + `<portName>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portName>`
      + `<portAccessId>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD SPL-1</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO HDT</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<dueDate>17-Jul-2015</dueDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}-1</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<graniteID>104596</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>MCISMIMN</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>UPPER PENINSULA MI</parentSiteName>`
      + `<street>@ HOBAN ST</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>15715</graniteLUId>`
      + `<graniteID>15715</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>HARBOR RD MDU</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD PFP</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62536</graniteLUId>`
      + `<graniteID>62536</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD SPL-1</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>1112FN/MCISMIMN</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>1</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-001</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-001</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>1112FN/MCISMIMN</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>5</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue1}</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>NT-A</slotName>`
      + `<portName>PON FIBER</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>CDW</instruction>`
      + `<seq1>6</seq1>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<dueDate>17-Jul-2015</dueDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}</ID>`
      + `<category>VDSL</category>`
      + `<bandwidth>VDSL</bandwidth>`
      + `<topology>P</topology>`
      + `<orderNumber>2456123</orderNumber>`
      + `<status>Design</status>`
      + `<BAN>234512311</BAN>`
      + `<graniteID>104718</graniteID>`
      + `<AsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>HARBOR RD MDU</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD PFP</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62536</graniteLUId>`
      + `<graniteID>62536</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>1234 HARBOR RD</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD MDU</parentSiteName>`
      + `<street>1234 HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>G000062554</graniteLUId>`
      + `<graniteID>62554</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>A2/MCXX/2345123//SW/GPON</elementName>`
      + `<elementCategory>GPON</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>Design</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue1}</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>LT/COMBO-7367-1</slotName>`
      + `<portName>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portName>`
      + `<portAccessId>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>XDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>NID</elementName>`
      + `<elementCategory>NID</elementCategory>`
      + `<slotName>1</slotName>`
      + `<portName>XDSL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>XDSL</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<dueDate>29-Jul-2015</dueDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<componentCLLI>${(this.textValue2)?.substr(0, 11)}</componentCLLI>`
      + `<componentLocation>${(this.textValue2)?.substr(0, 8)}</componentLocation>`
      + `<model>7342</model>`
      + `<deviceID>${this.textValue2}</deviceID>`
      + `<status>IE-In Effect</status>`
      + `<portName>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portName>`
      + `</item>`
      + `<item>`
      + `<componentType>ONU</componentType>`
      + `<componentCLLI>${(this.textValue1)?.substr(0, 8)}</componentCLLI>`
      + `<componentLocation>HARBOR RD MDU&#123;62536&#125;</componentLocation>`
      + `<model>7367</model>`
      + `<deviceID>${this.textValue1}-${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</deviceID>`
      + `<status>IE-In Effect</status>`
      + `<portName>COMBO</portName>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>ARM</transactionType>`
      + `</QueryNetworkInventoryResponse>`

    return Granite_Assignment
  }

  //QNI g.Fast Function
  GFAST_L1_Assignment() {
    var gfastMsg: String = "<QueryNetworkInventoryResponse xmlns=\"http://granite.it.att.com/qni/v2\">\n"
      + "<schema_version>ROCT</schema_version>\n"
      + "<GroupREC>\n"
      + "<path>\n"
      + "<item>\n"
      + "<ID>" + this.circuitId + "</ID>\n"
      + "<category>GPON</category>\n"
      + "<bandwidth>GPON</bandwidth>\n"
      + "<topology>P</topology>\n"
      // + "<orderNumber>" + uvOrigOrderActionId.text + "</orderNumber>\n"
      + "<orderNumber/>"
      + "<status>Design</status>\n"
      + "<BAN>" + this.banValue + "</BAN>\n"
      + "<graniteID>20325091</graniteID>\n"
      + "<AsideSite>\n"
      + "<siteType>CO</siteType>\n"
      + "<name>" + this.wireCenter + "</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<servingWireCenterCLLI>" + this.wireCenter + "</servingWireCenterCLLI>\n"
      + "<parentSiteName>DALLAS TEXAS</parentSiteName>\n"
      + "<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>\n"
      + "<latitude>32.9492</latitude>\n"
      + "<longitude>-96.7292</longitude>\n"
      + "<street>201 NORTH GREENVILLE AVENUE/200 EAST TYLER STREET</street>\n"
      + "<city>RICHARDSON</city>\n"
      + "<county>DALLAS</county>\n"
      + "<state>TX</state>\n"
      + "<postal_Code_1>75081</postal_Code_1>\n"
      + "<graniteLUId>1867</graniteLUId>\n"
      + "<graniteID>1867</graniteID>\n"
      + "</AsideSite>\n"
      + "<ZsideSite>\n"
      + "<siteType>REMOTE TERM</siteType>\n"
      + "<name>DLLSTXLEA00</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<parentSiteName>" + this.wireCenter + "</parentSiteName>\n"
      + "<state>TX</state>\n"
      + "<graniteLUId>28780689</graniteLUId>\n"
      + "<graniteID>28780689</graniteID>\n"
      + "</ZsideSite>\n"
      + "<Leg_GRP>\n"
      + "<leg>\n"
      + "<sequence>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<objectType>Channel</objectType>\n"
      + "<elementName>131LS/PON/" + this.wireCenter + "OL0/1-1-6-1</elementName>\n"
      + "<elementCategory>PON NETWORK</elementCategory>\n"
      + "<channelName>2</channelName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>GPON</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>2</sequenceNumber>\n"
      + "<objectType>Channel</objectType>\n"
      + "<elementName>131LS/PON/" + this.wireCenter + "OL0/" + this.textTitle23 + "-2</elementName>\n"
      + "<elementCategory>PON ACCESS</elementCategory>\n"
      + "<channelName>2</channelName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>GPON</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>3</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>" + this.textTitle20 + "</elementName>\n"
      + "<elementCategory>ONU</elementCategory>\n"
      + "<slotName>LT</slotName>\n"
      + "<portName>GPON-1</portName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>G.FAST</bandwidth>\n"
      + "</sequence>\n"
      + "<legName>1</legName>\n"
      + "</leg>\n"
      + "</Leg_GRP>\n"
      + "<attributes_GRP>\n"
      + "<NTI>FTTP</NTI>\n"
      + "<NTIModifier>GPON</NTIModifier>\n"
      + "<requestID>N01-152901619-GPON</requestID>\n"
      + "<versionNumber>0</versionNumber>\n"
      + "<inServiceDate>26-Sep-2015</inServiceDate>\n"
      + "<dueDate>26-Sep-2015</dueDate>\n"
      + "<orderedDate>23-Sep-2015</orderedDate>\n"
      + "</attributes_GRP>\n"
      + "</item>\n"
      + "<item>\n"
      + "<ID>131LS/PON/" + this.wireCenter + "OL0/1-1-6-1</ID>\n"
      + "<category>PON NETWORK</category>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "<topology>P</topology>\n"
      + "<status>IE-In Effect</status>\n"
      + "<graniteID>20324311</graniteID>\n"
      + "<AsideSite>\n"
      + "<siteType>CO</siteType>\n"
      + "<name>" + this.wireCenter + "</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<servingWireCenterCLLI>" + this.wireCenter + "</servingWireCenterCLLI>\n"
      + "<parentSiteName>DALLAS TEXAS</parentSiteName>\n"
      + "<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>\n"
      + "<latitude>32.9492</latitude>\n"
      + "<longitude>-96.7292</longitude>\n"
      + "<street>201 NORTH GREENVILLE AVENUE/200 EAST TYLER STREET</street>\n"
      + "<city>RICHARDSON</city>\n"
      + "<county>DALLAS</county>\n"
      + "<state>TX</state>\n"
      + "<postal_Code_1>75081</postal_Code_1>\n"
      + "<graniteLUId>1867</graniteLUId>\n"
      + "<graniteID>1867</graniteID>\n"
      + "</AsideSite>\n"
      + "<ZsideSite>\n"
      + "<siteType>PFP</siteType>\n"
      + "<name>R 1227 HORIZON TR PFP</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<parentSiteName>" + this.wireCenter + "</parentSiteName>\n"
      + "<state>TX</state>\n"
      + "<graniteLUId>28780688</graniteLUId>\n"
      + "<graniteID>28780688</graniteID>\n"
      + "</ZsideSite>\n"
      + "<Leg_GRP>\n"
      + "<leg>\n"
      + "<sequence>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>" + this.textTitle21 + "</elementName>\n"
      + "<elementCategory>OLT</elementCategory>\n"
      + "<slotName>LT-2</slotName>\n"
      + "<portName>" + this.textTitle23 + "</portName>\n"
      + "<portAccessId>" + this.textTitle23 + "</portAccessId>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>2</sequenceNumber>\n"
      + "<objectType>CablePair</objectType>\n"
      + "<elementName>OF534/" + this.wireCenter + "</elementName>\n"
      + "<elementCategory>SMF</elementCategory>\n"
      + "<cablePairStrand>1</cablePairStrand>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>3</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>R 1227 HORIZON TR SPL-1</elementName>\n"
      + "<elementCategory>OPTICAL SPLITTER</elementCategory>\n"
      + "<slotName>01</slotName>\n"
      + "<portName>NT PORT</portName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<legName>1</legName>\n"
      + "</leg>\n"
      + "</Leg_GRP>\n"
      + "<attributes_GRP>\n"
      + "<NTI>FTTP</NTI>\n"
      + "<NTIModifier>GPON</NTIModifier>\n"
      + "<inServiceDate>05-Aug-2015</inServiceDate>\n"
      + "<dueDate>06-Aug-2015</dueDate>\n"
      + "<orderedDate>05-Aug-2015</orderedDate>\n"
      + "</attributes_GRP>\n"
      + "</item>\n"
      + "<item>\n"
      + "<ID>131LS/PON/" + this.wireCenter + "OL0/" + this.textTitle23 + "-2</ID>\n"
      + "<category>PON ACCESS</category>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "<topology>P</topology>\n"
      + "<status>IE-In Effect</status>\n"
      + "<graniteID>20324312</graniteID>\n"
      + "<AsideSite>\n"
      + "<siteType>PFP</siteType>\n"
      + "<name>R 1227 HORIZON TR PFP</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<parentSiteName>" + this.wireCenter + "</parentSiteName>\n"
      + "<state>TX</state>\n"
      + "<graniteLUId>28780688</graniteLUId>\n"
      + "<graniteID>28780688</graniteID>\n"
      + "</AsideSite>\n"
      + "<ZsideSite>\n"
      + "<siteType>REMOTE TERM</siteType>\n"
      + "<name>" + this.wireCenter + "OLD</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<parentSiteName>" + this.wireCenter + "</parentSiteName>\n"
      + "<state>TX</state>\n"
      + "<graniteLUId>28780689</graniteLUId>\n"
      + "<graniteID>28780689</graniteID>\n"
      + "</ZsideSite>\n"
      + "<Leg_GRP>\n"
      + "<leg>\n"
      + "<sequence>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>R 1227 HORIZON TR SPL-1</elementName>\n"
      + "<elementCategory>OPTICAL SPLITTER</elementCategory>\n"
      + "<slotName>01</slotName>\n"
      + "<portName>01</portName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>2</sequenceNumber>\n"
      + "<objectType>CablePair</objectType>\n"
      + "<elementName>SPT1652PL/" + this.wireCenter + "</elementName>\n"
      + "<elementCategory>SMF</elementCategory>\n"
      + "<cablePairStrand>1</cablePairStrand>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>3</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>R 1227 HORIZON TR PFP</elementName>\n"
      + "<elementCategory>FDP</elementCategory>\n"
      + "<slotName>01</slotName>\n"
      + "<portName>NPN-001</portName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>4</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>R 1227 HORIZON TR PFP</elementName>\n"
      + "<elementCategory>FDP</elementCategory>\n"
      + "<slotName>01</slotName>\n"
      + "<portName>APN-001</portName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>5</sequenceNumber>\n"
      + "<objectType>CablePair</objectType>\n"
      + "<elementName>PON1652PL/" + this.wireCenter + "</elementName>\n"
      + "<elementCategory>SMF</elementCategory>\n"
      + "<cablePairStrand>1</cablePairStrand>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>6</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>" + this.textTitle20 + "</elementName>\n"
      + "<elementCategory>ONU</elementCategory>\n"
      + "<slotName>NT-A</slotName>\n"
      + "<portName>PON FIBER</portName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>FIBER</bandwidth>\n"
      + "</sequence>\n"
      + "<legName>1</legName>\n"
      + "</leg>\n"
      + "</Leg_GRP>\n"
      + "<attributes_GRP>\n"
      + "<NTI>FTTP</NTI>\n"
      + "<NTIModifier>GPON</NTIModifier>\n"
      + "<workInstructions_GRP>\n"
      + "<item>\n"
      + "<instruction>PDW</instruction>\n"
      + "<seq1>6</seq1>\n"
      + "</item>\n"
      + "</workInstructions_GRP>\n"
      + "<inServiceDate>05-Aug-2015</inServiceDate>\n"
      + "<dueDate>06-Aug-2015</dueDate>\n"
      + "<orderedDate>21-Aug-2015</orderedDate>\n"
      + "</attributes_GRP>\n"
      + "</item>\n"
      + "<item>\n"
      + "<ID>" + this.circuitId + "</ID>\n"
      + "<category>VDSL</category>\n"
      + "<bandwidth>VDSL</bandwidth>\n"
      + "<topology>P</topology>\n"
      // + "<orderNumber>" + uvOrigOrderActionId.text + "</orderNumber>\n"
      + "<orderNumber/>"
      + "<status>Design</status>\n"
      + "<BAN>" + this.banValue + "</BAN>\n"
      + "<graniteID>20325090</graniteID>\n"
      + "<AsideSite>\n"
      + "<siteType>REMOTE TERM</siteType>\n"
      + "<name>" + this.wireCenter + "OLD</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<parentSiteName>" + this.wireCenter + "</parentSiteName>\n"
      + "<state>TX</state>\n"
      + "<graniteLUId>28780689</graniteLUId>\n"
      + "<graniteID>28780689</graniteID>\n"
      + "</AsideSite>\n"
      + "<ZsideSite>\n"
      + "<siteType>SFU</siteType>\n"
      + "<name>13250 EMILY RD</name>\n"
      + "<status>Live</status>\n"
      + "<nPATTA>972231</nPATTA>\n"
      + "<parentSiteName>" + this.wireCenter + "OLD</parentSiteName>\n"
      + "<street>13250 EMILY RD</street>\n"
      + "<unitType>UNIT</unitType>\n"
      + "<unitValue>1121</unitValue>\n"
      + "<state>TX</state>\n"
      + "<graniteLUId>G028780698</graniteLUId>\n"
      + "<graniteID>28780698</graniteID>\n"
      + "<NTI_GRP>\n"
      + "<item>\n"
      + "<NTI>FTTP</NTI>\n"
      + "<NTIModifier>GPON</NTIModifier>\n"
      + "</item>\n"
      + "</NTI_GRP>\n"
      + "<sharedSiteIndicator>Unknown</sharedSiteIndicator>\n"
      + "</ZsideSite>\n"
      + "<Leg_GRP>\n"
      + "<leg>\n"
      + "<sequence>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>" + this.textTitle20 + "</elementName>\n"
      + "<elementCategory>ONU</elementCategory>\n"
      + "<slotName>LT</slotName>\n"
      + "<portName>02</portName>\n"
      + "<portAccessId>" + this.textTitle22 + "</portAccessId>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>G.FAST</bandwidth>\n"
      + "</sequence>\n"
      + "<sequence>\n"
      + "<sequenceNumber>2</sequenceNumber>\n"
      + "<objectType>Port</objectType>\n"
      + "<elementName>MODEM</elementName>\n"
      + "<elementCategory>MODEM</elementCategory>\n"
      + "<slotName>1</slotName>\n"
      + "<portName>NT</portName>\n"
      + "<status>IE-In Effect</status>\n"
      + "<bandwidth>G.FAST</bandwidth>\n"
      + "</sequence>\n"
      + "<legName>1</legName>\n"
      + "</leg>\n"
      + "</Leg_GRP>\n"
      + "<attributes_GRP>\n"
      + "<NTI>FTTP</NTI>\n"
      + "<NTIModifier>GPON</NTIModifier>\n"
      + "<requestID>N01-152901619-VDSL</requestID>\n"
      + "<versionNumber>0</versionNumber>\n"
      + "<inServiceDate>26-Sep-2015</inServiceDate>\n"
      + "<dueDate>26-Sep-2015</dueDate>\n"
      + "<orderedDate>23-Sep-2015</orderedDate>\n"
      + "</attributes_GRP>\n"
      + "</item>\n"
      + "<componentList_GRP>\n"
      + "<item>\n"
      + "<componentType>OLT</componentType>\n"
      + "<componentCLLI>" + this.wireCenter + "OL0</componentCLLI>\n"
      + "<componentLocation>" + this.wireCenter + "</componentLocation>\n"
      + "<model>7342</model>\n"
      + "<deviceID>" + this.textTitle21 + "</deviceID>\n"
      + "<status>IE-In Effect</status>\n"
      + "<portName>" + this.textTitle23 + "</portName>\n"
      + "</item>\n"
      + "<item>\n"
      + "<componentType>ONU</componentType>\n"
      + "<componentLocation>" + this.wireCenter + "OLD</componentLocation>\n"
      + "<model>516G DPU COAX</model>\n"
      + "<deviceID>" + this.textTitle20 + "-" + this.textTitle22 + "</deviceID>\n"
      + "<status>IE-In Effect</status>\n"
      + "<portName>GPON-1</portName>\n"
      + "</item>\n"
      + "<item>\n"
      + "<componentType>ONT</componentType>\n"
      + "<componentLocation>" + this.wireCenter + "OLD</componentLocation>\n"
      + "<model>G-010S-P</model>\n"
      + "<deviceID>ONT-" + this.textTitle23 + "-2</deviceID>\n"
      + "<status>Pending</status>\n"
      + "<portName>PON FIBER</portName>\n"
      + "</item>\n"
      + "</componentList_GRP>\n"
      + "</path>\n"
      + "</GroupREC>\n"
      + "<transactionType>ARM</transactionType>\n"
      + "</QueryNetworkInventoryResponse>";

    // var gfastNotifXml:XML = new XML (gfastMsg);

    return gfastMsg;

  }

  //FX TO GPON Function
  FXGPON_L1_Assignment() {
    var Granite_Assignment;
    var oldnti: String = null;
    var ntiModifier: String = null;

    if (this.ntiValue == "FTTP-EGPON") {
      oldnti = "FTTP";
      ntiModifier = "EGPON";
    } else {
      oldnti = this.ntiValue;
      ntiModifier = this.ntiValue;
    }

    Granite_Assignment = `<QueryNetworkInventoryResponse xsi:schemaLocation="http://granite.it.att.com/qni/v2 ......main&#xD;esourcesxsdgraniteQniResponse.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2">`
      + `<schema_version>14.0</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<orderNumber>1362997866</orderNumber>`
      + `<status>Design</status>`
      + `<BAN>403121282</BAN>`
      + `<graniteID>19095964</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>AUSTTXRR</name>`
      + `<status>Live</status>`
      + `<nPATTA>512255</nPATTA>`
      + `<servingWireCenterCLLI>AUSTTXRR</servingWireCenterCLLI>`
      + `<parentSiteName>AUSTIN TEXAS</parentSiteName>`
      + `<sBCISPoolName>AUSTTXGR LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>30.50962</latitude>`
      + `<longitude>97.67649</longitude>`
      + `<street>105 WEST BAGDAD AVENUE</street>`
      + `<city>ROUND ROCK</city>`
      + `<county>WILLIAMSON</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>78664</postal_Code_1>`
      + `<graniteLUId>6881</graniteLUId>`
      + `<graniteID>6881</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>501 WALSH HILL TRL</name>`
      + `<status>Live</status>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>F 500 WALSH HILL TRL FST</parentSiteName>`
      + `<street>501 WALSH HILL TRL</street>`
      + `<state>TX</state>`
      + `<graniteLUId>G016046525</graniteLUId>`
      + `<graniteID>16046525</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>${oldnti}</NTI>`
      + `<NTIModifier>${ntiModifier}</NTIModifier>`
      + `</item>`
      + `<item>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>106LS/LAG/AUSTTXRR0GW/AUSYTXTVOL1</elementName>`
      + `<elementCategory>LAG</elementCategory>`
      + `<channelName>252</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VLAN</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>GA-AB/MCXX/777693//SW/GPON-16046525-1</elementName>`
      + `<elementCategory>GPON</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>Design</status>`
      + `<bandwidth>VLAN</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-1-1-12-3-12</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>12</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>Pending</status>`
      + `<bandwidth>10/100/1000BASET</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>501 WALSH HILL TRL{16046525}-RG-1</elementName>`
      + `<elementCategory>RG</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>VLAN-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VLAN</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<requestID>N01-112975712-VLAN</requestID>`
      + `<versionNumber>0</versionNumber>`
      + `<inServiceDate>04-Nov-2014</inServiceDate>`
      + `<dueDate>04-Nov-2014</dueDate>`
      + `<orderedDate>30-Oct-2014</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>103LS/PON/AUSYTXTVOL0/1-1-12-3</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<graniteID>18991293</graniteID>`
      + `<AsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>AUSYTXTV</name>`
      + `<status>Live</status>`
      + `<nPATTA>512255</nPATTA>`
      + `<servingWireCenterCLLI>AUSYTXTV</servingWireCenterCLLI>`
      + `<parentSiteName>AUSTTXRR</parentSiteName>`
      + `<street>15101 AVERY RANCH BLVD</street>`
      + `<city>AUSTIN</city>`
      + `<county>WILLIAMSON</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>78717</postal_Code_1>`
      + `<graniteLUId>24610</graniteLUId>`
      + `<graniteID>24610</graniteID>`
      + `<sharedSiteIndicator>No</sharedSiteIndicator>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>F 1110 WALSH HILLS TRL PFP</name>`
      + `<status>Live</status>`
      + `<nPATTA>512255</nPATTA>`
      + `<parentSiteName>AUSYTXTV</parentSiteName>`
      + `<street>F 1110 WALSH HILLS TRL PFP</street>`
      + `<state>TX</state>`
      + `<graniteLUId>2810024</graniteLUId>`
      + `<graniteID>2810024</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue21}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>${this.textValue5}</slotName>`
      + `<portName>${this.textValue6}</portName>`
      + `<portAccessId>1-1-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 010001.01.03</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>46</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/BTRGLASW</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>Active</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<inServiceDate>30-Sep-2014</inServiceDate>`
      + `<dueDate>30-Sep-2014</dueDate>`
      + `<orderedDate>30-Sep-2014</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<orderNumber>${this.textValue25}</orderNumber>`
      + `<orderType>IN</orderType>`
      + `<status>Design</status>`
      + `<graniteID>19095955</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<status>Live</status>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>AUSYTXTV</parentSiteName>`
      + `<street>F 1110 WALSH HILLS TRL PFP</street>`
      + `<state>TX</state>`
      + `<graniteLUId>2810024</graniteLUId>`
      + `<graniteID>2810024</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>501 WALSH HILL TRL</name>`
      + `<status>Live</status>`
      + `<nPATTA>512255</nPATTA>`
      + `<parentSiteName>F 500 WALSH HILL TRL FST</parentSiteName>`
      + `<street>501 WALSH HILL TRL</street>`
      + `<state>TX</state>`
      + `<graniteLUId>G016046525</graniteLUId>`
      + `<graniteID>16046525</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>${oldnti}</NTI>`
      + `<NTIModifier>${ntiModifier}</NTIModifier>`
      + `</item>`
      + `<item>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 1110 WALSH HILLS TRL SPL-10</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>14</portName>`
      + `<status>Active</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT4194PA/AUSTTXRR</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>302</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 1110 WALSH HILLS TRL PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-302</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 1110 WALSH HILLS TRL PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-853</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1110WHT/AUSTTXRR</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>853</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 500 WALSH HILL TRL FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 500 WALSH HILL TRL FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>${this.textValue5}</slotName>`
      + `<portName>${this.textValue6}</portName>`
      + `<status>Pending</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<taperCode>4194PA</taperCode>`
      + `<requestID>N01-112975712-PON ACCESS</requestID>`
      + `<versionNumber>0</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>EOD</instruction>`
      + `<seq1>6</seq1>`
      + `<seq2>7</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<inServiceDate>04-Nov-2014</inServiceDate>`
      + `<dueDate>04-Nov-2014</dueDate>`
      + `<orderedDate>30-Oct-2014</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<componentCLLI>AUSYTXTVOL1</componentCLLI>`
      + `<componentLocation>AUSYTXTV</componentLocation>`
      + `<model>7342</model>`
      + `<deviceID>SUNDGAAABLM1500IT9R02</deviceID>`
      + `<status>IE-In Effect</status>`
      + `<switchId>AUSYTXTVOLT301</switchId>`
      + `<portName>1-1-1-15</portName>`
      + `</item>`
      + `<item>`
      + `<componentType>ONT</componentType>`
      + `<componentLocation>501 WALSH HILL TRL{16046525}</componentLocation>`
      + `<model>O-210G-B</model>`
      + `<deviceID>ONT-1-1-1-1-15</deviceID>`
      + `<status>Pending</status>`
      + `<portName>GPON-1</portName>`
      + `</item>`
      + `</componentList_GRP>`
      + ` < /path>`
      + `< path >`
      + `<item>`
      + `<ID>231LS/PON/BTRGLASWOL0/8-1-5</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<orderNumber>237216975</orderNumber>`
      + `<status>IE-In Effect</status>`
      + `<BAN>403121282</BAN>`
      + `<graniteID>16045748</graniteID>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<status>Live</status>`
      + `<servingWireCenterCLLI>AUSTTXGRW30</servingWireCenterCLLI>`
      + `<parentSiteName>AUSTIN TEXAS</parentSiteName>`
      + `<street>909 COLORADO STREET</street>`
      + `<city>AUSTIN</city>`
      + `<county>TRAVIS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>78701</postal_Code_1>`
      + `<graniteLUId>231627</graniteLUId>`
      + `<graniteID>231627</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>501 WALSH HILL TRL</name>`
      + `<status>Live</status>`
      + `<nPATTA>512255</nPATTA>`
      + `<parentSiteName>F 500 WALSH HILL TRL FST</parentSiteName>`
      + `<street>501 WALSH HILL TRL</street>`
      + `<state>TX</state>`
      + `<graniteLUId>G016046525</graniteLUId>`
      + `<graniteID>16046525</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>${oldnti}</NTI>`
      + `<NTIModifier>${ntiModifier}</NTIModifier>`
      + `</item>`
      + `<item>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/VPLS/1086010906</elementName>`
      + `<elementCategory>VPLS</elementCategory>`
      + `<channelName>svc-mgr:service-1:15.02.4.04:interface-3/1/19-inner-tag-482-outer-tag-114</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VLAN</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LX/GE1N/AUSTTXRR0BW/AUSYTXTVOL0</elementName>`
      + `<elementCategory>ENET</elementCategory>`
      + `<channelName>1105</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VLAN</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>${this.textValue24}/${ntiModifier}</elementName>`
      + `<elementCategory>EGPON DATA</elementCategory>`
      + `<channelName>1105</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VLAN</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>00D09E-520919007287</elementName>`
      + `<elementCategory>RG</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>VLAN-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VLAN</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>${oldnti}</NTI>`
      + `<NTIModifier>${ntiModifier}</NTIModifier>`
      + `<requestID>N01-403121282-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<inServiceDate>01-Sep-2011</inServiceDate>`
      + `<dueDate>04-Nov-2014</dueDate>`
      + `<orderedDate>01-Sep-2011</orderedDate>`
      + `<decommissionDate>04-Nov-2014</decommissionDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/BTRGLASWOL0/3-2</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<graniteID>460605</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>BTRGLASW</name>`
      + `<status>Live</status>`
      + `<nPATTA>512255</nPATTA>`
      + `<servingWireCenterCLLI>AUSYTXTV</servingWireCenterCLLI>`
      + `<parentSiteName>AUSTTXRR</parentSiteName>`
      + `<street>15101 AVERY RANCH BLVD</street>`
      + `<city>AUSTIN</city>`
      + `<county>WILLIAMSON</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>78717</postal_Code_1>`
      + `<graniteLUId>24610</graniteLUId>`
      + `<graniteID>24610</graniteID>`
      + `<sharedSiteIndicator>No</sharedSiteIndicator>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>F 1110 WALSH HILLS TRL PFP</name>`
      + `<status>Live</status>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>BTRGLASW</parentSiteName>`
      + `<street>F 1110 WALSH HILLS TRL PFP</street>`
      + `<state>TX</state>`
      + `<graniteLUId>2810024</graniteLUId>`
      + `<graniteID>2810024</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue7}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>AP-8</slotName>`
      + `<portName>OLT-1</portName>`
      + `<portAccessId>OLT-8-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/BTRGLASW</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>${oldnti}</NTI>`
      + `<NTIModifier>${ntiModifier}</NTIModifier>`
      + `<inServiceDate>24-Apr-2007</inServiceDate>`
      + `<dueDate>30-Jul-2012</dueDate>`
      + `<orderedDate>24-Apr-2007</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.textValue24}/${ntiModifier}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<orderNumber>3121282</orderNumber>`
      + `<orderType>OUT</orderType>`
      + `<status>IE-In Effect</status>`
      + `<BAN>403121282</BAN>`
      + `<graniteID>16045744</graniteID>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>F 1110 WALSH HILLS TRL PFP</name>`
      + `<status>Live</status>`
      + `<nPATTA>512255</nPATTA>`
      + `<parentSiteName>AUSYTXTV</parentSiteName>`
      + `<street>F 1110 WALSH HILLS TRL PFP</street>`
      + `<state>TX</state>`
      + `<graniteLUId>2810024</graniteLUId>`
      + `<graniteID>2810024</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>501 WALSH HILL TRL</name>`
      + `<status>Live</status>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>F 500 WALSH HILL TRL FST</parentSiteName>`
      + `<street>501 WALSH HILL TRL</street>`
      + `<state>TX</state>`
      + `<graniteLUId>G016046525</graniteLUId>`
      + `<graniteID>16046525</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>${oldnti}</NTI>`
      + `<NTIModifier>${ntiModifier}</NTIModifier>`
      + `</item>`
      + `<item>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 1110 WALSH HILLS TRL SPL-4</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>17</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT4194PA/AUSTTXRR</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>113</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 1110 WALSH HILLS TRL PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-113</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 1110 WALSH HILLS TRL PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-853</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1110WHT/AUSTTXRR</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>853</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 500 WALSH HILL TRL FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>F 500 WALSH HILL TRL FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-5-1-29-EGPON</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>MAIN-1</slotName>`
      + `<portName>PON FIBER</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>${oldnti}</NTI>`
      + `<NTIModifier>${ntiModifier}</NTIModifier>`
      + `<taperCode>4194PA</taperCode>`
      + `<requestID>D01-112975712-PON ACCESS</requestID>`
      + `<versionNumber>1</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>RNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>ROX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>EOD</instruction>`
      + `<seq1>6</seq1>`
      + `<seq2>7</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<inServiceDate>01-Sep-2011</inServiceDate>`
      + `<dueDate>04-Nov-2014</dueDate>`
      + `<orderedDate>01-Sep-2011</orderedDate>`
      + `<decommissionDate>04-Nov-2014</decommissionDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<componentCLLI>AUSYTXTVOL1</componentCLLI>`
      + `<componentLocation>AUSYTXTV</componentLocation>`
      + `<model>7340</model>`
      + `<deviceID>{fxOldOltTid.text}</deviceID>`
      + `<status>IE-In Effect</status>`
      + `<switchId>BTRGLASW0AW502</switchId>`
      + `<portName>1-1-3-1</portName>`
      + `</item>`
      + `<item>`
      + `<componentType>ONT</componentType>`
      + `<componentLocation>501 WALSH HILL TRL{16046525}</componentLocation>`
      + `<model>H-ONT-A</model>`
      + `<deviceID>ONT-8-1-5</deviceID>`
      + `<serialNo>1500438</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<portName>DATA-1</portName>`
      + `</item>`
      + `</componentList_GRP>`
      + `< /path>`
      + `< /GroupREC>`
      + `< transactionType > ARM_IN_OUT < /transactionType>`
      + `< /QueryNetworkInventoryResponse>`

    return Granite_Assignment;
  }

  //FTTN-BP Remote DSLAM/IP-RT Function
  FTTNBP_L1_Assignment(action: String): String {
    /*var pgs:String;*/
    this.SOAC_Circuit = this.SOAC_Circuit.replace(this.pattern, ".");
    this.SOAC_Circuit2 = this.SOAC_Circuit2.replace(this.pattern, ".");
    this.SOAC_Circuit2 = this.SOAC_Circuit2.replace("..", ".2.");

    // if (NTI.text == 'IP-RT-BP') {
    //   pgs = '73IPD';
    // } else {
    //   pgs = '73RMD';
    // }

    this.assignmentLines = "<SoacServiceOrder>\n"
      + "<bbnms:soacServiceOrderNumber>" + this.textValue9 + "</bbnms:soacServiceOrderNumber>\n"
      + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
      + "</SoacServiceOrder>\n"
      + "<assignmentLines>\n"
      + "<item>---ASGM</item>\n"
      + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
      + "<item>FA   4781 ROBINWOOD DR/RT 59G/RZ 13</item>\n"
      + "<item>IOE  00010-00110-62/EXK 440 257/TN </item>\n"
      + "<item>     440 209-1304/LPS/DF F01001</item>\n"
      + "<item>G2   WC 440 257</item>\n"
      + "<item>IF1  /CA 32/PR 973/CUC E NREQ/DF </item>\n"
      + "<item>     F01001/PRQ Y/BP 273/OBP 1303</item>\n"
      + "<item>     /TEA 4890 ROBINWOOD DR VRAD; </item>\n"
      + "<item>     PXJ/TPR 141502/RMTE </item>\n"
      + "<item>     LIGHTSPEED DSLAM/RMK RXJ TEA </item>\n"
      + "<item>     UG OP 9141 ROSEMARY LN-UF M </item>\n"
      + "<item>     BP 814</item>\n"
      + "<item>IF2  /CA " + this.textValue7 + "/PR " + this.textValue15 + "/PGS " + this.selectedPgs + ",1</item>\n"
      + "<item>     /PGSC U/CUR E " + this.selectedLts + "/BP 803/OBP </item>\n"
      + "<item>     814/TEA UG OP 9141 ROSEMARY </item>\n"
      + "<item>     LN-UF M; PXJ/RLC MNTROHTX/RLA </item>\n"
      + "<item>     4890 ROBINWOOD DR/RMTE PROJ </item>\n"
      + "<item>     LIGHTSPEED DA/NO FTWO CHNGES ON </item>\n"
      + "<item>     PRI PRS ALLOWED</item>\n"
      + "<item>IF3  /CA 9141R/PR 814/BP 4/TEA F </item>\n"
      + "<item>     4780 ROBINWOOD DR; CDW/RMTE </item>\n"
      + "<item>     LIGHTSPEED/RMKP PRIMARY PAIR</item>\n"
      + "<item>G1   CLS " + this.SOAC_Circuit2 + "</item>\n"
      + "<item>FA   4781 ROBINWOOD DR/RT 59G/RZ 13</item>\n"
      + "<item>IOE  00010-00110-62/EXK 440 257/TN </item>\n"
      + "<item>     440 209-1304/LPS/DF F01001</item>\n"
      + "<item>G2   WC 440 257</item>\n"
      + "<item>IF1  /CA 32/PR 973/CUC E NREQ/DF </item>\n"
      + "<item>     F01001/PRQ Y/BP 273/OBP 1303</item>\n"
      + "<item>     /TEA 4890 ROBINWOOD DR VRAD; </item>\n"
      + "<item>     PXJ/TPR 141502/RMTE </item>\n"
      + "<item>     LIGHTSPEED DSLAM/RMK RXJ TEA </item>\n"
      + "<item>     UG OP 9141 ROSEMARY LN-UF M </item>\n"
      + "<item>     BP 814</item>\n"
      + "<item>IF2  /CA " + this.textValue7 + "/PR " + this.textValue16 + "/PGS " + this.selectedPgs + ",1</item>\n"
      + "<item>     /PGSC U/CUR E " + this.selectedLts + "/BP 803/OBP </item>\n"
      + "<item>     814/TEA UG OP 9141 ROSEMARY </item>\n"
      + "<item>     LN-UF M; PXJ/RLC MNTROHTX/RLA </item>\n"
      + "<item>     4890 ROBINWOOD DR/RMTE PROJ </item>\n"
      + "<item>     LIGHTSPEED DA/NO FTWO CHNGES ON </item>\n"
      + "<item>     PRI PRS ALLOWED</item>\n"
      + "<item>IF3  /CA 9141R/PR 814/BP 4/TEA F </item>\n"
      + "<item>     4780 ROBINWOOD DR; CDW/RMTE </item>\n"
      + "<item>     LIGHTSPEED/RMKP BONDED MATE</item>\n"
      + "</assignmentLines>\n";

    this.SOAC_Assignment = this.csinmAssignment(action, this.assignmentLines);

    /*var soacAssignmentXML:XML = new XML(SOAC_Assignment);*/

    return this.SOAC_Assignment;
  }

  //FTTN Remote DSLAM/IP-RT Function
  FTTN_L1_Assignment(action: String): String {
    this.SOAC_Circuit = this.SOAC_Circuit.replace(this.pattern, ".");

    this.assignmentLines = "<SoacServiceOrder>\n"
      + "<bbnms:soacServiceOrderNumber>" + this.textValue25 + "</bbnms:soacServiceOrderNumber>\n"
      + "<bbnms:soacServiceOrderCorrectionSuffix>" + this.selectedSuffix + "</bbnms:soacServiceOrderCorrectionSuffix>\n"
      + "</SoacServiceOrder>\n"
      + "<assignmentLines>\n"
      + "<item>---ASGM</item>\n"
      + "<item>G1   CLS " + this.SOAC_Circuit + "</item>\n"
      + "<item>FA   1468 WOOD PARK WAY NW, KENNSW,</item>\n"
      + "<item>      GA/RT 1408/CZ 9</item>\n"
      + "<item>IOE  NR</item>\n"
      + "<item>G2   WC 770 422</item>\n"
      + "<item>IF1  /CA PG98/PR 9416/PGS SL53,5274</item>\n"
      + "<item>     /PGSC I/CUC E NREQ/CUR E ES</item>\n"
      + "<item>     /PRQ Y/BP 616/OBP 2204/TEC</item>\n"
      + "<item>      KNSWGAQN/TEA 1408E 1294</item>\n"
      + "<item>      GORDON COMBS RD NW VRAD; PXJ</item>\n"
      + "<item>     /RLC MRTTGAU0001/RLA 1408B1</item>\n"
      + "<item>      1630 KENNESAW DUE WEST RD/TPR</item>\n"
      + "<item>      140804/RMK RXJ TEA F 1294</item>\n"
      + "<item>      GORDON COMBS RD NW BP 3</item>\n"
      + "<item>IF2  /CA " + this.textValue7 + "/PR " + this.textValue8 + "/PGS " + this.selectedPgs + ",</item>\n"
      + "<item>     0484/PGSC U/CUR E " + this.selectedLts + "/BP 1004</item>\n"
      + "<item>     /OBP 3/TEC MRTTGAU0001/TEA F</item>\n"
      + "<item>      1294 GORDON COMBS RD NW; PXJ</item>\n"
      + "<item>     /RLC KNSWGAQN/RLA 1408E 1294</item>\n"
      + "<item>      GORDON COMBS RD NW VRAD/RMTE</item>\n"
      + "<item>      DO NOT USE PG50:1901-1925</item>\n"
      + "<item>IF3  /CA 1294GC/PR 3/BP 3/TEC</item>\n"
      + "<item>      MRTTGAMAH02/TEA F 1470 WOOD</item>\n"
      + "<item>      PARK WAY; CBW/RMKP LIGHTSPEED</item>\n"
      + "</assignmentLines>\n"

    this.SOAC_Assignment = this.csinmAssignment(action, this.assignmentLines);
    /*var soacAssignmentXML:XML = new XML(SOAC_Assignment);*/
    return this.SOAC_Assignment;
  }

  //FTTP-EGPON Function
  EFTTP_L1_Assignment() {
    var Granite_Assignment;

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi:schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>14.0</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}-${this.textValue11}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>Design</status>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>GA</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S SPL-5</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT1501/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>65</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-065</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-175</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1806R/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>175</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>${this.textValue5}</slotName>`
      + `<portName>${this.textValue11}</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONT 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>N01-${this.banValue}-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>7</seq1>`
      + `<seq2>8</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>TUCKER GEORGIA</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue10}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>AP-${this.textValue5}</slotName>`
      + `<portName>OLT-${this.textValue6}</portName>`
      + `<portAccessId>OLT-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>FOT 020270.09.11</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>71</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}/GPON</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>TUCKER GEORGIA</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>PON</elementCategory>`
      + `<channelName>9</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-5-1-29</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>ONT</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>T111G</model>`
      + `<deviceID>ONT-${this.textValue5}-${this.textValue6}-${this.textValue11}</deviceID>`
      + `<serialNo>1500438</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>1500</model>`
      + `<deviceID>${this.textValue10}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>ARM</transactionType>`
      + `</QueryNetworkInventoryResponse>`

    return Granite_Assignment;
  }

  //FTTC-EGPON Function
  EFTTC_L1_Assignment() {
    var Granite_Assignment;

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns="http://granite.it.att.com/qni/v2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://granite.it.att.com/qni/v2 ......main&#13;esourcesxsdgraniteQniResponse.xsd">`
      + `<schema_version>14.0</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>${this.circuitId}/VDSL</ID>`
      + `<category>VDSL</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>GA</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>2309 TRELLIS PL</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>233 TRELLIS PL EW BLDG 36 MDU</parentSiteName>`
      + `<street>TRELLIS PL</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>XDSL-${this.textValue18}</slotName>`
      + `<portName>XDSL-${this.textValue19}</portName>`
      + `<portAccessId>XDSL-${this.textValue18}-${this.textValue19}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>NID</elementName>`
      + `<elementCategory>NID</elementCategory>`
      + `<slotName>1</slotName>`
      + `<portName>VDSL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>00D09E-190711009414</elementName>`
      + `<elementCategory>RG</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>PHYSICAL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>N01-${this.banValue}-01</requestID>`
      + `<versionNumber>0</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>TDW</instruction>`
      + `<seq1>1</seq1>`
      + `<seq2>2</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}/GPON</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>771500394</BAN>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>231LS/PON/${this.wireCenter}OL0/12-4-2</elementName>`
      + `<elementCategory>PON</elementCategory>`
      + `<channelName>9</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>XDSL-${this.textValue18}</slotName>`
      + `<portName>XDSL-${this.textValue19}</portName>`
      + `<portAccessId>XDSL-${this.textValue18}-${this.textValue19}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}-${this.textValue17}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT2936PB/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>113</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-113</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-648</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1498A/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>1296</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>MAIN-A</slotName>`
      + `<portName>PON FIBER</portName>`
      + `<portAccessId>PON FIBER</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONTVDSL 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>5</seq1>`
      + `<seq2>6</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>6</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>2</seq1>`
      + `<seq2>3</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue10}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>AP-${this.textValue18}</slotName>`
      + `<portName>OLT-${this.textValue6}</portName>`
      + `<portAccessId>OLT-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>Pending</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>FOT 020270.09.11</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>71</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>ONU</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>T550G</model>`
      + `<deviceID>ONT-${this.textValue5}-${this.textValue6}-${this.textValue17}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>1500</model>`
      + `<deviceID>${this.textValue10}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>ARM</transactionType>`
      + `</QueryNetworkInventoryResponse>`

    return Granite_Assignment;
  }

  //FTTN/FTTN-BP Remote DSLAM/IP-RT Function "MPC"
  FTTN_MPC() {
    this.SOAC_Assignment = `<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">`
      + `<SOAP-ENV:Header xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">`
      + `<urn:MessageHeader xmlns:urn="urn:soap.embus.sbc.com">`
      + `<urn:MessageTag xmlns:urn="urn:soap.embus.sbc.com">SendFiberServiceFacilityMaintenanceNotification</urn:MessageTag>`
      + `<urn:ApplicationID xmlns:urn="urn:soap.embus.sbc.com">CSI</urn:ApplicationID>`
      + `<urn:MessageID xmlns:urn="urn:soap.embus.sbc.com">NEWIAP123</urn:MessageID>`
      + `<urn:ConversationKey xmlns:urn="urn:soap.embus.sbc.com">csitest~CNG-CSI~f3318314a5d39d32:7a3c47cd:132f7a8b123:bbnmskris</urn:ConversationKey>`
      + `<urn:LoggingKey xmlns:urn="urn:soap.embus.sbc.com">NEWIAP123</urn:LoggingKey>`
      + `</urn:MessageHeader>`
      + `</SOAP-ENV:Header>`
      + `<SOAP-ENV:Body xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">`
      + `<SendFiberServiceFacilityMaintenanceNotification xmlns="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd" xmlns:bbnms="http://csi.cingular.com/CSI/Namespaces/Types/Private/BBNMS/BBNMSDataModel.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd D:\dslnms\docs\CSI-Migration\ToolKit\BBNMS\SendFiberServiceFacilityMaintenanceNotification.xsd">`
      + `<serviceOrderAssignment xmlns="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd">`
      + `<bbnms:wireCenter>${this.wireCenter}</bbnms:wireCenter>`
      + `<bbnms:serviceOrderNumber>${this.textValue9}</bbnms:serviceOrderNumber>`
      + `<bbnms:lightspeedCircuitId>${this.circuitId}</bbnms:lightspeedCircuitId>`
      + `<bbnms:networkTypeChoice>`
      + `<bbnms:fttn>`
      + `<bbnms:segments>`
      + `<bbnms:item>`
      + `<bbnms:segmentNumber>1</bbnms:segmentNumber>`
      + `<bbnms:terminalId>R 1600 HANOVER AV</bbnms:terminalId>`
      + `<bbnms:outBindingPost>2107</bbnms:outBindingPost>`
      + `<bbnms:inCableName>1114FN_I/HSTNTXJA</bbnms:inCableName>`
      + `<bbnms:inCablePair>107</bbnms:inCablePair>`
      + `</bbnms:item>`
      + `<bbnms:item>`
      + `<bbnms:segmentNumber>2</bbnms:segmentNumber>`
      + `<bbnms:terminalId>R 1600 HANOVER AV</bbnms:terminalId>`
      + `<bbnms:inBindingPost>907</bbnms:inBindingPost>`
      + `<bbnms:inCableName>${this.textValue7}_O/${this.wireCenter}</bbnms:inCableName>`
      + `<bbnms:inCablePair>${this.textValue8}</bbnms:inCablePair>`
      + `</bbnms:item>`
      + `<bbnms:item>`
      + `<bbnms:segmentNumber>3</bbnms:segmentNumber>`
      + `<bbnms:terminalId>R 1513 BLUE MILLS RD</bbnms:terminalId>`
      + `<bbnms:inBindingPost>3</bbnms:inBindingPost>`
      + `<bbnms:outBindingPost>1790</bbnms:outBindingPost>`
      + `<bbnms:inCableName>1600H/HSTNTXJA</bbnms:inCableName>`
      + `<bbnms:inCablePair>1790</bbnms:inCablePair>`
      + `</bbnms:item>`
      + `</bbnms:segments>`
      + `</bbnms:fttn>`
      + `</bbnms:networkTypeChoice>`
      + `<bbnms:assignmentLines/>`
      + `</serviceOrderAssignment>`
      + `<Status xmlns="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd">`
      + `<bbnms:code>0</bbnms:code>`
      + `<bbnms:description>Success</bbnms:description>`
      + `</Status>`
      + `</SendFiberServiceFacilityMaintenanceNotification>`
      + `</SOAP-ENV:Body>`
      + `</SOAP-ENV:Envelope>;`

    return this.SOAC_Assignment;
  }

  //FTTP-GPON Function "MPC" 
  GPON_MPC() {
    var Granite_Assignment;
    var slotName: String = this.textValue5;
    var portName: String = this.textValue6;
    var sfuportName: String = this.textValue11;
    if (slotName.length == 1) {
      slotName = "0" + slotName;
    }

    if (portName.length == 1) {
      portName = "0" + portName;
    }

    if (sfuportName.length == 1) {
      sfuportName = "0" + sfuportName;
    }

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns: xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi: schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>14.0 < /schema_version>`
      + `< GroupREC >`
      + `<path>`
      + `<item>`
      + `<ID>231LS / PON / ${this.wireCenter}OL0 / 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /ID>`
      + `< category > PON ACCESS < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > L < /topology>`
      + `< status > Design < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< AsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > I 1498 ARAPAHO CEV TERM B PFP < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< street > I 1498 ARAPAHO CEV TERM B PFP < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< state > TX < /state>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>SFU < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > I 1498 ARAPAHO CEV TERM B PFP < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S SPL - 5 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > SPT1501 / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 65 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 065 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > APN - 175 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > PON1806R / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 175 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>6 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>7 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 02 < /slotName>`
      + `< portName > APN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>8 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > ONT < /elementCategory>`
      + `< slotName > ${slotName} < /slotName>`
      + `< portName > ${sfuportName} < /portName>`
      + `< portAccessId > ETH1 - 1 < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > ONT 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > GPON < /NTIModifier>`
      + `< taperCode > TaperCode < /taperCode>`
      + `< requestID > C01 - ${this.banValue} - 01 < /requestID>`
      + `< versionNumber > 2 < /versionNumber>`
      + `< workInstructions_GRP >`
      + `<item>`
      + `<instruction>POD < /instruction>`
      + `< seq1 > 7 < /seq1>`
      + `< seq2 > 8 < /seq2>`
      + `< /item>`
      + `< item >`
      + `<instruction>PNT < /instruction>`
      + `< seq1 > 8 < /seq1>`
      + `< /item>`
      + `< item >`
      + `<instruction>POX < /instruction>`
      + `< seq1 > 3 < /seq1>`
      + `< seq2 > 4 < /seq2>`
      + `< /item>`
      + `< /workInstructions_GRP>`
      + `< IPAddressType > Dynamic < /IPAddressType>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>231LS / PON / ${this.wireCenter}OL0 / 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /ID>`
      + `< category > PON ACCESS < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > L < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< AsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > I 1498 ARAPAHO CEV TERM B PFP < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< street > I 1498 ARAPAHO CEV TERM B PFP < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< state > TX < /state>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>SFU < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > I 1498 ARAPAHO CEV TERM B PFP < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S SPL - 5 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > SPT1501 / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 65 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 065 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1806 RIVER LAKES RD S PFP < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > APN - 175 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > PON1806R / OCNMWI11 < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 175 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>6 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NPN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>7 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > R1843 WELLSPRINGS CT FST < /elementName>`
      + `< elementCategory > FST < /elementCategory>`
      + `< slotName > 02 < /slotName>`
      + `< portName > APN - 01 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>8 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > ONT < /elementCategory>`
      + `< slotName > ${slotName} < /slotName>`
      + `< portName > ${sfuportName} < /portName>`
      + `< portAccessId > ETH1 - 1 < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > ONT 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< attributes_GRP >`
      + `<NTI>FTTP < /NTI>`
      + `< NTIModifier > GPON < /NTIModifier>`
      + `< taperCode > TaperCode < /taperCode>`
      + `< requestID > N01 - ${this.banValue} - 01 < /requestID>`
      + `< versionNumber > 2 < /versionNumber>`
      + `< workInstructions_GRP >`
      + `<item>`
      + `<instruction>POD < /instruction>`
      + `< seq1 > 7 < /seq1>`
      + `< seq2 > 8 < /seq2>`
      + `< /item>`
      + `< item >`
      + `<instruction>PNT < /instruction>`
      + `< seq1 > 8 < /seq1>`
      + `< /item>`
      + `< item >`
      + `<instruction>POX < /instruction>`
      + `< seq1 > 3 < /seq1>`
      + `< seq2 > 4 < /seq2>`
      + `< /item>`
      + `< /workInstructions_GRP>`
      + `< IPAddressType > Dynamic < /IPAddressType>`
      + `< /attributes_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>231LS / PON / ${this.wireCenter}OL0 / ${this.textValue5} - ${this.textValue6} < /ID>`
      + `< category > PON NETWORK < /category>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< topology > L < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< AsideSite >`
      + `<siteType>CO < /siteType>`
      + `< name > ${this.wireCenter} < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< servingWireCenterCLLI > ${this.wireCenter} < /servingWireCenterCLLI>`
      + `< parentSiteName > DALLAS TEXAS < /parentSiteName>`
      + `< sBCISPoolName > RCSNTXHV LIGHTSPEED HSIA LAN < /sBCISPoolName>`
      + `< latitude > 32.9492 < /latitude>`
      + `< longitude > -96.7292 < /longitude>`
      + `< street > 201 NORTH GREENVILLE AVENUE / 20 < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>PFP < /siteType>`
      + `< name > I 1498 ARAPAHO CEV TERM B PFP < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > ${this.wireCenter} < /parentSiteName>`
      + `< street > I 1498 ARAPAHO CEV TERM B PFP < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< state > TX < /state>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ${this.textValue10} < /elementName>`
      + `< elementCategory > OLT < /elementCategory>`
      + `< slotName > ${slotName} < /slotName>`
      + `< portName > ${portName} < /portName>`
      + `< portAccessId > 1 - 1 - ${this.textValue5} - ${this.textValue6} < /portAccessId>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > FOT 020270.09.11 < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 00 FRONT < /slotName>`
      + `< portName > 71 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>3 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > OSP 020270.10.01 < /elementName>`
      + `< elementCategory > FDP < /elementCategory>`
      + `< slotName > 00 FRONT < /slotName>`
      + `< portName > 63 < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>4 < /sequenceNumber>`
      + `< objectType > CablePair < /objectType>`
      + `< elementName > RN028 / ${this.wireCenter} < /elementName>`
      + `< elementCategory > SMF < /elementCategory>`
      + `< cablePairStrand > 63 < /cablePairStrand>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>5 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > I 1498 ARAPAHO CEV TERM B PFP SPL - 15 < /elementName>`
      + `< elementCategory > OPTICAL SPLITTER < /elementCategory>`
      + `< slotName > 01 < /slotName>`
      + `< portName > NT PORT < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > MAIN FROM CO TO PFP < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< /item>`
      + `< item >`
      + `<ID>${this.circuitId} / GPON < /ID>`
      + `< category > GPON < /category>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< topology > P < /topology>`
      + `< status > IE - In Effect < /status>`
      + `< BAN > ${this.banValue} < /BAN>`
      + `< AsideSite >`
      + `<siteType>CO < /siteType>`
      + `< name > ${this.wireCenter} < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< servingWireCenterCLLI > ${this.wireCenter} < /servingWireCenterCLLI>`
      + `< parentSiteName > DALLAS TEXAS < /parentSiteName>`
      + `< sBCISPoolName > RCSNTXHV LIGHTSPEED HSIA LAN < /sBCISPoolName>`
      + `< latitude > 32.9492 < /latitude>`
      + `< longitude > -96.7292 < /longitude>`
      + `< street > 201 NORTH GREENVILLE AVENUE / 20 < /street>`
      + `< structureType />`
      + `<structureValue/>`
      + `< elevationType />`
      + `<elevationValue/>`
      + `< unitType />`
      + `<unitValue/>`
      + `< city > RICHARDSON < /city>`
      + `< county > DALLAS < /county>`
      + `< state > TX < /state>`
      + `< postal_Code_1 > 75081 < /postal_Code_1>`
      + `< /AsideSite>`
      + `< ZsideSite >`
      + `<siteType>REMOTE TERM < /siteType>`
      + `< name > 233 TRELLIS PL EW BLDG 36 < /name>`
      + `< nPATTA > 972231 < /nPATTA>`
      + `< parentSiteName > I 1498 ARAPAHO CEV TERM B PFP < /parentSiteName>`
      + `< street > 233 TRELLIS PL EW BLDG 36 < /street>`
      + `< state > TX < /state>`
      + `< /ZsideSite>`
      + `< Leg_GRP >`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1 < /sequenceNumber>`
      + `< objectType > Channel < /objectType>`
      + `< elementName > 231LS / PON / ${this.wireCenter}OL0 / 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > PON < /elementCategory>`
      + `< channelName > 9 < /channelName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > 25 MBPS < /bandwidth>`
      + `< /sequence>`
      + `< sequence >`
      + `<sequenceNumber>2 < /sequenceNumber>`
      + `< objectType > Port < /objectType>`
      + `< elementName > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /elementName>`
      + `< elementCategory > ONT < /elementCategory>`
      + `< slotName > ${slotName} < /slotName>`
      + `< portName > ${sfuportName} < /portName>`
      + `< status > IE - In Effect < /status>`
      + `< bandwidth > FIBER < /bandwidth>`
      + `< /sequence>`
      + `< legName > 1 < /legName>`
      + `< /leg>`
      + `< /Leg_GRP>`
      + `< /item>`
      + `< componentList_GRP >`
      + `<item>`
      + `<componentType>ONT < /componentType>`
      + `< vendor > ALCATEL < /vendor>`
      + `< model > H - ONT - A < /model>`
      + `< deviceID > ONT - 1 - 1 - ${this.textValue5} - ${this.textValue6} - ${this.textValue11} < /deviceID>`
      + `< serialNo > 210711005126 < /serialNo>`
      + `< status > IE - In Effect < /status>`
      + `< inServiceDate > 20070705 < /inServiceDate>`
      + `< dueDate > 20070705 < /dueDate>`
      + `< orderedDate > 20070705 < /orderedDate>`
      + `< purchaseDate > 20070705 < /purchaseDate>`
      + `< scheduleDate > 20070705 < /scheduleDate>`
      + `< installedDate > 20070705 < /installedDate>`
      + `< decommissionDate > 20070705 < /decommissionDate>`
      + `< UVerseTechnology > Lightspeed < /UVerseTechnology>`
      + `< /item>`
      + `< item >`
      + `<componentType>OLT < /componentType>`
      + `< vendor > ALCATEL < /vendor>`
      + `< model > 7342 < /model>`
      + `< deviceID > ${this.textValue10} < /deviceID>`
      + `< serialNo > 210711005126 < /serialNo>`
      + `< status > IE - In Effect < /status>`
      + `< inServiceDate > 20070705 < /inServiceDate>`
      + `< dueDate > 20070705 < /dueDate>`
      + `< orderedDate > 20070705 < /orderedDate>`
      + `< purchaseDate > 20070705 < /purchaseDate>`
      + `< scheduleDate > 20070705 < /scheduleDate>`
      + `< installedDate > 20070705 < /installedDate>`
      + `< decommissionDate > 20070705 < /decommissionDate>`
      + `< UVerseTechnology > Lightspeed < /UVerseTechnology>`
      + `< /item>`
      + `< /componentList_GRP>`
      + `< /path>`
      + `< /GroupREC>`
      + `< transactionType > MTC < /transactionType>`
      + `< /QueryNetworkInventoryResponse>;`

    return Granite_Assignment;
  }

  // FTTPIP Function 
  FTTPIP_L1_Assignment_Granite() {
    var Granite_Assignment;

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns="http://granite.it.att.com/qni/v2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>14.0</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>${this.circuitId}/BPON</ID>`
      + `<category>BPON DATA</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<graniteID>34636</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>LAGRGANS</name>`
      + `<status>Live</status>`
      + `<nPATTA>214331</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTX LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<street>123</street>`
      + `<city>DALLAS</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<graniteLUId>13388</graniteLUId>`
      + `<graniteID>13388</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<status>IE-In Effect</status>`
      + `<nPATTA>214331</nPATTA>`
      + `<parentSiteName>233 TRELLIS PL EW BLDG 36 FST</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<graniteID>27971</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>BPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/GE1/${this.wireCenter}LANX/${this.textValue10}</elementName>`
      + `<elementCategory>ENET</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/PON/${this.textValue10}/1-1-${this.textValue5}-${this.textValue6}</elementName>`
      + `<elementCategory>PON NETWORK</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/PON/${this.textValue10}/1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>PON ACCESS</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>3</slotName>`
      + `<portName>DATA-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>10/100BASET</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>BPON</NTIModifier>`
      + `<inServiceDate>25-Mar-2008</inServiceDate>`
      + `<orderedDate>25-Mar-2008</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>101LS/PON/${this.textValue10}/1-1-${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<graniteID>34616</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<status>Live</status>`
      + `<nPATTA>214331</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTX LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<street>123</street>`
      + `<city>DALLAS</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<graniteLUId>13388</graniteLUId>`
      + `<graniteID>13388</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 PFP</name>`
      + `<status>IE-In Effect</status>`
      + `<nPATTA>214331</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<graniteLUId>27973</graniteLUId>`
      + `<graniteID>27973</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue10}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>LP-${this.textValue5}</slotName>`
      + `<portName>${this.textValue6}</portName>`
      + `<portAccessId>1-1-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>FOT 020270.09.11</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>71</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/DLLSTXRN</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>BPON</NTIModifier>`
      + `<inServiceDate>28-Mar-2008</inServiceDate>`
      + `<dueDate>28-Mar-2008</dueDate>`
      + `<orderedDate>25-Mar-2008</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>101LS/PON/${this.textValue10}/1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<graniteID>34617</graniteID>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 PFP</name>`
      + `<status>IE-In Effect</status>`
      + `<nPATTA>214331</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<graniteLUId>27973</graniteLUId>`
      + `<graniteID>27973</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<status>IE-In Effect</status>`
      + `<nPATTA>214331</nPATTA>`
      + `<parentSiteName>233 TRELLIS PL EW BLDG 36 FST</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<graniteID>27971</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>BPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S SPL-5</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT1501/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>65</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-065</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-175</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1806R/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>175</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>BPON</NTIModifier>`
      + `<requestID>N01-${this.banValue}-01</requestID>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>7</seq1>`
      + `<seq2>8</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<inServiceDate>25-Mar-2008</inServiceDate>`
      + `<orderedDate>25-Mar-2008</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<componentCLLI>${this.wireCenter}OLT</componentCLLI>`
      + `<componentLocation>${this.wireCenter}</componentLocation>`
      + `<model>7340</model>`
      + `<deviceID>${this.textValue10}</deviceID>`
      + `<status>Pending</status>`
      + `<portName>1-1-${this.textValue5}-${this.textValue6}</portName>`
      + `</item>`
      + `<item>`
      + `<componentType>ONT</componentType>`
      + `<componentLocation>233 TRELLIS PL EW BLDG 36{27971}</componentLocation>`
      + `<model>H-ONT-A</model>`
      + `<deviceID>ONT-1-1-${this.textValue5}-${this.textValue6}-${this.textValue11}</deviceID>`
      + `<status>IE-In Effect</status>`
      + `<portName>DATA-1</portName>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>ARM</transactionType>`
      + `< /QueryNetworkInventoryResponse>`

    return Granite_Assignment;
  }

  //RGPON Function
  RGPON_L1_Assignment() {
    var Granite_Assignment;
    var slotName: String = this.textValue5;

    if (slotName.length == 1) {
      slotName = "0" + slotName;
    }

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi:schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>14.0</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>${this.circuitId}/VDSL</ID>`
      + `<category>VDSL</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>GA</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>2309 TRELLIS PL</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>233 TRELLIS PL EW BLDG 36 MDU</parentSiteName>`
      + `<street>TRELLIS PL</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>LP-${this.textValue18}/COMBO-${this.textValue18}-${this.textValue19}</slotName>`
      + `<portName>VDSL-${this.textValue18}-${this.textValue19}</portName>`
      + `<portAccessId>ONTVDSL-1-1-${this.textValue5}-${this.textValue6}-${this.textValue17}-${this.textValue18}-${this.textValue19}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>NID</elementName>`
      + `<elementCategory>NID</elementCategory>`
      + `<slotName>1</slotName>`
      + `<portName>VDSL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>00D09E-190711009414</elementName>`
      + `<elementCategory>RG</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>PHYSICAL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>RGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>N01-${this.banValue}-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>TDW</instruction>`
      + `<seq1>1</seq1>`
      + `<seq2>2</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}/GPON</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>100294098</BAN>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>TUCKER GEORGIA</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>231LS/PON/${this.wireCenter}OL0/1</elementName>`
      + `<elementCategory>PON</elementCategory>`
      + `<channelName>9</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>PON FIBER</slotName>`
      + `<portName>PON FIBER</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/1-1-${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT2936PB/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>113</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-113</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-648</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1498A/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>1296</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>MAIN-A</slotName>`
      + `<portName>PON FIBER</portName>`
      + `<portAccessId>PON FIBER</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONTVDSL 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>RGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>5</seq1>`
      + `<seq2>6</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>6</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>2</seq1>`
      + `<seq2>3</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/1-1-${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>TUCKER GEORGIA</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>TUCKER</city>`
      + `<county>DEKALB</county>`
      + `<state>GA</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>GA</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue10}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>LP-${slotName}</slotName>`
      + `<portName>{RGPON_Port.text}</portName>`
      + `<portAccessId>1-1-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>Pending</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>FOT 020270.09.11</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>71</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>ONU</componentType>`
      + `<vendor>ALCATEL</vendor>`
      + `<model>M300</model>`
      + `<deviceID>ONU-1-1-${this.textValue5}-${this.textValue6}-${this.textValue17}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<vendor>ALCATEL</vendor>`
      + `<model>7342</model>`
      + `<deviceID>${this.textValue10}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>ARM</transactionType>`
      + `</QueryNetworkInventoryResponse>;`

    return Granite_Assignment;
  }

  // FTTN CO DSLAM/IP-CO "MPC" Function
  FTTN_CO_MPC() {
    var SOAC_Assignment;

    SOAC_Assignment = `<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">`
      + `<SOAP-ENV:Header xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">`
      + `<urn:MessageHeader xmlns:urn="urn:soap.embus.sbc.com">`
      + `<urn:MessageTag xmlns:urn="urn:soap.embus.sbc.com">SendFiberServiceFacilityMaintenanceNotification</urn:MessageTag>`
      + `<urn:ApplicationID xmlns:urn="urn:soap.embus.sbc.com">CSI</urn:ApplicationID>`
      + `<urn:MessageID xmlns:urn="urn:soap.embus.sbc.com">NEWIAP123</urn:MessageID>`
      + `<urn:ConversationKey xmlns:urn="urn:soap.embus.sbc.com">csitest~CNG-CSI~f3318314a5d39d32:7a3c47cd:132f7a8b123:bbnmskris</urn:ConversationKey>`
      + `<urn:LoggingKey xmlns:urn="urn:soap.embus.sbc.com">NEWIAP123</urn:LoggingKey>`
      + `</urn:MessageHeader>`
      + `</SOAP-ENV:Header>`
      + `<SOAP-ENV:Body xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">`
      + `<SendFiberServiceFacilityMaintenanceNotification xmlns="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd" xmlns:bbnms="http://csi.cingular.com/CSI/Namespaces/Types/Private/BBNMS/BBNMSDataModel.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd D:\dslnms\docs\CSI-Migration\ToolKit\BBNMS\SendFiberServiceFacilityMaintenanceNotification.xsd">`
      + `<serviceOrderAssignment xmlns="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd">`
      + `<bbnms:wireCenter>${this.wireCenter}</bbnms:wireCenter>`
      + `<bbnms:serviceOrderNumber>${this.textValue9}</bbnms:serviceOrderNumber>`
      + `<bbnms:lightspeedCircuitId>${this.circuitId}</bbnms:lightspeedCircuitId>`
      + `<bbnms:networkTypeChoice>`
      + `<bbnms:fttn>`
      + `<bbnms:dSLAM>`
      + `< bbnms: id > ${this.textTitle12} - ${this.textValue5} - ${this.textTitle6} < /bbnms:id>`
      + `< bbnms: connectivityStatus > false < /bbnms:connectivityStatus>`
      + `</bbnms:dSLAM>`
      + `<bbnms:segments>`
      + `< bbnms: item >`
      + `<bbnms:segmentNumber>1</bbnms:segmentNumber>`
      + `< /bbnms:item>`
      + `</bbnms:segments>`
      + `</bbnms:fttn>`
      + `</bbnms:networkTypeChoice>`
      + `<bbnms:assignmentLines/>`
      + `</serviceOrderAssignment>`
      + `<Status xmlns="http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityMaintenanceNotification.xsd">`
      + `<bbnms:code>0</bbnms:code>`
      + `<bbnms:description>Success</bbnms:description>`
      + `</Status>`
      + `</SendFiberServiceFacilityMaintenanceNotification>`
      + `</SOAP-ENV:Body>`
      + `</SOAP-ENV:Envelope>;`

    return SOAC_Assignment;

  }

  //FTTC-GPON Function "MPC"
  FTTCGPON_MPC() {
    var Granite_Assignment

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns="http://granite.it.att.com/qni/v2">`
      + `<schema_version>RJUN</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>A2/MCXX/2345123//SW/GPON</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>GPON</bandwidth>`
      + `<topology>P</topology>`
      + `<orderNumber>2456123</orderNumber>`
      + `<status>Design</status>`
      + `<BAN>234512311</BAN>`
      + `<graniteID>104641</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>MCISMIMN</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>UPPER PENINSULA MI</parentSiteName>`
      + `<street>@ HOBAN ST</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>15715</graniteLUId>`
      + `<graniteID>15715</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>HARBOR RD MDU</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD PFP</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62536</graniteLUId>`
      + `<graniteID>62536</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</elementName>`
      + `<elementCategory>PON NETWORK</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>GPON</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}-1</elementName>`
      + `<elementCategory>PON ACCESS</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>GPON</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue1}</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>LT/COMBO-7367-1</slotName>`
      + `<portName>COMBO</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<dueDate>29-Jul-2015</dueDate>`
      + `<orderedDate>20-Jul-2015</orderedDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<graniteID>104594</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>MCISMIMN</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>UPPER PENINSULA MI</parentSiteName>`
      + `<street>@ HOBAN ST</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>15715</graniteLUId>`
      + `<graniteID>15715</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>HARBOR RD PFP</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>MCISMIMN</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62535</graniteLUId>`
      + `<graniteID>62535</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue2}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>LT-01</slotName>`
      + `<portName>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portName>`
      + `<portAccessId>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD SPL-1</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO HDT</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<dueDate>17-Jul-2015</dueDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>101LS/PON/MCISMIMNOL0/${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}-1</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<graniteID>104596</graniteID>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>MCISMIMN</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>UPPER PENINSULA MI</parentSiteName>`
      + `<street>@ HOBAN ST</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>15715</graniteLUId>`
      + `<graniteID>15715</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>HARBOR RD MDU</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD PFP</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62536</graniteLUId>`
      + `<graniteID>62536</graniteID>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD SPL-1</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>1112FN/MCISMIMN</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>1</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-001</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>HARBOR RD PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-001</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>1112FN/MCISMIMN</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>5</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue1}</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>NT-A</slotName>`
      + `<portName>PON FIBER</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>CDW</instruction>`
      + `<seq1>6</seq1>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<dueDate>17-Jul-2015</dueDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}</ID>`
      + `<category>VDSL</category>`
      + `<bandwidth>VDSL</bandwidth>`
      + `<topology>P</topology>`
      + `<orderNumber>2456123</orderNumber>`
      + `<status>Design</status>`
      + `<BAN>234512311</BAN>`
      + `<graniteID>104718</graniteID>`
      + `<AsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>HARBOR RD MDU</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD PFP</parentSiteName>`
      + `<street>HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>62536</graniteLUId>`
      + `<graniteID>62536</graniteID>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>1234 HARBOR RD</name>`
      + `<status>Live</status>`
      + `<nPATTA>906847</nPATTA>`
      + `<servingWireCenterCLLI>MCISMIMN</servingWireCenterCLLI>`
      + `<parentSiteName>HARBOR RD MDU</parentSiteName>`
      + `<street>1234 HARBOR RD</street>`
      + `<city>MACKINAC ISLAND</city>`
      + `<state>MI</state>`
      + `<postal_Code_1>49757</postal_Code_1>`
      + `<graniteLUId>G000062554</graniteLUId>`
      + `<graniteID>62554</graniteID>`
      + `<NTI_GRP>`
      + `<item>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `</item>`
      + `</NTI_GRP>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>A2/MCXX/2345123//SW/GPON</elementName>`
      + `<elementCategory>GPON</elementCategory>`
      + `<channelName>1</channelName>`
      + `<status>Design</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue1}</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>LT/COMBO-7367-1</slotName>`
      + `<portName>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portName>`
      + `<portAccessId>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>XDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>NID</elementName>`
      + `<elementCategory>NID</elementCategory>`
      + `<slotName>1</slotName>`
      + `<portName>XDSL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>XDSL</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>GPON</NTIModifier>`
      + `<dueDate>29-Jul-2015</dueDate>`
      + `</attributes_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<componentCLLI>${(this.textValue2)?.substr(0, 11)}</componentCLLI>`
      + `<componentLocation>${(this.textValue2)?.substr(0, 8)}</componentLocation>`
      + `<model>7342</model>`
      + `<deviceID>${this.textValue2}</deviceID>`
      + `<status>IE-In Effect</status>`
      + `<portName>${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</portName>`
      + `</item>`
      + `<item>`
      + `<componentType>ONU</componentType>`
      + `<componentCLLI>${(this.textValue1)?.substr(0, 8)}</componentCLLI>`
      + `<componentLocation>HARBOR RD MDU&#123;62536&#125;</componentLocation>`
      + `<model>7367</model>`
      + `<deviceID>${this.textValue1}-${this.textValue3}-${this.textValue4}-${this.textValue5}-${this.textValue6}</deviceID>`
      + `<status>IE-In Effect</status>`
      + `<portName>COMBO</portName>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>MTC</transactionType>`
      + `</QueryNetworkInventoryResponse>`

    return Granite_Assignment;
  }

  // FTTP-EGPON Function "MPC"
  EFTTP_MPC() {
    var Granite_Assignment;
    var slotName: String = this.textValue5;
    var oldslotName: String = this.textValue31;
    var sfuportName: String = this.textValue11;
    var oldsfuportName: String = this.textValue33;

    if (slotName.length == 1) {
      slotName = "0" + slotName;
    }

    if (oldslotName.length == 1) {
      oldslotName = "0" + oldslotName;
    }

    if (sfuportName.length == 1) {
      sfuportName = "0" + sfuportName;
    }
    if (oldsfuportName.length == 1) {
      oldsfuportName = "0" + oldsfuportName;
    }

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi:schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>13.0</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue31}-${this.textValue32}-${this.textValue33}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>TX</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S SPL-5</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT1501/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>65</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-065</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-175</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1806R/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>175</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-${this.textValue31}-${this.textValue32}-${this.textValue33}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>${oldslotName}</slotName>`
      + `<portName>${oldsfuportName}</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONT 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>7</seq1>`
      + `<seq2>8</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}-${this.textValue11}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>TX</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S SPL-5</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT1501/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>65</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-065</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1806 RIVER LAKES RD S PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-175</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1806R/OCNMWI11</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>175</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>7</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>R1843 WELLSPRINGS CT FST</elementName>`
      + `<elementCategory>FST</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>8</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-${this.textValue5}-${this.textValue32}-${this.textValue33}</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>${slotName}</slotName>`
      + `<portName>${sfuportName}</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONT 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTP</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>C01-${this.banValue}-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>7</seq1>`
      + `<seq2>8</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>8</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>3</seq1>`
      + `<seq2>4</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>TX</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue10}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>AP-${slotName}</slotName>`
      + `<portName>OLT-${this.textValue6}</portName>`
      + `<portAccessId>OLT-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>FOT 020270.09.11</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>71</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}/GPON</ID>`
      + `<category>GPON</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>TX</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Channel</objectType>`
      + `<elementName>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}-${this.textValue11}</elementName>`
      + `<elementCategory>PON</elementCategory>`
      + `<channelName>9</channelName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>ONT-3-2-1</elementName>`
      + `<elementCategory>ONT</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<portAccessId>ETH1-1</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>ONT</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>T111G</model>`
      + `<deviceID>ONT-${this.textValue5}-${this.textValue6}-${this.textValue11}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>1500</model>`
      + `<deviceID>${this.textValue10}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>MTC</transactionType>`
      + `</QueryNetworkInventoryResponse>;`

    return Granite_Assignment;

  }

  // FTTC-EGPON Function "MPC"
  EFTTC_MPC() {
    var Granite_Assignment;
    var slotName: String = this.textValue5;
    var mduslotName: String = this.textValue18;
    var oldmduslotName: String = this.textValue29;

    if (slotName.length == 1) {
      slotName = "0" + slotName;
    }

    if (mduslotName.length == 1) {
      mduslotName = "0" + mduslotName;
    }

    if (oldmduslotName.length == 1) {
      oldmduslotName = "0" + oldmduslotName;
    }

    Granite_Assignment = `<QueryNetworkInventoryResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://granite.it.att.com/qni/v2" xsi:schemaLocation="http://granite.it.att.com/qni/v2">`
      + `<schema_version>13.0</schema_version>`
      + `<GroupREC>`
      + `<path>`
      + `<item>`
      + `<ID>${this.circuitId}/VDSL</ID>`
      + `<category>VDSL</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>IE-In Effect</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>TX</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>2309 TRELLIS PL</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>233 TRELLIS PL EW BLDG 36 MDU</parentSiteName>`
      + `<street>TRELLIS PL</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>XDSL-${oldmduslotName}</slotName>`
      + `<portName>XDSL-${this.textValue19}</portName>`
      + `<portAccessId>XDSL-${this.textValue18}-${this.textValue19}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>NID</elementName>`
      + `<elementCategory>NID</elementCategory>`
      + `<slotName>1</slotName>`
      + `<portName>VDSL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>00D09E-190711009414</elementName>`
      + `<elementCategory>RG</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>PHYSICAL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>N01-${this.banValue}-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>TDW</instruction>`
      + `<seq1>1</seq1>`
      + `<seq2>2</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>${this.circuitId}/VDSL</ID>`
      + `<category>VDSL</category>`
      + `<bandwidth>25 MBPS</bandwidth>`
      + `<topology>P</topology>`
      + `<status>Design</status>`
      + `<BAN>${this.banValue}</BAN>`
      + `<AsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>TX</state>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>SFU</siteType>`
      + `<name>2309 TRELLIS PL</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>233 TRELLIS PL EW BLDG 36 MDU</parentSiteName>`
      + `<street>TRELLIS PL</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>XDSL-${mduslotName}</slotName>`
      + `<portName>XDSL-${this.textValue19}</portName>`
      + `<portAccessId>XDSL-${this.textValue18}-${this.textValue19}</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>NID</elementName>`
      + `<elementCategory>NID</elementCategory>`
      + `<slotName>1</slotName>`
      + `<portName>VDSL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>VDSL</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>00D09E-190711009414</elementName>`
      + `<elementCategory>RG</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>PHYSICAL-1</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>COPPER</bandwidth>`
      + `</sequence>`
      + `<legName>1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<requestID>C01-${this.banValue}-01</requestID>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>TDW</instruction>`
      + `<seq1>1</seq1>`
      + `<seq2>2</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}-${this.textValue17}</ID>`
      + `<category>PON ACCESS</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>REMOTE TERM</siteType>`
      + `<name>233 TRELLIS PL EW BLDG 36 MDU</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>I 1498 ARAPAHO CEV TERM B PFP</parentSiteName>`
      + `<street>233 TRELLIS PL EW BLDG 36</street>`
      + `<state>TX</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>01</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>SPT2936PB/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>113</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NPN-113</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>APN-648</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>PON1498A/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>1296</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>6</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>233 TRELLIS PL EW BLDG 36 MDU</elementName>`
      + `<elementCategory>ONU</elementCategory>`
      + `<slotName>MAIN-A</slotName>`
      + `<portName>PON FIBER</portName>`
      + `<portAccessId>PON FIBER</portAccessId>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>ONTVDSL 1</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `<attributes_GRP>`
      + `<NTI>FTTC</NTI>`
      + `<NTIModifier>EGPON</NTIModifier>`
      + `<taperCode>TaperCode</taperCode>`
      + `<versionNumber>2</versionNumber>`
      + `<workInstructions_GRP>`
      + `<item>`
      + `<instruction>POD</instruction>`
      + `<seq1>5</seq1>`
      + `<seq2>6</seq2>`
      + `</item>`
      + `<item>`
      + `<instruction>PNT</instruction>`
      + `<seq1>6</seq1>`
      + `</item>`
      + `<item>`
      + `<instruction>POX</instruction>`
      + `<seq1>2</seq1>`
      + `<seq2>3</seq2>`
      + `</item>`
      + `</workInstructions_GRP>`
      + `<IPAddressType>Dynamic</IPAddressType>`
      + `</attributes_GRP>`
      + `</item>`
      + `<item>`
      + `<ID>231LS/PON/${this.wireCenter}OL0/${this.textValue5}-${this.textValue6}</ID>`
      + `<category>PON NETWORK</category>`
      + `<bandwidth>FIBER</bandwidth>`
      + `<topology>L</topology>`
      + `<status>IE-In Effect</status>`
      + `<AsideSite>`
      + `<siteType>CO</siteType>`
      + `<name>${this.wireCenter}</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<servingWireCenterCLLI>${this.wireCenter}</servingWireCenterCLLI>`
      + `<parentSiteName>DALLAS TEXAS</parentSiteName>`
      + `<sBCISPoolName>RCSNTXHV LIGHTSPEED HSIA LAN</sBCISPoolName>`
      + `<latitude>32.9492</latitude>`
      + `<longitude>-96.7292</longitude>`
      + `<street>201 NORTH GREENVILLE AVENUE/20</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<city>RICHARDSON</city>`
      + `<county>DALLAS</county>`
      + `<state>TX</state>`
      + `<postal_Code_1>75081</postal_Code_1>`
      + `</AsideSite>`
      + `<ZsideSite>`
      + `<siteType>PFP</siteType>`
      + `<name>I 1498 ARAPAHO CEV TERM B PFP</name>`
      + `<nPATTA>972231</nPATTA>`
      + `<parentSiteName>${this.wireCenter}</parentSiteName>`
      + `<street>I 1498 ARAPAHO CEV TERM B PFP</street>`
      + `<structureType/>`
      + `<structureValue/>`
      + `<elevationType/>`
      + `<elevationValue/>`
      + `<unitType/>`
      + `<unitValue/>`
      + `<state>TX</state>`
      + `</ZsideSite>`
      + `<Leg_GRP>`
      + `<leg>`
      + `<sequence>`
      + `<sequenceNumber>1</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>${this.textValue10}</elementName>`
      + `<elementCategory>OLT</elementCategory>`
      + `<slotName>AP-${slotName}</slotName>`
      + `<portName>OLT-${this.textValue6}</portName>`
      + `<portAccessId>OLT-${this.textValue5}-${this.textValue6}</portAccessId>`
      + `<status>Pending</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>2</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>FOT 020270.09.11</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>71</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>3</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>OSP 020270.10.01</elementName>`
      + `<elementCategory>FDP</elementCategory>`
      + `<slotName>00 FRONT</slotName>`
      + `<portName>63</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>4</sequenceNumber>`
      + `<objectType>CablePair</objectType>`
      + `<elementName>RN028/${this.wireCenter}</elementName>`
      + `<elementCategory>SMF</elementCategory>`
      + `<cablePairStrand>63</cablePairStrand>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<sequence>`
      + `<sequenceNumber>5</sequenceNumber>`
      + `<objectType>Port</objectType>`
      + `<elementName>I 1498 ARAPAHO CEV TERM B PFP SPL-15</elementName>`
      + `<elementCategory>OPTICAL SPLITTER</elementCategory>`
      + `<slotName>01</slotName>`
      + `<portName>NT PORT</portName>`
      + `<status>IE-In Effect</status>`
      + `<bandwidth>FIBER</bandwidth>`
      + `</sequence>`
      + `<legName>MAIN FROM CO TO PFP</legName>`
      + `</leg>`
      + `</Leg_GRP>`
      + `</item>`
      + `<componentList_GRP>`
      + `<item>`
      + `<componentType>ONU</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>T550G</model>`
      + `<deviceID>ONT-${this.textValue5}-${this.textValue6}-${this.textValue17}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `<item>`
      + `<componentType>OLT</componentType>`
      + `<vendor>ERICSSON</vendor>`
      + `<model>1500</model>`
      + `<deviceID>${this.textValue10}</deviceID>`
      + `<serialNo>210711005126</serialNo>`
      + `<status>IE-In Effect</status>`
      + `<inServiceDate>20070705</inServiceDate>`
      + `<dueDate>20070705</dueDate>`
      + `<orderedDate>20070705</orderedDate>`
      + `<purchaseDate>20070705</purchaseDate>`
      + `<scheduleDate>20070705</scheduleDate>`
      + `<installedDate>20070705</installedDate>`
      + `<decommissionDate>20070705</decommissionDate>`
      + `<UVerseTechnology>Lightspeed</UVerseTechnology>`
      + `</item>`
      + `</componentList_GRP>`
      + `</path>`
      + `</GroupREC>`
      + `<transactionType>MTC</transactionType>`
      + `</QueryNetworkInventoryResponse>;`

    return Granite_Assignment;
  }

  csinmAssignment(action: String, assignmentLines: String): String {
    var assignment: String;

    if (action == 'L1 Assignment') {
      assignment = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
        + "<SOAP-ENV:Header>\n"
        + "<mes:MessageHeader xmlns:mes=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\">\n"
        + "<mes:TrackingMessageHeader>\n"
        + "<cin:conversationId xmlns:cin=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">spm2async~CNG-CSI~2eaa6420-6656-4965-8173-1e0d73ec4147</cin:conversationId>\n"
        + "<cin:uniqueTransactionId xmlns:cin=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">SendFiberServiceFacilityAssignmentNotification</cin:uniqueTransactionId>\n"
        + "</mes:TrackingMessageHeader>\n"
        + "</mes:MessageHeader>\n"
        /*+"<urn:MessageHeader xmlns:urn=\"urn:soap.embus.sbc.com\">\n"
        +"<urn:MessageTag xmlns:urn=\"urn:soap.embus.sbc.com\">SendFiberServiceFacilityAssignmentNotification</urn:MessageTag>\n"
        +"<urn:ApplicationID xmlns:urn=\"urn:soap.embus.sbc.com\">CSI</urn:ApplicationID>\n"
        +"<urn:MessageID xmlns:urn=\"urn:soap.embus.sbc.com\">NEWIAP123</urn:MessageID>\n"
        +"<urn:ConversationKey xmlns:urn=\"urn:soap.embus.sbc.com\">csitest~CNG-CSI~f3318314a5d39d32:7a3c47cd:132f7a8b123:bbnmskris</urn:ConversationKey>\n"
        +"<urn:LoggingKey xmlns:urn=\"urn:soap.embus.sbc.com\">NEWIAP123</urn:LoggingKey>\n"
        +"</urn:MessageHeader>\n"*/
        + "</SOAP-ENV:Header>\n"
        + "<SOAP-ENV:Body>\n"
        + "<SendFiberServiceFacilityAssignmentNotification xmlns=\"http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityAssignmentNotification.xsd\" xmlns:bbnms=\"http://csi.cingular.com/CSI/Namespaces/Types/Private/BBNMS/BBNMSDataModel.xsd\">\n"
        + assignmentLines
        + "<Status>\n"
        + "<bbnms:code>FANK</bbnms:code>\n"
        + "<bbnms:description>FACS assignment - no prior knowledge</bbnms:description>\n"
        + "</Status>\n"
        + "</SendFiberServiceFacilityAssignmentNotification>\n"
        + "</SOAP-ENV:Body>\n"
        + "</SOAP-ENV:Envelope>\n";
    } else {
      assignment = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
        + "<SOAP-ENV:Header>\n"
        + "<mes:MessageHeader xmlns:mes=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\">\n"
        + "<mes:TrackingMessageHeader>\n"
        + "<cin:conversationId xmlns:cin=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">spm2async~CNG-CSI~2eaa6420-6656-4965-8173-1e0d73ec4147</cin:conversationId>\n"
        + "<cin:uniqueTransactionId xmlns:cin=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">SendFiberServiceFacilityUpdateNotification</cin:uniqueTransactionId>\n"
        + "</mes:TrackingMessageHeader>\n"
        + "</mes:MessageHeader>\n"
        /*+"<urn:MessageHeader xmlns:urn=\"urn:soap.embus.sbc.com\">\n"
        +"<urn:MessageTag xmlns:urn=\"urn:soap.embus.sbc.com\">SendFiberServiceFacilityUpdateNotification</urn:MessageTag>\n"
        +"<urn:ApplicationID xmlns:urn=\"urn:soap.embus.sbc.com\">CSI</urn:ApplicationID>\n"
        +"<urn:MessageID xmlns:urn=\"urn:soap.embus.sbc.com\">NEWIAP123</urn:MessageID>\n"
        +"<urn:ConversationKey xmlns:urn=\"urn:soap.embus.sbc.com\">csitest~CNG-CSI~f3318314a5d39d32:7a3c47cd:132f7a8b123:bbnmskris</urn:ConversationKey>\n"
        +"<urn:LoggingKey xmlns:urn=\"urn:soap.embus.sbc.com\">NEWIAP123</urn:LoggingKey>\n"
        +"</urn:MessageHeader>\n"*/
        + "</SOAP-ENV:Header>\n"
        + "<SOAP-ENV:Body>\n"
        + "<SendFiberServiceFacilityUpdateNotification xmlns=\"http://csi.cingular.com/CSI/Namespaces/Container/Private/BBNMS/SendFiberServiceFacilityUpdateNotification.xsd\" xmlns:bbnms=\"http://csi.cingular.com/CSI/Namespaces/Types/Private/BBNMS/BBNMSDataModel.xsd\">\n"
        + assignmentLines
        + "<Status>\n"
        + "<bbnms:code>0</bbnms:code>\n"
        + "<bbnms:description>Success</bbnms:description>\n"
        + "</Status>\n"
        + "</SendFiberServiceFacilityUpdateNotification>\n"
        + "</SOAP-ENV:Body>\n"
        + "</SOAP-ENV:Envelope>\n";
    }

    return assignment;
  }

}