import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Header } from 'app/components/header/header.model';
import { HeaderState } from 'app/components/header/header.state';
import { RadioOptionsValues2 } from 'app/constants/header.constant';
import { cmTabSelected, pvTabSelected } from 'app/constants/tab.constant';
import { Observable } from 'rxjs';
import { WllFtService } from './wll-ft.service';

@Component({
  selector: 'app-wll-ft',
  templateUrl: './wll-ft.component.html',
  styleUrls: ['./wll-ft.component.css']
})
export class WllFtComponent implements OnInit {
  radioValues: any[] = RadioOptionsValues2;
  wllftOptions: any[] = [
    { label: "MI JBBOS", value: "miJbbos" }
  ]
  cmTitle: string = "WLL CM"
  pvTitle: string = "WLL PV"

  pvTabs: any[] = pvTabSelected;
  cmTabs: any[] = cmTabSelected;
  tabTitle: string = "wllft";
  title1: string = "Customer Info";
  contClass1: string = "h6"
  checkBoxClass: string = "d-inline-flex";
  wllRadioSelect: any = "wllData";

  headerData: Observable<Header[]>;

  constructor(private store: Store<HeaderState>,
    private wllFtService: WllFtService) {
    this.headerData = this.store.select(state => state.header);
  }

  ngOnInit(): void {
    this.store.dispatch({
      type: 'ADD_WLL_FT_VALUE',
      payload: <Header>{
        wllFtRadioSelect: this.wllRadioSelect
      }
    });
  }

  radioValueChange(value) {
    this.wllRadioSelect = value;
    this.store.dispatch({
      type: 'ADD_WLL_FT_VALUE',
      payload: <Header>{
        wllFtRadioSelect: this.wllRadioSelect
      }
    });
  }

  onWllftChange(val) { }

  CSIINFT() {
    this.wllFtService.triggerSomeEvent("generateCsiIn");
  }

  pubRg() {
    this.wllFtService.triggerSomeEvent("pubRg");
  }

  OMSWLL_FT(taskName) {
    this.wllFtService.triggerSomeEvent(taskName);
  }

}
