import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WllFtComponent } from './wll-ft.component';

const routes: Routes = [
  { path: '', component: WllFtComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WllFtRoutingModule { }
