import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WllFtRoutingModule } from './wll-ft-routing.module';
import { SharedModule } from 'app/shared/shared.module';
import { WllFtComponent } from './wll-ft.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    WllFtComponent,
  ],
  imports: [
    CommonModule,
    WllFtRoutingModule,
    SharedModule,
    NgbModule,
    FormsModule
  ],
  exports: [
  ]
})
export class WllFtModule { }
