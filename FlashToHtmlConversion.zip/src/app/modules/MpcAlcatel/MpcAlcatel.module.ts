import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MpcAlcatelComponent } from './MpcAlcatel.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { MpcAlcatelRoutingModule } from './MpcAlcatel-routing.module'

@NgModule({
    declarations: [
        MpcAlcatelComponent,
    ],
    imports: [
        NgbModule,
        CommonModule,
        FormsModule,
        SharedModule,
        MpcAlcatelRoutingModule
    ],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class MpcAlcatelModule { }