
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MpcAlcatelComponent } from './MpcAlcatel.component';

const routes: Routes = [
  { path: '', component: MpcAlcatelComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MpcAlcatelRoutingModule { }
