import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';

@Component({
  selector: 'mpc-alcatel',
  templateUrl: './MpcAlcatel.component.html',
  styleUrls: ['./MpcAlcatel.component.css']
})
export class MpcAlcatelComponent implements OnInit {
  title1: string = "FTTN/FTTN-BP Remote DSLAM/IP-RT";
  title2: string = "FTTP-GPON";
  title3: string = "FTTPIP";
  title4: string = "FTTN CO DSLAM/IP-CO";
  title5: string = "RGPON";
  title6: string = "FTTC-GPON";

  contClass1: string = "wh10"
  contClass2: string = "wh8"
  contClass3: string = "wh8"
  contClass4: string = "wh9"
  contClass5: string = "wh9"
  contClass6: string = "wh9"

  tabSelect: string = "mpcAlcatel";
  ntiValue: any;

  isNtiValid1: boolean;
  isNtiValid2: boolean;
  isNtiValid3: boolean;
  isNtiValid4: boolean;
  isNtiValid5: boolean;
  isNtiValid6: boolean;

  constructor(private store: Store<HeaderState>) { }

  ngOnInit() {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.ntiValue = storeObj['nti'];
        if (this.ntiValue?.length) {
          this.isNtiValid1 = true;
          this.isNtiValid2 = true;
          this.isNtiValid3 = true;
          this.isNtiValid4 = true;
          this.isNtiValid5 = true;
          this.isNtiValid6 = true;
          if (this.ntiValue == "FTTN-BP (RT)") {
            this.isNtiValid1 = false;
          } else if (this.ntiValue == "FTTP-GPON") {
            this.isNtiValid2 = false;
          } else if (this.ntiValue == "FTTPIP") {
            this.isNtiValid3 = false;
          } else if (this.ntiValue == "FTTN (CO)") {
            this.isNtiValid4 = false;
          } else if (this.ntiValue == "RGPON") {
            this.isNtiValid5 = false;
          } else if (this.ntiValue == "FTTC-GPON") {
            this.isNtiValid6 = false;
          }
        }
      });
  }
}
