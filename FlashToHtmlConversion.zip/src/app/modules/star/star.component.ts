import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { infoValue } from 'app/constants/omsMessage.constant';
import { starTabSelection } from 'app/constants/tab.constant';
import { CheckboxItem } from 'app/shared/checkBox-value/checkBox-value.component';
import { ModelBoxComponent } from 'app/shared/model-box/model-box.component';
import { RelatedProductModalComponent } from 'app/shared/related-product-modal/related-product-modal.component';
import { StarMainComponent } from './modules/star-main/star-main.component';
import { StarService } from './star.service';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class StarComponent implements OnInit {
  @ViewChild(StarMainComponent) starMain: StarMainComponent;

  starTabs: any[] = starTabSelection
  starUrl: string = "/star";
  checkBoxClass1: string = "d-inline-flex";
  infoValueOptions = new Array<any>();
  configChecked: boolean = true;

  enviornmentVal: any;

  public checkBoxModel = {
    id: 0,
    name: "",
    roles: []
  };

  constructor(private router: Router, private starService: StarService,
    private modalService: NgbModal, private store: Store<HeaderState>) {
    this.infoValueOptions = infoValue.filter(x => x.id == 2).map(x => new CheckboxItem(x.id, x.name, false));
  }

  ngOnInit() {
    this.router.navigateByUrl(this.starUrl + '/main');
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.enviornmentVal = storeObj['enviornment'];
      })
  }

  selectedTab(id, tabValue): any {
    let indexNo = id.nextId.replace(/[^0-9]/g, '');
    if (tabValue[indexNo].label === "main") {
      this.router.navigateByUrl(this.starUrl + '/main');
    } else if (tabValue[indexNo].label === "tdarFnt") {
      this.router.navigateByUrl(this.starUrl + '/tdarFnt');
    } else if (tabValue[indexNo].label === "tdar") {
      this.router.navigateByUrl(this.starUrl + '/tdar');
    } else {
      this.router.navigateByUrl(this.starUrl + '/isaacTdar');
    }
  }

  onInfoChange(value) {
    if (value.indexOf('Related Product Info') != -1) {
      this.configChecked = false
    } else {
      this.configChecked = true;
    }
    this.checkBoxModel.roles = value;
  }

  //Generate Isaac Req Function
  OMSISSAC() {
    this.starService.triggerSomeEvent("genIsaacReq");
  }

  //GenerateTdarIsaacReq Function
  TDARISSAC() {
    this.starService.triggerSomeEvent("genTdarIsaacReq");
  }

  //Gen ISWO Act Resp Function
  CsiOsm() {
    this.starService.triggerSomeEvent("genIswoActResp");
  }

  //Gen Sub Sat Resp Function
  CsiOsmSubSatResp() {
    this.starService.triggerSomeEvent("genSubSatResp");
  }

  // Gen Manage Sat Resp Function
  CsiOsmManageSatResp() {
    var responseXml: String = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<SOAP-ENV:Header>\n"
      + "<ns2:MessageHeader xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\" xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">\n"
      + "<ns2:TrackingMessageHeader>\n"
      + "<version>v97</version>\n"
      + "<messageId>messageId</messageId>\n"
      + "<responseTo>BBNMS</responseTo>\n"
      + "<timeToLive>30000</timeToLive>\n"
      + "<conversationId>bbnms~CNG-CSI~996af131-2aeb-4b7a-b8b2-5e7fdb5f1fa7</conversationId>\n"
      + "<dateTimeStamp>2015-05-27T15:28:27.469Z</dateTimeStamp>\n"
      + "<uniqueTransactionId>ServiceGateway27546@q29csg1c3_b377e557-acad-4103-bb3c-2001f3120a8b</uniqueTransactionId>\n"
      + "</ns2:TrackingMessageHeader>\n"
      + "<ns2:SecurityMessageHeader>\n"
      + "<userName>bbnms</userName>\n"
      + "<userPassword>bbnmstest</userPassword>\n"
      + "</ns2:SecurityMessageHeader>\n"
      + "<ns2:SequenceMessageHeader>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<totalInSequence>1</totalInSequence>\n"
      + "</ns2:SequenceMessageHeader>\n"
      + "</ns2:MessageHeader>\n"
      + "</SOAP-ENV:Header>\n"
      + "<SOAP-ENV:Body>\n"
      + "<ns2:ManageSatelliteWorkOrderStatusResponse xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/ManageSatelliteWorkOrderStatusResponse.xsd\" xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">\n"
      + "<ns2:ActivityAttributes>\n"
      + "<status>status</status>\n"
      + "<earlyStartDateTime>2014-11-09T11:00:00</earlyStartDateTime>\n"
      + "<dueDateTime>2014-12-08T16:00:00</dueDateTime>\n"
      + "<currentProtectionPlan>None</currentProtectionPlan>\n"
      + "<accountId>71774203</accountId>\n"
      + "<genericId>1-5R2AEWW</genericId>\n"
      + "</ns2:ActivityAttributes>\n"
      + "<ns2:activityId>1-5R2AEXP</ns2:activityId>\n"
      + "<ns2:activityNumber>1-5R2AEXP</ns2:activityNumber>\n"
      + "<ns2:WorkOrderSignature>\n"
      + "<workOrderId>1-12520343568</workOrderId>\n"
      + "<signatureStatus>Not Required</signatureStatus>\n"
      + "<signatureCapturedByTechnician>N/A</signatureCapturedByTechnician>\n"
      + "<documentType>Order Modification</documentType>\n"
      + "<documentId>1-53XMMFB</documentId>\n"
      + "</ns2:WorkOrderSignature>\n"
      + "<ns2:WorkOrderSignature>\n"
      + "<workOrderId>1-12520343568</workOrderId>\n"
      + "<signatureStatus>Not Required</signatureStatus>\n"
      + "<signatureCapturedByTechnician>N/A</signatureCapturedByTechnician>\n"
      + "<documentType>Lease Agreement</documentType>\n"
      + "<documentId>1-5LD4LDL</documentId>\n"
      + "</ns2:WorkOrderSignature>\n"
      + "<ns2:WorkOrderSignature>\n"
      + "<workOrderId>1-12520343568</workOrderId>\n"
      + "<signatureStatus>Not Required</signatureStatus>\n"
      + "<signatureCapturedByTechnician>N/A</signatureCapturedByTechnician>\n"
      + "<documentType>Protection Plan</documentType>\n"
      + "<documentId>1-5LB3E8K</documentId>\n"
      + "</ns2:WorkOrderSignature>\n"
      + "<ns2:WorkOrderSignature>\n"
      + "<workOrderId>1-12520343568</workOrderId>\n"
      + "<signatureStatus>Not Required</signatureStatus>\n"
      + "<signatureCapturedByTechnician>N/A</signatureCapturedByTechnician>\n"
      + "<documentType>Landlord Permission</documentType>\n"
      + "<documentId>1-5LD4LDK</documentId>\n"
      + "</ns2:WorkOrderSignature>\n"
      + "<ns2:WorkOrderSignature>\n"
      + "<workOrderId>1-12520343568</workOrderId>\n"
      + "<signatureStatus>Not Required</signatureStatus>\n"
      + "<signatureCapturedByTechnician>N/A</signatureCapturedByTechnician>\n"
      + "<documentType>Protection Plan Premier ADH</documentType>\n"
      + "<documentId>1-5LD4LDE</documentId>\n"
      + "</ns2:WorkOrderSignature>\n"
      + "<ns2:WorkOrderSignature>\n"
      + "<workOrderId>1-12520343568</workOrderId>\n"
      + "<signatureStatus>Not Required</signatureStatus>\n"
      + "<signatureCapturedByTechnician>N/A</signatureCapturedByTechnician>\n"
      + "<documentType>Protection Plan Premier</documentType>\n"
      + "<documentId>1-5LD4LDI</documentId>\n"
      + "</ns2:WorkOrderSignature>\n"
      + "<ns2:WorkOrderSignature>\n"
      + "<workOrderId>1-12520343568</workOrderId>\n"
      + "<signatureStatus>WO Not Signed</signatureStatus>\n"
      + "<signatureCapturedByTechnician>N/A</signatureCapturedByTechnician>\n"
      + "<documentType>Work Order</documentType>\n"
      + "<documentId>1-5LD4LDM</documentId>\n"
      + "</ns2:WorkOrderSignature>\n"
      + "<ns2:Response>\n"
      + "<code>0</code>\n"
      + "<description>Success</description>\n"
      + "</ns2:Response>\n"
      + "</ns2:ManageSatelliteWorkOrderStatusResponse>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>\n";

    let mainXml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\nxmlns:ws="http://ws.sender.bbnms.att.com/">\n`
      + `<soapenv:Header/>\n`
      + `<soapenv:Body>\n`
      + `<ws:sendMessageToQueue>\n`
      + `<MessageSenderRequest_V2>\n`
      + `<environment>${this.enviornmentVal}</environment>\n`
      + `<queue>OMS</queue>\n`
      + `<message>`
      + `<![CDATA[\n`
      // <Place request xml> 
      + responseXml
      + '\n]]></message>\n'
      + '</MessageSenderRequest_V2>\n'
      + '</ws:sendMessageToQueue>\n'
      + '</soapenv:Body>\n'
      + '</soapenv:Envelope>\n';

    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = "Complete XML Generation";
    modalRef.componentInstance.type = "template2";
    modalRef.componentInstance.content = mainXml;
    modalRef.componentInstance.fileName = "fileName";
  }

  // GEN TDAR PT Function
  TDAROMS(taskName: String) {
    this.starService.triggerSomeEvent(taskName);
  }

  //Generate ISSOD Req Function
  CsiCreateIssodResp() {
    this.starService.triggerSomeEvent("genIssodResp");
  }

  //generate Inquire Sat CSP Resp Function
  CsiOsmInqSatCpeResp() {
    this.starService.triggerSomeEvent("genInquireSatCspResp");
  }

  //Generate Inq Sat Cust Prof Resp Function
  CsiOsmInqSatCustProfResp() {
    this.starService.triggerSomeEvent("genInquireSatustProfResp");
  }

  //Generate Ban Treatment Function
  CreateDTVBANTreatmentMessage(task) {
    this.starService.triggerSomeEvent(task);
  }

  //Config Related Product Function
  generateConfigProd() {
    const modalRef = this.modalService.open(RelatedProductModalComponent);
    modalRef.componentInstance.title = 'Related Product Info Config';
  }

}
