import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { CustomerInfoComponent } from 'app/shared/customerInfo/customerInfo.component';
import { ModelBoxComponent } from 'app/shared/model-box/model-box.component';
import { OrderInfoComponent } from 'app/shared/order-info/order-info.component';
import { ServiceFspComponent } from 'app/shared/serviceFsp/serviceFsp.component';
import { SubContainerComponent } from 'app/shared/subComponent/subContainer.component';
import { StarService } from '../../star.service';

@Component({
  selector: 'app-star-tdar',
  templateUrl: './star-tdar.component.html',
  styleUrls: ['./star-tdar.component.css']
})
export class StarTdarComponent implements OnInit {
  tabType: string = "star"
  cusTabType: string = "starTdar"
  contClass1: string = "h2";
  scrollClass1: string = "h3";
  contClass2: string = "ht-240";
  title1: string = "Customer Info";
  title2: string = "New Customer Info";

  tabContent: string = "h1";
  ServicFspTitle: string = "Service Fsp";

  starTitle: string = "TDAR Order Info";
  scrollHt: string = "h430"

  stackOrderTitle: string = "Stacked Order"
  superSedeTitle: string = "Supersede";
  tdarCompInfoTitle: string = "TDAR Component Info";

  scrollClass: any = "wh5";

  @ViewChild(OrderInfoComponent) orderInfo: OrderInfoComponent;
  @ViewChild(ServiceFspComponent) serviceFsp: ServiceFspComponent;
  @ViewChild(SubContainerComponent) subContainer: SubContainerComponent;
  @ViewChild(CustomerInfoComponent) customerInfo: CustomerInfoComponent;
  @ViewChild(CustomerInfoComponent) newCustomerInfo: CustomerInfoComponent;

  tdarOrderNumber: any;
  tdarOrigOrdId: any;
  tdarOrderActionType: any;
  tdarOrderActionSubType: any;
  tdarDueDate: any;
  tdarCreationDate: any;
  tdarOrderActionRef: any;
  tdarNfflIndicator: any;
  tdarCity: any;
  tdarState: any;
  tdarPostalCode: any;
  tdarPostalCode2: any;
  tdarCustFirstName: any;
  tdarCustLastName: any;
  tdarCustTimeZone: any;
  tdarCustConatactNo: any;
  tdarCustSecondaryNo: any;
  tdarSupersede: any;
  tdar: any;

  banValue: any;
  DTGP1: String
  DTGP2: String
  DTGP3: String
  DTGP4: String
  DTGP5: String

  DTT: String;
  newCustomerInfoDtv: String;
  supercedeStr: String;
  dtvbvpPartnerNameStr: String;
  tdarAdultContentRestrictionStr: String;
  relatedProductOrderInfo: String;
  relatedOrderInfoTdar: String;
  currentcustIndTrue: String;
  currentcustIndFalse: String;
  serviceType: String;
  serviceType1: String;
  DTACRD: String;
  bypassReasonCode: String;
  PropertyContractType: String;
  contractId_DTVM: String;
  contractId_DTCP: String;
  contractId_ATTDV: String;
  customerLine_DTVM: String;
  ccid_FSP: String;
  NFFLIndicator: String;
  AddSrvComponent: String;
  DTOTA: String;
  dtvAccountType: String;
  dealerCode: String;
  dealerAccountType: String;
  oldDtvAccountType: String = "";
  oldDealerCode: String = "";
  oldDealerActType: String = "";
  oldCustomLine: String = "";
  oldPropType: String = "";

  Action_AddSrv: any;
  Action_AddIns: any;
  WholeHomeDVR_Addsrv: any;
  relocateReceiverCount_Addsrv: any;
  relocateDishCount_Addsrv: any;
  addSrvVisuallyImpaired: any;
  TdarstbProductLn1: any;
  customerLineIndicator: any;
  PropertyContractIndicator: any;

  isActive_DTSTB1: any = "";
  isActive_DTSTB2: any = "";
  isActive_DTSTB3: any = "";
  isActive_DTSTB4: any = "";
  isActive_DTSTB5: any = "";
  oldvalueInd1: any;
  oldvalueInd2: any;
  oldvalueInd3: any;
  oldvalueInd4: any;
  oldvalueInd5: any;
  mduDtvActTyp: any;
  mduOldDtvActTyp: any;
  mduOldDealerCode: any;
  mduOldDealerActTyp: any;
  mduOldCustLine: any;
  mduOldPropContTyp: any;
  mduDealerCode: any;
  mduDealerActTyp: any;
  ContractId_DTSTB1: any;
  ContractId_DTSTB2: any;
  ContractId_DTSTB3: any;
  ContractId_DTSTB4: any;
  ContractId_DTSTB5: any;
  contractId_DTGP1: any;
  contractId_DTGP2: any;
  contractId_DTGP3: any;
  contractId_DTGP4: any;
  contractId_DTGP5: any;
  contractIdInd_DTVM: any;
  contractIdInd_DTCP: any;
  contractIdInd_ATTDV: any;

  includeDTACRD: any;
  dtacrdActionIndicator: any;
  dtacrdPrdoductLine: any;
  tdarPartnerName: any;
  dtvbvpActionIndicator: any;
  tdarPartnerID: any;
  relatedOrderInfo_DTV: any;
  stbcomp: any;
  adultContentIndicator: any;
  dttAction: any;
  DTSTB1: any;
  DTSTB2: any;
  DTSTB3: any;
  DTSTB4: any;
  DTSTB5: any;
  dtvmOrdActResCode: any;
  tdarNewCustFname: any;
  tdarNewCustLname: any;
  tdarNewCustContactPh: any;
  tdarNewCustSecondaryPh: any;
  tdarNewCustBan: any;
  relatedProductOrderInfoTdar: any;
  tdarPrimaryNpanx: any;
  tdarRateCentreCode: any;
  tdarStreetName: any;
  tdarHouseNo: any;
  tdarAddressId: any;
  tdarLivingUnitAddressId: any;
  tdarVhoCode: any;
  tdarTarCode: any;
  tdarStreetThroughfare: any
  tdarCustUbIndicator: any;
  tdarCustCreditRiskClass: any;
  tdarWorkOrderId: any;
  tdarPrevWorkOrderId: any;

  enviornmentVal: any;

  constructor(private modalService: NgbModal, private store: Store<HeaderState>,
    private starService: StarService) { }

  ngOnInit(): void {
    this.store.select(state => state['header']).subscribe((data) => {
      let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
      if (storeObj['banValue']?.length) {
        this.banValue = storeObj['banValue'];
      }
      this.enviornmentVal = storeObj['enviornment'];
    });

    this.starService.getEventSubject().subscribe((value) => {
      if (value == "BANTreatment") {
        this.DTVBANTreatment(value);
      } else if (value == "provisionTransport") {
        this.generateTdar(value);
      } else if (value == "exchangeCpeDataCall1") {
        this.generateTdar(value);
      } else if (value == "provisionTransportComplete") {
        this.generateTdar(value);
      }

    });

    this.getSubCompData();
  }

  getSubCompData() {
    //tdar Order Info
    this.tdarOrderNumber = this.orderInfo?.textValue3;
    this.tdarOrigOrdId = this.orderInfo?.textValue1;
    this.tdarOrderActionType = this.orderInfo?.selectedOrderActionType;
    this.tdarOrderActionSubType = this.orderInfo?.selectedOrderActionSubType;
    this.tdarDueDate = this.orderInfo?.myDate5;
    this.tdarCreationDate = this.orderInfo?.myDate6;
    this.tdarOrderActionRef = this.orderInfo?.selectedOrderActionRef;
    this.tdarNfflIndicator = this.orderInfo?.selectedNFFLIndicator;
    this.tdarPrevWorkOrderId = this.orderInfo?.textValue6;
    this.tdarWorkOrderId = this.orderInfo?.textValue5;

    //serviceFsp
    this.tdarCity = this.serviceFsp?.textValue9;
    this.tdarState = this.serviceFsp?.textValue10
    this.tdarPostalCode = this.serviceFsp?.textValue11;
    this.tdarPostalCode2 = this.serviceFsp?.textValue11a;
    this.tdarPrimaryNpanx = this.serviceFsp?.textValue16;
    this.tdarRateCentreCode = this.serviceFsp?.textValue4;
    this.tdarStreetName = this.serviceFsp?.textValue7;
    this.tdarHouseNo = this.serviceFsp?.textValue6;
    this.tdarAddressId = this.serviceFsp?.textValue5;
    this.tdarLivingUnitAddressId = this.serviceFsp?.textValue1;
    this.tdarVhoCode = this.serviceFsp?.selectValue;
    this.tdarTarCode = this.serviceFsp?.textValue2;
    this.tdarStreetThroughfare = this.serviceFsp?.textValue8;

    //customerInfo
    this.tdarCustFirstName = this.customerInfo?.textValue1;
    this.tdarCustLastName = this.customerInfo?.textValue2;
    this.tdarCustTimeZone = this.customerInfo?.selectedTimeZone;
    this.tdarCustConatactNo = this.customerInfo?.textValue3;
    this.tdarCustSecondaryNo = this.customerInfo?.textValue4;
    this.tdarCustUbIndicator = this.customerInfo?.selectedUBIndicator;
    this.tdarCustCreditRiskClass = this.customerInfo?.selectedCreditRiskClass;

    //New Customer Info
    this.tdarNewCustFname = this.newCustomerInfo?.textValue1;
    this.tdarNewCustLname = this.newCustomerInfo?.textValue2;
    this.tdarNewCustContactPh = this.newCustomerInfo?.textValue3;
    this.tdarNewCustSecondaryPh = this.newCustomerInfo?.textValue4;
    this.tdarNewCustBan = this.newCustomerInfo?.textValue8;

    //supersed
    this.tdarSupersede = this.subContainer?.selectedSuperSede;


    //tdar Component Info
    this.includeDTACRD = this.subContainer?.dtacrdIsInclude
    this.Action_AddSrv = this.subContainer?.AddSrvAction
    this.Action_AddIns = this.subContainer?.AddSrvAddInsAction
    this.WholeHomeDVR_Addsrv = this.subContainer?.AddSrvWholeHomeDVR
    this.relocateReceiverCount_Addsrv = this.subContainer?.AddSrvRelocateReceiverCount
    this.relocateDishCount_Addsrv = this.subContainer?.AddSrvRelocateDishCount
    this.addSrvVisuallyImpaired = this.subContainer?.AddSrvVisuallyImpaired
    this.TdarstbProductLn1 = this.subContainer?.DtsbProductLine;
    this.customerLineIndicator = this.subContainer?.dtvmCustomerLine;
    this.PropertyContractIndicator = this.subContainer?.dtvmPropertyContractType;
    this.isActive_DTSTB1 = this.subContainer?.DtstbIsActive;
    this.isActive_DTSTB2 = this.subContainer?.DtstbIsActive;
    this.isActive_DTSTB3 = this.subContainer?.DtstbIsActive;
    this.isActive_DTSTB4 = this.subContainer?.DtstbIsActive;
    this.isActive_DTSTB5 = this.subContainer?.DtstbIsActive;
    this.oldvalueInd1 = this.subContainer?.DtstbOldValue;
    this.oldvalueInd2 = this.subContainer?.DtstbOldValue;
    this.oldvalueInd3 = this.subContainer?.DtstbOldValue;
    this.oldvalueInd4 = this.subContainer?.DtstbOldValue;
    this.oldvalueInd5 = this.subContainer?.DtstbOldValue;
    this.mduDtvActTyp = this.subContainer?.dtvmDtvActType;
    this.mduOldDtvActTyp = this.subContainer?.dtvmOldDtvActType;
    this.mduOldDealerCode = this.subContainer?.dtvmOldDealerCode;
    this.mduOldDealerActTyp = this.subContainer?.dtvmOldDealerActType;
    this.mduOldCustLine = this.subContainer?.dtvmOldCustLine;
    this.mduOldPropContTyp = this.subContainer?.dtvmOldPropContType
    this.mduDealerCode = this.subContainer?.dtvmDealerCode;
    this.mduDealerActTyp = this.subContainer?.dtvmDealerAcType;
    this.ContractId_DTSTB1 = this.subContainer?.DtstContractId
    this.ContractId_DTSTB2 = this.subContainer?.DtstContractId
    this.ContractId_DTSTB3 = this.subContainer?.DtstContractId
    this.ContractId_DTSTB4 = this.subContainer?.DtstContractId
    this.ContractId_DTSTB5 = this.subContainer?.DtstContractId;
    this.contractId_DTGP1 = this.subContainer?.dtgpContractId
    this.contractId_DTGP2 = this.subContainer?.dtgpContractId
    this.contractId_DTGP3 = this.subContainer?.dtgpContractId
    this.contractId_DTGP4 = this.subContainer?.dtgpContractId
    this.contractId_DTGP5 = this.subContainer?.dtgpContractId;
    this.contractIdInd_DTVM = this.subContainer?.dtvmContractId;
    this.contractIdInd_DTCP = this.subContainer?.dtcpContractId;
    this.contractIdInd_ATTDV = this.subContainer?.attdvContractId;
    this.dtacrdActionIndicator = this.subContainer?.dtacrdAction;
    this.dtacrdPrdoductLine = this.subContainer?.dtacrdPrdoductLine;
    this.tdarPartnerName = this.subContainer?.dtvbvpPartnerName;
    this.dtvbvpActionIndicator = this.subContainer?.dtvbvpAction;
    this.tdarPartnerID = this.subContainer?.dtvbvpPartnerId
    this.adultContentIndicator = this.subContainer?.dtvmAdultContractRestriction;
    this.dttAction = this.subContainer?.dttAction
  }

  //gen ban treatment function
  DTVBANTreatment(taskName: String) {
    this.getSubCompData();
    let requestXml = "<SOAP-ENV:Envelope xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:m1=\"http://lightspeed.bbnms.att.com/header\" xmlns:m2=\"http://lightspeed.bbnms.att.com/ordering\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<SOAP-ENV:Header>\n"
      + "<m1:MessageHeader xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:bbnmsOrderHeader=\"http://lightspeed.bbnms.att.com/header\">\n"
      + "<ns2:WSHeader xmlns:ns2=\"http://cio.att.com/commonheader/v3\">\n"
      + "<ns2:WSContext>\n"
      + "<ns2:SourceIPAddress>10.160.249.210</ns2:SourceIPAddress>\n"
      + "</ns2:WSContext>\n"
      + "<ns2:WSMessageData>\n"
      + "<ns2:Timestamp>2008-02-19T10:09:25.0440</ns2:Timestamp>\n"
      + "</ns2:WSMessageData>\n"
      + "<ns2:WSEnterpriseLogging>\n"
      + "<ns2:LoggingKey>TN:3142353655</ns2:LoggingKey>\n"
      + "</ns2:WSEnterpriseLogging>\n"
      + "</ns2:WSHeader>\n"
      + "<ns1:WSDiscovery xmlns:ns1=\"http://aftdiscovery.att.com/header/v1\">\n"
      + "<ns1:name>MQSSL_ESB_J2EEEJB_ON_AIX</ns1:name>\n"
      + "<ns1:version>\n"
      + "<ns1:major>3</ns1:major>\n"
      + "<ns1:minor>0</ns1:minor>\n"
      + "</ns1:version>\n"
      + "<ns1:envContext>Y</ns1:envContext>\n"
      + "<ns1:bindingType>fusionBus</ns1:bindingType>\n"
      + "</ns1:WSDiscovery>\n"
      + "</m1:MessageHeader>\n"
      + "</SOAP-ENV:Header>\n"
      + "<SOAP-ENV:Body>\n"
      + "<m2:bbnmsOrder>\n"
      + "<m2:transactionInfo xmlns:bbnmsOrder=\"http://lightspeed.bbnms.att.com/ordering\">\n"
      + "<m2:transactionId>MknkAgC6h1WHKQwKs7A</m2:transactionId>\n"
      + "<m2:taskName>BANTreatment</m2:taskName>\n"
      + "<m2:cvoipSdpProvisioningInd>true</m2:cvoipSdpProvisioningInd>\n"
      + "<m2:order>\n"
      + "<m2:orderActionInfoList>\n"
      + "<m2:orderActionInfo>\n"
      + "<m2:orderNumber>" + this.tdarOrderNumber + "</m2:orderNumber>\n"
      + "<m2:orderActionId>" + this.tdarOrderNumber + "</m2:orderActionId>\n"
      + "<m2:originalOrderActionId>" + this.tdarOrigOrdId + "</m2:originalOrderActionId>\n"
      + "<m2:orderActionType>" + this.tdarOrderActionType + "</m2:orderActionType>\n"
      + "<m2:orderActionSubType>" + this.tdarOrderActionSubType + "</m2:orderActionSubType>\n"
      + "<m2:orderActionReferenceNumber>" + this.tdarOrigOrdId + this.tdarOrderActionRef + "</m2:orderActionReferenceNumber>\n"
      + "<m2:orderCreationDate>" + this.tdarCreationDate + "T01:01:01</m2:orderCreationDate>\n"
      + "<m2:assignedProductId>535703164</m2:assignedProductId>\n"
      + "<m2:orderActionReasonCode>NP</m2:orderActionReasonCode>\n"
      + "<m2:salesChannel>CS</m2:salesChannel>\n"
      + "<m2:dueDate>" + this.tdarDueDate + "T23:59:59</m2:dueDate>\n"
      + "<m2:appointment>\n"
      + "<m2:startTime>2010-03-10T13:00:00</m2:startTime>\n"
      + "<m2:endTime>2010-03-10T16:00:00</m2:endTime>\n"
      + "</m2:appointment>\n"
      + "<m2:orderActionStatus>DE</m2:orderActionStatus>\n"
      + "<m2:addressInfoList>\n"
      + "<m2:addressInfo>\n"
      + "<m2:addressType>LSBilling</m2:addressType>\n"
      + "<m2:fieldedAddress>\n"
      + "<m2:city>AUSTIN</m2:city>\n"
      + "<m2:state>TX</m2:state>\n"
      + "<m2:postalCode>78704</m2:postalCode>\n"
      + "<m2:addressId>" + this.banValue + "</m2:addressId>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n"
      + "<m2:addressInfo>\n"
      + "<m2:addressType>ShippingFrom</m2:addressType>\n"
      + "<m2:fieldedAddress>\n"
      + "<m2:houseNumber>123</m2:houseNumber>\n"
      + "<m2:streetDirection>NE</m2:streetDirection>\n"
      + "<m2:streetName>MAIN</m2:streetName>\n"
      + "<m2:streetThoroughfare>ST</m2:streetThoroughfare>\n"
      + "<m2:streetNameSuffix>NE</m2:streetNameSuffix>\n"
      + "<m2:city>ST. LOUIS</m2:city>\n"
      + "<m2:state>MO</m2:state>\n"
      + "<m2:postalCode>63101</m2:postalCode>\n"
      + "<m2:postalCodePlus4>0000</m2:postalCodePlus4>\n"
      + "<m2:county>ST. LOUIS</m2:county>\n"
      + "<m2:country>USA</m2:country>\n"
      + "<m2:unitType>APT</m2:unitType>\n"
      + "<m2:addressId>571001130</m2:addressId>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n"
      + "<m2:addressInfo>\n"
      + "<m2:addressType>ServiceFSP</m2:addressType>\n"
      + "<m2:primaryNpanxx>512442</m2:primaryNpanxx>\n"
      + "<m2:clli8>HINEGACA</m2:clli8>\n"
      + "<m2:fttbBuildingClli>fttbBuildingClli</m2:fttbBuildingClli>\n"
      + "<m2:emtClli>emtClli</m2:emtClli>\n"
      + "<m2:livingUnitAddressId>LS571001135</m2:livingUnitAddressId>\n"
      + "<m2:rateCenterCode>BARKER</m2:rateCenterCode>\n"
      + "<m2:vhoCode>AUS2TX</m2:vhoCode>\n"
      + "<m2:fieldedAddress>\n"
      + "<m2:houseNumber>123</m2:houseNumber>\n"
      + "<m2:streetName>Peachtree</m2:streetName>\n"
      + "<m2:streetThoroughfare>ST</m2:streetThoroughfare>\n"
      + "<m2:city>Atlanta</m2:city>\n"
      + "<m2:state>" + this.tdarState + "</m2:state>\n"
      + "<m2:postalCode>" + this.tdarPostalCode + "</m2:postalCode>\n"
      + "<m2:postalCodePlus4>" + this.tdarPostalCode2 + "</m2:postalCodePlus4>\n"
      + "<m2:county>ST. LOUIS</m2:county>\n"
      + "<m2:unitType>APT</m2:unitType>\n"
      + "<m2:unitValue>1234</m2:unitValue>\n"
      + "<m2:cassAddressLines>\n"
      + "<m2:addressLine>John Montana</m2:addressLine>\n"
      + "<m2:addressLine>123 Peachtree ST</m2:addressLine>\n"
      + "<m2:addressLine>Atlanta GA 30308</m2:addressLine>\n"
      + "</m2:cassAddressLines>\n"
      + "<m2:addressId>" + this.banValue + "</m2:addressId>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n"
      + "</m2:addressInfoList>\n"
      + "<m2:productList>\n"
      + "<m2:product>\n"
      + "<m2:name>AT&amp;T DTV</m2:name>\n"
      + "<m2:componentList>\n"
      + "<m2:component>\n"
      + "<m2:assignedProductId>345678900</m2:assignedProductId>\n"
      + "<m2:serviceType>DTVM</m2:serviceType>\n"
      + "<m2:actionIndicator>M</m2:actionIndicator>\n"
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>UVOrderActionType</m2:name>\n"
      + "<m2:value>" + this.tdarOrderActionType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n"
      + "</m2:componentList>\n"
      + "</m2:product>\n"
      + "</m2:productList>\n"
      + "<m2:extendedDueDateIndicator>N</m2:extendedDueDateIndicator>\n"
      + "<m2:retainedServicesProcessIndicator>false</m2:retainedServicesProcessIndicator>\n"
      + "<m2:dslDisconnectTns>1571001135</m2:dslDisconnectTns>\n"
      + "</m2:orderActionInfo>\n"
      + "</m2:orderActionInfoList>\n"
      + "<m2:customerInfoList>\n"
      + "<m2:customerInfo>\n"
      + "<m2:accountId>" + this.banValue + "</m2:accountId>\n"
      + "<m2:name>" + this.tdarCustFirstName + " " + this.tdarCustLastName + "</m2:name>\n"
      + "<m2:type>I</m2:type>\n"
      + "<m2:subType>9</m2:subType>\n"
      + "<m2:UBIndicator>true</m2:UBIndicator>\n"
      + "<m2:classOfService>Residential</m2:classOfService>\n"
      + "<m2:legalEntity>King</m2:legalEntity>\n"
      + "<m2:creditRiskClass>High</m2:creditRiskClass>\n"
      + "<m2:timeZoneOffset>" + this.tdarCustTimeZone + "</m2:timeZoneOffset>\n"
      + "<m2:billCycle>30</m2:billCycle>\n"
      + "<m2:billRound>2</m2:billRound>\n"
      + "<m2:customerInfoContactList>\n"
      + "<m2:customerInfoContact>\n"
      + "<m2:contactType>CU</m2:contactType>\n"
      + "<m2:title>Mr</m2:title>\n"
      + "<m2:firstName>" + this.tdarCustFirstName + "</m2:firstName>\n"
      + "<m2:lastName>" + this.tdarCustLastName + "</m2:lastName>\n"
      + "<m2:phoneNumber>" + this.tdarCustConatactNo + "</m2:phoneNumber>\n"
      + "<m2:secondaryPhoneNumber>" + this.tdarCustSecondaryNo + "</m2:secondaryPhoneNumber>\n"
      + "<m2:SellerName>Seller John</m2:SellerName>\n"
      + "<m2:SellerTn>2605658974</m2:SellerTn>\n"
      + "<m2:SellerId>SellerID</m2:SellerId>\n"
      + "</m2:customerInfoContact>\n"
      + "</m2:customerInfoContactList>\n"
      + "</m2:customerInfo>\n"
      + "</m2:customerInfoList>\n"
      + "</m2:order>\n"
      + "</m2:transactionInfo>\n"
      + "</m2:bbnmsOrder>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>";

    this.callModalPopUp(requestXml, "template2", "Complete XML Generation", "A_BANTreatment.xml");
  }

  //gen tdar pt/cpe/ptc Function
  generateTdar(taskName) {
    this.getSubCompData();

    this.getOrderActType();
    this.getAddSrvInsData();
    this.getNfflIndicator();
    this.getSuperSede();
    this.getTabData();
    let OMS_request;

    // separate request for Voluntary SU/RS
    if (this.tdarOrderActionType == "SU" || this.tdarOrderActionType == "RS") {
      OMS_request = "<SOAP-ENV:Envelope xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:m1=\"http://lightspeed.bbnms.att.com/header\" xmlns:m2=\"http://lightspeed.bbnms.att.com/ordering\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
        + "<SOAP-ENV:Header>\n"
        + "<m1:MessageHeader xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:bbnmsOrderHeader=\"http://lightspeed.bbnms.att.com/header\">\n"
        + "<ns2:WSHeader xmlns:ns2=\"http://cio.att.com/commonheader/v3\">\n"
        + "<ns2:WSContext>\n"
        + "<ns2:SourceIPAddress>10.160.249.210</ns2:SourceIPAddress>\n"
        + "</ns2:WSContext>\n"
        + "<ns2:WSMessageData>\n"
        + "<ns2:Timestamp>2008-02-19T10:09:25.0440</ns2:Timestamp>\n"
        + "</ns2:WSMessageData>\n"
        + "<ns2:WSEnterpriseLogging>\n"
        + "<ns2:LoggingKey>TN:3142353655</ns2:LoggingKey>\n"
        + "</ns2:WSEnterpriseLogging>\n"
        + "</ns2:WSHeader>\n"
        + "<ns1:WSDiscovery xmlns:ns1=\"http://aftdiscovery.att.com/header/v1\">\n"
        + "<ns1:name>MQSSL_ESB_J2EEEJB_ON_AIX</ns1:name>\n"
        + "<ns1:version>\n"
        + "<ns1:major>3</ns1:major>\n"
        + "<ns1:minor>0</ns1:minor>\n"
        + "</ns1:version>\n"
        + "<ns1:envContext>Y</ns1:envContext>\n"
        + "<ns1:bindingType>fusionBus</ns1:bindingType>\n"
        + "</ns1:WSDiscovery>\n"
        + "</m1:MessageHeader>\n"
        + "</SOAP-ENV:Header>\n"
        + "<SOAP-ENV:Body>\n"
        + "<m2:bbnmsOrder>\n"
        + "<m2:transactionInfo xmlns:bbnmsOrder=\"http://lightspeed.bbnms.att.com/ordering\">\n"
        + "<m2:transactionId>MknkAgC6h1WHKQwKs7A</m2:transactionId>\n"
        + "<m2:taskName>" + taskName + "</m2:taskName>\n"
        + "<m2:cvoipSdpProvisioningInd>true</m2:cvoipSdpProvisioningInd>\n"
        + "<m2:order>\n"
        + "<m2:orderActionInfoList>\n"
        + "<m2:orderActionInfo>\n"
        + "<m2:orderNumber>" + this.tdarOrderNumber + "</m2:orderNumber>\n"
        + "<m2:orderActionId>" + this.tdarOrderNumber + "</m2:orderActionId>\n"
        + "<m2:originalOrderActionId>" + this.tdarOrigOrdId + "</m2:originalOrderActionId>\n"
        + "<m2:orderActionType>" + this.tdarOrderActionType + "</m2:orderActionType>\n"
        + "<m2:orderActionSubType>" + this.tdarOrderActionSubType + "</m2:orderActionSubType>\n"
        + "<m2:orderActionReferenceNumber>" + this.tdarOrigOrdId + this.tdarOrderActionRef + "</m2:orderActionReferenceNumber>\n"
        + "<m2:orderCreationDate>" + this.tdarCreationDate + "T01:01:01</m2:orderCreationDate>\n"
        + "<m2:assignedProductId>535703164</m2:assignedProductId>\n"
        + "<m2:bypassReasonCode>DO_PR</m2:bypassReasonCode>\n"
        + "<m2:salesChannel>CS</m2:salesChannel>\n"
        + "<m2:dueDate>" + this.tdarDueDate + "T23:59:59</m2:dueDate>\n"
        + "<m2:appointment>\n"
        + "<m2:startTime>2010-03-10T13:00:00</m2:startTime>\n"
        + "<m2:endTime>2010-03-10T16:00:00</m2:endTime>\n"
        + "</m2:appointment>\n"
        + "<m2:orderActionStatus>DE</m2:orderActionStatus>\n"
        + "<m2:addressInfoList>\n"
        + "<m2:addressInfo>\n"
        + "<m2:addressType>LSBilling</m2:addressType>\n"
        + "<m2:fieldedAddress>\n"
        + "<m2:city>" + this.tdarCity + "</m2:city>\n"
        + "<m2:state>" + this.tdarState + "</m2:state>\n"
        + "<m2:postalCode>" + this.tdarPostalCode + "</m2:postalCode>\n"
        + "<m2:addressId>" + this.tdarAddressId + "</m2:addressId>\n"
        + "</m2:fieldedAddress>\n"
        + "</m2:addressInfo>\n"
        + "<m2:addressInfo>\n"
        + "<m2:addressType>ShippingFrom</m2:addressType>\n"
        + "<m2:fieldedAddress>\n"
        + "<m2:houseNumber>" + this.tdarHouseNo + "</m2:houseNumber>\n"
        + "<m2:streetDirection>NE</m2:streetDirection>\n"
        + "<m2:streetName>" + this.tdarStreetName + "</m2:streetName>\n"
        + "<m2:streetThoroughfare>" + this.tdarStreetThroughfare + "</m2:streetThoroughfare>\n"
        + "<m2:streetNameSuffix>NE</m2:streetNameSuffix>\n"
        + "<m2:city>" + this.tdarCity + "</m2:city>\n"
        + "<m2:state>" + this.tdarState + "</m2:state>\n"
        + "<m2:postalCode>" + this.tdarPostalCode + "</m2:postalCode>\n"
        + "<m2:postalCodePlus4>" + this.tdarPostalCode2 + "</m2:postalCodePlus4>\n"
        + "<m2:county></m2:county>\n"
        + "<m2:country>USA</m2:country>\n"
        + "<m2:unitType></m2:unitType>\n"
        + "<m2:addressId>" + this.tdarAddressId + "</m2:addressId>\n"
        + "</m2:fieldedAddress>\n"
        + "</m2:addressInfo>\n"
        + "<m2:addressInfo>\n"
        + "<m2:addressType>ServiceFSP</m2:addressType>\n"
        + "<m2:primaryNpanxx>" + this.tdarPrimaryNpanx + "</m2:primaryNpanxx>\n"
        + "<m2:clli8>HINEGACA</m2:clli8>\n"
        + "<m2:fttbBuildingClli>fttbBuildingClli</m2:fttbBuildingClli>\n"
        + "<m2:emtClli>emtClli</m2:emtClli>\n"
        + "<m2:livingUnitAddressId>" + this.tdarLivingUnitAddressId + "</m2:livingUnitAddressId>\n"
        + "<m2:rateCenterCode>" + this.tdarRateCentreCode + "</m2:rateCenterCode>\n"
        + "<m2:vhoCode>" + this.tdarVhoCode + "</m2:vhoCode>\n"
        + "<m2:fieldedAddress>\n"
        + "<m2:houseNumber>" + this.tdarHouseNo + "</m2:houseNumber>\n"
        + "<m2:streetName>" + this.tdarStreetName + "</m2:streetName>\n"
        + "<m2:streetThoroughfare>" + this.tdarStreetThroughfare + "</m2:streetThoroughfare>\n"
        + "<m2:city>" + this.tdarCity + "</m2:city>\n"
        + "<m2:state>" + this.tdarState + "</m2:state>\n"
        + "<m2:postalCode>" + this.tdarPostalCode + "</m2:postalCode>\n"
        + "<m2:postalCodePlus4>" + this.tdarPostalCode2 + "</m2:postalCodePlus4>\n"
        + "<m2:county></m2:county>\n"
        + "<m2:unitType></m2:unitType>\n"
        + "<m2:unitValue></m2:unitValue>\n"
        + "<m2:cassAddressLines>\n"
        + "<m2:addressLine>" + this.tdarCustFirstName + " " + this.tdarCustLastName + "</m2:addressLine>\n"
        + "<m2:addressLine>" + this.tdarHouseNo + " " + this.tdarStreetName + " " + this.tdarStreetThroughfare + "</m2:addressLine>\n"
        + "<m2:addressLine>" + this.tdarCity + " " + this.tdarState + " " + this.tdarPostalCode + "</m2:addressLine>\n"
        + "</m2:cassAddressLines>\n"
        + "<m2:addressId>" + this.tdarAddressId + "</m2:addressId>\n"
        + "</m2:fieldedAddress>\n"
        + "</m2:addressInfo>\n"
        + "</m2:addressInfoList>\n"
        + "<m2:productList>\n"
        + "<m2:product>\n"
        + "<m2:name>AT&amp;T DTV</m2:name>\n"
        + "<m2:componentList>\n"
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543282</m2:assignedProductId>\n"
        + "<m2:serviceType>DTVM</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.subContainer?.dtvmAction + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>UVOrderActionType</m2:name>\n"
        + "<m2:value>" + this.tdarOrderActionType + "</m2:value>\n"
        + "</m2:attribute>\n"
        + this.dtvmOrdActResCode
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543310</m2:assignedProductId>\n"
        + "<m2:serviceType>DTT</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.dttAction + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>networkNonLocalIndicator</m2:name>\n"
        + "<m2:value>N</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>hdUnservedIndicator</m2:name>\n"
        + "<m2:value>N</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>CountyFIPS</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dttCountyFIPS + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>D2LiteEligibility</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dttD2LiteEligibility + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>D2LiteRestriction</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>moveIndicator</m2:name>\n"
        + "<m2:value>N</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>MRVIndicator</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dttMRVIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>SWMIndicator</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dttSWMIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>mpeg4RegionIndicator</m2:name>\n"
        + "<m2:value>Y</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n"
        + "</m2:componentList>\n"
        + "</m2:component>\n"
        + "</m2:componentList>\n"
        + "</m2:product>\n"
        + "</m2:productList>\n"
        + this.NFFLIndicator
        + "<m2:extendedDueDateIndicator>N</m2:extendedDueDateIndicator>\n"
        + "<m2:retainedServicesProcessIndicator>false</m2:retainedServicesProcessIndicator>\n"
        + "<m2:dslDisconnectTns>1571001135</m2:dslDisconnectTns>\n"
        + this.relatedOrderInfoTdar
        + "</m2:orderActionInfo>\n"
        + "</m2:orderActionInfoList>\n"
        + "<m2:customerInfoList>\n"
        + "<m2:customerInfo>\n"
        + "<m2:accountId>" + this.banValue + "</m2:accountId>\n"
        + "<m2:name>" + this.tdarCustFirstName + " " + this.tdarCustLastName + "</m2:name>\n"
        + "<m2:type>I</m2:type>\n"
        + "<m2:subType>9</m2:subType>\n"
        + "<m2:UBIndicator>" + this.tdarCustUbIndicator + "</m2:UBIndicator>\n"
        + "<m2:classOfService>Residential</m2:classOfService>\n"
        + "<m2:legalEntity>King</m2:legalEntity>\n"
        + "<m2:creditRiskClass>" + this.tdarCustCreditRiskClass + "</m2:creditRiskClass>\n"
        + "<m2:timeZoneOffset>" + this.tdarCustTimeZone + "</m2:timeZoneOffset>\n"
        + "<m2:billCycle>30</m2:billCycle>\n"
        + "<m2:billRound>2</m2:billRound>\n"
        + "<m2:customerInfoContactList>\n"
        + "<m2:customerInfoContact>\n"
        + "<m2:contactType>CU</m2:contactType>\n"
        + "<m2:title>Mr</m2:title>\n"
        + "<m2:firstName>" + this.tdarCustFirstName + "</m2:firstName>\n"
        + "<m2:lastName>" + this.tdarCustLastName + "</m2:lastName>\n"
        + "<m2:phoneNumber>" + this.tdarCustConatactNo + "</m2:phoneNumber>\n"
        + "<m2:secondaryPhoneNumber>" + this.tdarCustSecondaryNo + "</m2:secondaryPhoneNumber>\n"
        + "<m2:SellerName>Seller John</m2:SellerName>\n"
        + "<m2:SellerTn>2605658974</m2:SellerTn>\n"
        + "<m2:SellerId>SellerID</m2:SellerId>\n"
        + "</m2:customerInfoContact>\n"
        + "</m2:customerInfoContactList>\n"
        + "</m2:customerInfo>\n"
        + "</m2:customerInfoList>\n"
        + "</m2:order>\n"
        + "</m2:transactionInfo>\n"
        + "</m2:bbnmsOrder>\n"
        + "</SOAP-ENV:Body>\n"
        + "</SOAP-ENV:Envelope>";
    } else {
      OMS_request = "<SOAP-ENV:Envelope xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:m1=\"http://lightspeed.bbnms.att.com/header\" xmlns:m2=\"http://lightspeed.bbnms.att.com/ordering\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
        + "<SOAP-ENV:Header>\n"
        + "<m1:MessageHeader xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:bbnmsOrderHeader=\"http://lightspeed.bbnms.att.com/header\">\n"
        + "<ns2:WSHeader xmlns:ns2=\"http://cio.att.com/commonheader/v3\">\n"
        + "<ns2:WSContext>\n"
        + "<ns2:SourceIPAddress>10.160.249.210</ns2:SourceIPAddress>\n"
        + "</ns2:WSContext>\n"
        + "<ns2:WSMessageData>\n"
        + "<ns2:Timestamp>2008-02-19T10:09:25.0440</ns2:Timestamp>\n"
        + "</ns2:WSMessageData>\n"
        + "<ns2:WSEnterpriseLogging>\n"
        + "<ns2:LoggingKey>TN:3142353655</ns2:LoggingKey>\n"
        + "</ns2:WSEnterpriseLogging>\n"
        + "</ns2:WSHeader>\n"
        + "<ns1:WSDiscovery xmlns:ns1=\"http://aftdiscovery.att.com/header/v1\">\n"
        + "<ns1:name>MQSSL_ESB_J2EEEJB_ON_AIX</ns1:name>\n"
        + "<ns1:version>\n"
        + "<ns1:major>3</ns1:major>\n"
        + "<ns1:minor>0</ns1:minor>\n"
        + "</ns1:version>\n"
        + "<ns1:envContext>Y</ns1:envContext>\n"
        + "<ns1:bindingType>fusionBus</ns1:bindingType>\n"
        + "</ns1:WSDiscovery>\n"
        + "</m1:MessageHeader>\n"
        + "</SOAP-ENV:Header>\n"
        + "<SOAP-ENV:Body>\n"
        + "<m2:bbnmsOrder>\n"
        + "<m2:transactionInfo xmlns:bbnmsOrder=\"http://lightspeed.bbnms.att.com/ordering\">\n"
        + "<m2:transactionId>MknkAgC6h1WHKQwKs7A</m2:transactionId>\n"
        + "<m2:taskName>" + taskName + "</m2:taskName>\n"
        + "<m2:cvoipSdpProvisioningInd>true</m2:cvoipSdpProvisioningInd>\n"
        + "<m2:order>\n"
        + "<m2:orderActionInfoList>\n"
        + "<m2:orderActionInfo>\n"
        + "<m2:orderNumber>" + this.tdarOrderNumber + "</m2:orderNumber>\n"
        + "<m2:orderActionId>" + this.tdarOrderNumber + "</m2:orderActionId>\n"
        + "<m2:originalOrderActionId>" + this.tdarOrigOrdId + "</m2:originalOrderActionId>\n"
        + "<m2:orderActionType>" + this.tdarOrderActionType + "</m2:orderActionType>\n"
        + "<m2:orderActionSubType>" + this.tdarOrderActionSubType + "</m2:orderActionSubType>\n"
        + "<m2:orderActionReferenceNumber>" + this.tdarOrigOrdId + this.tdarOrderActionRef + "</m2:orderActionReferenceNumber>\n"
        + "<m2:orderCreationDate>" + this.tdarCreationDate + "T01:01:01</m2:orderCreationDate>\n"
        + "<m2:assignedProductId>535703164</m2:assignedProductId>\n"
        + this.bypassReasonCode
        + this.dtvmOrdActResCode
        + "<m2:salesChannel>CS</m2:salesChannel>\n"
        + "<m2:dueDate>" + this.tdarDueDate + "T23:59:59</m2:dueDate>\n"
        + "<m2:appointment>\n"
        + "<m2:startTime>2010-03-10T13:00:00</m2:startTime>\n"
        + "<m2:endTime>2010-03-10T16:00:00</m2:endTime>\n"
        + "</m2:appointment>\n"
        + "<m2:orderActionStatus>DE</m2:orderActionStatus>\n"
        + "<m2:addressInfoList>\n"
        + "<m2:addressInfo>\n"
        + "<m2:addressType>LSBilling</m2:addressType>\n"
        + "<m2:fieldedAddress>\n"
        + "<m2:city>" + this.tdarCity + "</m2:city>\n"
        + "<m2:state>" + this.tdarState + "</m2:state>\n"
        + "<m2:postalCode>" + this.tdarPostalCode + "</m2:postalCode>\n"
        + "<m2:addressId>" + this.tdarAddressId + "</m2:addressId>\n"
        + "</m2:fieldedAddress>\n"
        + "</m2:addressInfo>\n"
        + "<m2:addressInfo>\n"
        + "<m2:addressType>ShippingFrom</m2:addressType>\n"
        + "<m2:fieldedAddress>\n"
        + "<m2:houseNumber>" + this.tdarHouseNo + "</m2:houseNumber>\n"
        + "<m2:streetDirection></m2:streetDirection>\n"
        + "<m2:streetName>" + this.tdarStreetName + "</m2:streetName>\n"
        + "<m2:streetThoroughfare>" + this.tdarStreetThroughfare + "</m2:streetThoroughfare>\n"
        + "<m2:streetNameSuffix></m2:streetNameSuffix>\n"
        + "<m2:city>" + this.tdarCity + "</m2:city>\n"
        + "<m2:state>" + this.tdarState + "</m2:state>\n"
        + "<m2:postalCode>" + this.tdarPostalCode + "</m2:postalCode>\n"
        + "<m2:postalCodePlus4>" + this.tdarPostalCode2 + "</m2:postalCodePlus4>\n"
        + "<m2:county></m2:county>\n"
        + "<m2:country>USA</m2:country>\n"
        + "<m2:unitType></m2:unitType>\n"
        + "<m2:addressId>" + this.tdarAddressId + "</m2:addressId>\n"
        + "</m2:fieldedAddress>\n"
        + "</m2:addressInfo>\n"
        + "<m2:addressInfo>\n"
        + "<m2:addressType>ServiceFSP</m2:addressType>\n"
        + "<m2:primaryNpanxx>" + this.tdarPrimaryNpanx + "</m2:primaryNpanxx>\n"
        + "<m2:clli8>HINEGACA</m2:clli8>\n"
        + "<m2:fttbBuildingClli>fttbBuildingClli</m2:fttbBuildingClli>\n"
        + "<m2:emtClli>emtClli</m2:emtClli>\n"
        + this.ccid_FSP
        + "<m2:livingUnitAddressId>" + this.tdarLivingUnitAddressId + "</m2:livingUnitAddressId>\n"
        + "<m2:rateCenterCode>" + this.tdarRateCentreCode + "</m2:rateCenterCode>\n"
        + "<m2:vhoCode>" + this.tdarVhoCode + "</m2:vhoCode>\n"
        + "<m2:fieldedAddress>\n"
        + "<m2:houseNumber>" + this.tdarHouseNo + "</m2:houseNumber>\n"
        + "<m2:streetName>" + this.tdarStreetName + "</m2:streetName>\n"
        + "<m2:streetThoroughfare>" + this.tdarStreetThroughfare + "</m2:streetThoroughfare>\n"
        + "<m2:city>" + this.tdarCity + "</m2:city>\n"
        + "<m2:state>" + this.tdarState + "</m2:state>\n"
        + "<m2:postalCode>" + this.tdarPostalCode + "</m2:postalCode>\n"
        + "<m2:postalCodePlus4>" + this.tdarPostalCode2 + "</m2:postalCodePlus4>\n"
        + "<m2:county></m2:county>\n"
        + "<m2:unitType></m2:unitType>\n"
        + "<m2:unitValue></m2:unitValue>\n"
        + "<m2:cassAddressLines>\n"
        + "<m2:addressLine>" + this.tdarCustFirstName + " " + this.tdarCustLastName + "</m2:addressLine>\n"
        + "<m2:addressLine>" + this.tdarHouseNo + " " + this.tdarStreetName + " " + this.tdarStreetThroughfare + "</m2:addressLine>\n"
        + "<m2:addressLine>" + this.tdarCity + " " + this.tdarState + " " + this.tdarPostalCode + "</m2:addressLine>\n"
        + "</m2:cassAddressLines>\n"
        + "<m2:addressId>" + this.tdarAddressId + "</m2:addressId>\n"
        + "</m2:fieldedAddress>\n"
        + "</m2:addressInfo>\n"
        + "</m2:addressInfoList>\n"
        + "<m2:productList>\n"
        + "<m2:product>\n"
        + "<m2:name>AT&amp;T DTV</m2:name>\n"
        + "<m2:componentList>\n"
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543282</m2:assignedProductId>\n"
        + "<m2:serviceType>DTVM</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.subContainer?.dtvmAction + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>Parent</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>installationType</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dtvmIstallationType + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>technicianDispatchIndicator</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dtvmTechDispatchIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + this.tdarAdultContentRestrictionStr
        + "<m2:attribute>\n"
        + "<m2:name>shippingIndicator</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dtvmShippingIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>workOrderId</m2:name>\n"
        + "<m2:value>" + this.tdarWorkOrderId + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>previousWorkOrderId</m2:name>\n"
        + "<m2:value>" + this.tdarPrevWorkOrderId + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ARS</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + this.customerLine_DTVM
        + this.contractId_DTVM
        + this.PropertyContractType
        + this.dtvAccountType
        + this.dealerCode
        + this.dealerAccountType
        + "<m2:attribute>\n"
        + "<m2:name>telegenceId</m2:name>\n"
        + "<m2:value>null</m2:value>\n"
        + "</m2:attribute>\n"
        + this.supercedeStr
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + this.dtvbvpPartnerNameStr
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543284</m2:assignedProductId>\n"
        + "<m2:serviceType>DTCP</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.subContainer?.dttAction + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>installationType</m2:name>\n"
        + "<m2:value>TECH</m2:value>\n"
        + "</m2:attribute>\n"
        + this.contractId_DTCP
        + "<m2:attribute>\n"
        + "<m2:name>technicianDispatchIndicator</m2:name>\n"
        + "<m2:value>Install</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shippingIndicator</m2:name>\n"
        + "<m2:value>Tech</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DTVSD</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DTVHD</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DTVHDD</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DTVTivoHDD</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DTVGenie</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DTVGenieMini</m2:name>\n"
        + "<m2:value>1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>recordOnly</m2:name>\n"
        + "<m2:value>N</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + this.DTSTB1
        + this.DTSTB2
        + this.DTSTB3
        + this.DTSTB4
        + this.DTSTB5
        + "</m2:componentList>\n"
        + "</m2:component>\n"
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543316</m2:assignedProductId>\n"
        + "<m2:serviceType>DTACC</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.subContainer?.dttAction + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>OffAirAntenna</m2:name>\n"
        + "<m2:value>A</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>moveIndicator</m2:name>\n"
        + "<m2:value>NA</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543288</m2:assignedProductId>\n"
        + "<m2:serviceType>DTDH</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.subContainer?.dttAction + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>1234543280</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DISHType</m2:name>\n"
        + "<m2:value>Standard</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>criticalFullfillment</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>materialCode</m2:name>\n"
        + "<m2:value>Generic BOM Wifi STB Access Point</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>fulfillmentIndicator</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>productLine</m2:name>\n"
        + "<m2:value>ANTENNA</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n"
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543290</m2:assignedProductId>\n"
        + "<m2:serviceType>DTWB</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.subContainer?.dtwbAction + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>1234543290</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>purchaseTerms</m2:name>\n"
        + "<m2:value>Rent</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>action_type</m2:name>\n"
        + "<m2:value>Acquisition</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>DV</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>criticalFullfillment</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>fulfillmentIndicator</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>None</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>materialCode</m2:name>\n"
        + "<m2:value>Generic BOM Wifi STB Access Point</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shipmentType</m2:name>\n"
        + "<m2:value>Ground Standard</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>productLine</m2:name>\n"
        + "<m2:value>WIRELESS VIDEO BRIDGE</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>modelNumber</m2:name>\n"
        + "<m2:value>WVB2-34</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>manufacturer</m2:name>\n"
        + "<m2:value>DIRECTV</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>receiverID</m2:name>\n"
        + "<m2:value>REC2244005</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>serialNumber</m2:name>\n"
        + "<m2:value>AVVVVVZZ1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>accessCardNumber</m2:name>\n"
        + "<m2:value>LBVWWVHZ2LBVWWVHZ2</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n"
        + "</m2:componentList>\n"
        + "</m2:component>\n"
        + this.DTACRD
        + this.AddSrvComponent
        + "<m2:component>\n"
        + "<m2:assignedProductId>1234543292</m2:assignedProductId>\n"
        + "<m2:serviceType>ATTDV</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.subContainer?.dtvAttDv + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>BasePkg</m2:name>\n"
        + "<m2:value>" + this.subContainer?.BaseProgramDtv + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>HDAccess</m2:name>\n"
        + "<m2:value>" + this.subContainer?.dtvHDAccessIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + this.contractId_ATTDV
        + "<m2:attribute>\n"
        + "<m2:name>installationType</m2:name>\n"
        + "<m2:value>TECH</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>Child</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>DV</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>action_type</m2:name>\n"
        + "<m2:value>Acquisition</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>availableForSelfInstall</m2:name>\n"
        + "<m2:value>Not Allowed</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>completionIndicator</m2:name>\n"
        + "<m2:value>None</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>fulfillmentIndicator</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>AllinCapable</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + this.DTGP1
        + this.DTGP2
        + this.DTGP3
        + this.DTGP4
        + this.DTGP5
        + "</m2:componentList>\n"
        + "</m2:component>\n"
        + this.DTT
        + this.DTOTA
        + "</m2:componentList>\n"
        + "</m2:component>\n"
        + "</m2:componentList>\n"
        + "</m2:product>\n"
        + "</m2:productList>\n"
        + this.NFFLIndicator
        + "<m2:extendedDueDateIndicator>N</m2:extendedDueDateIndicator>\n"
        + "<m2:retainedServicesProcessIndicator>false</m2:retainedServicesProcessIndicator>\n"
        + "<m2:dslDisconnectTns>1571001135</m2:dslDisconnectTns>\n"
        + this.relatedProductOrderInfo
        + this.relatedOrderInfoTdar
        + "</m2:orderActionInfo>\n"
        + "</m2:orderActionInfoList>\n"
        + "<m2:customerInfoList>\n"
        + this.newCustomerInfoDtv
        + "<m2:customerInfo>\n"
        + "<m2:accountId>" + this.banValue + "</m2:accountId>\n"
        + this.currentcustIndFalse
        + "<m2:name>" + this.tdarCustFirstName + " " + this.tdarCustLastName + "</m2:name>\n"
        + "<m2:type>I</m2:type>\n"
        + "<m2:subType>9</m2:subType>\n"
        + "<m2:UBIndicator>" + this.tdarCustUbIndicator + "</m2:UBIndicator>\n"
        + "<m2:classOfService>Residential</m2:classOfService>\n"
        + "<m2:legalEntity>King</m2:legalEntity>\n"
        + "<m2:creditRiskClass>" + this.tdarCustCreditRiskClass + "</m2:creditRiskClass>\n"
        + "<m2:timeZoneOffset>" + this.tdarCustTimeZone + "</m2:timeZoneOffset>\n"
        + "<m2:billCycle>30</m2:billCycle>\n"
        + "<m2:billRound>2</m2:billRound>\n"
        + "<m2:customerInfoContactList>\n"
        + "<m2:customerInfoContact>\n"
        + "<m2:contactType>CU</m2:contactType>\n"
        + "<m2:title>Mr</m2:title>\n"
        + "<m2:firstName>" + this.tdarCustFirstName + "</m2:firstName>\n"
        + "<m2:lastName>" + this.tdarCustLastName + "</m2:lastName>\n"
        + "<m2:phoneNumber>" + this.tdarCustConatactNo + "</m2:phoneNumber>\n"
        + "<m2:secondaryPhoneNumber>" + this.tdarCustSecondaryNo + "</m2:secondaryPhoneNumber>\n"
        + "<m2:SellerName>Seller John</m2:SellerName>\n"
        + "<m2:SellerTn>2605658974</m2:SellerTn>\n"
        + "<m2:SellerId>SellerID</m2:SellerId>\n"
        + "</m2:customerInfoContact>\n"
        + "</m2:customerInfoContactList>\n"
        + "</m2:customerInfo>\n"
        + "</m2:customerInfoList>\n"
        + "</m2:order>\n"
        + "</m2:transactionInfo>\n"
        + "</m2:bbnmsOrder>\n"
        + "</SOAP-ENV:Body>\n"
        + "</SOAP-ENV:Envelope>";
    }

    this.callModalPopUp(OMS_request, "template2", "Complete XML Generation", "A_exchangeCpeDataCall1.xml")

  }

  getTabData() {
    //DTEQAC
    if (this.TdarstbProductLn1 == "GENIE LITE HD DVR KIT") {
      this.serviceType1 = "DTEQAC";
      this.serviceType = "DTSTB";
    } else {
      this.serviceType1 = "DTSTB";
      this.serviceType = "DTSTB";
    }

    // CCID TAG IN SERVICE FSP 
    if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL")) {
      this.ccid_FSP = "<m2:CCID>test</m2:CCID>\n"
    } else if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "NDPL")) {
      this.ccid_FSP = "<m2:CCID>test</m2:CCID>\n"
    } else if ((this.customerLineIndicator == "NA") || (this.customerLineIndicator == "MDU_DTH") || (this.PropertyContractIndicator == "NA")) {
      this.ccid_FSP = "";
    }

    //IS ACTIVE INDICATOR
    if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL") && (this.tdarOrderActionType == "PR")) {
      this.isActive_DTSTB1 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB1 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB2 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB2 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB3 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB3 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB4 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB4 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB5 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB5 + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL") && (this.tdarOrderActionType == "CH")) {
      this.isActive_DTSTB1 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB1 + "</m2:value>\n"
        + "<m2:oldValue>" + this.oldvalueInd1 + "</m2:oldValue>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB2 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB2 + "</m2:value>\n"
        + "<m2:oldValue>" + this.oldvalueInd2 + "</m2:oldValue>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB3 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB3 + "</m2:value>\n"
        + "<m2:oldValue>" + this.oldvalueInd3 + "</m2:oldValue>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB4 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB4 + "</m2:value>\n"
        + "<m2:oldValue>" + this.oldvalueInd4 + "</m2:oldValue>\n"
        + "</m2:attribute>\n";

      this.isActive_DTSTB5 = "<m2:attribute>\n"
        + "<m2:name>isActive</m2:name>\n"
        + "<m2:value>" + this.isActive_DTSTB5 + "</m2:value>\n"
        + "<m2:oldValue>" + this.oldvalueInd5 + "</m2:oldValue>\n"
        + "</m2:attribute>\n";
    } else if ((this.customerLineIndicator == "NA") || (this.customerLineIndicator == "MDU_DTH") || (this.PropertyContractIndicator == "NDPL") || (this.PropertyContractIndicator == "NA")) {
      this.isActive_DTSTB1 = "";
      this.isActive_DTSTB2 = "";
      this.isActive_DTSTB3 = "";
      this.isActive_DTSTB4 = "";
      this.isActive_DTSTB5 = "";
    }

    // Contract Id for DTSTB
    if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL")) {
      this.ContractId_DTSTB1 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.ContractId_DTSTB1 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.ContractId_DTSTB2 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.ContractId_DTSTB2 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.ContractId_DTSTB3 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.ContractId_DTSTB3 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.ContractId_DTSTB4 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.ContractId_DTSTB4 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.ContractId_DTSTB5 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.ContractId_DTSTB5 + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else if ((this.customerLineIndicator == "NA") || (this.customerLineIndicator == "MDU_DTH") || (this.PropertyContractIndicator == "NDPL") || (this.PropertyContractIndicator == "NA")) {
      this.ContractId_DTSTB1 = "";
      this.ContractId_DTSTB2 = "";
      this.ContractId_DTSTB3 = "";
      this.ContractId_DTSTB4 = "";
      this.ContractId_DTSTB5 = "";
    }

    // Contract Id for DTGP
    if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL")) {
      this.contractId_DTGP1 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractId_DTGP1 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.contractId_DTGP2 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractId_DTGP2 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.contractId_DTGP3 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractId_DTGP3 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.contractId_DTGP4 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractId_DTGP4 + "</m2:value>\n"
        + "</m2:attribute>\n";

      this.contractId_DTGP5 = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractId_DTGP5 + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else if ((this.customerLineIndicator == "NA") || (this.customerLineIndicator == "MDU_DTH") || (this.PropertyContractIndicator == "NDPL") || (this.PropertyContractIndicator == "NA")) {
      this.contractId_DTGP1 = "";
      this.contractId_DTGP2 = "";
      this.contractId_DTGP3 = "";
      this.contractId_DTGP4 = "";
      this.contractId_DTGP5 = "";
    }

    // Contract Id ,  Customer Line , Property Contract Type for DTVM , DTCP, ATTDV

    //DTVM
    if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL")) {
      this.contractId_DTVM = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractIdInd_DTVM + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else if ((this.customerLineIndicator == "NA") || (this.PropertyContractIndicator == "NDPL") || (this.PropertyContractIndicator == "NA")) {
      this.contractId_DTVM = "";
    }

    if ((this.customerLineIndicator == "MDU_BULK") || (this.customerLineIndicator == "MDU_DTH")) {
      this.customerLine_DTVM = "<m2:attribute>\n"
        + "<m2:name>customerLine</m2:name>\n"
        + "<m2:value>" + this.customerLineIndicator + "</m2:value>\n"
        + this.oldCustomLine
        + "</m2:attribute>\n";
    } else if (this.customerLineIndicator == "NA") {
      this.customerLine_DTVM = "";
    }

    if ((this.customerLineIndicator == "MDU_BULK") || (this.customerLineIndicator == "MDU_DTH")) {
      this.PropertyContractType = "<m2:attribute>\n"
        + "<m2:name>PropertyContractType</m2:name>\n"
        + "<m2:value>" + this.PropertyContractIndicator + "</m2:value>\n"
        + this.oldPropType
        + "</m2:attribute>\n";
    } else if (this.customerLineIndicator == "NA") {
      this.PropertyContractType = "";
    }

    //DTCP
    if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL")) {
      this.contractId_DTCP = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractIdInd_DTCP + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else if ((this.customerLineIndicator == "NA") || (this.PropertyContractIndicator == "NDPL") || (this.PropertyContractIndicator == "NA")) {
      this.contractId_DTCP = "";
    }

    //ATTDV
    if ((this.customerLineIndicator == "MDU_BULK") && (this.PropertyContractIndicator == "DPL")) {
      this.contractId_ATTDV = "<m2:attribute>\n"
        + "<m2:name>contractId</m2:name>\n"
        + "<m2:value>" + this.contractIdInd_ATTDV + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else if ((this.customerLineIndicator == "NA") || (this.PropertyContractIndicator == "NDPL") || (this.PropertyContractIndicator == "NA")) {
      this.contractId_ATTDV = "";
    }

    //DTACRD
    if (this.includeDTACRD) {
      this.DTACRD = "<m2:component>\n"
        + "<m2:assignedProductId>1234543292</m2:assignedProductId>\n"
        + "<m2:serviceType>DTACRD</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.dtacrdActionIndicator + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>1234543292</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>action_type</m2:name>\n"
        + "<m2:value>Acquisition</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>DV</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>criticalFullfillment</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>fulfillmentIndicator</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>None</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>materialCode</m2:name>\n"
        + "<m2:value>Access Card</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shipmentType</m2:name>\n"
        + "<m2:value>Ground Standard</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>productLine</m2:name>\n"
        + "<m2:value>" + this.dtacrdPrdoductLine + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n";

      this.bypassReasonCode = "<m2:bypassReasonCode>ACCRD_SW</m2:bypassReasonCode>\n"
    } else {
      this.DTACRD = "";
      this.bypassReasonCode = "<m2:bypassReasonCode>DO_PR</m2:bypassReasonCode>\n";
    }

    // DTVBVP 
    if ((this.tdarPartnerName == "Centurylink") || (this.tdarPartnerName == "Quest")) {
      this.dtvbvpPartnerNameStr = "<m2:component>\n"
        + "<m2:assignedProductId>1234543280</m2:assignedProductId>\n"
        + "<m2:serviceType>DTVBVP</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.dtvbvpActionIndicator + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>partnerName</m2:name>\n"
        + "<m2:value>" + this.tdarPartnerName + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>partnerID</m2:name>\n"
        + "<m2:value>" + this.tdarPartnerID + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n";
    } else {
      this.dtvbvpPartnerNameStr = "";
    }

    // Add DTV dongle component
    // if (addDongleService.selected) {
    //   this.DTOTA = "<m2:component>\n"
    //     + "<m2:assignedProductId>1234543312</m2:assignedProductId>\n"
    //     + "<m2:serviceType>DTOTA</m2:serviceType>\n"
    //     + "<m2:actionIndicator>" + dtotaActInd.text + "</m2:actionIndicator>\n"
    //     + "<m2:attributeList>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>OTATypes</m2:name>\n"
    //     + "<m2:value>Wired_Indoor</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "</m2:attributeList>\n"
    //     + "<m2:componentList>\n"
    //     + "<m2:component>\n"
    //     + "<m2:assignedProductId>1234543313</m2:assignedProductId>\n"
    //     + "<m2:serviceType>DTOTAL</m2:serviceType>\n"
    //     + "<m2:actionIndicator>" + dtotalActInd.text + "</m2:actionIndicator>\n"
    //     + "<m2:attributeList>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>productLine</m2:name>\n"
    //     + "<m2:value>WIRED LOCAL CHANNEL CONNECTOR</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>LCCType</m2:name>\n"
    //     + "<m2:value>Wired</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "</m2:attributeList>\n"
    //     + "</m2:component>\n"
    //     + "<m2:component>\n"
    //     + "<m2:assignedProductId>1234543314</m2:assignedProductId>\n"
    //     + "<m2:serviceType>DTOTAA</m2:serviceType>\n"
    //     + "<m2:actionIndicator>" + dtotaaActInd.text + "</m2:actionIndicator>\n"
    //     + "<m2:attributeList>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>productLine</m2:name>\n"
    //     + "<m2:value>LCC INDOOR ANTENNA</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>antennaType</m2:name>\n"
    //     + "<m2:value>Indoor</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "</m2:attributeList>\n"
    //     + "</m2:component>\n"
    //     + "</m2:componentList>\n"
    //     + "</m2:component>";
    // } else {
    //   this.DTOTA = "";
    // }

    // Adult Content Restriction 
    if ((this.tdarPartnerName == "Centurylink") || (this.tdarPartnerName == "Quest")) {
      this.tdarAdultContentRestrictionStr = "<m2:attribute>\n"
        + "<m2:name>AdultContentRestriction</m2:name>\n"
        + "<m2:value>" + this.adultContentIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
    } else {
      this.tdarAdultContentRestrictionStr = "";
    }

    this.DTT = "<m2:component>\n"
      + "<m2:assignedProductId>1234543310</m2:assignedProductId>\n"
      + "<m2:serviceType>DTT</m2:serviceType>\n"
      + "<m2:actionIndicator>" + this.dttAction + "</m2:actionIndicator>\n"
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>networkNonLocalIndicator</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hdUnservedIndicator</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>CountyFIPS</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttCountyFIPS + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>D2LiteEligibility</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttD2LiteEligibility + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>mduConnectedProperty</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttmMDUConnectedProperty + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>D2LiteRestriction</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>dealerRestrictedProperty</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttDealerRestrictedPropertyIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>MRVIndicator</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttMRVIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>SWMIndicator</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttSWMIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>4kService</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dtt4kService + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>mpeg4RegionIndicator</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttmpeg4RegionIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>genieGen1Indicator</m2:name>\n"
      + "<m2:value>" + this.subContainer?.dttgenieGen1Indicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";

    // this.DTSTB1 = this.DtstbComp(tdarDtStbActInd1.selectedItem.data, stbType1.selectedItem.data, TdarstbProductLn1.selectedItem.data, TdarModelNumber1.selectedItem.data, serviceType1, ContractId_DTSTB1, purchaseTermsInd1.selectedItem.data, isActive_DTSTB1, macAddress1.text, receiverID1.text, serialNumber1.text, accessCardNumber1.text, APID1.text, dtStbSapOrdStatus1.selectedItem.data);

    // if (includeStbType2.selected) {
    //   this.DTSTB2 = this.DtstbComp(tdarDtStbActInd2.selectedItem.data, stbType2.selectedItem.data, TdarstbProductLn2.selectedItem.data, TdarModelNumber2.selectedItem.data, serviceType, ContractId_DTSTB2, purchaseTermsInd2.selectedItem.data, isActive_DTSTB2, macAddress2.text, receiverID2.text, serialNumber2.text, accessCardNumber2.text, APID2.text, dtStbSapOrdStatus2.selectedItem.data);
    // } else {
    //   this.DTSTB2 = "";
    // }

    // if (includeStbType3.selected) {
    //   this.DTSTB3 = this.DtstbComp(tdarDtStbActInd3.selectedItem.data, stbType3.selectedItem.data, TdarstbProductLn3.selectedItem.data, TdarModelNumber3.selectedItem.data, serviceType, ContractId_DTSTB3, purchaseTermsInd3.selectedItem.data, isActive_DTSTB3, macAddress3.text, receiverID3.text, serialNumber3.text, accessCardNumber3.text, APID3.text, dtStbSapOrdStatus3.selectedItem.data);
    // } else {
    //   this.DTSTB3 = "";
    // }

    // if (includeStbType4.selected) {
    //   this.DTSTB4 = this.DtstbComp(tdarDtStbActInd4.selectedItem.data, stbType4.selectedItem.data, TdarstbProductLn4.selectedItem.data, TdarModelNumber4.selectedItem.data, serviceType, ContractId_DTSTB4, purchaseTermsInd4.selectedItem.data, isActive_DTSTB4, macAddress4.text, receiverID4.text, serialNumber4.text, accessCardNumber4.text, APID4.text, dtStbSapOrdStatus4.selectedItem.data);
    // } else {
    //   this.DTSTB4 = "";
    // }

    // if (includeStbType5.selected) {
    //   this.DTSTB5 = this.DtstbComp(tdarDtStbActInd5.selectedItem.data, stbType5.selectedItem.data, TdarstbProductLn5.selectedItem.data, TdarModelNumber5.selectedItem.data, serviceType, ContractId_DTSTB5, purchaseTermsInd5.selectedItem.data, isActive_DTSTB5, macAddress5.text, receiverID5.text, serialNumber5.text, accessCardNumber5.text, APID5.text, dtStbSapOrdStatus5.selectedItem.data);
    // } else {
    //   this.DTSTB5 = "";
    // }

    // this.DTGP1 = this.DtGpComp(tdarDtgp1.selectedItem.data, tdarDtGenrePkg.selectedItem.data, contractId_DTGP1, '1');

    // if (dtgpChkbox2.selected) {
    //   this.DTGP2 = this.DtGpComp(tdarDtgp2.selectedItem.data, tdarDtGenrePkg2.selectedItem.data, contractId_this.DTGP2, '2');
    // } else {
    //   this.DTGP2 = "";
    // }

    // if (dtgpChkbox3.selected) {
    //   this.DTGP3 = this.DtGpComp(tdarDtgp3.selectedItem.data, tdarDtGenrePkg3.selectedItem.data, contractId_DTGP3, '3');
    // } else {
    //   this.DTGP3 = "";
    // }

    // if (dtgpChkbox4.selected) {
    //   this.DTGP4 = this.DtGpComp(tdarDtgp4.selectedItem.data, tdarDtGenrePkg4.selectedItem.data, contractId_DTGP4, '4');
    // } else {
    //   this.DTGP4 = "";
    // }

    // if (dtgpChkbox5.selected) {
    //   this.DTGP5 = this.DtGpComp(tdarDtgp5.selectedItem.data, tdarDtGenrePkg5.selectedItem.data, contractId_DTGP5, '5');
    // } else {
    //   this.DTGP5 = "";
    // }

    // set new customer info
    // if (NewCustomerInfo_DTV.enabled) {
    //   this.newCustomerInfoDtv = "<m2:customerInfo>\n"
    //     + "<m2:accountId>" + this.tdarNewCustBan + "</m2:accountId>\n"
    //     + this.currentcustIndTrue
    //     + "<m2:name>" + this.tdarNewCustFname + " " + this.tdarNewCustLname + "</m2:name>\n"
    //     + "<m2:type>I</m2:type>\n"
    //     + "<m2:subType>9</m2:subType>\n"
    //     + "<m2:UBIndicator>" + this.customerInfo?.selectedUBIndicator + "</m2:UBIndicator>\n"
    //     + "<m2:classOfService>Residential</m2:classOfService>\n"
    //     + "<m2:legalEntity>King</m2:legalEntity>\n"
    //     + "<m2:creditRiskClass>" + this.customerInfo?.selectedCreditRiskClass + "</m2:creditRiskClass>\n"
    //     + "<m2:timeZoneOffset>" + this.tdarCustTimeZone + "</m2:timeZoneOffset>\n"
    //     + "<m2:billCycle>30</m2:billCycle>\n"
    //     + "<m2:billRound>2</m2:billRound>\n"
    //     + "<m2:customerInfoContactList>\n"
    //     + "<m2:customerInfoContact>\n"
    //     + "<m2:contactType>CU</m2:contactType>\n"
    //     + "<m2:title>Mr</m2:title>\n"
    //     + "<m2:firstName>" + this.tdarNewCustFname + "</m2:firstName>\n"
    //     + "<m2:lastName>" + this.tdarNewCustLname + "</m2:lastName>\n"
    //     + "<m2:phoneNumber>" + this.tdarNewCustContactPh + "</m2:phoneNumber>\n"
    //     + "<m2:secondaryPhoneNumber>" + this.tdarNewCustSecondaryPh + "</m2:secondaryPhoneNumber>\n"
    //     + "<m2:SellerName>Seller John</m2:SellerName>\n"
    //     + "<m2:SellerTn>2605658974</m2:SellerTn>\n"
    //     + "<m2:SellerId>SellerID</m2:SellerId>\n"
    //     + "</m2:customerInfoContact>\n"
    //     + "</m2:customerInfoContactList>\n"
    //     + "</m2:customerInfo>\n";
    // } else {
    //   this.newCustomerInfoDtv = "";
    // }

    // if (tdarRpiChkBox.selected) {
    //   this.relatedProductOrderInfo = this.relatedProductOrderInfoTdar;
    // } else {
    //   this.relatedProductOrderInfo = "";
    // }

    // if (stackedOrder_DTV.selected) {
    //   if (this.relatedOrderInfo_DTV == null) {
    //     this.SetStackedOrderData_DTV();
    //   }
    //   this.relatedOrderInfoTdar = this.relatedOrderInfo_DTV;
    // } else {
    //   this.relatedOrderInfoTdar = "";
    // }

    // // DTVM order action reason code
    // if (dtvmOrdActReasonCode.enabled) {
    //   this.dtvmOrdActResCode = "<m2:orderActionReasonCode>" + this.subContainer?.dtvmReasonCode + "</m2:orderActionReasonCode>\n";
    // } else if ((this.tdarOrderActionType == "PR") && ((this.customerLineIndicator == "MDU_DTH") || (this.customerLineIndicator == "MDU_BULK"))) {
    //   this.dtvmOrdActResCode = "<m2:orderActionReasonCode>TT</m2:orderActionReasonCode>\n";
    // } else {
    //   this.dtvmOrdActResCode = "";
    // }
  }

  //orderAct type
  getOrderActType() {
    if (this.tdarOrderActionType == "CH") {
      if (this.mduOldDtvActTyp == "") {
        this.oldDtvAccountType = "";
      } else {
        this.oldDtvAccountType = "<bbnmsOrder:oldValue>" + this.mduOldDtvActTyp + "</bbnmsOrder:oldValue>\n";
      }

      if (this.mduOldDealerCode == "") {
        this.oldDealerCode = "";
      } else {
        this.oldDealerCode = "<bbnmsOrder:oldValue>" + this.mduOldDealerCode + "</bbnmsOrder:oldValue>\n";
      }

      if (this.mduOldDealerActTyp == "") {
        this.oldDealerActType = "";
      } else {
        this.oldDealerActType = "<bbnmsOrder:oldValue>" + this.mduOldDealerActTyp + "</bbnmsOrder:oldValue>\n";
      }

      if (this.mduOldCustLine == "") {
        this.oldCustomLine = "";
      } else {
        this.oldCustomLine = "<bbnmsOrder:oldValue>" + this.mduOldCustLine + "</bbnmsOrder:oldValue>\n";
      }

      if (this.mduOldPropContTyp == "") {
        this.oldPropType = "";
      } else {
        this.oldPropType = "<bbnmsOrder:oldValue>" + this.mduOldPropContTyp + "</bbnmsOrder:oldValue>\n";
      }
    }

    if (this.mduDtvActTyp == "") {
      this.dtvAccountType = "";
    } else {
      this.dtvAccountType = "<bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:name>dtvAccountType</bbnmsOrder:name>\n"
        + "<bbnmsOrder:value>" + this.mduDtvActTyp + "</bbnmsOrder:value>\n"
        + this.oldDtvAccountType
        + "</bbnmsOrder:attribute>\n";
    }

    if (this.mduDealerCode == "") {
      this.dealerCode = "";
    } else {
      this.dealerCode = "<bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:name>dealerCode</bbnmsOrder:name>\n"
        + "<bbnmsOrder:value>" + this.mduDealerCode + "</bbnmsOrder:value>\n"
        + this.oldDealerCode
        + "</bbnmsOrder:attribute>\n";
    }

    if (this.mduDealerActTyp == "") {
      this.dealerAccountType = "";
    } else {
      this.dealerAccountType = "<bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:name>dealerAccountType</bbnmsOrder:name>\n"
        + "<bbnmsOrder:value>" + this.mduDealerActTyp + "</bbnmsOrder:value>\n"
        + this.oldDealerActType
        + "</bbnmsOrder:attribute>\n";
    }
  }

  //NFFL Indicator
  getNfflIndicator() {
    if ((this.tdarNfflIndicator == "Y") || (this.tdarNfflIndicator == "N")) {
      this.NFFLIndicator = "<m2:nonProductCatalogDataList>\n"
        + "<m2:nonProductCatalogData>\n"
        + "<m2:name>NFFLIndicator</m2:name>\n"
        + "<m2:value>" + this.tdarNfflIndicator + "</m2:value>\n"
        + "</m2:nonProductCatalogData>\n"
        + "<m2:nonProductCatalogData>\n"
        + "<m2:name>dealerCode</m2:name>\n"
        + "<m2:value>12345</m2:value>\n"
        + "</m2:nonProductCatalogData>\n"
        + "</m2:nonProductCatalogDataList>\n";
    } else if (this.tdarNfflIndicator == "NA") {
      this.NFFLIndicator = "";
    }
  }

  //AddSrv , AddIns Components
  getAddSrvInsData() {
    if (this.tdarOrderActionType == "CH") {
      this.AddSrvComponent = "<m2:component>\n"
        + "<m2:assignedProductId>577399690</m2:assignedProductId>\n"
        + "<m2:serviceType>AddSrv</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.Action_AddSrv + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>577399690</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relationID</m2:name>\n"
        + "<m2:value>422150395</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relocateReceiverCount</m2:name>\n"
        + "<m2:value>" + this.relocateReceiverCount_Addsrv + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>nonDTVEquipment</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>WholeHomeDVR</m2:name>\n"
        + "<m2:value>" + this.WholeHomeDVR_Addsrv + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>DV</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relocateDishCount</m2:name>\n"
        + "<m2:value>" + this.relocateDishCount_Addsrv + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + "<m2:component>\n"
        + "<m2:assignedProductId>577399691</m2:assignedProductId>\n"
        + "<m2:serviceType>AddIns</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.Action_AddIns + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>577399691</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relationID</m2:name>\n"
        + "<m2:value>422150405</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>type</m2:name>\n"
        + "<m2:value>RCVR</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>DV</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n"
        + "</m2:componentList>\n"
        + "</m2:component>\n";
    } else if (this.tdarOrderActionType == "PR") {
      this.AddSrvComponent = "<m2:component>\n"
        + "<m2:assignedProductId>577399690</m2:assignedProductId>\n"
        + "<m2:serviceType>AddSrv</m2:serviceType>\n"
        + "<m2:actionIndicator>" + this.Action_AddSrv + "</m2:actionIndicator>\n"
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>577399690</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relationID</m2:name>\n"
        + "<m2:value>422150395</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>visuallyImpaired</m2:name>\n"
        + "<m2:value>" + this.addSrvVisuallyImpaired + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>nonDTVEquipment</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>WholeHomeDVR</m2:name>\n"
        + "<m2:value>" + this.WholeHomeDVR_Addsrv + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>DV</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n";
    } else {
      this.AddSrvComponent = "";
    }
  }

  //Supersede
  getSuperSede() {
    if (this.tdarSupersede == "2BAN") {
      this.supercedeStr = "<bbnmsOrder:attribute>\n"
        + "<bbnmsOrder:name>supersedeIndicator</bbnmsOrder:name>\n"
        + "<bbnmsOrder:value>2BAN</bbnmsOrder:value>\n"
        + "</bbnmsOrder:attribute>\n";
    } else {
      this.supercedeStr = "";
    }

    if (this.tdarSupersede == "2BAN") {
      this.currentcustIndTrue = "<m2:currentCustomerIndicator>true</m2:currentCustomerIndicator>\n"
    } else {
      this.currentcustIndTrue = "";
      this.currentcustIndTrue = "";
    }

    if (this.tdarSupersede == "2BAN") {
      this.currentcustIndFalse = "<m2:currentCustomerIndicator>false</m2:currentCustomerIndicator>\n"
    } else {
      this.currentcustIndFalse = "";
      this.currentcustIndFalse = "";
    }

  }

  callModalPopUp(xml, type, title, fileName) {
    let mainXml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\nxmlns:ws="http://ws.sender.bbnms.att.com/">\n`
      + `<soapenv:Header/>\n`
      + `<soapenv:Body>\n`
      + `<ws:sendMessageToQueue>\n`
      + `<MessageSenderRequest_V2>\n`
      + `<environment>${this.enviornmentVal}</environment>\n`
      + `<queue>OMS</queue>\n`
      + `<message>`
      + `<![CDATA[\n`
      // <Place request xml> 
      + xml
      + '\n]]></message>\n'
      + '</MessageSenderRequest_V2>\n'
      + '</ws:sendMessageToQueue>\n'
      + '</soapenv:Body>\n'
      + '</soapenv:Envelope>\n';

    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = title;
    modalRef.componentInstance.type = type;
    modalRef.componentInstance.content = mainXml;
    if (type == "template2") {
      modalRef.componentInstance.fileName = fileName;
    }
  }

  SetStackedOrderData_DTV() {

    this.relatedOrderInfo_DTV = "<bbnmsOrder:relatedOrderInfoList>\n"
      + "<bbnmsOrder:relatedOrderInfo>\n"
      + "<bbnmsOrder:orderNumber>123455</bbnmsOrder:orderNumber>\n"
      + "<bbnmsOrder:originalOrderActionId>3423232</bbnmsOrder:originalOrderActionId>\n"
      + "<bbnmsOrder:orderActionType>PR</bbnmsOrder:orderActionType>\n"
      + "<bbnmsOrder:orderActionSubType>NA</bbnmsOrder:orderActionSubType>\n"
      + "<bbnmsOrder:orderActionReferenceNumber>12345A</bbnmsOrder:orderActionReferenceNumber>\n"
      + "<bbnmsOrder:orderCreationDate>T01:01:01.0Z</bbnmsOrder:orderCreationDate>\n"
      + "<bbnmsOrder:orderActionReasonCode>aa</bbnmsOrder:orderActionReasonCode>\n"
      + "<bbnmsOrder:dueDate>T22:59:59.0Z</bbnmsOrder:dueDate>\n"
      + "<bbnmsOrder:orderRanking>1</bbnmsOrder:orderRanking>\n"
      + "</bbnmsOrder:relatedOrderInfo>\n"
      + "<bbnmsOrder:relatedOrderInfo>\n"
      + "<bbnmsOrder:orderNumber>1234552</bbnmsOrder:orderNumber>\n"
      + "<bbnmsOrder:originalOrderActionId>1234552</bbnmsOrder:originalOrderActionId>\n"
      + "<bbnmsOrder:orderActionType>PR</bbnmsOrder:orderActionType>\n"
      + "<bbnmsOrder:orderActionSubType>NA</bbnmsOrder:orderActionSubType>\n"
      + "<bbnmsOrder:orderActionReferenceNumber>1234552A</bbnmsOrder:orderActionReferenceNumber>\n"
      + "<bbnmsOrder:orderCreationDate>T02:02:02.0Z</bbnmsOrder:orderCreationDate>\n"
      + "<bbnmsOrder:orderActionReasonCode>aa</bbnmsOrder:orderActionReasonCode>\n"
      + "<bbnmsOrder:dueDate>T23:59:59.0Z</bbnmsOrder:dueDate>\n"
      + "<bbnmsOrder:orderRanking>2</bbnmsOrder:orderRanking>\n"
      + "</bbnmsOrder:relatedOrderInfo>\n"
      + "</bbnmsOrder:relatedOrderInfoList>";
  }

  DtGpComp(dtgpaction: String, dtgenrepkg: String, contractId: String, apid: String): String {
    let dtgpcomp: String;

    dtgpcomp = "<m2:component>\n"
      + "<m2:assignedProductId>123454328" + apid + "</m2:assignedProductId>\n"
      + "<m2:serviceType>DTGP</m2:serviceType>\n"
      + "<m2:actionIndicator>" + dtgpaction + "</m2:actionIndicator>\n"
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DTgenrePackage</m2:name>\n"
      + "<m2:value>" + dtgenrepkg + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>TECH</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>Child</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>DV</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>action_type</m2:name>\n"
      + "<m2:value>Acquisition</m2:value>\n"
      + "</m2:attribute>\n"
      + String(contractId)
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>Not Allowed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>AllinCapable</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";
    return dtgpcomp;
  }

  DtstbComp(stbaction: String, stbType: String, productLine: String, modelNumber: String, serviceType: String, contractId: String, purchaseterms: String, isActive: String, macAddress: String, receiverID: String, serialNumber: String, accessCardNumber: String, apid: String, sapOrderStatus: String): String {
    var macAddComp: String = "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>macAddress</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + macAddress + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n";

    var accessCardComp: String = "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>accessCardNumber</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + accessCardNumber + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n";

    if (macAddress == "") {
      macAddComp = "";
    }

    if (accessCardNumber == "") {
      accessCardComp = "";
    }

    this.stbcomp = "<m2:component>\n"
      + "<m2:assignedProductId>" + apid + "</m2:assignedProductId>\n"
      + "<m2:serviceType>" + serviceType + "</m2:serviceType>\n"
      + "<m2:actionIndicator>" + stbaction + "</m2:actionIndicator>\n"
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + apid + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>C1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isPartOfPackage</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ServiceDueDate</m2:name>\n"
      + "<m2:value>null</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>stbType</m2:name>\n"
      + "<m2:value>" + stbType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>productLine</m2:name>\n"
      + "<m2:value>" + productLine + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>modelNumber</m2:name>\n"
      + "<m2:value>" + modelNumber + "</m2:value>\n"
      + "</m2:attribute>\n"
      + String(contractId)
      + "<m2:attribute>\n"
      + "<m2:name>purchaseTerms</m2:name>\n"
      + "<m2:value>" + purchaseterms + "</m2:value>\n"
      + "</m2:attribute>\n"
      + String(isActive)
      + macAddComp
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>manufacturer</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>DIRECTV</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>availableForSelfInstall</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>NA</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>receiverID</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + receiverID + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>serialNumber</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + serialNumber + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + accessCardComp
      + "<bbnmsOrder:attribute>\n"
      + "<bbnmsOrder:name>sapOrderStatus</bbnmsOrder:name>\n"
      + "<bbnmsOrder:value>" + sapOrderStatus + "</bbnmsOrder:value>\n"
      + "</bbnmsOrder:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";
    return this.stbcomp;
  }
}
