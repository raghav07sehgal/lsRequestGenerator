import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StarTdarRoutingModule } from './star-tdar-routing.module';
import { StarTdarComponent } from './star-tdar.component';
import { SharedModule } from 'app/shared/shared.module';
import { StarTdarFntModule } from '../star-tdar-fnt/star-tdar-fnt.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    StarTdarComponent,

  ],
  imports: [
    CommonModule,
    StarTdarRoutingModule,
    SharedModule,
    NgbModule,
    FormsModule,
    StarTdarFntModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class StarTdarModule { }
