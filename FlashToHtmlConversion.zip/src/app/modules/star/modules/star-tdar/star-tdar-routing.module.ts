import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StarTdarComponent } from './star-tdar.component';

const routes: Routes = [
  { path: '', component: StarTdarComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StarTdarRoutingModule { }
