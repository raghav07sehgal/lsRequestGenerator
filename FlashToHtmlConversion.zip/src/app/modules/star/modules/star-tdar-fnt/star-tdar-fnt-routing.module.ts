import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StarTdarFntComponent } from './star-tdar-fnt.component';

const routes: Routes = [
  { path: '', component: StarTdarFntComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StarTdarFntRoutingModule { }