import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StarTdarFntRoutingModule } from './star-tdar-fnt-routing.module';
import { StarTdarFntComponent } from './star-tdar-fnt.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'app/shared/shared.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    StarTdarFntComponent,
  ],
  imports: [
    CommonModule,
    StarTdarFntRoutingModule,
    NgbModule,
    SharedModule,
    FormsModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class StarTdarFntModule { }
