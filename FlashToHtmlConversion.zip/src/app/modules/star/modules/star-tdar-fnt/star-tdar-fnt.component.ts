import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-star-tdar-fnt',
  templateUrl: './star-tdar-fnt.component.html',
  styleUrls: ['./star-tdar-fnt.component.css']
})
export class StarTdarFntComponent implements OnInit {
  starTdarFntUrl: string = "/star/tdarFnt";

  cusTabType: string = "starTdarFnt"
  tabType: string = "star"
  contClass1: string = "h5";
  scrollClass1: string = "h3";
  contClass2: string = "ht-240";
  title1: string = "Customer Info";
  tabClass1: string = "h7";

  cmTitle: string = "CM"
  pvTitle: string = "PV"
  constructor(private router: Router) { }

  ngOnInit(): void {
  }

}
