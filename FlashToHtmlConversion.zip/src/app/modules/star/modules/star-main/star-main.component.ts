import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { extLineItemDropdown, lineItemDropdown, modeDropdown } from 'app/constants/star.constant';
import { starMainTabs } from 'app/constants/tab.constant';
import { LineItemComponent } from 'app/shared/line-item/line-item.component';
import { ModelBoxComponent } from 'app/shared/model-box/model-box.component';
import { StarService } from '../../star.service';

@Component({
  selector: 'app-star-main',
  templateUrl: './star-main.component.html',
  styleUrls: ['./star-main.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class StarMainComponent implements OnInit {
  starMainTabs: any[] = starMainTabs;
  starMainUrl: string = "/star/main";

  textTitle1: string = "Activity Id";
  textTitle2: string = "";
  textTitle3: string = "dtv account id";
  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';

  dropdownTitle1: string = "Mode";
  dropdownTitle2: string = "LineItem";
  dropdownTitle3: string = "ExtenralLineItem";
  dropdownValues1: any[] = modeDropdown;
  dropdownValues2: any[] = lineItemDropdown;
  dropdownValues3: any[] = extLineItemDropdown;

  selectedMode: any = this.dropdownValues1[0].label;
  selectedLineItem: any = this.dropdownValues2[0].label;
  selectedExtLineItem: any = this.dropdownValues3[0].label;

  title: string = "starMain"
  banValue: any;

  lineItem1: String;
  lineItem2: String;
  lineItem3: String;
  lineItem4: String;
  lineItem5: String;
  lineItem6: String;
  lineItem7: String;
  lineItem8: String;
  extLineItem1: String;
  extLineItem2: String;
  swapDetail: String;

  accessCardId: string;
  orderLineItemActionId
  irdActionId: string;
  productLineId: string;
  productNameId: string;
  receiverId: string;
  macaddressId: string;
  dateId: string;
  lineItemId: string;
  category: string;
  accessCardStatus: string;
  lineItemStatus: string;
  equipOwnership: string;

  enviornmentVal: any;

  @ViewChild(LineItemComponent) lineItem: LineItemComponent;

  constructor(private router: Router, private store: Store<HeaderState>,
    private starService: StarService, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.router.navigate([this.starMainUrl]);
    this.store.select(state => state['header']).subscribe((data) => {
      let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
      if (storeObj['banValue']?.length) {
        this.banValue = storeObj['banValue'];
        this.textValue3 = storeObj['banValue'];
      }
      this.enviornmentVal = storeObj['enviornment'];
    })

    this.starService.getEventSubject().subscribe((value) => {
      if (value == "genIsaacReq") {
        this.getIsaacReq();
      } else if (value == "genIswoActResp") {
        this.genIswoActResp()
      } else if (value == "genSubSatResp") {
        this.genSubSatResp();
      } else if (value == "genIssodResp") {
        this.genIssodReq();
      } else if (value == "genInquireSatCspResp") {
        this.getLineItemData();
      } else if (value == "genInquireSatustProfResp") {
        this.GenInqSatCustProfResp();
      }
    });

    this.accessCardId = this.lineItem?.textValue4;
    this.orderLineItemActionId = this.lineItem?.SelectedOrderLineItemAction;
    this.irdActionId = this.lineItem?.SelectedIrdAction;
    this.productLineId = this.lineItem?.SelectedProductLine;
    this.productNameId = this.lineItem?.SelectedProductName;
    this.receiverId = this.lineItem?.textValue2;
    this.macaddressId = this.lineItem?.textValue5;
    this.dateId = this.lineItem?.myDate;
    this.lineItemId = this.lineItem?.textValue1;
    this.category = this.lineItem?.SelectedCategory;
    this.accessCardStatus = this.lineItem?.SelectedAccessCardStatus;
    this.lineItemStatus = this.lineItem?.SelectedLineItemStatus;
    this.equipOwnership = this.lineItem?.SelectedEquipmentOwnership;
  }

  dropDownChange(evt, title) {
    if (title == "Mode") {
      this.selectedMode = evt;
    } else if (title == "LineItem") {
      this.selectedLineItem = evt;
      this.starMainTabs.map(val => val.disabled = true)
      for (let i = 0; i < this.selectedLineItem; i++) {
        this.starMainTabs[i].disabled = false;
      }
    } else if (title == "ExtenralLineItem") {
      this.selectedExtLineItem = evt;
      let extlineItemTab = this.starMainTabs.filter(v => v.label.indexOf('extlineItem') != -1)
      console.log("extlineItemTab<<<<<<", extlineItemTab);
      // for (let i = 0; i < this.selectedExtLineItem.length; i++) {
      //   // if (this.starMainTabs[i].label.indexOf('extlineItem') != -1) {
      //   // if (extlineItemTab[i]?.label.indexOf(evt.slice(evt.length - 1)) != -1) {
      //   extlineItemTab[i].disabled = false;
      //   // }
      //   // }
      // }
      // console.log("extlineItemTab", extlineItemTab);

      // this.starMainTabs = this.starMainTabs.map(val => {
      //   if (val.label.indexOf('extlineItem') != -1) {
      //     if (val.label.lastIndexOf(this.selectedExtLineItem.slice(evt.length - 1)) != -1) {
      //       val.disabled = false;
      //     } else {
      //       val.disabled = true;
      //     }
      //   }
      //   return val;
      // });
    }
  }

  getReferenceId() {
    this.textValue2 = Math.floor(Math.random() * (999999 - 100000)) + 200000000000;
  }

  onlyNumberKey(event) {
    return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
  }

  // Generate Isaac Req star Function - getting details from main tab
  getIsaacReq() {
    // lineItem
    this.lineItem1 = this.OnCondLineExtType("lineItem1", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem2 = this.OnCondLineExtType("lineItem2", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem3 = this.OnCondLineExtType("lineItem3", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem4 = this.OnCondLineExtType("lineItem4", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem5 = this.OnCondLineExtType("lineItem5", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem6 = this.OnCondLineExtType("lineItem6", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem7 = this.OnCondLineExtType("lineItem7", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem8 = this.OnCondLineExtType("lineItem8", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.extLineItem1 = this.OnCondLineExtType("extlineItem1", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId);

    this.extLineItem2 = this.OnCondLineExtType("extlineItem2", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId);

    if (this.selectedMode == "Swap") {
      this.swapDetail = "<p:SwapDetails>\n"
        + "<p:swapAccessCardId>1250588634</p:swapAccessCardId>\n"
        + "<p:failureReason>failureReason24328</p:failureReason>\n"
        + "</p:SwapDetails>";
    } else if (this.selectedMode == "Initiate" || this.selectedMode == "Closeout") {
      this.lineItem1 = "";
      this.lineItem2 = "";
      this.lineItem3 = "";
      this.lineItem4 = "";
      this.lineItem5 = "";
      this.lineItem6 = "";
      this.lineItem7 = "";
      this.lineItem8 = "";
      this.extLineItem1 = "";
      this.extLineItem2 = "";
    } else {
      this.swapDetail = "";
    }

    var starMainXml: String = "<p:SubmitSatelliteCPERequest xmlns:p=\"http://bbnms.lightspeed.att.com/csibbnmssscpet/submitsatellitecperequest/schema\">\n"
      + "<p:uverseBAN>" + this.textValue3 + "</p:uverseBAN>\n"
      + "<p:dtvBAN>" + this.textValue3 + "</p:dtvBAN>\n"
      + "<p:referenceId>" + this.textValue2 + "</p:referenceId>\n"
      + "<p:orderNumber>" + this.textValue1 + "</p:orderNumber>\n"
      + "<p:orderActionMode>" + this.selectedMode + "</p:orderActionMode>\n"
      + "<p:activityId>" + this.textValue1 + "</p:activityId>\n"
      + "<p:propertyType>Own</p:propertyType>\n"
      + "<p:customerSelectedProtectionPlan>protectionplan</p:customerSelectedProtectionPlan>\n"
      + "<p:sourceSystemURL>http:</p:sourceSystemURL>\n"
      + this.lineItem1
      + this.lineItem2
      + this.lineItem3
      + this.lineItem4
      + this.lineItem5
      + this.lineItem6
      + this.lineItem7
      + this.lineItem8
      + this.extLineItem1
      + this.extLineItem2
      + this.swapDetail
      + "</p:SubmitSatelliteCPERequest>\n"

    this.callModalPopUp(starMainXml, "template1", "Complete XML Generation", "");
  }

  //Gen ISWO Act Resp Star Function - getting details from main tab
  genIswoActResp() {
    this.lineItem1 = this.OnCondLineExtType("lineItem1", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem2 = this.OnCondLineExtType("lineItem2", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem3 = this.OnCondLineExtType("lineItem3", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem4 = this.OnCondLineExtType("lineItem4", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem5 = this.OnCondLineExtType("lineItem5", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem6 = this.OnCondLineExtType("lineItem6", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem7 = this.OnCondLineExtType("lineItem7", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem8 = this.OnCondLineExtType("lineItem8", "genIswoActResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    var responseXml: String = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<SOAP-ENV:Header xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<MessageHeader xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\" xmlns:cng=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
      + "<TrackingMessageHeader>\n"
      + "<cng:version>v97</cng:version>\n"
      + "<cng:messageId>717350019-1-1431701110443+4300022935</cng:messageId>\n"
      + "<cng:originatorId>String</cng:originatorId>\n"
      + "<cng:responseTo>String</cng:responseTo>\n"
      + "<cng:returnURL>String</cng:returnURL>\n"
      + "<cng:timeToLive>0</cng:timeToLive>\n"
      + "<cng:conversationId>717350019-1-1431701110443</cng:conversationId>\n"
      + "<cng:dateTimeStamp>2015-05-15T14:45:10.443Z</cng:dateTimeStamp>\n"
      + "</TrackingMessageHeader>\n"
      + "<SecurityMessageHeader>\n"
      + "<cng:userName>test</cng:userName>\n"
      + "<cng:userPassword>test</cng:userPassword>\n"
      + "</SecurityMessageHeader>\n"
      + "<SequenceMessageHeader>\n"
      + "<cng:sequenceNumber>1</cng:sequenceNumber>\n"
      + "<cng:totalInSequence>1</cng:totalInSequence>\n"
      + "</SequenceMessageHeader>\n"
      + "</MessageHeader>\n"
      + "</SOAP-ENV:Header>\n"
      + "<SOAP-ENV:Body xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<InquireSatelliteWorkOrderActivityResponse xmlns=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSatelliteWorkOrderActivityResponse.xsd\" xmlns:cng=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">\n"
      + "<Message>\n"
      + "<cng:messageStatus/>\n"
      + "<cng:provider/>\n"
      + "<cng:messageCode/>\n"
      + "<cng:messageText/>\n"
      + "<cng:messageSeverity/>\n"
      + "<cng:messageCategory/>\n"
      + "<cng:additionalInformation/>\n"
      + "</Message>\n"
      + "<Activity>\n"
      + "<ActivityDetails>\n"
      + "<cng:number>" + this.textValue1 + "</cng:number>\n"
      + "<cng:serviceRequestId/>\n"
      + "<cng:protectionPlanIndicator/>\n"
      + "<cng:previousStatus/>\n"
      + "<cng:integrationStatus/>\n"
      + "<cng:approvedIndicator/>\n"
      + "<cng:type/>\n"
      + "</ActivityDetails>\n"
      + "<ActivityAttributes>\n"
      + "<cng:techTeam/>\n"
      + "<cng:workOrderSignatureIndicator/>\n"
      + "<cng:priorityLevel/>\n"
      + "<cng:tenure/>\n"
      + "<cng:status/>\n"
      + "<cng:serviceWithinSevenIndicator/>\n"
      + "<cng:repeatServiceIndicator/>\n"
      + "<cng:priorityName/>\n"
      + "<cng:primaryOwnerId/>\n"
      + "<cng:primaryOwner/>\n"
      + "<cng:plannedDurationMinutes/>\n"
      + "<cng:plannedStartDateTime/>\n"
      + "<cng:plannedEndDateTime/>\n"
      + "<cng:partnerName/>\n"
      + "<cng:signatureIndicator/>\n"
      + "<cng:previousActivityEndDateTime/>\n"
      + "<cng:orderSubType/>\n"
      + "<cng:singleWireMultiSwitchIndicator/>\n"
      + "<cng:orderNumber/>\n"
      + "<cng:orderClass/>\n"
      + "<cng:omsOrderId/>\n"
      + "<cng:earlyStartDateTime/>\n"
      + "<cng:mode/>\n"
      + "<cng:massProgrammingIndicator/>\n"
      + "<cng:leaseAddendumSignatureIndicator/>\n"
      + "<cng:landlordSignatureIndicator/>\n"
      + "<cng:installationVerificationRetestEnforcedIndicator/>\n"
      + "<cng:installationVerificationEnforcedIndicator/>\n"
      + "<cng:upgradeEligibilityDateTime/>\n"
      + "<cng:fortyFootLadderIndicator/>\n"
      + "<cng:drivingDirections/>\n"
      + "<cng:noteToTech/>\n"
      + "<cng:propertyStatus/>\n"
      + "<cng:fieldServiceRequestSubArea/>\n"
      + "<cng:jeopardyReason/>\n"
      + "<cng:jeopardyIndicator/>\n"
      + "<cng:caseIndicator/>\n"
      + "<cng:travelTimeMinutes/>\n"
      + "<cng:estimatedTimeOfCompletionIndicator/>\n"
      + "<cng:enhancedProtectionPlanEligibleIndicator/>\n"
      + "<cng:dwellingType/>\n"
      + "<cng:totalDurationMinutes/>\n"
      + "<cng:durationMinutes/>\n"
      + "<cng:propertyType/>\n"
      + "<cng:dueDateTime/>\n"
      + "<cng:daysPastOpenCalculationIndicator/>\n"
      + "<cng:additionalInformation/>\n"
      + "<cng:dtvProtectionPlanSignatureIndicator/>\n"
      + "<cng:customerSelectedProtectionPlan/>\n"
      + "<cng:accountProtectionPlan/>\n"
      + "<cng:currentProtectionPlan>none</cng:currentProtectionPlan>\n"
      + "<cng:compatibility/>\n"
      + "<cng:billableLineItemIndicator/>\n"
      + "<cng:alert/>\n"
      + "<cng:agentFirstName/>\n"
      + "<cng:accountId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:genericId/>\n"
      + "<cng:accidentalDamageHandlingSignatureIndicator/>\n"
      + "<cng:lastUpdateDateTime/>\n"
      + "<cng:Address>\n"
      + "<cng:addressType/>\n"
      + "<cng:fieldIndicator/>\n"
      + "<cng:incorporatedIndicator/>\n"
      + "<cng:Attention/>\n"
      + "<cng:AddressLine1/>\n"
      + "<cng:AddressLine2/>\n"
      + "<cng:Street>\n"
      + "<cng:streetNumber/>\n"
      + "<cng:streetDirection/>\n"
      + "<cng:streetName/>\n"
      + "<cng:streetType/>\n"
      + "<cng:streetTrailingDirection/>\n"
      + "</cng:Street>\n"
      + "<cng:Unit>\n"
      + "<cng:unitNumber/>\n"
      + "<cng:unitDesignator/>\n"
      + "</cng:Unit>\n"
      + "<cng:PostOfficeBox/>\n"
      + "<cng:RuralRoute>\n"
      + "<cng:ruralRouteCenterNumber/>\n"
      + "<cng:ruralRouteBoxNumber/>\n"
      + "</cng:RuralRoute>\n"
      + "<cng:City/>\n"
      + "<cng:County>\n"
      + "<cng:countyName/>\n"
      + "<cng:countyType/>\n"
      + "</cng:County>\n"
      + "<cng:State/>\n"
      + "<cng:Zip>\n"
      + "<cng:zipCode/>\n"
      + "<cng:zipCodeExtension/>\n"
      + "<cng:zipGeoCode/>\n"
      + "</cng:Zip>\n"
      + "<cng:Country/>\n"
      + "<cng:UrbanizationCode/>\n"
      + "<cng:lastUpdate/>\n"
      + "<cng:addressSubType/>\n"
      + "<cng:ruralAddressAttention/>\n"
      + "<cng:internationalAddressLine/>\n"
      + "<cng:internationalZip/>\n"
      + "</cng:Address>\n"
      + "<cng:subarea/>\n"
      + "<cng:serviceRegion/>\n"
      + "<cng:fullAddress/>\n"
      + "<cng:firstName/>\n"
      + "<cng:lastName/>\n"
      + "<cng:CombinedName/>\n"
      + "<cng:Phone>\n"
      + "<cng:telephoneNumber/>\n"
      + "<cng:extension/>\n"
      + "</cng:Phone>\n"
      + "<cng:alternatePhoneNumber>\n"
      + "<cng:telephoneNumber/>\n"
      + "<cng:extension/>\n"
      + "</cng:alternatePhoneNumber>\n"
      + "<cng:rowId/>\n"
      + "<cng:estimatedTimeCompletionThreshold/>\n"
      + "<cng:multiTechnicianActivityType/>\n"
      + "</ActivityAttributes>\n"
      + "<OrderItems>\n"
      + "<cng:workOrderStatus/>\n"
      + "<cng:status/>\n"
      + "<cng:omsOrderNumber/>\n"
      + "<cng:rowId/>\n"
      + "<cng:organization/>\n"
      + "<cng:activityId>" + this.textValue1 + "</cng:activityId>\n"
      + "<cng:protectionPlanStatus/>\n"
      + "<cng:type/>\n"
      + "<cng:subtype/>\n"
      + "<cng:number/>\n"
      + "<cng:landlordStatus/>\n"
      + "<cng:leaseAgreementStatus/>\n"
      + "<cng:emailAddress/>\n"
      + "<cng:currency/>\n"
      + "<cng:communicationEventId/>\n"
      + "<cng:Signatures>\n"
      + "<cng:workOrderId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:signatureStatus/>\n"
      + "<cng:signatureMode/>\n"
      + "<cng:signatureDateTime/>\n"
      + "<cng:signature/>\n"
      + "<cng:signatureCapturedByTechnician/>\n"
      + "<cng:sequenceNumber/>\n"
      + "<cng:documentType/>\n"
      + "<cng:documentId/>\n"
      + "<cng:cancelReasonCode/>\n"
      + "</cng:Signatures>\n"
      + "<cng:LineItemAttribute>\n"
      + "<cng:rowId/>\n"
      + "<cng:name/>\n"
      + "<cng:value/>\n"
      + "<cng:fullValue/>\n"
      + "<cng:lineItemId/>\n"
      + "<cng:orderLineItemId/>\n"
      + "</cng:LineItemAttribute>\n"
      + "</OrderItems>\n"
      + this.lineItem1
      + this.lineItem2
      + this.lineItem3
      + this.lineItem4
      + this.lineItem5
      + this.lineItem6
      + this.lineItem7
      + this.lineItem8
      + "<Resolution>\n"
      + "<cng:Resolution>\n"
      + "<cng:rowId/>\n"
      + "<cng:type/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:lastUpdateDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:proirResolutioncode/>\n"
      + "<cng:resolution/>\n"
      + "<cng:action/>\n"
      + "</cng:Resolution>\n"
      + "<cng:PriorResolution>\n"
      + "<cng:rowId/>\n"
      + "<cng:type/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:lastUpdateDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:proirResolutioncode/>\n"
      + "<cng:resolution/>\n"
      + "<cng:action/>\n"
      + "</cng:PriorResolution>\n"
      + "</Resolution>\n"
      + "<Estimate>\n"
      + "<cng:TechnicianEstimatedTimeOfArrival>\n"
      + "<cng:rowId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:lastUpdateDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:estimatedTimeOfArrivalDuration/>\n"
      + "<cng:estimatedTimeOfCompletionDuration/>\n"
      + "<cng:estimateTimeOfCompletionCode/>\n"
      + "<cng:resolution/>\n"
      + "</cng:TechnicianEstimatedTimeOfArrival>\n"
      + "<cng:TechnicianEstimatedTimeOfCompletion>\n"
      + "<cng:rowId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:lastUpdateDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:estimatedTimeOfArrivalDuration/>\n"
      + "<cng:estimatedTimeOfCompletionDuration/>\n"
      + "<cng:estimateTimeOfCompletionCode/>\n"
      + "<cng:resolution/>\n"
      + "</cng:TechnicianEstimatedTimeOfCompletion>\n"
      + "</Estimate>\n"
      + "<Comment>\n"
      + "<cng:Activity>\n"
      + "<cng:rowId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:upateDateTime/>\n"
      + "<cng:openDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:serivceRequestId/>\n"
      + "<cng:noteToTech/>\n"
      + "<cng:noteType/>\n"
      + "<cng:commentText/>\n"
      + "<cng:description/>\n"
      + "</cng:Activity>\n"
      + "<cng:Dispatch>\n"
      + "<cng:rowId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:upateDateTime/>\n"
      + "<cng:openDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:serivceRequestId/>\n"
      + "<cng:noteToTech/>\n"
      + "<cng:noteType/>\n"
      + "<cng:commentText/>\n"
      + "<cng:description/>\n"
      + "</cng:Dispatch>\n"
      + "<cng:Technician>\n"
      + "<cng:rowId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:upateDateTime/>\n"
      + "<cng:openDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:serivceRequestId/>\n"
      + "<cng:noteToTech/>\n"
      + "<cng:noteType/>\n"
      + "<cng:commentText/>\n"
      + "<cng:description/>\n"
      + "</cng:Technician>\n"
      + "<cng:CallCenter>\n"
      + "<cng:rowId/>\n"
      + "<cng:createDateTime/>\n"
      + "<cng:upateDateTime/>\n"
      + "<cng:openDateTime/>\n"
      + "<cng:externalId/>\n"
      + "<cng:serivceRequestId/>\n"
      + "<cng:noteToTech/>\n"
      + "<cng:noteType/>\n"
      + "<cng:commentText/>\n"
      + "<cng:description/>\n"
      + "</cng:CallCenter>\n"
      + "</Comment>\n"
      + "<LineItemAttribute>\n"
      + "<cng:rowId/>\n"
      + "<cng:name/>\n"
      + "<cng:value/>\n"
      + "<cng:fullValue/>\n"
      + "<cng:lineItemId/>\n"
      + "<cng:orderLineItemId/>\n"
      + "</LineItemAttribute>\n"
      + "</Activity>\n"
      + "<noJobIndicator/>\n"
      + "<positionType/>\n"
      + "<LunchDetails>\n"
      + "<startDateTime/>\n"
      + "<endDateTime/>\n"
      + "</LunchDetails>\n"
      + "<Response>\n"
      + "<cng:code/>\n"
      + "<cng:description/>\n"
      + "</Response>\n"
      + "</InquireSatelliteWorkOrderActivityResponse>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>";

    this.callModalPopUp(responseXml, "template2", "Complete XML Generation", "");
  }

  // Gen Sub Sat Resp Star Function - getting details from main tab
  genSubSatResp() {
    this.lineItem1 = this.OnCondLineExtType("lineItem1", "genSubSatResp", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem2 = this.OnCondLineExtType("lineItem2", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem3 = this.OnCondLineExtType("lineItem3", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem4 = this.OnCondLineExtType("lineItem4", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem5 = this.OnCondLineExtType("lineItem5", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem6 = this.OnCondLineExtType("lineItem6", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem7 = this.OnCondLineExtType("lineItem7", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.lineItem8 = this.OnCondLineExtType("lineItem8", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId)

    this.extLineItem1 = this.OnCondLineExtType("extlineItem1", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId);

    this.extLineItem2 = this.OnCondLineExtType("extlineItem2", "getIsaacReq", this.accessCardId,
      this.orderLineItemActionId, this.irdActionId, this.productNameId, this.productLineId,
      this.receiverId, this.macaddressId, this.dateId, this.lineItemId);

    var responseXml: String = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<SOAP-ENV:Header>\n"
      + "<ns2:MessageHeader xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\" xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">\n"
      + "<ns2:TrackingMessageHeader>\n"
      + "<version>v97</version>\n"
      + "<messageId>361754365</messageId>\n"
      + "<timeToLive>180000</timeToLive>\n"
      + "<dateTimeStamp>2015-05-20T03:29:04Z</dateTimeStamp>\n"
      + "<uniqueTransactionId/>\n"
      + "</ns2:TrackingMessageHeader>\n"
      + "<ns2:SecurityMessageHeader>\n"
      + "<userName>cingularcom</userName>\n"
      + "<userPassword>cingularcom100</userPassword>\n"
      + "</ns2:SecurityMessageHeader>\n"
      + "<ns2:SequenceMessageHeader>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<totalInSequence>1</totalInSequence>\n"
      + "</ns2:SequenceMessageHeader>\n"
      + "</ns2:MessageHeader>\n"
      + "</SOAP-ENV:Header>\n"
      + "<SOAP-ENV:Body>\n"
      + "<SubmitSatelliteWorkOrderResponse xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/SubmitSatelliteWorkOrderResponse.xsd\">\n"
      + "<duration>348</duration>\n"
      + "<mode>programming</mode>\n"
      + "<currentProtectionPlan>None</currentProtectionPlan>\n"
      + "<integrationStatus>Done</integrationStatus>\n"
      + "<activityId>" + this.textValue1 + "</activityId>\n"
      + "<technicianId>SKAK003009</technicianId>\n"
      + this.lineItem1
      + this.lineItem2
      + this.lineItem3
      + this.lineItem4
      + this.lineItem5
      + this.lineItem6
      + this.lineItem7
      + this.lineItem8
      + this.extLineItem1
      + this.extLineItem2
      + "<OrderAttribute>\n"
      + "<value>no</value>\n"
      + "<name>InternetConnectivity</name>\n"
      + "</OrderAttribute>\n"
      + "<OrderAttribute>\n"
      + "<value>true</value>\n"
      + "<name>MPEG-4</name>\n"
      + "</OrderAttribute>\n"
      + "<OrderAttribute>\n"
      + "<value>programming</value>\n"
      + "<name>MRV</name>\n"
      + "</OrderAttribute>\n"
      + "<OrderAttribute>\n"
      + "<value>true</value>\n"
      + "<name>SWiM</name>\n"
      + "</OrderAttribute>\n"
      + "<Response>\n"
      + "<ns2:code>0</ns2:code>\n"
      + "<ns2:description>Success</ns2:description>\n"
      + "</Response>\n"
      + "</SubmitSatelliteWorkOrderResponse>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>";

    this.callModalPopUp(responseXml, "template2", "Complete XML Generation", "");
  }

  //generate issod req function
  genIssodReq() {
    var responseXML: String = "<SOAP-ENV:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<SOAP-ENV:Header>\n"
      + "<ns2:MessageHeader xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\">\n"
      + "<ns2:TrackingMessageHeader>\n"
      + "<version>v97</version>\n"
      + "<messageId>14255061597</messageId>\n"
      + "<responseTo>BBNMS</responseTo>\n"
      + "<timeToLive>70000</timeToLive>\n"
      + "<conversationId>bbnmspse~CNG-CSI~79e3423f-e1d4-493a-98d2-ffa2d7c507b6</conversationId>\n"
      + "<dateTimeStamp>2015-08-28T14:16:25.707Z</dateTimeStamp>\n"
      + "<uniqueTransactionId>ServiceGateway814322@q100csg58c1_c60108f9-0966-4386-8c36-22b6acc747f4</uniqueTransactionId>\n"
      + "</ns2:TrackingMessageHeader>\n"
      + "<ns2:SecurityMessageHeader>\n"
      + "<userName>bbnmspse</userName>\n"
      + "<userPassword>bbnmspse813</userPassword>\n"
      + "</ns2:SecurityMessageHeader>\n"
      + "<ns2:SequenceMessageHeader>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<totalInSequence>1</totalInSequence>\n"
      + "</ns2:SequenceMessageHeader>\n"
      + "</ns2:MessageHeader>\n"
      + "</SOAP-ENV:Header>\n"
      + "<SOAP-ENV:Body>\n"
      + "<ns2:InquireSatelliteServiceOrderDetailsResponse xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSatelliteServiceOrderDetailsResponse.xsd\">\n"
      + "<ns2:Order>\n"
      + "<ns2:ServiceOrder>\n"
      + "<orderType>newOrder</orderType>\n"
      + "<OrderIdentifier>\n"
      + "<orderId>101185808</orderId>\n"
      + "<customerId>101025100</customerId>\n"
      + "<attCustomerId>9794695634</attCustomerId>\n"
      + "<attOrderId>se~CNG-CSI~726a6c3a-8186-4fd8-8eeb-c2c75d4a44fa</attOrderId>\n"
      + "<productConfigurationId>100368235</productConfigurationId>\n"
      + "<originatorSystem>ATT</originatorSystem>\n"
      + "</OrderIdentifier>\n"
      + "<treatmentCodeValue>A001</treatmentCodeValue>\n"
      + "<offerLanguage>English-International</offerLanguage>\n"
      + "<AccountAssociation>\n"
      + "<attAccountNumber>182600896</attAccountNumber>\n"
      + "<attAnchorAccountType>X</attAnchorAccountType>\n"
      + "<AccountBillingIndicator>\n"
      + "<combinedBillIndicator>true</combinedBillIndicator>\n"
      + "</AccountBillingIndicator>\n"
      + "</AccountAssociation>\n"
      + "<salesChannelIndicator>1O</salesChannelIndicator>\n"
      + "<salesDealerCode>A0000</salesDealerCode>\n"
      + "<alternateSalesDealerCode>A0000</alternateSalesDealerCode>\n"
      + "<salesAgentUID>dg649q</salesAgentUID>\n"
      + "<orderCreationDate>2015-08-28</orderCreationDate>\n"
      + "<marketingSourceCode>7111</marketingSourceCode>\n"
      + "<dealerId>1778902</dealerId>\n"
      + "<CustomerProfile>\n"
      + "<accountId>71823243</accountId>\n"
      + "<ServiceAddress>\n"
      + "<Name>\n"
      + "<firstName>JOANNA</firstName>\n"
      + "<middleName>P</middleName>\n"
      + "<lastName>CURRAN</lastName>\n"
      + "</Name>\n"
      + "<Address>\n"
      + "<addressLine1>133 ENCHANTED WAY</addressLine1>\n"
      + "<city>SAN RAMON</city>\n"
      + "<state>CA</state>\n"
      + "<Zip>\n"
      + "<zipCode>94583</zipCode>\n"
      + "</Zip>\n"
      + "<county>CONTRA COSTA</county>\n"
      + "<countyCode>013</countyCode>\n"
      + "</Address>\n"
      + "<phone>9794695634</phone>\n"
      + "</ServiceAddress>\n"
      + "<BillingAddress>\n"
      + "<Name>\n"
      + "<firstName>JOANNA</firstName>\n"
      + "<middleName>P</middleName>\n"
      + "<lastName>CURRAN</lastName>\n"
      + "</Name>\n"
      + "<Address>\n"
      + "<addressLine1>133 ENCHANTED WAY</addressLine1>\n"
      + "<city>SAN RAMON</city>\n"
      + "<state>CA</state>\n"
      + "<Zip>\n"
      + "<zipCode>94583</zipCode>\n"
      + "</Zip>\n"
      + "<county>CONTRA COSTA</county>\n"
      + "<countyCode>013</countyCode>\n"
      + "</Address>\n"
      + "<phone>9794695634</phone>\n"
      + "</BillingAddress>\n"
      + "<ShippingAddress>\n"
      + "<Name>\n"
      + "<firstName>JOANNA</firstName>\n"
      + "<middleName>P</middleName>\n"
      + "<lastName>CURRAN</lastName>\n"
      + "</Name>\n"
      + "<Address>\n"
      + "<addressLine1>133 ENCHANTED WAY</addressLine1>\n"
      + "<city>SAN RAMON</city>\n"
      + "<state>CA</state>\n"
      + "<Zip>\n"
      + "<zipCode>94583</zipCode>\n"
      + "</Zip>\n"
      + "<county>CONTRA COSTA</county>\n"
      + "<countyCode>013</countyCode>\n"
      + "</Address>\n"
      + "<phone>9794695634</phone>\n"
      + "</ShippingAddress>\n"
      + "<customerType>new</customerType>\n"
      + "<accountType>PTR</accountType>\n"
      + "<emailAddress>dg649q@att.com</emailAddress>\n"
      + "<creditScoreRequestId>0</creditScoreRequestId>\n"
      + "<authorizedCreditScore>false</authorizedCreditScore>\n"
      + "<EquipmentOwnership>\n"
      + "<equipmentSecurityFeeIndicator>n</equipmentSecurityFeeIndicator>\n"
      + "</EquipmentOwnership>\n"
      + "<AutoPayAndCreditCard>\n"
      + "<autoPayEnrollment>false</autoPayEnrollment>\n"
      + "</AutoPayAndCreditCard>\n"
      + "<creditBand>12</creditBand>\n"
      + "<WelcomeLetter>\n"
      + "<code>SDATTREG</code>\n"
      + "</WelcomeLetter>\n"
      + "</CustomerProfile>\n"
      + "<OrderPrice>\n"
      + "<totalAmount>21.65</totalAmount>\n"
      + "<nonRecurringCharges>19.95</nonRecurringCharges>\n"
      + "<tax>1.7</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "</OrderPrice>\n"
      + "<OrderPaymentDetails>\n"
      + "<PaymentMethod>\n"
      + "<CreditCard>\n"
      + "<CreditCardDetails>\n"
      + "<creditCardType>MC</creditCardType>\n"
      + "<CreditCard>\n"
      + "<lastFourCreditCardNumber>1100</lastFourCreditCardNumber>\n"
      + "</CreditCard>\n"
      + "<creditCardExpirationDate>201512</creditCardExpirationDate>\n"
      + "</CreditCardDetails>\n"
      + "<CreditCardBillingAddress>\n"
      + "<Name>\n"
      + "<firstName>JOANNA</firstName>\n"
      + "<middleName>P</middleName>\n"
      + "<lastName>CURRAN</lastName>\n"
      + "</Name>\n"
      + "<Address>\n"
      + "<addressLine1>133 ENCHANTED WAY</addressLine1>\n"
      + "<city>SAN RAMON</city>\n"
      + "<state>CA</state>\n"
      + "<Zip>\n"
      + "<zipCode>94583</zipCode>\n"
      + "</Zip>\n"
      + "<county>CONTRA COSTA</county>\n"
      + "</Address>\n"
      + "</CreditCardBillingAddress>\n"
      + "</CreditCard>\n"
      + "</PaymentMethod>\n"
      + "<billingEventDateTime>2015-08-28T15:10:00</billingEventDateTime>\n"
      + "</OrderPaymentDetails>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>true</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>virtual</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608923</lineItemId>\n"
      + "<productId>2317</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>VFirstHWRebate</productCode>\n"
      + "<productName>First Instant Rebate</productName>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608924</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>215.92</totalAmount>\n"
      + "<nonRecurringCharges>199.0</nonRecurringCharges>\n"
      + "<tax>-16.92</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>true</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>virtual</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608912</lineItemId>\n"
      + "<productId>1013</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>H00000001013</productCode>\n"
      + "<productName>Delivery and Handling Fee</productName>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608913</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>21.65</totalAmount>\n"
      + "<nonRecurringCharges>19.95</nonRecurringCharges>\n"
      + "<tax>1.7</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>false</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>virtual</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608910</lineItemId>\n"
      + "<productId>682</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>H00000000682</productCode>\n"
      + "<productName>MRV Install</productName>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608911</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>0.0</totalAmount>\n"
      + "<nonRecurringCharges>0.0</nonRecurringCharges>\n"
      + "<tax>0.0</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>true</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>virtual</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608908</lineItemId>\n"
      + "<productId>22419</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>VConditionEarlyCancellationFee</productCode>\n"
      + "<productName>Early Cancellation Fee Condition</productName>\n"
      + "<productDescription>24 month programming agreement required for receiver(s)early cancellation may result in a fee of up to $480.</productDescription>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608909</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>0.0</totalAmount>\n"
      + "<nonRecurringCharges>0.0</nonRecurringCharges>\n"
      + "<tax>0.0</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>true</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>optIn</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>virtual</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608906</lineItemId>\n"
      + "<productId>22419</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>VCONATT10DollarMonBundleDiscount</productCode>\n"
      + "<productName>Combined Bill Discount $10</productName>\n"
      + "<productDescription>You are opting your ATT and DIRECTV services into an integrated bill. In addition to your qualifying ATT services, your $10 ATT DIRECTV Combined Bill Discount requires that you maintain a DIRECTV programming package.</productDescription>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608907</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>0.0</totalAmount>\n"
      + "<nonRecurringCharges>0.0</nonRecurringCharges>\n"
      + "<tax>0.0</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>false</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>programming</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608920</lineItemId>\n"
      + "<productId>45921</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>P6376</productCode>\n"
      + "<productName>HD Access</productName>\n"
      + "<productDescription>Access DIRECTV's superior HD technology, enabling customers to see a wide range of HD programming. Customers will be able to watch all available HD channels associated with their base package.</productDescription>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608921</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>0.0</totalAmount>\n"
      + "<nonRecurringCharges>0.0</nonRecurringCharges>\n"
      + "<tax>0.0</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "<RecurringCharge>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<price>0.0</price>\n"
      + "<numberOfInstallments>0</numberOfInstallments>\n"
      + "<frequency>monthly</frequency>\n"
      + "</RecurringCharge>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "<LineItemDetails>\n"
      + "<Programming>\n"
      + "<productType>P</productType>\n"
      + "<productCode>6376</productCode>\n"
      + "<priceCode>200</priceCode>\n"
      + "<productSourceCode>auth</productSourceCode>\n"
      + "</Programming>\n"
      + "</LineItemDetails>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>true</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>programming</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608918</lineItemId>\n"
      + "<productId>10001101</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>VR103209-035</productCode>\n"
      + "<productName>NFL SUNDAY TICKET? MAX included for the 2015 Season</productName>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608922</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>0.0</totalAmount>\n"
      + "<nonRecurringCharges>0.0</nonRecurringCharges>\n"
      + "<tax>0.0</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "<RecurringCharge>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<price>0.0</price>\n"
      + "<numberOfInstallments>1</numberOfInstallments>\n"
      + "<frequency>monthly</frequency>\n"
      + "</RecurringCharge>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "<LineItemDetails>\n"
      + "<Programming>\n"
      + "<productType>R</productType>\n"
      + "<productCode>103209</productCode>\n"
      + "<priceCode>35</priceCode>\n"
      + "<productSourceCode>auth</productSourceCode>\n"
      + "</Programming>\n"
      + "</LineItemDetails>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>false</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>programming</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608897</lineItemId>\n"
      + "<productId>10002302</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>B101201</productCode>\n"
      + "<productName>BasPkgSav</productName>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>offerDetail</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608926</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>0.0</totalAmount>\n"
      + "<nonRecurringCharges>0.0</nonRecurringCharges>\n"
      + "<tax>0.0</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "<RecurringCharge>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<price>0.0</price>\n"
      + "<numberOfInstallments>1</numberOfInstallments>\n"
      + "<frequency>annually</frequency>\n"
      + "</RecurringCharge>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "<LineItemDetails>\n"
      + "<Programming>\n"
      + "<productType>B</productType>\n"
      + "<productCode>101201</productCode>\n"
      + "<priceCode>123</priceCode>\n"
      + "<productSourceCode>auth</productSourceCode>\n"
      + "</Programming>\n"
      + "</LineItemDetails>\n"
      + "</LineItem>\n"
      + "<LineItem>\n"
      + "<LineItemHeader>\n"
      + "<visibleToCustomerFlag>false</visibleToCustomerFlag>\n"
      + "<provisionableLineItemFlag>true</provisionableLineItemFlag>\n"
      + "<lineItemAddedByRuleFlag>true</lineItemAddedByRuleFlag>\n"
      + "<lineItemOrderType>new</lineItemOrderType>\n"
      + "<action>add</action>\n"
      + "<type>programming</type>\n"
      + "<LineItemAttributes>\n"
      + "<lineItemId>5024608895</lineItemId>\n"
      + "<productId>10002303</productId>\n"
      + "<originatingLineItemId>0</originatingLineItemId>\n"
      + "<productCode>B102964</productCode>\n"
      + "<productName>Advanced Receiver</productName>\n"
      + "</LineItemAttributes>\n"
      + "<RelatedLineItems>\n"
      + "<relationshipDependencyType>activationDependency</relationshipDependencyType>\n"
      + "<relatedLineItemId>5024608904</relatedLineItemId>\n"
      + "</RelatedLineItems>\n"
      + "<Price>\n"
      + "<totalAmount>0.0</totalAmount>\n"
      + "<nonRecurringCharges>0.0</nonRecurringCharges>\n"
      + "<tax>0.0</tax>\n"
      + "<shippingCharges>0.0</shippingCharges>\n"
      + "<RecurringCharge>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<price>0.0</price>\n"
      + "<numberOfInstallments>0</numberOfInstallments>\n"
      + "<frequency>monthly</frequency>\n"
      + "</RecurringCharge>\n"
      + "</Price>\n"
      + "<shippingMethod>installerDelivered</shippingMethod>\n"
      + "</LineItemHeader>\n"
      + "<LineItemDetails>\n"
      + "<Programming>\n"
      + "<productType>B</productType>\n"
      + "<productCode>102964</productCode>\n"
      + "<priceCode>200</priceCode>\n"
      + "<productSourceCode>auth</productSourceCode>\n"
      + "</Programming>\n"
      + "</LineItemDetails>\n"
      + "</LineItem>\n"
      + "</ns2:ServiceOrder>\n"
      + "<ns2:orderReadyForProvisioningFlag>true</ns2:orderReadyForProvisioningFlag>\n"
      + "<ns2:Status>\n"
      + "<orderStatus>PENDING</orderStatus>\n"
      + "<shippingStatus>NOTSHIPPED</shippingStatus>\n"
      + "</ns2:Status>\n"
      + "<ns2:activityId>" + this.textValue1 + "</ns2:activityId>\n"
      + "</ns2:Order>\n"
      + "<ns2:Response>\n"
      + "<code>0</code>\n"
      + "<description>Success</description>\n"
      + "</ns2:Response>\n"
      + "</ns2:InquireSatelliteServiceOrderDetailsResponse>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>";

    this.callModalPopUp(responseXML, "template2", "Complete XML Generation", "");
  }

  //generate Inquire Sat CSP Resp Function
  genInquireSatCpeResp(lineItemId: String, accessCard: String) {
    var responseXml: String = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://schemas.xmlsoap.org/so ap/envelope/\">\n"
      + "<SOAP-ENV:Header xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<MessageHeader xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\" xmlns:cng=\"http://csi.cingular.com/CSI/Names paces/Types/Public/CingularDataModel.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://schemas.xmlsoap.org/so ap/envelope/\">\n"
      + "<TrackingMessageHeader>\n"
      + "<cng:version>v97</cng:version>\n"
      + "<cng:messageId>362375623</cng:messageId>\n"
      + "<cng:originatorId>String</cng:originatorId>\n"
      + "<cng:responseTo>String</cng:responseTo>\n"
      + "<cng:returnURL>String</cng:returnURL>\n"
      + "<cng:timeToLive>0</cng:timeToLive>\n"
      + "<cng:conversationId>717350019-1-1431701110443</cng:conversationId>\n"
      + "<cng:dateTimeStamp>2015-05-15T14:45:10.443Z</cng:dateTimeStamp>\n"
      + "</TrackingMessageHeader>\n"
      + "<SecurityMessageHeader>\n"
      + "<cng:userName>test</cng:userName>\n"
      + "<cng:userPassword>test</cng:userPassword>\n"
      + "</SecurityMessageHeader>\n"
      + "<SequenceMessageHeader>\n"
      + "<cng:sequenceNumber>1</cng:sequenceNumber>\n"
      + "<cng:totalInSequence>1</cng:totalInSequence>\n"
      + "</SequenceMessageHeader>\n"
      + "</MessageHeader>\n"
      + "</SOAP-ENV:Header>\n"
      + "<SOAP-ENV:Body xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<InquireSatelliteCPEDetailsResponse xmlns=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSatelliteCPEDetailsResponse.xsd\" xmlns:cng=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
      + "<accessCardId>" + accessCard + "</accessCardId>\n"
      + "<manufacturer>aaaaaaaaaaaa</manufacturer>\n"
      + "<model>DIRECTV</model>\n"
      + "<serialNumber>11:" + lineItemId + "</serialNumber>\n"
      + "<receiverId/>\n"
      + "<macAddress>11:" + lineItemId + "</macAddress>\n"
      + "<alreadyInstalledFlagIndicator>true</alreadyInstalledFlagIndicator>\n"
      + "<productName>DIRECTV HD-DVR Receiver</productName>\n"
      + "<Message>\n"
      + "<cng:messageStatus>success</cng:messageStatus>\n"
      + "<cng:provider>vxomTA02_MS02-server</cng:provider>\n"
      + "</Message>\n"
      + "<Message>\n"
      + "<cng:messageCode>Second Instant Rebate:400012-%HWRec</cng:messageCode>\n"
      + "<cng:messageText>The $99 instant rebate for a 2nd, 3rd and 4th HD receiver is only available when the 1st receiver is a HD receiver (not available with a HD-DVR).</cng:messageText>\n"
      + "<cng:messageSeverity>information</cng:messageSeverity>\n"
      + "<cng:messageCategory>business</cng:messageCategory>\n"
      + "</Message>\n"
      + "<Response>\n"
      + "<cng:code>0</cng:code>\n"
      + "<cng:description>Success</cng:description>\n"
      + "</Response>\n"
      + "</InquireSatelliteCPEDetailsResponse>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>";

    this.callModalPopUp(responseXml, "template2", "Complete XML Generation", "");
  }

  //Generate Inq Sat Cust Prof Resp Function 
  GenInqSatCustProfResp() {
    var receiverAndProgDetails1: String;
    var receiverAndProgDetails2: String;
    var receiverAndProgDetails3: String;
    var receiverAndProgDetails4: String;
    var receiverAndProgDetails5: String;
    var receiverAndProgDetails6: String;
    var receiverAndProgDetails7: String;
    var receiverAndProgDetails8: String;

    let tabLineItemDisable1 = this.starMainTabs[0].disabled;
    let tabLineItemDisable2 = this.starMainTabs[1].disabled;
    let tabLineItemDisable3 = this.starMainTabs[2].disabled;
    let tabLineItemDisable4 = this.starMainTabs[3].disabled;
    let tabLineItemDisable5 = this.starMainTabs[4].disabled;
    let tabLineItemDisable6 = this.starMainTabs[5].disabled;
    let tabLineItemDisable7 = this.starMainTabs[6].disabled;
    let tabLineItemDisbale8 = this.starMainTabs[7].disabled;

    if (tabLineItemDisable1 == false) {
      receiverAndProgDetails1 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails1 = "";
    }

    if (tabLineItemDisable2 == false) {
      receiverAndProgDetails2 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails2 = "";
    }

    if (tabLineItemDisable3 == false) {
      receiverAndProgDetails3 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails3 = "";
    }

    if (tabLineItemDisable4 == false) {
      receiverAndProgDetails4 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails4 = "";
    }

    if (tabLineItemDisable5 == false) {
      receiverAndProgDetails5 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails5 = "";
    }

    if (tabLineItemDisable6 == false) {
      receiverAndProgDetails6 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails6 = "";
    }

    if (tabLineItemDisable7 == false) {
      receiverAndProgDetails7 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails7 = "";
    }

    if (tabLineItemDisbale8 == false) {
      receiverAndProgDetails8 = this.getCsiOsmRecAndProgDetails(this.accessCardId, this.accessCardStatus, this.equipOwnership);
    } else {
      receiverAndProgDetails8 = "";
    }

    var responseXml: String = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
      + "<SOAP-ENV:Header>\n"
      + "<ns2:MessageHeader xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\">\n"
      + "<ns2:TrackingMessageHeader>\n"
      + "<version>v100</version>\n"
      + "<messageId>12345678</messageId>\n"
      + "<originatorId>csitest</originatorId>\n"
      + "<timeToLive>600000</timeToLive>\n"
      + "<conversationId>csitest~CNG-CSI~77dae5f0-b7a1-4d8d-a54d-08bdeba9640b</conversationId>\n"
      + "<dateTimeStamp>2001-12-17T09:30:47.0Z</dateTimeStamp>\n"
      + "<uniqueTransactionId>ServiceGateway769386@q100csg138c3_e88a668e-c711-404e-aa41-ccdee6041666</uniqueTransactionId>\n"
      + "</ns2:TrackingMessageHeader>\n"
      + "<ns2:SecurityMessageHeader>\n"
      + "<userName>csitest</userName>\n"
      + "<userPassword>testingcsi</userPassword>\n"
      + "</ns2:SecurityMessageHeader>\n"
      + "<ns2:SequenceMessageHeader>\n"
      + "<sequenceNumber>1</sequenceNumber>\n"
      + "<totalInSequence>1</totalInSequence>\n"
      + "</ns2:SequenceMessageHeader>\n"
      + "</ns2:MessageHeader>\n"
      + "</SOAP-ENV:Header>\n"
      + "<SOAP-ENV:Body>\n"
      + "<InquireSatelliteCustomerProfileResponse xmlns=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSatelliteCustomerProfileResponse.xsd\" xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\">\n"
      + "<CustomerLevelResponse>\n"
      + "<Detail>\n"
      + "<CustomerDetails>\n"
      + "<PartnerDetails>\n"
      + "<primaryOwner>NRTC</primaryOwner>\n"
      + "<secondaryOwner>0331</secondaryOwner>\n"
      + "</PartnerDetails>\n"
      + "<CustomerAccountDetails>\n"
      + "<CustomerBusinessSelection>\n"
      + "<CustomerName>\n"
      + "<lastName>COWMAN</lastName>\n"
      + "<firstName>HOLLIS</firstName>\n"
      + "</CustomerName>\n"
      + "</CustomerBusinessSelection>\n"
      + "<AddressDetails>\n"
      + "<ServiceAddress>\n"
      + "<streetNumber>1298</streetNumber>\n"
      + "<streetName>COUNTY ROAD 326</streetName>\n"
      + "<city>GIDDINGS</city>\n"
      + "<state>TX</state>\n"
      + "<zipCode>78942</zipCode>\n"
      + "</ServiceAddress>\n"
      + "</AddressDetails>\n"
      + "<AccountDetails>\n"
      + "<accountId>242342</accountId>\n"
      + "<accountType>REG</accountType>\n"
      + "<accountStatus>DISC</accountStatus>\n"
      + "</AccountDetails>\n"
      + "</CustomerAccountDetails>\n"
      + "<AssetDetails>\n"
      + "<ReceiverDetails>\n"
      + "<ReceiverDetailsRequestStatus>\n"
      + "<messageStatus>success</messageStatus>\n"
      + "</ReceiverDetailsRequestStatus>\n"
      + receiverAndProgDetails1
      + receiverAndProgDetails2
      + receiverAndProgDetails3
      + receiverAndProgDetails4
      + receiverAndProgDetails5
      + receiverAndProgDetails6
      + receiverAndProgDetails7
      + receiverAndProgDetails8
      + "</ReceiverDetails>\n"
      + "</AssetDetails>\n"
      + "</CustomerDetails>\n"
      + "<MessageDetails>\n"
      + "<messageStatus>SUCCESS</messageStatus>\n"
      + "<provider>ZLDS</provider>\n"
      + "</MessageDetails>\n"
      + "<videoAccountFoundIndicator>true</videoAccountFoundIndicator>\n"
      + "</Detail>\n"
      + "</CustomerLevelResponse>\n"
      + "<Response>\n"
      + "<ns2:code>0</ns2:code>\n"
      + "<ns2:description>Success</ns2:description>\n"
      + "</Response>\n"
      + "</InquireSatelliteCustomerProfileResponse>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>\n";

    this.callModalPopUp(responseXml, "template2", "Complete XML Generation", "");

  }

  callModalPopUp(xml, type, title, fileName) {
    let mainXml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\nxmlns:ws="http://ws.sender.bbnms.att.com/">\n`
      + `<soapenv:Header/>\n`
      + `<soapenv:Body>\n`
      + `<ws:sendMessageToQueue>\n`
      + `<MessageSenderRequest_V2>\n`
      + `<environment>${this.enviornmentVal}</environment>\n`
      + `<queue>OMS</queue>\n`
      + `<message>`
      + `<![CDATA[\n`
      // <Place request xml> 
      + xml
      + '\n]]></message>\n'
      + '</MessageSenderRequest_V2>\n'
      + '</ws:sendMessageToQueue>\n'
      + '</soapenv:Body>\n'
      + '</soapenv:Envelope>\n';

    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = title;
    modalRef.componentInstance.type = type;
    modalRef.componentInstance.content = mainXml;
    if (type == "template2") {
      modalRef.componentInstance.fileName = fileName;
    }
  }

  OnCondLineExtType(lineItemType, buttonType, accessCardId, orderLineItemActionId, irdActionId,
    productNameId, productLineId, receiverId, macaddressId, dateId, lineItemId) {
    let tabLineItemDisable = this.starMainTabs.filter(v => v.label == lineItemType)[0].disabled
    if (tabLineItemDisable == false) {//lineItem enable
      if (buttonType == "getIsaacReq") {
        return this.getExtLineItem(lineItemType, accessCardId, orderLineItemActionId, irdActionId,
          productNameId, productLineId, receiverId, macaddressId, dateId, lineItemId);
      } else if (buttonType == "genIswoActResp") {
        return this.getCsiOsmLineItems(lineItemId, productLineId, productNameId, orderLineItemActionId,
          macaddressId, this.category, irdActionId, accessCardId, this.accessCardStatus, this.lineItemStatus,
          this.equipOwnership);
      } else if (buttonType == "genSubSatResp") {
        return this.getCsiSubSatWorkOrderLineItems(lineItemId, productLineId, productNameId,
          orderLineItemActionId, macaddressId, this.category, irdActionId, accessCardId, this.accessCardStatus,
          true, this.equipOwnership);
      }
    } else {
      return "";
    }
  }

  getExtLineItem(lineItemType, accessCard: String, orderLineItemAction: String, irdAction: String, productName: String,
    productLine: String, receiver: String, macadd: String, date: String, lineItem: String): String {
    var ExtLineItemXml: String;
    var receiverId: String = "";
    if (receiver != null && receiver != "") {
      receiverId = "<p:receiverId>" + receiver + "</p:receiverId>\n";
    }
    ExtLineItemXml = "<p:LineItemDetails>\n"
      + "<p:LineItemType>\n"

    if (lineItemType.indexOf('lineItem') != -1) {
      ExtLineItemXml += "<p:lineItemId>" + lineItem + "</p:lineItemId>\n"
    } else {
      ExtLineItemXml += "<p:externalLineItemId>" + lineItem + "</p:externalLineItemId>\n"
    }

    ExtLineItemXml += "</p:LineItemType>\n"
      + "<p:serialNumber>" + macadd + "</p:serialNumber>\n"
      + "<p:status>3333</p:status>\n"
      + "<p:make>Motorola</p:make>\n"
      + "<p:model>666</p:model>\n"
      + "<p:accessCardId>" + accessCard + "</p:accessCardId>\n"
      + "<p:deliveryMethod>Tech Delivers</p:deliveryMethod>\n"
      + "<p:partStatus>Good new</p:partStatus>\n"
      + "<p:modifyReason>modifyReason89967</p:modifyReason>\n"
      + "<p:orderLineItemAction>" + orderLineItemAction + "</p:orderLineItemAction>\n"
      + "<p:irdAction>" + irdAction + "</p:irdAction>\n"
      + "<p:location>Kitchen</p:location>\n"
      + "<p:remoteCode>remoteCode23323</p:remoteCode>\n"
      + "<p:tvInput>video</p:tvInput>\n"
      + "<p:productName>" + productName + "</p:productName>\n"
      + "<p:productLine>" + productLine + "</p:productLine>\n"
      + "<p:createdDateTime>" + date + "</p:createdDateTime>\n"
      + "<p:noSerialIndicator>true</p:noSerialIndicator>\n"
      + "<p:macAddress>" + macadd + "</p:macAddress>\n"
      + receiverId
      + "<p:ivRetestSuccessCode>ivRetestSuccessCode643643</p:ivRetestSuccessCode>\n"
      + "</p:LineItemDetails>";

    return ExtLineItemXml;
  }

  getCsiOsmLineItems(lineItemId: String, productLineId: String, productName: String,
    orderLineItemAction: String, macid: String, category: String, irdaction: String,
    accessCardId: String, accessCardStatus: String, lineItemStatus: String, equipOwnership: String): String {
    var lineItem: String = "<LineItem>\n"
      + "<cng:technicianId>1234</cng:technicianId>\n"
      + "<cng:tvInput>viedo</cng:tvInput>\n"
      + "<cng:swapSerialNumber/>\n"
      + "<cng:swapClient/>\n"
      + "<cng:swapAccessCardId/>\n"
      + "<cng:successCodeOverrideIndicator>N</cng:successCodeOverrideIndicator>\n"
      + "<cng:successCode/>\n"
      + "<cng:status>" + lineItemStatus + "</cng:status>\n"
      + "<cng:serialNumberNotAvailableIndicator>Y</cng:serialNumberNotAvailableIndicator>\n"
      + "<cng:successCodeOverrideReason/>\n"
      + "<cng:rowId>" + lineItemId + "</cng:rowId>\n"
      + "<cng:remoteCode/>\n"
      + "<cng:reactivationSource/>\n"
      + "<cng:reactivationDateTime/>\n"
      + "<cng:receiverIdRequiredIndicator/>\n"
      + "<cng:productLine>" + productLineId + "</cng:productLine>\n"
      + "<cng:productName>" + productName + "</cng:productName>\n"
      + "<cng:partStatus>Good new</cng:partStatus>\n"
      + "<cng:orderLineItemAction>" + orderLineItemAction + "</cng:orderLineItemAction>\n"
      + "<cng:mode>programming</cng:mode>\n"
      + "<cng:mirroredIndicator/>\n"
      + "<cng:macAddress>" + macid + "</cng:macAddress>\n"
      + "<cng:lineNumber>1</cng:lineNumber>\n"
      + "<cng:integrationSubStatus/>\n"
      + "<cng:integrationStatus>done</cng:integrationStatus>\n"
      + "<cng:ivRetestIndicator/>\n"
      + "<cng:serialNumber>" + macid + "</cng:serialNumber>\n"
      + "<cng:techActionTaken>Support Hardware Installed</cng:techActionTaken>\n"
      + "<cng:failureReason>failure reason</cng:failureReason>\n"
      + "<cng:externalLineItemId/>\n"
      + "<cng:equipmentOwnership>" + equipOwnership + "</cng:equipmentOwnership>\n"
      + "<cng:description>Success</cng:description>\n"
      + "<cng:deliveryMethod>Customer own</cng:deliveryMethod>\n"
      + "<cng:deactivationSource/>\n"
      + "<cng:deactivationDateTime/>\n"
      + "<cng:category>" + category + "</cng:category>\n"
      + "<cng:callCenterAction/>\n"
      + "<cng:activationSource/>\n"
      + "<cng:activationDateTime/>\n"
      + "<cng:actionRequired/>\n"
      + "<cng:action>" + irdaction + "</cng:action>\n"
      + "<cng:accessCardType/>\n"
      + "<cng:accessCardReceiverId/>\n"
      + "<cng:accessCardId>" + accessCardId + "</cng:accessCardId>\n"
      + "<cng:location>Kitchen</cng:location>\n"
      + "<cng:accessCardStatus>" + accessCardStatus + "</cng:accessCardStatus>\n"
      + "<cng:modifyReason/>\n"
      + "<cng:agentId/>\n"
      + "<cng:triggeredBy/>\n"
      + "<cng:unitType/>\n"
      + "<cng:sensorType/>\n"
      + "<cng:placement/>\n"
      + "<cng:encryptionKey/>\n"
      + "<cng:LineItemAttribute>\n"
      + "<cng:rowId>" + lineItemId + "</cng:rowId>\n"
      + "<cng:name/>\n"
      + "<cng:value/>\n"
      + "<cng:fullValue/>\n"
      + "<cng:lineItemId/>\n"
      + "<cng:orderLineItemId/>\n"
      + "</cng:LineItemAttribute>\n"
      + "</LineItem>\n";

    return lineItem;
  }

  getCsiSubSatWorkOrderLineItems(lineItemId: String, productLineId: String, productName: String,
    orderLineItemAction: String, macid: String, category: String, irdaction: String,
    accessCardId: String, accessCardStatus: String, isExtLine: Boolean, equipOwnership: String): String {
    var extLineItem: String = "";
    if (isExtLine == true) {
      extLineItem = "<externalLineItemId>" + lineItemId + "</externalLineItemId>";
    }

    var woLineItem: String = "<WorkOrderLineItem>\n"
      + "<mode>programming</mode>\n"
      + "<description>Success</description>\n"
      + "<rowId>" + lineItemId + "</rowId>\n"
      + extLineItem
      + "<location>ATTIC</location>\n"
      + "<accessCardStatus>" + accessCardStatus + "</accessCardStatus>\n"
      + "<accessCardType>P</accessCardType>\n"
      + "<accessCardId>" + accessCardId + "</accessCardId>\n"
      + "<equipmentType>" + equipOwnership + "</equipmentType>\n"
      + "<category>" + category + "</category>\n"
      + "<actionRequired>New</actionRequired>\n"
      + "<callCenterAction>N</callCenterAction>\n"
      + "<deliveryMethod>Tech Delivers</deliveryMethod>\n"
      + "<techActionTaken>" + irdaction + "</techActionTaken>\n"
      + "<serialNumber>" + macid + "</serialNumber>\n"
      + "<macAddress>" + macid + "</macAddress>\n"
      + "<partStatus>Good New</partStatus>\n"
      + "<productName>" + productName + "</productName>\n"
      + "<productLineName>" + productLineId + "</productLineName>\n"
      + "<lineNumber>1</lineNumber>\n"
      + "<orderLineItemAction>" + orderLineItemAction + "</orderLineItemAction>\n"
      + "<integrationSubStatus>Success</integrationSubStatus>\n"
      + "<technicianId>SKAK003009</technicianId>\n"
      + "<integrationStatus>Success</integrationStatus>\n"
      + "<status>Closed</status>\n"
      + "</WorkOrderLineItem>\n";
    return woLineItem;
  }

  getLineItemData() {
    var recieverId: String = this.receiverId;
    var macAddress: String = this.macaddressId;
    var accessCard: String = this.accessCardId;
    var lineItemId: String = this.lineItemId;

    this.genInquireSatCpeResp(lineItemId, accessCard)
  }

  getCsiOsmRecAndProgDetails(accessCardId: String, accessCardStatus: String, equipmentOwnership: String): String {
    var receiverAndProgDetails: String = "<ReceiverAndProgrammingDetails>\n"
      + "<installedDate>2013-05-31</installedDate>\n"
      + "<installerId>MMNT3840</installerId>\n"
      + "<equipmentOwnership>" + equipmentOwnership + "</equipmentOwnership>\n"
      + "<AccessCardDetails>\n"
      + "<accessCardId>" + accessCardId + "</accessCardId>\n"
      + "<accessCardStatus>" + accessCardStatus + "</accessCardStatus>\n"
      + "<accessCardStatusDate>2013-07-12</accessCardStatusDate>\n"
      + "<mirroredIndicator>true</mirroredIndicator>\n"
      + "<accessCardType>secondary</accessCardType>\n"
      + "<phoneConnectionIndicator>true</phoneConnectionIndicator>\n"
      + "<allowOPPVIndicator>true</allowOPPVIndicator>\n"
      + "<rateCeiling>X</rateCeiling>\n"
      + "<purchaseLimit>0.0</purchaseLimit>\n"
      + "<lastCallbackDate>2008-07-16-07:00</lastCallbackDate>\n"
      + "<disconnectDate>2013-07-12</disconnectDate>\n"
      + "<lastModifiedBy>NEWDBERSUDER</lastModifiedBy>\n"
      + "<lastModifiedDate>2013-07-12</lastModifiedDate>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>B</productType>\n"
      + "<productCode>5335</productCode>\n"
      + "<productName>To Our Valued Customer:</productName>\n"
      + "<priceCode>6</priceCode>\n"
      + "<priceBeginDate>2006-08-16</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2008-08-15</activationDate>\n"
      + "<disconnectDate>2009-02-15</disconnectDate>\n"
      + "<disconnectReason>9110</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>6</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>B</productType>\n"
      + "<productCode>5714</productCode>\n"
      + "<productName>No Annual Commitment</productName>\n"
      + "<priceCode>10</priceCode>\n"
      + "<priceBeginDate>2011-04-01</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2012-09-28</activationDate>\n"
      + "<disconnectDate>2012-10-01</disconnectDate>\n"
      + "<disconnectReason>9110</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>2</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>B</productType>\n"
      + "<productCode>6268</productCode>\n"
      + "<productName>We appreciate your loyalty.</productName>\n"
      + "<priceCode>1</priceCode>\n"
      + "<priceBeginDate>2006-10-03</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2008-08-04</activationDate>\n"
      + "<disconnectDate>2009-02-04</disconnectDate>\n"
      + "<disconnectReason>9110</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>6</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>B</productType>\n"
      + "<productCode>101851</productCode>\n"
      + "<productName>Enhanced Protection Plan_Track</productName>\n"
      + "<priceCode>3</priceCode>\n"
      + "<priceBeginDate>2012-07-16</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2012-08-08</activationDate>\n"
      + "<disconnectDate>2012-10-08</disconnectDate>\n"
      + "<disconnectReason>9110</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>2</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>F</productType>\n"
      + "<productCode>910000000</productCode>\n"
      + "<productName>Additional TV_OWN</productName>\n"
      + "<priceCode>0</priceCode>\n"
      + "<price>6.0</price>\n"
      + "<activationDate>2013-05-31</activationDate>\n"
      + "<disconnectDate>2013-07-12</disconnectDate>\n"
      + "<disconnectReason>9001</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<autoRenewIndicator>true</autoRenewIndicator>\n"
      + "<basePriceTaxAmount>0.38</basePriceTaxAmount>\n"
      + "<serviceLength>1</serviceLength>\n"
      + "<prodPrimaryOwner>NRTC</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>0331</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>P</productType>\n"
      + "<productCode>2140</productCode>\n"
      + "<productName>HBO</productName>\n"
      + "<priceCode>1</priceCode>\n"
      + "<priceBeginDate>2009-03-04</priceBeginDate>\n"
      + "<price>14.99</price>\n"
      + "<activationDate>2004-09-23</activationDate>\n"
      + "<disconnectDate>2010-01-04</disconnectDate>\n"
      + "<disconnectReason>1000</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<autoRenewIndicator>true</autoRenewIndicator>\n"
      + "<basePriceTaxAmount>0.94</basePriceTaxAmount>\n"
      + "<serviceLength>1</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>P</productType>\n"
      + "<productCode>6277</productCode>\n"
      + "<productName>SHOWTIME</productName>\n"
      + "<priceCode>3</priceCode>\n"
      + "<priceBeginDate>2009-08-19</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2011-10-19</activationDate>\n"
      + "<disconnectDate>2012-01-19</disconnectDate>\n"
      + "<disconnectReason>9110</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>3</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>P</productType>\n"
      + "<productCode>6412</productCode>\n"
      + "<productName>SHOWTIME HD</productName>\n"
      + "<priceCode>1</priceCode>\n"
      + "<priceBeginDate>2007-01-24</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2011-10-19</activationDate>\n"
      + "<disconnectDate>2012-01-19</disconnectDate>\n"
      + "<disconnectReason>1100</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<autoRenewIndicator>true</autoRenewIndicator>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>1</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>P</productType>\n"
      + "<productCode>6413</productCode>\n"
      + "<productName>HBO HD</productName>\n"
      + "<priceCode>1</priceCode>\n"
      + "<priceBeginDate>2007-01-24</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2008-08-07</activationDate>\n"
      + "<disconnectDate>2010-01-04</disconnectDate>\n"
      + "<disconnectReason>1100</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<autoRenewIndicator>true</autoRenewIndicator>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>1</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "<ProgrammingList>\n"
      + "<productStatus>DISC</productStatus>\n"
      + "<productType>P</productType>\n"
      + "<productCode>6415</productCode>\n"
      + "<productName>Advanced Receiver-HD_SplOfrExp</productName>\n"
      + "<priceCode>1</priceCode>\n"
      + "<priceBeginDate>2007-01-24</priceBeginDate>\n"
      + "<price>0.0</price>\n"
      + "<activationDate>2007-01-25</activationDate>\n"
      + "<disconnectDate>2008-08-07</disconnectDate>\n"
      + "<disconnectReason>1000</disconnectReason>\n"
      + "<ProductDetails>\n"
      + "<autoRenewIndicator>true</autoRenewIndicator>\n"
      + "<basePriceTaxAmount>0.0</basePriceTaxAmount>\n"
      + "<serviceLength>1</serviceLength>\n"
      + "<prodPrimaryOwner>DTV</prodPrimaryOwner>\n"
      + "<prodSecondaryOwner>DTV</prodSecondaryOwner>\n"
      + "</ProductDetails>\n"
      + "</ProgrammingList>\n"
      + "</AccessCardDetails>\n"
      + "<HardwareDetails>\n"
      + "<manufacturer>RCA</manufacturer>\n"
      + "<model>P61300</model>\n"
      + "<serialNumber>124320076</serialNumber>\n"
      + "<receiverId>0</receiverId>\n"
      + "<receiverType>HD</receiverType>\n"
      + "<location>LIV RM</location>\n"
      + "</HardwareDetails>\n"
      + "</ReceiverAndProgrammingDetails>\n";
    return receiverAndProgDetails;

  }

}
