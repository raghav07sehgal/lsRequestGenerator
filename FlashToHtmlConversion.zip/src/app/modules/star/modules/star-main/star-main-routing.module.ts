import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LineItemComponent } from 'app/shared/line-item/line-item.component';
import { StarMainComponent } from './star-main.component';

const routes: Routes = [
  { path: '', component: StarMainComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StarMainRoutingModule { }
