import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { shortToggleDropdown } from 'app/constants/global.constant';
import { issacLineItemDropdown, modeDropdown } from 'app/constants/star.constant';
import { starIsaacTabs } from 'app/constants/tab.constant';
import { LineItemComponent } from 'app/shared/line-item/line-item.component';
import { ModelBoxComponent } from 'app/shared/model-box/model-box.component';
import { StarService } from '../../star.service';

@Component({
  selector: 'app-isaac-tdar',
  templateUrl: './isaac-tdar.component.html',
  styleUrls: ['./isaac-tdar.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class IsaacTdarComponent implements OnInit {
  textTitle1: string = "Activity Id";
  textTitle2: string = "";
  textValue1: any = '';
  textValue2: any = '';

  dropdownTitle1: string = "Mode";
  dropdownTitle2: string = "LineItem";
  dropdownTitle3: string = "RepairInd";
  dropdownValues1: any[] = modeDropdown;
  dropdownValues2: any[] = issacLineItemDropdown;
  dropdownValues3: any[] = shortToggleDropdown;
  starIsaacTabs: any[] = starIsaacTabs;

  selectedMode: any = this.dropdownValues1[0].label;
  selectedLineItem: any = this.dropdownValues2[0].label;
  selectedRepairInd: any = this.dropdownValues3[0].label;

  starIsaacUrl: string = "/star/isaacTdar";
  title: string = "isaacTdar";

  lineItem1: String;
  lineItem2: String;
  lineItem3: String;
  lineItem4: String;
  swapDetail: string;
  banValue: string;

  lineItemAction: string;
  receiverId: string;
  productLineId: string;
  productNameId: string;
  accessCardId: string;
  actionType: string;
  macaddressId: string;
  serialNum: string;
  equipOwnType: string
  lineItemId: string;

  enviornmentVal: any;

  @ViewChild(LineItemComponent) lineItem: LineItemComponent;

  constructor(private router: Router, private starService: StarService,
    private modalService: NgbModal, private store: Store<HeaderState>) { }

  ngOnInit(): void {
    this.router.navigate([this.starIsaacUrl]);
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        if (storeObj['banValue']?.length) {
          this.banValue = storeObj['banValue'];
        }
        this.enviornmentVal = storeObj['enviornment'];
      })

    this.starService.getEventSubject().subscribe((value) => {
      if (value == "genTdarIsaacReq") {
        this.genTdarIsaacReq();
      }
    });

    this.lineItemAction = this.lineItem?.SelectedLineItemAction;
    this.receiverId = this.lineItem?.textValue2
    this.productLineId = this.lineItem?.SelectedProductLine
    this.productNameId = this.lineItem?.SelectedProductName
    this.accessCardId = this.lineItem?.textValue4;
    this.actionType = this.lineItem?.SelectedActionType
    this.macaddressId = this.lineItem?.textValue5
    this.serialNum = this.lineItem?.textValue3
    this.equipOwnType = this.lineItem?.SelectedEquipOwnType
    this.lineItemId = this.lineItem?.textValue1;
  }

  getReferenceId() {
    this.textValue2 = Math.floor(Math.random() * (999999 - 100000)) + 200000000000;
  }

  dropDownChange(evt, title) {
    if (title == "Mode") {
      this.selectedMode = evt;
    } else if (title == "LineItem") {
      this.selectedLineItem = evt;
      this.starIsaacTabs.map(val => val.disabled = true)
      for (let i = 0; i < this.selectedLineItem; i++) {
        this.starIsaacTabs[i].disabled = false;
      }
    } else if (title == "RepairInd") {
      this.selectedRepairInd = evt;
    }
  }

  //Gen Tdar Isaac Req Star function - getting details from main tab 
  genTdarIsaacReq() {
    if (this.selectedMode == "Swap") {
      this.swapDetail = "<p:SwapDetails>\n"
        + "<p:swapAccessCardId>1250588634</p:swapAccessCardId>\n"
        + "<p:failureReason>failureReason24328</p:failureReason>\n"
        + "</p:SwapDetails>";
    } else if (this.selectedMode == "Initiate" || this.selectedMode == "Closeout") {
      this.lineItem1 = "";
    } else if (this.selectedMode == "Process") {
      this.swapDetail = "";
      this.lineItem1 = "<sch:LineItemDetails>\n"
        + "<sch:LineItemType>\n"
        + "<sch:lineItemId>" + this.lineItemId + "</sch:lineItemId>\n"
        + "</sch:LineItemType>\n"
        + "<sch:serialNumber>" + this.serialNum + "</sch:serialNumber>\n"
        + "<sch:make>Nokia</sch:make>\n"
        + "<sch:model>HR55</sch:model>\n"
        + "<sch:accessCardId>" + this.accessCardId + "</sch:accessCardId>\n"
        + "<sch:orderLineItemAction>" + this.lineItemAction + "</sch:orderLineItemAction>\n"
        + "<sch:productName>" + this.productNameId + "</sch:productName>\n"
        + "<sch:productLine>" + this.productLineId + "</sch:productLine>\n"
        + "<sch:noSerialIndicator>true</sch:noSerialIndicator>\n"
        + "<sch:actionType>" + this.actionType + "</sch:actionType>\n"
        + "<sch:ResidentialCustomerLineItemDetails>\n"
        + "<sch:equipmentOwnership>" + this.equipOwnType + "</sch:equipmentOwnership>\n"
        + "<sch:productTypeIdentifier>Client</sch:productTypeIdentifier>\n"
        + "<sch:receiverConnectionType>broadband</sch:receiverConnectionType>\n"
        + "<sch:technicianVehicleId>127915</sch:technicianVehicleId>\n"
        + "<sch:waiverCode>123</sch:waiverCode>\n"
        + "<sch:technicianId>td890y</sch:technicianId>\n"
        + "<sch:CapabilityDetails>\n"
        + "<sch:capabilityName>ATSC</sch:capabilityName>\n"
        + "<sch:capabilityValue>True</sch:capabilityValue>\n"
        + "</sch:CapabilityDetails>\n"
        + "</sch:ResidentialCustomerLineItemDetails>\n"
        + "<sch:macAddress>" + this.macaddressId + "</sch:macAddress>\n"
        + "<sch:receiverId>" + this.receiverId + "</sch:receiverId>\n"
        + "</sch:LineItemDetails>\n";
    }

    var requestXML: String = "<sch:SubmitSatelliteCPERequest xmlns:sch=\"http://bbnms.lightspeed.att.com/csibbnmssscpet/submitsatellitecperequest/schema\">\n"
      + "<sch:uverseBAN>" + this.banValue + "</sch:uverseBAN>\n"
      + "<sch:referenceId>" + this.textValue2 + "</sch:referenceId>\n"
      // + "<sch:orderNumber>" + tdarOrigOrdId.text + "</sch:orderNumber>\n"
      + "<sch:orderActionMode>" + this.selectedMode + "</sch:orderActionMode>\n"
      + "<sch:activityId>" + this.textValue1 + "</sch:activityId>\n"
      + "<sch:applicationId>ISAAC</sch:applicationId>\n"
      + "<sch:propertyType>Own</sch:propertyType>\n"
      + "<sch:residentialCustomerIndicator>true</sch:residentialCustomerIndicator>\n"
      + "<sch:customerSelectedProtectionPlan>protectionplan</sch:customerSelectedProtectionPlan>\n"
      + "<sch:sourceSystemURL>http:</sch:sourceSystemURL>\n"
      + this.lineItem1
      + "</sch:SubmitSatelliteCPERequest>\n"

    this.callModalPopUp(requestXML, "template1", "Complete XML Generation", "");
  }

  callModalPopUp(xml, type, title, fileName) {
    let mainXml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\nxmlns:ws="http://ws.sender.bbnms.att.com/">\n`
      + `<soapenv:Header/>\n`
      + `<soapenv:Body>\n`
      + `<ws:sendMessageToQueue>\n`
      + `<MessageSenderRequest_V2>\n`
      + `<environment>${this.enviornmentVal}</environment>\n`
      + `<queue>OMS</queue>\n`
      + `<message>`
      + `<![CDATA[\n`
      // <Place request xml> 
      + xml
      + '\n]]></message>\n'
      + '</MessageSenderRequest_V2>\n'
      + '</ws:sendMessageToQueue>\n'
      + '</soapenv:Body>\n'
      + '</soapenv:Envelope>\n';

    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = title;
    modalRef.componentInstance.type = type;
    modalRef.componentInstance.content = mainXml;
    if (type == "template2") {
      modalRef.componentInstance.fileName = fileName;
    }
  }

}
