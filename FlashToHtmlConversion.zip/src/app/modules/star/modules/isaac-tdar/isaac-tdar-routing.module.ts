import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LineItemComponent } from 'app/shared/line-item/line-item.component';
import { IsaacTdarComponent } from './isaac-tdar.component';

const routes: Routes = [
  { path: '', component: IsaacTdarComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IsaacTdarRoutingModule { }
