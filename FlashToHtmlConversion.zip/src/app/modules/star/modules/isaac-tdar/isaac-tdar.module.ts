import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IsaacTdarRoutingModule } from './isaac-tdar-routing.module';
import { IsaacTdarComponent } from './isaac-tdar.component';
import { SharedModule } from 'app/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [IsaacTdarComponent],
  imports: [
    CommonModule,
    IsaacTdarRoutingModule,
    SharedModule,
    NgbModule,
    FormsModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class IsaacTdarModule { }
