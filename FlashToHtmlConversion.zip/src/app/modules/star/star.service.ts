import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StarService {
  private eventSubject = new BehaviorSubject<any>(undefined);

  constructor() { }

  triggerSomeEvent(val) {
    this.eventSubject.next(val);
  }

  getEventSubject(): BehaviorSubject<any> {
    return this.eventSubject;
  }

}
