import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IsaacTdarModule } from './modules/isaac-tdar/isaac-tdar.module';
import { StarMainModule } from './modules/star-main/star-main.module';
import { StarTdarFntModule } from './modules/star-tdar-fnt/star-tdar-fnt.module';
import { StarTdarModule } from './modules/star-tdar/star-tdar.module';
import { StarComponent } from './star.component';

const routes: Routes = [
  {
    path: '', component: StarComponent,
    children: [
      { path: 'main', loadChildren: () => StarMainModule },
      { path: 'tdarFnt', loadChildren: () => StarTdarFntModule },
      { path: 'tdar', loadChildren: () => StarTdarModule },
      { path: 'isaacTdar', loadChildren: () => IsaacTdarModule },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StarRoutingModule { }