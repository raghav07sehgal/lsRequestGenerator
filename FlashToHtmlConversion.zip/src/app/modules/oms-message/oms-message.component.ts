import { formatDate } from '@angular/common';
import { Component, OnInit, SystemJsNgModuleLoaderConfig, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbDateStruct, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  OrderActionDropdown,
  OrderActionReasonCodeDropdown,
  SubTypeDropdown,
  ReferenceDropdown,
  CreationAppDropdown,
  infoValue,
  ntiValue
} from 'app/constants/omsMessage.constant';
import { omsTabSelection, tabValue1 } from 'app/constants/tab.constant';
import { CheckboxItem } from 'app/shared/checkBox-value/checkBox-value.component';
import { OmsMessageService } from './oms-message.service';
import { State, Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { ModelBoxComponent } from 'app/shared/model-box/model-box.component';
import { ServiceFspComponent } from 'app/shared/serviceFsp/serviceFsp.component';
import { CustomerInfoComponent } from 'app/shared/customerInfo/customerInfo.component';
import { UmcComponent } from './component/umc/umc.component';
import { PlstComponent } from './component/plst/plst.component';
import { shortToggleDropdown } from 'app/constants/global.constant'
import { SubContainerComponent } from 'app/shared/subComponent/subContainer.component';
import { SubModuleComponent } from 'app/shared/sub-module/sub-module.component';
import { RelatedProductModalComponent } from 'app/shared/related-product-modal/related-product-modal.component';
import { Body } from '@angular/http/src/body';
import { parse } from 'querystring';
import { OmsMessage } from './oms.model';
import { NtiDropdownValues } from 'app/constants/header.constant';

@Component({
  selector: 'app-oms-message',
  templateUrl: './oms-message.component.html',
  styleUrls: ['./oms-message.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class OmsMessageComponent implements OnInit {
  @ViewChild(ServiceFspComponent) serviceFsp: ServiceFspComponent;
  @ViewChild(CustomerInfoComponent) customerInfo: CustomerInfoComponent;
  @ViewChild(UmcComponent) umc: UmcComponent;
  @ViewChild(PlstComponent) plst: PlstComponent;
  @ViewChild(SubContainerComponent) subContainer: SubContainerComponent;
  @ViewChild(SubModuleComponent) subModule: SubModuleComponent;

  omsUrl: string = "/oms";
  dueDate: NgbDateStruct;

  textTitle1: string = "Order Number";
  textTitle2: string = "OrigOrderActionId";
  textTitle3: string = "dslDisconnectTn";
  textTitle4: string = "TelegenceId";
  textTitle5: string = "APID"
  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any;
  textValue6: any = '';

  disableText3: boolean = false;

  dropdownTitle1: string = "Order Action Reason Code";
  dropdownTitle2: string = "Order Action";
  dropdownTitle3: string = "Extended Due Date";
  dropdownTitle4: string = "SubType";
  dropdownTitle5: string = "Reference";
  dropdownTitle6: string = "Creation Application";
  dropdownValues1: any[] = OrderActionReasonCodeDropdown;
  dropdownValues2: any[] = OrderActionDropdown;
  dropdownValues3: any[] = shortToggleDropdown;
  dropdownValues4: any[] = SubTypeDropdown;
  dropdownValues5: any[] = ReferenceDropdown;
  dropdownValues6: any[] = CreationAppDropdown;

  selectValue5: any = ReferenceDropdown[0].label;

  omsTabs: any[] = omsTabSelection;
  myDate: any;
  tabType: string = "oms"
  tabContent: string = "ht550"
  scrollContent: string = "serviceContent";
  checkBoxClass: string = "d-block";
  checkBoxClass1: string = "d-inline-flex";

  iadTitle: string = "IAD Device";
  superSedeTitle: string = "Supersede";

  tabClass: string = "wh3"
  tabClass1: string = "wh7"
  contClass1: string = "wh1";
  contClass2: string = "wh2";
  contClass3: string = "h1"
  contClass4: string = "h2";
  title1: string = "Customer Info";
  title2: string = "New Customer Info";

  retaineService: string = "retained ServicesProviderIndicator";
  stackOrder: string = "Stacked Order";
  nadSwap: string = "NAD Swap";
  nadTitle: string = "NAD Component";
  connectCommunity: string = "Connected Community";
  nadModels: any;

  scrollCss: string = "wh2";
  scrollCss1: string = "wh4";

  vpi_CM: String;
  vci_CM: String;
  vpi_PV: String;
  vci_PV: String;
  NAD_component_CM: String;
  HSIA_component_CM: String;
  WIFI_component_CM: String;
  CVOIP_component_CM: String;
  IPTV_component_CM: String;
  DTV_component_CM: String;
  WL_component_CM: String;
  ACCS_component_CM: String;
  NAD_component_PV: String;
  HSIA_component_PV: String;
  WIFI_component_PV: String;
  CVOIP_component_PV: String;
  IPTV_component_PV: String;
  DTV_component_PV: String;
  WL_component_PV: String;
  ACCS_component_PV: String;
  ir_CM: string;
  ir_PV: string;
  HSIA_component: any;

  nonProductCatalogDataList_PV: String;
  telegenceId_PV: String;
  telegenceId_CM: String;
  exhaustHoldIndicator: String;
  loop: String;
  dslRetainedServicesList: String;
  recordOnlyAttribute: String;
  firstNameCm: String;
  lastNameCm: String;
  bisNameCm: String;
  firstNamePv: String;
  lastNamePv: String;
  bisNamePv: String;
  accountTypeCm: String;
  accountTypePv: String;
  insideWireFt: String;
  iWireCompFt: String;
  serviceIdPv: String;
  pipeCircuitIdPv: String;
  lsCircuitIdPv: String;
  serviceIdCm: String;
  pipeCircuitIdCm: String;
  lsCircuitIdCm: String;
  abfIndicatorFt: String = "";
  iadcompPV: String;
  relatedProductOrderInfoUvFt: String;
  ccid: String;
  reasonCode: String;
  salesChannel: String;
  customerInfo_LUStatus: String;
  newCustomerInfo_LUStatus: String;
  nonProductCatalogDataList: String;
  relatedOrderInfoList: String;
  dslDisconnectTN: String;
  dslDisconnectTN2: String;
  customerInfoFbs: String;
  relatedProductInfoList: String;
  relatedProductOrderInfoUv: String;
  uverseOrigOrdActId: String;
  insideWire: String;
  iWireComp: String;
  addressInfoServiceFSP: any;
  UMC_component: String;
  PLST_component: string;
  uvtypes: any;
  uaction: any;
  ACCS_component: any;
  WIRE_component: any;
  WIFI_component: any;
  VDNASB_component: any;
  CVOIP_component: any;
  IPTV_component: any;
  DTV_component: any;
  WL_component: any;
  OTT_component: any;
  newCustomerInfo: String;
  OMS_request: String;
  NAD_component: String = "";
  NewNAD_component: String = "";
  currentCustInd: String = "true";
  action: String;
  nadaction: String;
  actionInd: Boolean;
  completionIndicator: String;
  relatedOrderInfo: string;

  configChecked: boolean = true;
  GeneratePT: boolean = true;
  GeneratePTC: boolean = true;
  GenerateCPE1: boolean = true;
  ntiDisabled: boolean = true;

  wiringAction: string;
  selectedOrder: any;
  selectedSubType: any;
  selectedReference: any;
  selectedCreationApp: any;
  selectedOrderActionReasonCode: any;
  selectedExtendedDueDate: any;

  headervalue: any;

  public checkBoxModel = {
    id: 0,
    name: "",
    roles: []
  };

  infoValueOptions = new Array<any>();
  NtiValueOptions = new Array<any>();
  tabCheckOption1 = new Array<any>();
  banValue: any;
  CircuitIdVal: any;
  ntiVal: any;
  enviornmentVal: any;
  wireCenterVal: any;
  modelNo: any;

  selectedDueDate: any;

  constructor(private router: Router,
    public omsService: OmsMessageService,
    private store: Store<HeaderState>,
    private modalService: NgbModal,
  ) {
    this.selectedDueDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.infoValueOptions = infoValue.map(x => new CheckboxItem(x.id, x.name, false));
    this.NtiValueOptions = ntiValue.map(x => new CheckboxItem(x.id, x.name, false));
    this.tabCheckOption1 = tabValue1.map(x => new CheckboxItem(x.id, x.name, x.id == 1 || x.id == 2 ? true : false));
  }

  ngOnInit() {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        if (storeObj['banValue']?.length) {
          this.banValue = storeObj['banValue'];
          this.textValue5 = storeObj['banValue'].slice(0, this.banValue.length - 1);
          this.textValue3 = "1" + storeObj['banValue'];
          this.textValue4 = "A6MCXX" + storeObj['banValue'];
        }
        this.CircuitIdVal = storeObj['circuitId'];
        this.enviornmentVal = storeObj['enviornment'];
        this.modelNo = storeObj['model']
        this.wireCenterVal = storeObj['wireCenter'];
        let ntiValArr = NtiDropdownValues.filter(val => {
          return val.label == storeObj['nti'];
        });

        this.ntiVal = ntiValArr[0]?.value;
        this.onInitUpdateTabs();
      })
    this.dropdownValues3.reverse();


    this.selectedOrderActionReasonCode = this.dropdownValues1[0].label;
    this.selectedOrder = this.dropdownValues2[0].label;
    this.selectedExtendedDueDate = this.dropdownValues3[0].label;
    this.selectedSubType = this.dropdownValues4[0].label;
    this.selectedReference = this.dropdownValues5[0].label;
    this.selectedCreationApp = this.dropdownValues6[0].label;
  }

  setNonUverseActions() {
    if ((this.selectedSubType == "CA") || (this.selectedOrder == "RS") || (this.selectedOrder == "SR") || (this.selectedOrder == "SS") || (this.selectedOrder == "SU")) {
      // wifi_Action.selectedIndex = 5;
      // wl_Action.selectedIndex = 5;
      // dtv_Action.selectedIndex = 5;
      this.uaction = "";
      this.action = "";
      this.actionInd = false;
      this.completionIndicator = "NA";
    } else if (this.selectedOrder == "PR") {
      // wifi_Action.selectedIndex = 0;
      // wl_Action.selectedIndex = 0;
      // dtv_Action.selectedIndex = 0;
      this.uaction = "<m2:actionIndicator>I</m2:actionIndicator>\n";
      this.action = "<m2:actionIndicator>I</m2:actionIndicator>\n";
      this.actionInd = true;
      this.completionIndicator = "NA";
    } else if (this.selectedOrder == "CE") {
      // wifi_Action.selectedIndex = 3;
      // wl_Action.selectedIndex = 3;
      // dtv_Action.selectedIndex = 3;
      this.uaction = "<m2:actionIndicator>D</m2:actionIndicator>\n";
      this.action = "<m2:actionIndicator>D</m2:actionIndicator>\n";
      this.actionInd = true;
      this.completionIndicator = "CO";
    } else {
      // if (wifi_Tab.enabled == true) {
      //   wifi_Action.selectedIndex = 2;
      // } else {
      //   wifi_Action.selectedIndex = 0;
      // }

      // if (wl_Tab.enabled == true) {
      //   wl_Action.selectedIndex = 2;
      // } else {
      //   wl_Action.selectedIndex = 0;
      // }

      // if (dtv_Tab.enabled == true) {
      //   dtv_Action.selectedIndex = 2;
      // } else {
      //   dtv_Action.selectedIndex = 0;
      // }
      this.uaction = "<m2:actionIndicator>M</m2:actionIndicator>\n";
      this.action = "<m2:actionIndicator>R</m2:actionIndicator>\n";
      this.actionInd = true;
      this.completionIndicator = "CO";
    }
  }

  onInitUpdateTabs() {
    if (this.selectedOrder == "CH") {
      // supersedePanel.enabled = true;
      // wire_Tab.enabled = true;
      // wire.selected = true;
      // LRecordOnly.enabled = true;
      // this.umc?.dropdownDisable8 = true;
      this.disableText3 = true;
      this.tabCheckOption1 = tabValue1.map(x => new CheckboxItem(x.id, x.name, x.id == 1 || x.id == 2 || x.id == 7 ? true : false));
      this.omsTabs.filter(v => v.title == "WIRE")[0].disabled = false;
    } else if (this.selectedOrder == "PR" && this.selectedSubType == "CA") {
      this.disableText3 = true;
    } else {
      this.disableText3 = false;
      this.tabCheckOption1 = tabValue1.map(x => new CheckboxItem(x.id, x.name, x.id == 1 || x.id == 2 ? true : false));
      this.omsTabs.filter(v => v.title == "WIRE")[0].disabled = true;
      // supersedePanel.enabled = false;
      // supersede.selectedIndex = 0;
      // setNewCustomerInfo();
      // wire_Tab.enabled = false;
      // wire.selected = false;
      // LRecordOnly.enabled = false;
      // this.umc?.dropdownDisable8 = false;
    }
  }

  onChangeDate(val) {
    let month = val.month, day = val.day;
    if (0 < month && 10 > month) {
      month = `0${val.month}`
    }
    if (0 < day && 10 > day) {
      day = `0${val.day}`
    }
    this.selectedDueDate = `${val.year}-${month}-${day}`
  }

  selectedTab(id, tabSelection): any {
    //call your service which makes http call to get content for your selected tab
    let indexNo = id.nextId.replace(/[^0-9]/g, '');

    if (tabSelection[indexNo].label === "hsia") {
      this.router.navigateByUrl(this.omsUrl + '/hsia');
    } else if (tabSelection[indexNo].label === "wifi") {
      this.router.navigateByUrl(this.omsUrl + '/wifi');
    } else if (tabSelection[indexNo].label === "voip") {
      this.router.navigateByUrl(this.omsUrl + '/voip');
    } else if (tabSelection[indexNo].label === "iptv") {
      this.router.navigateByUrl(this.omsUrl + '/ipTv/main');
    } else if (tabSelection[indexNo].label === "wireless") {
      this.router.navigateByUrl(this.omsUrl + '/wireless');
    } else if (tabSelection[indexNo].label === "directv") {
      this.router.navigateByUrl(this.omsUrl + '/direcTv');
    } else if (tabSelection[indexNo].label === "wire") {
      this.router.navigateByUrl(this.omsUrl + '/wire');
    } else if (tabSelection[indexNo].label === "wap") {
      this.router.navigateByUrl(this.omsUrl + '/wap');
    } else if (tabSelection[indexNo].label === "ott") {
      this.router.navigateByUrl(this.omsUrl + '/ott');
    }
  }

  CreateOMSMessage(taskName, btnType) {
    this.changeVpi(this.ntiVal);
    this.changeIr(this.ntiVal);
    this.changeHsi(this.banValue, this.CircuitIdVal, this.textValue5, this.textValue4)

    const modalRef = this.modalService.open(ModelBoxComponent);
    if (btnType == "sendOrder") {
      modalRef.componentInstance.title = "Send Order";
      modalRef.componentInstance.type = "template3";
    } else {
      modalRef.componentInstance.title = "Complete XML Generation";
      modalRef.componentInstance.type = "template2";
    }
    console.log("wireCenter", this.wireCenterVal);

    let xml = this.generateXml(taskName, this.banValue, this.CircuitIdVal, this.wireCenterVal, this.ntiVal);
    modalRef.componentInstance.content = xml;

  }

  generateXml(taskName, banVal, circuitId, wireCenter, nti) {
    let loop;

    //cvoip
    let nonProductCatalogDataList_PV;
    if (this.subModule?.selectedCvoip == true) {
      nonProductCatalogDataList_PV = this.subModule?.NonProductCatalogDataList(this.subModule?.textValue4);
    } else {
      nonProductCatalogDataList_PV = "";
    }
    let retainedServicesList: String = null;
    let dslRetainedServicesList: String;

    //dslRetainedServicesList
    if (this.subContainer?.selectedretainedServicesProcessIndicator == true) {
      //set retainedServicesList if it is null
      if (retainedServicesList == null) {
        this.subContainer?.SetDslRetainedServicesList();
      }
      dslRetainedServicesList = retainedServicesList;
    } else {
      dslRetainedServicesList = "";
    }

    /* ACCS_Component PV*/
    let isWapDisabled = this.omsTabs.filter(v => v.title == "WAP")[0].disabled;
    // if (isWapDisabled == false) {
    //   this.ACCS_component_PV = this.getACCS_Comp(this.subModule?.selectedAction, this.banValue.slice(0, 8) + "80",
    //     install, this.subModule?.selectDropdownDeviceData1, this.subModule?.selectDropdownDeviceData2);
    // } else {
    //   this.ACCS_component_PV="";
    // }

    this.serviceFsp?.setTarCode();

    // if (loopIndicaton == "") {
    //   loop="";
    // } else {
    //   loop="<m2:attribute>\n"
    //     + "<m2:name>loopIndication</m2:name>\n"
    //     + "<m2:value>" + loopIndicaton + "</m2:value>\n"
    //     + "</m2:attribute>\n";
    // }

    return this.createXml(taskName, banVal, circuitId, wireCenter, nti);
  }

  createXml(taskName, banVal, circuitId, wireCenter, nti) {
    // serviceFsp values    
    let vhoCode = this.serviceFsp.selectValue;
    let primaryNpanxx = this.serviceFsp.textValue3;
    let rateCenterCode = this.serviceFsp.textValue4;
    let addressID = this.serviceFsp.textValue5;
    let houseNo = this.serviceFsp.textValue6;
    let streetName = this.serviceFsp.textValue7;
    let streetThoroughfare = this.serviceFsp.textValue8;
    let city = this.serviceFsp.textValue9;
    let state = this.serviceFsp.textValue10;
    let postalCode = this.serviceFsp.textValue11;
    let postalCodePlus4 = this.serviceFsp.textValue11a

    // customerInfo values
    let firstName = this.customerInfo.textValue1;
    let lastName = this.customerInfo.textValue2;
    let contactPhone = this.customerInfo.textValue3;
    let secondaryPhone = this.customerInfo.textValue4;
    let ubIndicator_FT = this.customerInfo.selectedUBIndicator;
    let subType = this.customerInfo.selectedSubType;
    let timeZone = this.customerInfo.selectedTimeZone;
    let title = this.customerInfo.selectedTitle;

    //umc values
    let uvOrderType = this.umc.selectedUvOrder
    let install = this.umc.selectedInstllType
    let techDispatch = this.umc.selectedTechDispatch
    let totalBandwidth = this.umc.selectedTotalBandwidth
    let loopIndicaton = this.umc.selectedLoopIndication

    // plst values
    let seventeenMhz = this.plst.selected17MHzFeature;
    let vectoringFeature = this.plst.selectedvectoringFeature;
    let originalVectoring = this.plst.selectedOriginalvectoringFeature;

    //nad values
    let modelNo = this.subContainer.selectedModel;

    this.setNonUverseActions();
    console.log("this.action--+++", this.action);

    // if (this.subContainer?.check3Disabled == false) {
    if (this.subContainer?.selectedNadSwap == true) {
      this.NAD_component = this.NAD_Comp(banVal, this.textValue5 + "2", this.selectedReference, this.CircuitIdVal,
        this.completionIndicator, this.umc?.selectedInstllType, this.umc?.selectedTechDispatch,
        this.subContainer?.selectedModelData2, this.subContainer?.selectedModelData1,
        this.subContainer?.selectedPrimaryModelData1,
        "<m2:actionIndicator>D</m2:actionIndicator>\n", "NA", this.recordOnlyAttribute,
        false, this.subContainer?.selectedUSPIndicator);
      this.NewNAD_component = this.NAD_Comp(banVal, this.textValue5 + "99", this.selectedReference, this.CircuitIdVal,
        this.completionIndicator, this.umc?.selectedInstllType, this.umc?.selectedTechDispatch, this.subContainer?.selectedModelData2,
        this.subContainer?.selectedModelData1, this.subContainer?.selectedPrimaryModelData1,
        "<m2:actionIndicator>I</m2:actionIndicator>\n", "NA", this.recordOnlyAttribute,
        true, this.subContainer?.selectedUSPIndicator);
    } else {
      this.NAD_component = this.NAD_Comp(banVal, this.textValue5 + "2", this.selectedReference,
        this.CircuitIdVal, this.completionIndicator, this.umc?.selectedInstllType,
        this.umc?.selectedTechDispatch, this.subContainer?.selectedModelData2, this.subContainer?.selectedModelData1,
        this.subContainer?.selectedPrimaryModelData1, this.action, "NA",
        this.recordOnlyAttribute, true, this.subContainer?.selectedUSPIndicator);
      this.NewNAD_component = "";
    }
    // } else {
    //   this.NAD_component = "";
    //   this.NewNAD_component = "";
    // }

    if (this.textValue2 == "") {
      this.uverseOrigOrdActId = this.textValue1;
    } else {
      this.uverseOrigOrdActId = this.textValue2;
    }

    //OrderActionReasonCode
    if (this.selectedOrderActionReasonCode == "") {
      this.reasonCode = "";
    } else {
      this.reasonCode = "<m2:orderActionReasonCode>" + this.selectedOrderActionReasonCode + "</m2:orderActionReasonCode>\n";
    }

    let isVoipDisabled = this.omsTabs.filter(v => v.title == "VOIP")[0].disabled;
    //salesChannel
    if (isVoipDisabled == false) {
      this.salesChannel = "<m2:salesChannel>" + this.subModule?.selectedSalesChannel + "</m2:salesChannel>\n";
      this.nonProductCatalogDataList = this.subModule?.NonProductCatalogDataList(this.subModule?.textValue4);
    } else {
      this.salesChannel = "";
      this.nonProductCatalogDataList = "";
    }

    //exhaustHoldIndicator
    if (loopIndicaton == "") {
      this.exhaustHoldIndicator = "";
    } else {
      this.exhaustHoldIndicator = "<m2:exhaustHoldIndicator>" + loopIndicaton + "</m2:exhaustHoldIndicator>\n";
    }

    //select Uverse vs NonUverse Components
    var cvoipTarCode: String;
    if ((this.serviceFsp?.textValue2.length > 0) && (this.serviceFsp?.disableText2 == false)) {
      cvoipTarCode = "<m2:tarCode>" + this.serviceFsp?.textValue2 + "</m2:tarCode>\n";
    } else {
      cvoipTarCode = "";
    }

    if (this.umc?.selectedUvOrder == "NA") {
      this.UMC_component = this.UMC_NoUverse_Comp();
      this.PLST_component = this.PLST_NoUverse_Comp();
      this.addressInfoServiceFSP = this.ServiceFSP(primaryNpanxx, wireCenter, this.serviceFsp?.textValue12, this.serviceFsp?.textValue13,
        this.ccid, this.serviceFsp?.textValue1, rateCenterCode, vhoCode, cvoipTarCode, houseNo, streetName,
        streetThoroughfare, city, state, postalCode, postalCodePlus4, firstName,
        lastName, addressID);
    } else {
      this.UMC_component = this.UMC_Comp();
      this.PLST_component = this.PLST_Comp();
      this.addressInfoServiceFSP = this.ServiceFSP(primaryNpanxx, wireCenter, this.serviceFsp?.textValue12, this.serviceFsp?.textValue13,
        this.ccid, this.serviceFsp?.textValue1, rateCenterCode, vhoCode, cvoipTarCode, houseNo,
        streetName, streetThoroughfare, city, state, postalCode, postalCodePlus4, firstName, lastName, addressID)
    }

    let isWireDisabled = this.omsTabs.filter(v => v.title == "WIRE")[0].disabled;
    if (isWireDisabled == false) {
      this.WIRE_component = this.WIRE_Comp();
    } else {
      this.WIRE_component = "";
    }

    let isWifiDisabled = this.omsTabs.filter(v => v.title == "WIFI")[0].disabled;

    if (isWifiDisabled == false) {
      this.WIFI_component = this.WIFI_Comp(this.banValue, this.selectedReference,
        this.subModule?.selectedCompletionIndicator, this.subModule?.selectedAction, "NA");
    } else {
      this.WIFI_component = "";
    }

    // if ((isVoipDisabled == false) && (voiceToggle.selectedIndex == 0)) {
    //   // this.CVOIP_component = this.CVOIP_Comp_NuT();
    // } else if ((isVoipDisabled == false) && (voiceToggle.selectedIndex == 1)) {
    //   this.CVOIP_component="";
    //   this.VDNASB_component = this.VDNASB_Comp();
    // } else {
    //   this.CVOIP_component="";
    //   this.VDNASB_component="";
    // }

    let isDirecTvDisabled = this.omsTabs.filter(v => v.title == "DIRECTV")[0].disabled;
    if (isDirecTvDisabled == false) {
      this.DTV_component
      // this.DTV_Comp(this.banValue, this.selectedReference, this.dtv?.selectedAction, "NA");
    } else {
      this.DTV_component = "";
    }

    let isWirelessDisabled = this.omsTabs.filter(v => v.title == "WIRELESS")[0].disabled;
    if (isWirelessDisabled == false) {
      this.WL_component = this.WL_Comp(this.banValue, this.selectedReference, this.subModule?.selectedAction, "NA");
    } else {
      this.WL_component = "";
    }

    if (this.disableText3 == false && this.textValue3.length > 1) {
      this.dslDisconnectTN = "<m2:dslDisconnectTns>" + this.textValue3 + "</m2:dslDisconnectTns>\n";
    } else {
      this.dslDisconnectTN = "";
    }

    if (this.textValue6.length > 1) {
      this.dslDisconnectTN2 = "<m2:dslDisconnectTns>" + this.textValue6 + "</m2:dslDisconnectTns>\n";
    } else {
      this.dslDisconnectTN2 = "";
    }

    if (this.subContainer?.configChecked == true) {
      //set relatedOrderInfo if it is null
      if (this.relatedOrderInfo == null) {
        this.SetStackedOrderData();
      }
      this.relatedOrderInfoList = this.relatedOrderInfo;
    } else {
      this.relatedOrderInfoList = "";
    }

    // if ((wllComp == "") && (tdarComp == "") && (wllVoiceComp == "") && (uverseComp == "")) {
    //   this.relatedProductOrderInfoUverse = "";
    // } else {
    //   this.relatedProductOrderInfoUverse = "<m2:relatedProductInfoList>\n"
    //     + wllComp
    //     + wllVoiceComp
    //     + tdarComp
    //     + uverseComp
    //     + "</m2:relatedProductInfoList>\n";
    // }

    // if (rpiUverseChkBox.selected) {
    //   this.relatedProductOrderInfoUv = this.relatedProductOrderInfoUverse;
    // } else {
    //   this.relatedProductOrderInfoUv = "";
    // }

    this.IPTV_Comp();
    this.ACCS_Comp();

    let header = `<SOAP-ENV:Envelope xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:m1="urn:soap.embus.sbc.com" xmlns:m2="http://lightspeed.bbnms.att.com/ordering" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">\n`
      + `<SOAP-ENV:Header>\n`
      + `<bbnmsOrderHeader:MessageHeader xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:bbnmsOrderHeader="http://lightspeed.bbnms.att.com/header">\n`
      + `<ns2:WSHeader xmlns:ns2="http://cio.att.com/commonheader/v3">\n`
      + `<ns2:WSContext>\n`
      + `<ns2:SourceIPAddress> 10.160.249.210 </ns2:SourceIPAddress>\n`
      + `</ns2:WSContext>\n`
      + `<ns2:WSMessageData>\n`
      + `<ns2:Timestamp> 2008-02-19T10:09:25.0440</ns2:Timestamp>\n`
      + `</ns2:WSMessageData>\n`
      + `<ns2:WSEnterpriseLogging>\n`
      + `<ns2:LoggingKey>TN:${this.textValue1}</ns2:LoggingKey>\n`
      + `</ns2:WSEnterpriseLogging>\n`
      + `</ns2:WSHeader>\n`
      + `<ns1:WSDiscovery xmlns:ns1="http://aftdiscovery.att.com/header/v1">\n`
      + `<ns1:name> MQSSL_ESB_J2EEEJB_ON_AIX </ns1:name>\n`
      + `<ns1:version>\n`
      + `<ns1:major> 3 </ns1:major>\n`
      + `<ns1:minor> 0 </ns1:minor>\n`
      + `</ns1:version>\n`
      + `<ns1:envContext> Y </ns1:envContext>\n`
      + `<ns1:bindingType> fusionBus </ns1:bindingType>\n`
      + `</ns1:WSDiscovery>\n`
      + `</bbnmsOrderHeader:MessageHeader>\n`
      + `</SOAP-ENV:Header>\n`
    console.log("due--->>>", this.dueDate);

    let body = "<SOAP-ENV:Body>\n"
      + "<m2:bbnmsOrder>\n"
      + '<m2:transactionInfo xmlns:bbnmsOrder="http://lightspeed.bbnms.att.com/ordering">\n'
      + "<m2:transactionId>" + this.textValue1 + "</m2:transactionId>\n"
      + "<m2:taskName>" + taskName + "</m2:taskName>\n"
      + "<m2:cvoipSdpProvisioningInd>true</m2:cvoipSdpProvisioningInd>\n"
      + "<m2:order>\n"
      + "<m2:orderActionInfoList>\n"
      + "<m2:orderActionInfo>\n"
      + "<m2:orderNumber>" + this.textValue1 + "</m2:orderNumber>\n"
      + "<m2:orderActionId>" + this.textValue1 + "</m2:orderActionId>\n"
      + "<m2:originalOrderActionId>" + this.uverseOrigOrdActId + "</m2:originalOrderActionId>\n"
      + "<m2:orderActionType>" + this.selectedOrder + "</m2:orderActionType>\n"
      + "<m2:orderActionSubType>" + this.selectedSubType + "</m2:orderActionSubType>\n"
      + "<m2:orderActionReferenceNumber>" + this.uverseOrigOrdActId + this.selectedReference + "</m2:orderActionReferenceNumber>\n"
      + "<m2:orderCreationDate>" + this.selectedDueDate + "T01:01:01</m2:orderCreationDate>\n"
      + "<m2:assignedProductId>" + this.textValue5 + "</m2:assignedProductId>\n"
      + "<m2:creationApplication>" + this.selectedCreationApp + "</m2:creationApplication>\n"
      + "<m2:bypassReasonCode>NONE</m2:bypassReasonCode>\n"
      + this.reasonCode
      + this.salesChannel
      + this.exhaustHoldIndicator
      + "<m2:dueDate>" + this.selectedDueDate + "T23:59:59</m2:dueDate>\n"
      + "<m2:appointment>\n"
      + "<m2:startTime>" + this.selectedDueDate + "T13:00:00</m2:startTime>\n"
      + "<m2:endTime>" + this.selectedDueDate + "T16:00:00</m2:endTime>\n"
      + "</m2:appointment>\n"
      + "<m2:orderActionStatus>DE</m2:orderActionStatus>\n"
      + "<m2:addressInfoList>\n"
      + "<m2:addressInfo>\n"
      + "<m2:addressType>LSBilling</m2:addressType>\n"
      + "<m2:fieldedAddress>\n"
      + "<m2:houseNumber>" + houseNo + "</m2:houseNumber>\n"
      + "<m2:streetName>" + streetName + "</m2:streetName>\n"
      + "<m2:streetThoroughfare>" + streetThoroughfare + "</m2:streetThoroughfare>\n"
      + "<m2:city>" + city + "</m2:city>\n"
      + "<m2:state>" + state + "</m2:state>\n"
      + "<m2:postalCode>" + postalCode + "</m2:postalCode>\n"
      + "<m2:postalCodePlus4>9999</m2:postalCodePlus4>\n"
      + "<m2:addressId>" + addressID + "</m2:addressId>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n"
      + "<m2:addressInfo>\n"
      + "<m2:addressType>ShippingFrom</m2:addressType>\n"
      + "<m2:fieldedAddress>\n"
      + "<m2:houseNumber>123</m2:houseNumber>\n"
      + "<m2:streetDirection>NE</m2:streetDirection>\n"
      + "<m2:streetName>MAIN</m2:streetName>\n"
      + "<m2:streetThoroughfare>ST</m2:streetThoroughfare>\n"
      + "<m2:streetNameSuffix>NE</m2:streetNameSuffix>\n"
      + "<m2:city>ST. LOUIS</m2:city>\n"
      + "<m2:state>MO</m2:state>\n"
      + "<m2:postalCode>63101</m2:postalCode>\n"
      + "<m2:postalCodePlus4>0000</m2:postalCodePlus4>\n"
      + "<m2:county>ST. LOUIS</m2:county>\n"
      + "<m2:country>USA</m2:country>\n"
      + "<m2:unitType>APT</m2:unitType>\n"
      + "<m2:addressId>" + addressID + "</m2:addressId>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n"
      + this.addressInfoServiceFSP
      + "<m2:addressInfo>\n"
      + "<m2:addressType>ServiceUSPS</m2:addressType>\n"
      + "<m2:fieldedAddress>\n"
      + "<m2:houseNumber>8000</m2:houseNumber>\n"
      + "<m2:streetName>FOREST CROSSING</m2:streetName>\n"
      + "<m2:city>LIVE OAK</m2:city>\n"
      + "<m2:state>TX</m2:state>\n"
      + "<m2:postalCode>78233</m2:postalCode>\n"
      + "<m2:postalCodePlus4>4338</m2:postalCodePlus4>\n"
      + "<m2:country>USA</m2:country>\n"
      + "<m2:cassAddressLines>\n"
      + "<m2:addressLine>8000 FOREST CROSSING </m2:addressLine>\n"
      + "<m2:addressLine>LIVE OAK,TX 78233 - 4338</m2:addressLine>\n"
      + "</m2:cassAddressLines>\n"
      + "<m2:addressId>" + addressID + "</m2:addressId>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n"
      + "<m2:addressInfo>\n"
      + "<m2:addressType>OSPBilling</m2:addressType>\n"
      + "<m2:fieldedAddress>\n"
      + "<m2:houseNumber>8000</m2:houseNumber>\n"
      + "<m2:streetName>FOREST CROSSING</m2:streetName>\n"
      + "<m2:city>LIVE OAK</m2:city>\n"
      + "<m2:state>TX</m2:state>\n"
      + "<m2:postalCode>78233</m2:postalCode>\n"
      + "<m2:postalCodePlus4>4338</m2:postalCodePlus4>\n"
      + "<m2:cassAddressLines>\n"
      + "<m2:addressLine>8000 FOREST CROSSING </m2:addressLine>\n"
      + "<m2:addressLine>LIVE OAK,TX 78233 - 4338</m2:addressLine>\n"
      + "</m2:cassAddressLines>\n"
      + "<m2:addressId>" + addressID + "</m2:addressId>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n"
      + "</m2:addressInfoList>\n"
      + "<m2:productList>\n"
      + "<m2:product>\n"
      + "<m2:name>AT&amp;T U-verse</m2:name>\n"
      + "<m2:componentList>\n"
      + "<m2:component>\n"
      + "<m2:assignedProductId>" + this.textValue5 + "0</m2:assignedProductId>\n"
      + "<m2:serviceType>UMC</m2:serviceType>\n"
      + this.uaction
      + this.UMC_component
      + "<m2:componentList>\n"
      + this.PLST_component
      + this.ACCS_component
      + this.WIRE_component
      + this.WIFI_component
      + this.HSIA_component
      // + this.VDNASB_component
      // + this.CVOIP_component
      // + IPTV_component
      // + this.DTV_component
      // + this.WL_component
      // + OTT_component
      + "</m2:componentList>\n"
      + "</m2:component>\n"
      + "</m2:componentList>\n"
      + "</m2:product>\n"
      + "</m2:productList>\n"
      // + nonProductCatalogDataList
      // + dslRetainedServicesList
      + "<m2:extendedDueDateIndicator>" + this.selectedExtendedDueDate + "</m2:extendedDueDateIndicator>\n"
      + "<m2:retainedServicesProcessIndicator>" + this.subContainer?.selectedretainedServicesProcessIndicator + "</m2:retainedServicesProcessIndicator>\n"
      + this.dslDisconnectTN
      // + this.dslDisconnectTN2
      // + this.relatedOrderInfoList
      // + this.relatedProductOrderInfoUv
      + "</m2:orderActionInfo>\n"
      + "</m2:orderActionInfoList>\n"
      + "<m2:customerInfoList>\n"
      // + newCustomerInfo
      + "<m2:customerInfo>\n"
      + "<m2:accountId>" + banVal + "</m2:accountId>\n"
      + "<m2:currentCustomerIndicator>" + this.currentCustInd + "</m2:currentCustomerIndicator>\n"
      + "<m2:name>" + firstName + " " + lastName + "</m2:name>\n"
      // + customerInfo_LUStatus
      + "<m2:type>I</m2:type>\n"
      + "<m2:subType>" + subType + "</m2:subType>\n"
      + "<m2:UBIndicator>" + ubIndicator_FT + "</m2:UBIndicator>\n"
      + "<m2:classOfService>" + this.customerInfo?.selectedClassOfService + "</m2:classOfService>\n"
      + "<m2:legalEntity>King</m2:legalEntity>\n"
      + "<m2:creditRiskClass>High</m2:creditRiskClass>\n"
      + "<m2:timeZoneOffset>" + timeZone + "</m2:timeZoneOffset>\n"
      + "<m2:billCycle>30</m2:billCycle>\n"
      + "<m2:billRound>2</m2:billRound>\n"
      + "<m2:customerInfoContactList>\n"
      + "<m2:customerInfoContact>\n"
      + "<m2:contactType>CU</m2:contactType>\n"
      + "<m2:title>" + title + "</m2:title>\n"
      + "<m2:firstName>" + firstName + "</m2:firstName>\n"
      + "<m2:lastName>" + lastName + "</m2:lastName>\n"
      + "<m2:phoneNumber>" + contactPhone + "</m2:phoneNumber>\n"
      + "<m2:secondaryPhoneNumber>" + secondaryPhone + "</m2:secondaryPhoneNumber>\n"
      // + customerInfoFbs
      + "</m2:customerInfoContact>\n"
      + "</m2:customerInfoContactList>\n"
      + "</m2:customerInfo>\n"
      + "</m2:customerInfoList>\n"
      + "</m2:order>\n"
      + "</m2:transactionInfo>\n"
      + "</m2:bbnmsOrder>\n"
      + "</SOAP-ENV:Body>\n"
      + "</SOAP-ENV:Envelope>";

    let mainXml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\nxmlns:ws="http://ws.sender.bbnms.att.com/">\n`
      + `<soapenv:Header/>\n`
      + `<soapenv:Body>\n`
      + `<ws:sendMessageToQueue>\n`
      + `<MessageSenderRequest_V2>\n`
      + `<environment>${this.enviornmentVal}</environment>\n`
      + `<queue>OMS</queue>\n`
      + `<message>`
      + `<![CDATA[\n`
      // <Place request xml> 
      + header + body
      + '\n]]></message>\n'
      + '</MessageSenderRequest_V2>\n'
      + '</ws:sendMessageToQueue>\n'
      + '</soapenv:Body>\n'
      + '</soapenv:Envelope>\n'

    return mainXml;
  }

  setNewCustomerInfo() {
    if (this.selectedOrder == "CW") {
      // NewCustomerInfo.enabled = true;
      this.currentCustInd = "false";
    }
    //  else if (supersede.selectedIndex > 1) {
    //   NewCustomerInfo.enabled = true;
    //   this.currentCustInd="false";
    // } 
    else {
      // NewCustomerInfo.enabled = false;
      this.currentCustInd = "true";
    }
    this.subContainer?.ccChange();
  }

  SetStackedOrderData() {
    this.relatedOrderInfo = "<m2:relatedOrderInfoList>\n"
      + "<m2:relatedOrderInfo>\n"
      + " <m2:orderNumber>" + this.textValue1 + "</m2:orderNumber>\n"
      + " <m2:originalOrderActionId>" + this.textValue1 + "</m2:originalOrderActionId>\n"
      + " <m2:UVOrderActionType>" + this.umc?.selectedUvOrder + "</m2:UVOrderActionType>\n"
      + " <m2:orderActionType>" + this.selectedOrder + "</m2:orderActionType>\n"
      + " <m2:orderActionSubType>" + this.selectedSubType + "</m2:orderActionSubType>\n"
      + " <m2:orderActionReferenceNumber>" + this.textValue1 + this.selectedReference + "</m2:orderActionReferenceNumber>\n"
      + " <m2:orderCreationDate>" + this.selectedDueDate + "T01:01:01.0Z</m2:orderCreationDate>\n"
      + " <m2:orderActionReasonCode>aa</m2:orderActionReasonCode>\n"
      + " <m2:dueDate>" + this.selectedDueDate + "T22:59:59.0Z</m2:dueDate>\n"
      + " <m2:orderRanking>1</m2:orderRanking>\n"
      + "</m2:relatedOrderInfo>\n"
      + "<m2:relatedOrderInfo>\n"
      + " <m2:orderNumber>" + this.textValue1 + "</m2:orderNumber>\n"
      + " <m2:originalOrderActionId>" + this.textValue1 + "</m2:originalOrderActionId>\n"
      + " <m2:UVOrderActionType>" + this.umc?.selectedUvOrder + "</m2:UVOrderActionType>\n"
      + " <m2:orderActionType>" + this.selectedOrder + "</m2:orderActionType>\n"
      + " <m2:orderActionSubType>" + this.selectedSubType + "</m2:orderActionSubType>\n"
      + " <m2:orderActionReferenceNumber>" + this.textValue1 + this.selectedReference + "</m2:orderActionReferenceNumber>\n"
      + " <m2:orderCreationDate>" + this.selectedDueDate + "T02:02:02.0Z</m2:orderCreationDate>\n"
      + " <m2:orderActionReasonCode>aa</m2:orderActionReasonCode>\n"
      + " <m2:dueDate>" + this.selectedDueDate + "T23:59:59.0Z</m2:dueDate>\n"
      + " <m2:orderRanking>2</m2:orderRanking>\n"
      + "</m2:relatedOrderInfo>\n"
      + "</m2:relatedOrderInfoList>";
  }

  CreateNotifyWAPActivation(orderNumber: String, type: String) {
    var notifyWAPActivation: String;
    let wap_Device_PV_Data1 = this.subModule.selectDropdownDevice.data1;
    let wap_Device_PV_Data2 = this.subModule.selectDropdownDevice.data2;
    let wap_NewDevice_PV_Data1 = this.subModule.selectDropdownNewDevice.data1;
    let wap_NewDevice_PV_Data2 = this.subModule.selectDropdownNewDevice.data2;

    if (type == "PV") {
      // notifyWAPActivation = this.subModule.NotifyWAPActivationResponse(this.banValue, this.subModule?.selectDropdownDeviceData1, wap_Device_PV.selectedItem.data2);
    } else {
      if (this.subModule.selectedWapChange == true) {
        notifyWAPActivation = this.subModule.NotifyWAPActivationResponse(this.banValue, wap_NewDevice_PV_Data1, wap_NewDevice_PV_Data2);
      } else {
        notifyWAPActivation = this.subModule.NotifyWAPActivationResponse(this.banValue, wap_Device_PV_Data1, wap_Device_PV_Data2);
      }
    }

    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = "Complete XML Generation";
    modalRef.componentInstance.type = "template2";
    modalRef.componentInstance.content = notifyWAPActivation;
  }

  ACCS_Comp() {
    var accsAction: String;
    var vdnarosw: String;
    var apComponent: String = "";
    var newApComponent: String = "";
    let isWapDisabled = this.omsTabs.filter(v => v.title == "WAP")[0].disabled;
    let isVoipDisabled = this.omsTabs.filter(v => v.title == "VOIP")[0].disabled;

    // if ((isVoipDisabled == false) && (voiceToggle.selectedIndex == 1)) {
    //   //set actionIndicator
    //   if (vdnasb_Action.text == "") {
    //     accsAction = "";
    //   } else {
    //     accsAction = "<m2:actionIndicator>" + vdnasb_Action.text + "</m2:actionIndicator>\n";
    //   }

    //   if (customerInfo_subType.selectedItem.data == "S") {
    //     vdnarosw = this.VDNARoSw_Comp("VDNARO", vdnasb_Action.text, "EdgeWater Networks", "Router",
    //       this.banValue + "RO", this.banValue.slice(0, 8) + "81");
    //   } else {
    //     vdnarosw = this.VDNARoSw_Comp("ROUTER", vdnasb_Action.text, "EdgeWater Networks", "Router",
    //       this.banValue + "RO", this.banValue.slice(0, 8) + "81");
    //   }

    //   if (switch_Type_1.enabled == true) {
    //     vdnarosw = vdnarosw + this.VDNARoSw_Comp("VDNASW", switch_Type_1_Action.selectedItem.data,
    //       "EdgeWater Networks", switch_Type_1.selectedItem.data, this.banValue + "SW1",
    //       this.banValue.slice(0, 8) + "82");
    //   }
    //   if (switch_Type_2.enabled == true) {
    //     vdnarosw = vdnarosw + this.VDNARoSw_Comp("VDNASW", switch_Type_2_Action.selectedItem.data,
    //       "EdgeWater Networks", switch_Type_2.selectedItem.data, this.banValue + "SW2",
    //       this.banValue.slice(0, 8) + "83");
    //   }

    //   this.ACCS_component = "<m2:component>\n"
    //     + "<m2:assignedProductId>" + this.textValue5 + "80</m2:assignedProductId>\n"
    //     + "<m2:serviceType>ACCS</m2:serviceType>\n"
    //     + accsAction
    //     + "<m2:attributeList>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>APID</m2:name>\n"
    //     + "<m2:value>" + this.textValue5 + "80</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>versionID</m2:name>\n"
    //     + "<m2:value>1</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>relationID</m2:name>\n"
    //     + "<m2:value>12345678</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>isSendToTeLS</m2:name>\n"
    //     + "<m2:value>None</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>timedLeasedRemoteCounter</m2:name>\n"
    //     + "<m2:value>value</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>timedLeasedRemoteTimestamp</m2:name>\n"
    //     + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>timedPurchasedRemoteCounter</m2:name>\n"
    //     + "<m2:value>value</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>timedPurchasedRemoteTimestamp</m2:name>\n"
    //     + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>totalLeasedRemoteCounter</m2:name>\n"
    //     + "<m2:value>value</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "<m2:attribute>\n"
    //     + "<m2:name>moveIndicator</m2:name>\n"
    //     + "<m2:value>NA</m2:value>\n"
    //     + "</m2:attribute>\n"
    //     + "</m2:attributeList>\n"
    //     + "<m2:componentList>\n"
    //     + vdnarosw
    //     + "</m2:componentList>\n"
    //     + "</m2:component>";

    // } else
    if (isWapDisabled == false) {
      //wap selected - true
      if (this.subModule?.selectedAction == "") {
        accsAction = "";
      } else {
        accsAction = "<m2:actionIndicator>" + this.subModule?.selectedAction + "</m2:actionIndicator>\n";
      }

      apComponent = this.AP_Comp(accsAction, this.textValue5 + "81", this.umc?.selectedInstllType,
        this.subModule?.selectDropdownDeviceData1, this.subModule?.selectDropdownDeviceData2);

      if (this.subModule?.selectedWapChange == true) {
        if (this.selectedOrder == "PR") {
          accsAction = "<m2:actionIndicator>I</m2:actionIndicator>\n";
        } else {
          accsAction = "<m2:actionIndicator>M</m2:actionIndicator>\n";
        }
        newApComponent = this.AP_Comp("<m2:actionIndicator>I</m2:actionIndicator>\n",
          this.textValue5 + "81", this.umc?.selectedInstllType, this.subModule?.selectDropdownNewDeviceData1,
          this.subModule?.selectDropdownNewDeviceData2);
      }

      this.ACCS_component = "<m2:component>\n"
        + "<m2:assignedProductId>" + this.textValue5 + "80</m2:assignedProductId>\n"
        + "<m2:serviceType>ACCS</m2:serviceType>\n"
        + accsAction
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>" + this.textValue5 + "80</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relationID</m2:name>\n"
        + "<m2:value>12345678</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>None</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>timedLeasedRemoteCounter</m2:name>\n"
        + "<m2:value>value</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>timedLeasedRemoteTimestamp</m2:name>\n"
        + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>timedPurchasedRemoteCounter</m2:name>\n"
        + "<m2:value>value</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>timedPurchasedRemoteTimestamp</m2:name>\n"
        + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>totalLeasedRemoteCounter</m2:name>\n"
        + "<m2:value>value</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>moveIndicator</m2:name>\n"
        + "<m2:value>NA</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + apComponent
        + newApComponent
        + "</m2:componentList>\n"
        + "</m2:component>";
    } else {
      this.ACCS_component = "";
    }
  }

  VDNARoSw_Comp(serviceType: String, actionInd: String, manufacturer: String, modelNumber: String, serialNumber: String, apid: String): String {
    var vaction: String;
    var VDNARoSw_component: String;

    if (actionInd == "") {
      vaction = "";
    } else {
      vaction = "<m2:actionIndicator>" + actionInd + "</m2:actionIndicator>\n";
    }

    VDNARoSw_component = "<m2:component>\n"
      + "<m2:assignedProductId>" + apid + "</m2:assignedProductId>\n"
      + "<m2:serviceType>" + serviceType + "</m2:serviceType>\n"
      + vaction
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + apid + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>12345678</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>actualMaterialCode</m2:name>\n"
      + "<m2:value>000000000100000283</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>actualMaterialDescription</m2:name>\n"
      + "<m2:value>Generic SWITCH</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>Optional</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>criticalFullfillment</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>Tech</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>manufacturer</m2:name>\n"
      + "<m2:value>" + manufacturer + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>materialCode</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>modelNumber</m2:name>\n"
      + "<m2:value>" + modelNumber + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>originalInstallationType</m2:name>\n"
      + "<m2:value>Tech</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>Parent Product Type</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>purchaseTerms</m2:name>\n"
      + "<m2:value>Rent</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reasonCode</m2:name>\n"
      + "<m2:value>Unknown</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>RMA</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>rpoApprovingManagerID</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>rpoBuyersRemorseExpirationDate</m2:name>\n"
      + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>rpoDateTime</m2:name>\n"
      + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>rpoWarrantyExpirationDate</m2:name>\n"
      + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sapOrderNumber</m2:name>\n"
      + "<m2:value>1234567890</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sapOrderStatus</m2:name>\n"
      + "<m2:value>N/A</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>serialNumber</m2:name>\n"
      + "<m2:value>" + serialNumber + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shipmentType</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shippingDate</m2:name>\n"
      + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>trackingNumber</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>trackingUrl</m2:name>\n"
      + "<m2:value>http://www.att.com</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>undeliverableReasonCode</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>deviceID</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>altMaterialCode</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>groupID</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>";
    return VDNARoSw_component;
  }

  IPTV_Comp() {
    var iaction: String;
    var gpaction: String;
    var stbaction: String;
    var GP: String;
    var STB: String;
    var M, N;
    var DVR: String;
    var hdSdDefinition: String;
    var enableHighDefinition: String;

    var stbreset: String;
    //set actionIndicators
    if (this.subModule?.selectedAction == "") {
      iaction = "";
    } else {
      iaction = "<m2:actionIndicator>" + this.subModule?.selectedAction + "</m2:actionIndicator>\n";
    }

    if (this.subModule?.selectedHDService == "Y") {
      hdSdDefinition = "HD";
      enableHighDefinition = "Allow";
    } else {
      hdSdDefinition = "SD";
      enableHighDefinition = "Disallow";
    }

    GP = "";
    M = parseInt(this.subModule?.selectedGps);
    // var gpType:Array = new Array(GP_1.text, GP_2.text, GP_3.text, GP_4.text, GP_5.text, GP_6.text, GP_7.text, GP_8.text);
    // var gpAction:Array = new Array(GP_Action_1.text, GP_Action_2.text, GP_Action_3.text, GP_Action_4.text, GP_Action_5.text, GP_Action_6.text, GP_Action_7.text, GP_Action_8.text);
    var gpType, gpAction
    while (M > 0) {
      if (gpAction[M - 1] == "") {
        gpaction = "";
      } else {
        gpaction = "<m2:actionIndicator>" + gpAction[M - 1] + "</m2:actionIndicator>\n";
      }

      GP = GP
        + "<m2:component>\n"
        + "<m2:assignedProductId>" + this.textValue5 + "2" + M + "</m2:assignedProductId>\n"
        + "<m2:serviceType>GP</m2:serviceType>\n"
        + gpaction
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + `<m2:value> ${this.textValue5} 2 ${M} </m2:value>\n`
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>" + ((this.selectedReference.charCodeAt(0)) - 64) + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relationID</m2:name>\n"
        + "<m2:value>2108337</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>amssDisplaySequence</m2:name>\n"
        + "<m2:value>700</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>amssRefresh</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>availableForSelfInstall</m2:name>\n"
        + "<m2:value>Automatic</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>creditPolicyRestriction</m2:name>\n"
        + "<m2:value>Z</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DefaultDisplayOrder</m2:name>\n"
        + "<m2:value>400</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
        + "<m2:value>N</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>fulfillmentIndicator</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>genrePackage</m2:name>\n"
        + "<m2:value>" + gpType[M - 1] + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ParentProductType</m2:name>\n"
        + "<m2:value>VD</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>restrictedContent</m2:name>\n"
        + "<m2:value>1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>completionIndicator</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedCompletionIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>offerSalesMode</m2:name>\n"
        + "<m2:value>Lead</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>hideComponent</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>inventoryComponentType</m2:name>\n"
        + "<m2:value>GP</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>Child</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>removeComponent</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>moveIndicator</m2:name>\n"
        + "<m2:value>NA</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n";

      M = M - 1;

    }

    STB = "";
    N = parseInt(this.subModule?.selectedSTBs);
    // var stbType:Array = new Array(STB_Type_1.text, STB_Type_2.text, STB_Type_3.text, STB_Type_4.text, STB_Type_5.text, STB_Type_6.text, STB_Type_7.text, STB_Type_8.text);
    // var stbAction:Array;
    // if ((SubType.text == "CA") || (OrderAction.text == "RS") || (OrderAction.text == "SR") || (OrderAction.text == "SS") || (OrderAction.text == "SU")) {
    //   stbAction = new Array("", "", "", "", "", "", "", "");
    // }
    // else {
    //   stbAction = new Array(STB_Action_1.text, STB_Action_2.text, STB_Action_3.text, STB_Action_4.text, STB_Action_5.text, STB_Action_6.text, STB_Action_7.text, STB_Action_8.text);
    // }
    var stbReset = new Array("", "", "", "", "", "", "", "");
    // if (OrderAction.text == "CW") {
    //   stbReset = new Array(STB_Reset_1.text, STB_Reset_2.text, STB_Reset_3.text, STB_Reset_4.text, STB_Reset_5.text, STB_Reset_6.text, STB_Reset_7.text, STB_Reset_8.text);
    // }
    while (N > 0) {
      if (N == 1) {
        // if (STB_Type_1.text == "HDSD With DVR") {
        //   DVR="Y";
        // } else if (STB_Type_1.text == "SD With DVR") {
        //   DVR="Y";
        // } else {
        //   DVR="N";
        // }
      } else {
        DVR = "N";
      }

      // if (stbAction[N - 1] == "") {
      //   stbaction="";
      // } else {
      //   stbaction="<m2:actionIndicator>" + stbAction[N - 1] + "</m2:actionIndicator>\n";
      // }

      if (stbReset[N - 1] == "") {
        stbreset = "";
      } else {
        stbreset = "<m2:attribute>\n"
          + "<m2:name>stbReset</m2:name>\n"
          + "<m2:value>" + stbReset[N - 1] + "</m2:value>\n"
          + "</m2:attribute>\n";
      }

      STB = STB
        + "<m2:component>\n"
        + "<m2:assignedProductId>" + this.textValue5 + "3" + N + "</m2:assignedProductId>\n"
        + "<m2:serviceType>STB</m2:serviceType>\n"
        // + stbaction
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>" + this.textValue5 + "3" + N + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>" + ((this.selectedReference.charCodeAt(0)) - 64) + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>amssDisplaySequence</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>amssRefresh</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>pipeCircuitId</m2:name>\n"
        + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>cpeRoomLocation</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DefaultDisplayOrder</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>deviceID</m2:name>\n"
        + "<m2:value>STB" + N + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>Dvr</m2:name>\n"
        + "<m2:value>" + DVR + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>sapOrderNumber</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>sapOrderStatus</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>freeStbIndication</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>HDSDDefinition</m2:name>\n"
        + "<m2:value>" + hdSdDefinition + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>manufacturer</m2:name>\n"
        + "<m2:value>Unknown</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>modelNumber</m2:name>\n"
        + "<m2:value>Unknown</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>materialCode</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProductFamily</m2:name>\n"
        + "<m2:value>LightSpeed</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>SB</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>purchaseTerms</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>RMA</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>salesOfferMode</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>serialNumber</m2:name>\n"
        + "<m2:value>Unknown</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shippingDate</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shippingIndicator</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>stbType</m2:name>\n"
        // + "<m2:value>" + stbType[N - 1] + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>Stream</m2:name>\n"
        + "<m2:value>1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>technicianDispatchIndicator</m2:name>\n"
        + "<m2:value>" + this.umc?.selectedTechDispatch + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>installationType</m2:name>\n"
        + "<m2:value>" + this.umc?.selectedInstllType + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>availableForSelfInstall</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>trackingNumber</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>trackingUrl</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>criticalFulfillment</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shipmentType</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>fulfillmentIndicator</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>completionIndicator</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedCompletionIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + stbreset
        + "<m2:attribute>\n"
        + "<m2:name>actualMaterialCode</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>actualMaterialDescription</m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>compStatus </m2:name>\n"
        + "<m2:value>validAttributeValue</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>moveIndicator</m2:name>\n"
        + "<m2:value>NA</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n";

      N = N - 1;

    }
    let isIptvDisabled = this.omsTabs.filter(v => v.title == "IPTV")[0].disabled;
    if (isIptvDisabled == false) {
      this.IPTV_component = "<m2:component>\n"
        + "<m2:assignedProductId>" + this.textValue5 + "20</m2:assignedProductId>\n"
        + "<m2:serviceType>VBP</m2:serviceType>\n"
        + iaction
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>" + this.textValue5 + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>versionID</m2:name>\n"
        + "<m2:value>" + ((this.selectedReference.charCodeAt(0)) - 64) + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>relationID</m2:name>\n"
        + "<m2:value>2107711</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>amssDisplaySequence</m2:name>\n"
        + "<m2:value>300</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>AMSSDefaultInd</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>AMSS_LinkInd</m2:name>\n"
        + "<m2:value>Yahoo_DVR_Link:SDP_Link</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>amssRefresh</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>sbcAffiliate</m2:name>\n"
        + "<m2:value>LightSpeed</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>actualMaterialCode</m2:name>\n"
        + "<m2:value>000000000100000270</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>actualMaterialDescription</m2:name>\n"
        + "<m2:value>Generic U-TV Services BOM</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>enableHighDefinition</m2:name>\n"
        + "<m2:value>" + enableHighDefinition + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>availBasicPackage</m2:name>\n"
        // + "<m2:value>" + iptv_Package.text + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>availableForSelfInstall</m2:name>\n"
        + "<m2:value>NA</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>RequestedPackage</m2:name>\n"
        // + "<m2:value>" + iptv_Package.text + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>pipeCircuitId</m2:name>\n"
        + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>componentBandwidth</m2:name>\n"
        + "<m2:value>23.4</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>compStatus</m2:name>\n"
        + "<m2:value>AC</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>criticalFullfillment</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>CustomerAcceptanceIPTV</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>DefaultDisplayOrder</m2:name>\n"
        + "<m2:value>300</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>sapOrderNumber</m2:name>\n"
        + "<m2:value>0002070395</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>sapOrderStatus</m2:name>\n"
        + "<m2:value>Shipped</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>eligibleForPrepayment</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
        + "<m2:value>Y</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>fulfillmentIndicator</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>HD_STREAM_QTY</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedHDStreams + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>HDSDStreamChangeInd</m2:name>\n"
        + "<m2:value>N</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>question2</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>question3</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>installationType</m2:name>\n"
        + "<m2:value>" + this.umc?.selectedInstllType + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>lastRecommendHdSdQty</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedHDStreams + "HD" + this.subModule?.selectedSDStreams + "SD</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>Last_Available_Basic_Package</m2:name>\n"
        // + "<m2:value>" + iptv_Package.text + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>Last_available_Basic_Package</m2:name>\n"
        + "<m2:value>Thick</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>materialCode</m2:name>\n"
        + "<m2:value>100000270</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>numberOfTvs</m2:name>\n"
        + "<m2:value>1</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>OMS_QA_COMPONENT_NAME</m2:name>\n"
        + "<m2:value>QVideoBasic</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ppvIndicator</m2:name>\n"
        + "<m2:value>Allow</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProductFamily</m2:name>\n"
        + "<m2:value>LightSpeed</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ProdType</m2:name>\n"
        + "<m2:value>VD</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>programGuide</m2:name>\n"
        + "<m2:value>None</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>hdSDCombinations</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedHDStreams + "HD" + this.subModule?.selectedSDStreams + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>purchaseTerms</m2:name>\n"
        + "<m2:value>Purchase</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>RMA</m2:name>\n"
        + "<m2:value>N</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>setRecommendHdSdQty</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedHDStreams + "HD" + this.subModule?.selectedSDStreams + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>SbpValue</m2:name>\n"
        + "<m2:value>0</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>SD_STREAM_QTY</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedSDStreams + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>modifiedIndicator</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>completionIndicator</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedCompletionIndicator + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>offerSalesMode</m2:name>\n"
        + "<m2:value>Lead</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shipmentType</m2:name>\n"
        + "<m2:value>NotApplicable</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shippingDate</m2:name>\n"
        + "<m2:value>2009-04-25T00:00:00</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>shippingIndicator</m2:name>\n"
        + "<m2:value>Tech</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>technicianDispatchIndicator</m2:name>\n"
        + "<m2:value>" + this.umc?.selectedTechDispatch + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>telegenceId</m2:name>\n"
        + "<m2:value>" + this.textValue4 + "20</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>uverseTechnology</m2:name>\n"
        + "<m2:value>PLS</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>VHO</m2:name>\n"
        + "<m2:value>" + this.serviceFsp?.textValue14 + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>vodIndicator</m2:name>\n"
        + "<m2:value>Allow</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>welcomeKit</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>question4</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>hideComponent</m2:name>\n"
        + "<m2:value>No</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>inventoryComponentType</m2:name>\n"
        + "<m2:value>IPTV</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>isSendToTeLS</m2:name>\n"
        + "<m2:value>Parent</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>removeComponent</m2:name>\n"
        + "<m2:value>Yes</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>moveIndicator</m2:name>\n"
        + "<m2:value>NA</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "<m2:componentList>\n"
        + GP
        + STB
        + "</m2:componentList>\n"
        + "</m2:component>\n";
    } else {
      this.IPTV_component = "";
    }

  }

  VDNASB_Comp(): String {
    var vaction: String;

    //set actionIndicators
    // if (vdnasb_Action.text == "") {
    //   vaction="";
    // } else {
    //   vaction="<m2:actionIndicator>" + vdnasb_Action.text + "</m2:actionIndicator>\n";
    // }

    this.VDNASB_component = "<m2:component>\n"
      + "<m2:assignedProductId>" + this.textValue5 + "70</m2:assignedProductId>\n"
      + "<m2:serviceType>VDNASB</m2:serviceType>\n"
      + vaction
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.textValue5 + "70</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + ((this.selectedReference.charCodeAt(0)) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>12345678</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>numberOfStations</m2:name>\n"
      // + "<m2:value>" + vdnasb_numberOfStations.text + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>numberOfSIPPhones</m2:name>\n"
      // + "<m2:value>" + vdnasb_numberOfSIPPhones.text + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>BVOIPLeadName</m2:name>\n"
      + "<m2:value>Test Er</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>BVOIPLeadContact</m2:name>\n"
      + "<m2:value>4045551234</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";

    return this.VDNASB_component;
  }

  DTV_Comp(ban: String, reference: String, actionInd: String, move: String): String {
    var action: String;
    var dtv_Component: String;
    var dtv_cpe: String;
    var M: any;
    var actiontype: String;

    var DTV_CPX: String;

    dtv_cpe = "";
    // M = parseInt(dtvCpeNum.text);

    // var cpeType = new Array(dtvCpeType1.text, dtvCpeType2.text, dtvCpeType3.text, dtvCpeType4.text, dtvCpeType5.text, dtvCpeType6.text);
    // var actionType = new Array(dtvCpeActionInd1.text, dtvCpeActionInd2.text, dtvCpeActionInd3.text, dtvCpeActionInd4.text, dtvCpeActionInd5.text, dtvCpeActionInd6.text);
    let cpeType, actionType
    //add DTV CPE component
    while (M > 0) {
      if (actionType[M - 1] == "") {
        actiontype = "";
      } else {
        actiontype = "<m2:actionIndicator>" + actionType[M - 1] + "</m2:actionIndicator>\n"
      }

      dtv_cpe = dtv_cpe
        + "<m2:component>\n"
        + "<m2:assignedProductId>8712948531" + M + "</m2:assignedProductId>\n"
        + "<m2:serviceType>DTVCP</m2:serviceType>\n"
        + actiontype
        + "<m2:attributeList>\n"
        + "<m2:attribute>\n"
        + "<m2:name>APID</m2:name>\n"
        + "<m2:value>8712948531" + M + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>CPEOwnership</m2:name>\n"
        + "<m2:value>ATT</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>CPEType</m2:name>\n"
        + "<m2:value>" + cpeType[M - 1] + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "</m2:attributeList>\n"
        + "</m2:component>\n";

      M = M - 1;
    }

    if (dtv_cpe == "") {
      DTV_CPX = "";
    } else {
      DTV_CPX = "<m2:componentList>\n"
        + dtv_cpe
        + "</m2:componentList>\n";
    }

    if (actionInd == "") {
      action = "";
    } else {
      action = "<m2:actionIndicator>" + actionInd + "</m2:actionIndicator>\n";
    }

    dtv_Component = "<m2:component>\n"
      + "<m2:assignedProductId>" + ban.slice(0, 8) + "80</m2:assignedProductId>\n"
      + "<m2:serviceType>DTV</m2:serviceType>\n"
      + action
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + ban.slice(0, 8) + "80</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + (reference?.charCodeAt(0) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>C1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isPartOfPackage</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ServiceDueDate</m2:name>\n"
      + "<m2:value>null</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>" + move + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DIRECTVAccountID</m2:name>\n"
      + "<m2:value>" + ban + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>dtvOrderNumber</m2:name>\n"
      + "<m2:value>" + this.textValue1 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DerivedSDIndicator</m2:name>\n"
      // + "<m2:value>" + SdIndFlag.selectedItem.data + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + DTV_CPX
      + "</m2:component>\n"

    return dtv_Component;
  }

  WL_Comp(ban: String, reference: String, actionInd: String, move: String): String {
    var action: String;
    var wl_Component: String;

    if (actionInd == "") {
      action = "";
    }
    else {
      action = "<m2:actionIndicator>" + actionInd + "</m2:actionIndicator>\n";
    }

    wl_Component = "<m2:component>\n"
      + "<m2:assignedProductId>6712948529</m2:assignedProductId>\n"
      + "<m2:serviceType>CWSBAN</m2:serviceType>\n"
      + action
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + ban.slice(0, 8) + "82</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>8509701</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>currentBillCycle</m2:name>\n"
      + "<m2:value>23/11/2014 00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>WCCreditIndication</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isPartOfPackage</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>WCbillCycle</m2:name>\n"
      + "<m2:value>22</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>Market</m2:name>\n"
      + "<m2:value>GAC</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>authenticationIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>BanID</m2:name>\n"
      + "<m2:value>534157938602</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>BANStatus</m2:name>\n"
      + "<m2:value>good</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>wirelessCustomerInd</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedWirelessCustomerInd + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>billCycleCloseDay</m2:name>\n"
      + "<m2:value>22</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>convergePendingInd</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>currentBillCycle</m2:name>\n"
      + "<m2:value>good</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>subMarket</m2:name>\n"
      + "<m2:value>033</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "<m2:componentList>\n"
      + "<m2:component>\n"
      + "<m2:assignedProductId>6712948532</m2:assignedProductId>\n"
      + "<m2:serviceType>CWSCTN</m2:serviceType>\n"
      + action
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + ban.slice(0, 8) + "83</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>serviceID</m2:name>\n"
      + "<m2:value>6782014501</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>8509702</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isNew</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>CTNprimaryLine_SDG</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ServiceDueDate</m2:name>\n"
      + "<m2:value>2014-12-21T15:21:54</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>deviceUpgrade</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>M</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>primaryIndFromMobility</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>SDG</m2:name>\n"
      + "<m2:value>true</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ETFType</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installPlanState</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ratePlan</m2:name>\n"
      + "<m2:value>913050909</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>tentativePrimaryInd</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>CTNNumber</m2:name>\n"
      + "<m2:value>6782014501</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>zip</m2:name>\n"
      + "<m2:value>30312</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>CTNStatus</m2:name>\n"
      + "<m2:value>R</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isPartOfPackage</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>CTNprimaryLine</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>SDG_Number</m2:name>\n"
      + "<m2:value>Mobile Share Group 2</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>subMarket</m2:name>\n"
      + "<m2:value>033</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n"
      + "</m2:componentList>\n"
      + "</m2:component>\n";

    return wl_Component;
  }

  WIFI_Comp(ban: String, reference: String, completion: String, actionInd: String, move: String): String {
    var action: String;
    var wifi_Component: String;

    if (actionInd == "") {
      action = "";
    } else {
      action = "<m2:actionIndicator>" + actionInd + "</m2:actionIndicator>\n";
    }

    wifi_Component = "<m2:component>\n"
      + "<m2:assignedProductId>" + this.textValue5 + "3</m2:assignedProductId>\n"
      + "<m2:serviceType>FL</m2:serviceType>\n"
      + action
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.textValue5 + "3</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + (reference?.charCodeAt(0) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2000035</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>3000</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>Automatic</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DefaultDisplayOrder</m2:name>\n"
      + "<m2:value>900</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>completionIndicator</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedCompletionIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>removeComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>inventoryComponentType</m2:name>\n"
      + "<m2:value>WiFi</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hideComponent</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>wifiIndicator</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>" + move + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";

    return wifi_Component;
  }

  WIRE_Comp(): String {
    var wireAction: String;
    var wiringComp: String = "";
    var numOfWiring;
    var wire_Component: String = "";

    //set actionIndicators
    if (this.selectedOrder + this.selectedSubType == "PRCA") {
      wireAction = "";
    } else if ((this.selectedSubType == "CA") || (this.selectedOrder == "RS") || (this.selectedOrder == "SR") || (this.selectedOrder == "SS") || (this.selectedOrder == "SU")) {
      wireAction = "";
    } else {
      wireAction = "<m2:actionIndicator>I</m2:actionIndicator>\n";
    }

    numOfWiring = parseInt(this.subModule?.selectedMoveNAD) + parseInt(this.subModule?.selectedMoveNID)
      + parseInt(this.subModule?.selectedWiringCVOIP) + parseInt(this.subModule?.selectedWiringHSIA) +
      parseInt(this.subModule?.seelctedWiringVideoBasic) + parseInt(this.subModule?.selectedDropWire);

    if (numOfWiring > 0) {
      while (numOfWiring > 0) {
        wiringComp = this.WIRING_Comp();
        numOfWiring = numOfWiring - 1;
      }
      wiringComp = "<m2:componentList>\n"
        + wiringComp
        + "</m2:componentList>\n";
    }

    wire_Component = "<m2:component>\n"
      + "<m2:assignedProductId>" + this.banValue.slice(0, 8) + "95</m2:assignedProductId>\n"
      + "<m2:serviceType>WIRE</m2:serviceType>\n"
      + wireAction
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.banValue.slice(0, 8) + "95</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>12345678</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>MoveNAD</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedMoveNAD + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>MoveNID</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedMoveNID + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>WiringCVOIP</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedWiringCVOIP + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>WiringHSIA</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedWiringHSIA + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>WiringVideoBasic</m2:name>\n"
      + "<m2:value>" + this.subModule?.seelctedWiringVideoBasic + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DropWire</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedDropWire + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + wiringComp
      + "</m2:component>\n";

    return wire_Component;

  }

  WIRING_Comp() {
    var wiringAction: String;
    var wiring_component: String;

    //set actionIndicators
    if (this.selectedOrder + this.selectedSubType == "PRCA") {
      wiringAction = "";
    } else if ((this.selectedSubType == "CA") || (this.selectedOrder == "RS") || (this.selectedOrder == "SR") || (this.selectedOrder == "SS") || (this.selectedOrder == "SU")) {
      wiringAction = "";
    } else {
      wiringAction = "<m2:actionIndicator>I</m2:actionIndicator>\n";
    }


    wiring_component = "<m2:component>\n"
      + "<m2:assignedProductId>" + this.banValue.slice(0, 8) + "96</m2:assignedProductId>\n"
      + "<m2:serviceType>WIRING</m2:serviceType>\n"
      + wiringAction
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.banValue.slice(0, 8) + "96</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>12345678</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>Parent Product Type</m2:name>\n"
      + "<m2:value>C1</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>";

    return wiring_component;

  }

  NAD_Comp(ban: String, apid: String, reference: String, circuit: String, completion: String,
    install: String, dispatch: String, nadType: String, modelNumber: String, primaryModelNumber: String,
    action: String, move: String, recordOnlyAttribute: String, isPrimaryReq: Boolean, Uspindicator: String): String {
    console.log("action!!!!!", action);

    var nad_Component: String;
    var manufacturer: String;
    var primaryManufacturer: String;

    if (modelNumber == "2210-02-1ATT" || modelNumber == "NM55") {
      manufacturer = "Motorola";
    } else if (modelNumber.substr(0, 3) == "NVG595") {
      manufacturer = "ARRIS";
    } else if (modelNumber.substr(0, 3) == "NVG") {
      manufacturer = "Motorola";
    } else if (modelNumber.substr(0, 3) == "BGW") {
      manufacturer = "ARRIS";
    } else {
      manufacturer = "2Wire";
    }

    if (primaryModelNumber == "2210-02-1ATT" || primaryModelNumber == "NM55") {
      primaryManufacturer = "Motorola";
    } else if (primaryModelNumber.substr(0, 3) == "NVG595") {
      primaryManufacturer = "ARRIS";
    } else if (primaryModelNumber.substr(0, 3) == "NVG") {
      primaryManufacturer = "Motorola";
    } else if (primaryModelNumber.substr(0, 3) == "BGW") {
      primaryManufacturer = "ARRIS";
    } else {
      primaryManufacturer = "2Wire";
    }

    var rgreset: String;

    if (this.selectedOrder == 'CW') {
      rgreset = "<m2:attribute>\n"
        + "<m2:name>rgReset</m2:name>\n"
        + "<m2:value>" + this.subModule?.selectedRgReset + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      rgreset = "";
    }
    var primaryNAD: String;

    if (isPrimaryReq == true) {
      primaryNAD = "<m2:attribute>\n"
        + "<m2:name>primarymaterialCode</m2:name>\n"
        + "<m2:value>100000611</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>primarymodelNumber</m2:name>\n"
        + "<m2:value>" + primaryModelNumber + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>primarymanufacturer</m2:name>\n"
        + "<m2:value>" + primaryManufacturer + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      primaryNAD = "";
    }

    let xml = "<m2:component>\n"
      + "<m2:assignedProductId>" + apid + "</m2:assignedProductId>\n"
      + "<m2:serviceType>RG</m2:serviceType>\n"
      + action
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + apid + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + (reference.charCodeAt(0) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2000006</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>2900</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + rgreset
      + "<m2:attribute>\n"
      + "<m2:name>actualMaterialCode</m2:name>\n"
      + "<m2:value>000000000100000283</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>actualMaterialDescription</m2:name>\n"
      + "<m2:value>Generic RG BOM</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>criticalFullfillment</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DefaultDisplayOrder</m2:name>\n"
      + "<m2:value>100</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sapOrderNumber</m2:name>\n"
      + "<m2:value>0002070395</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sapOrderStatus</m2:name>\n"
      + "<m2:value>Shipped</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fttxInput</m2:name>\n"
      + "<m2:value>FTTX</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>" + install + "</m2:value>\n"
      + "</m2:attribute>\n"
      + primaryNAD
      + "<m2:attribute>\n"
      + "<m2:name>materialCode</m2:name>\n"
      + "<m2:value>100000610</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>modelNumber</m2:name>\n"
      + "<m2:value>" + modelNumber + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>manufacturer</m2:name>\n"
      + "<m2:value>" + manufacturer + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>USPIndicator</m2:name>\n"
      + "<m2:value>" + Uspindicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>internalWAPIndicator</m2:name>\n"
      + "<m2:value>" + this.subContainer?.selectedInternalWapInd + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>NADExist</m2:name>\n"
      + "<m2:value>UNKNOWN</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>rgId</m2:name>\n"
      + "<m2:value>" + circuit + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>NADKitType</m2:name>\n"
      + "<m2:value>UNKNOWN</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>RGReplacementFlag</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>nadType</m2:name>\n"
      + "<m2:value>" + nadType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>numAtaPorts</m2:name>\n"
      + "<m2:value>2</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>purchaseTerms</m2:name>\n"
      + "<m2:value>Rent</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>RMA</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reasonCode</m2:name>\n"
      + "<m2:value>Unknown</m2:value>\n"
      + "</m2:attribute>\n"
      // + recordOnlyAttribute
      + "<m2:attribute>\n"
      + "<m2:name>completionIndicator</m2:name>\n"
      + "<m2:value>" + completion + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shipmentType</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shippingDate</m2:name>\n"
      + "<m2:value>2008-10-25T00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shippingIndicator</m2:name>\n"
      + "<m2:value>Tech</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>technicianDispatchIndicator</m2:name>\n"
      + "<m2:value>" + dispatch + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hideComponent</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>inventoryComponentType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>Child</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>removeComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>" + move + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";

    return xml;
  }

  UMC_NoUverse_Comp() {
    let umcCompletionIndicator: String;
    let umc_LUStatus: String;
    let unifyDeunifyIndicator: String = "";

    if (this.umc?.dropdownDisable8 == false) {
      unifyDeunifyIndicator = "<m2:attribute>\n"
        + "<m2:name>unifyDeunifyIndicator</m2:name>\n"
        + "<m2:value>" + this.umc?.selctedunifydeunifyInd + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      unifyDeunifyIndicator = "";
    }

    if (this.selectedOrder + this.selectedSubType == "PRCA") {
      umcCompletionIndicator = "NA";
    } else if ((this.selectedSubType == "CA") || (this.selectedOrder == "RS") || (this.selectedOrder == "SR") || (this.selectedOrder == "SS") || (this.selectedOrder == "SU")) {
      umcCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CE") {
      umcCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CH") {
      umcCompletionIndicator = "CO";
    } else {
      umcCompletionIndicator = "NA";
    }

    if (this.subContainer?.selectedCC == "Y") {
      umc_LUStatus = "<m2:attribute>\n"
        + "<m2:name>luStatus</m2:name>\n"
        + "<m2:value>" + this.subContainer?.selectedLUStatus + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      umc_LUStatus = "";
    }

    let selectedOrderCode;
    if (this.umc?.selectedOrderReasonCode == "") {
      selectedOrderCode = "<m2:value/>\n"
    } else {
      selectedOrderCode = "<m2:value>" + this.umc?.selectedOrderReasonCode + "</m2:value>\n"
    }

    let xml = "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.textValue5 + "0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + ((this.selectedReference?.charCodeAt(0)) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>orderActionID</m2:name>\n"
      + "<m2:value>" + this.textValue1 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>customerID</m2:name>\n"
      + "<m2:value>101494978</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>serviceID</m2:name>\n"
      + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2107709</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>UVOrderActionType</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedUvOrder + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>orderReasonCode</m2:name>\n"
      + selectedOrderCode
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>managerOverrideInd</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>100</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssInstallOption</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedInstllType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedInstllType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>technicianDispatchIndicator</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedTechDispatch + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>AMSS_LinkInd</m2:name>\n"
      + "<m2:value>Yahoo_DVR_Link:SDP_Link</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ADPI_isRequired</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableBandwidth</m2:name>\n"
      + "<m2:value>30.86</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>bandwidthSource</m2:name>\n"
      + "<m2:value>E</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>bandwidthUOM</m2:name>\n"
      + "<m2:value>MEGABITS_PER_SECOND</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>chngFrmCsiReason</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>pipeCircuitId</m2:name>\n"
      + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>couponValidationWarning</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>creditCardSecPaid</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>creditCardSecReq</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>NRF_isRequired</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>currentlyUsedBandwidth</m2:name>\n"
      + "<m2:value>0.0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DefaultDisplayOrder</m2:name>\n"
      + "<m2:value>700</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + umc_LUStatus
      + "<m2:attribute>\n"
      + "<m2:name>lowProfile</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>orderDispReason</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>originalavailableBandwidth</m2:name>\n"
      + "<m2:value>0.4</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>customerPaidNRF</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isPortOutToCLEC</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>preProvisioningIndicator</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>prepaymentRequired</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProductFamily</m2:name>\n"
      + "<m2:value>LightSpeed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>profileLevel</m2:name>\n"
      + "<m2:value>Med</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>requestedBandwidth</m2:name>\n"
      + "<m2:value>24.6</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>runCreditRules</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>tosIndicator</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>techRequest</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>telegenceId</m2:name>\n"
      + "<m2:value>" + this.textValue4 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>totalBandwidth</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedTotalBandwidth + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>nrfType</m2:name>\n"
      + "<m2:value>RegularNRF</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hideComponent</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>inventoryComponentType</m2:name>\n"
      + "<m2:value>UMC</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>Parent</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>removeComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>completionIndicator</m2:name>\n"
      + "<m2:value>" + umcCompletionIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>supersedeIndicator</m2:name>\n"
      + "<m2:value>" + this.subContainer?.selectedSuperSede + "</m2:value>\n"
      + "</m2:attribute>\n"
      + unifyDeunifyIndicator
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
    return xml;
  }

  UMC_Comp() {
    var umcCompletionIndicator: String;
    var umc_LUStatus: String;
    var vDates: String;
    var loop: String;
    var abfIndicator: String = "";
    var rpiUvWorkOrdId: String;
    var rpiUvPrevWorkOrdId: String;
    var unifyDeunifyIndicator: String = "";

    if (this.umc?.dropdownDisable8 == false) {
      unifyDeunifyIndicator = "<m2:attribute>\n"
        + "<m2:name>unifyDeunifyIndicator</m2:name>\n"
        + "<m2:value>" + this.umc?.selctedunifydeunifyInd + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      unifyDeunifyIndicator = "";
    }

    if (this.umc?.isWorkOrderId == false) {
      rpiUvWorkOrdId = "<m2:attribute>\n"
        + "<m2:name>workOrderID</m2:name>\n"
        + "<m2:value>" + this.umc?.workOrderId + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      rpiUvWorkOrdId = "";
    }

    if (this.umc?.isPrevWorkOrderId == false) {
      rpiUvPrevWorkOrdId = "<m2:attribute>\n"
        + "<m2:name>previousWorkOrderID</m2:name>\n"
        + "<m2:value>" + this.umc?.prevWorkOrderId + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      rpiUvPrevWorkOrdId = "";
    }

    if (this.umc?.dropdownDisable7 == false) {
      abfIndicator = "<m2:attribute>\n"
        + "<m2:name>ABFIndicator</m2:name>\n"
        + "<m2:value>" + this.umc?.selectedAbfInd + "</m2:value>\n"
        + "</m2:attribute>\n";
    }

    if (this.selectedOrder + this.selectedSubType == "PRCA") {
      umcCompletionIndicator = "NA";
    } else if ((this.selectedSubType == "CA") || (this.selectedOrder == "RS") || (this.selectedOrder == "SR") || (this.selectedOrder == "SS") || (this.selectedOrder == "SU")) {
      umcCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CE") {
      umcCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CH") {
      umcCompletionIndicator = "CO";
    } else {
      umcCompletionIndicator = "NA";
    }

    if (this.umc?.selectedLoopIndication == "") {
      loop = "";
    } else {
      loop = "<m2:attribute>\n"
        + "<m2:name>loopIndication</m2:name>\n"
        + "<m2:value>" + this.umc?.selectedLoopIndication + "</m2:value>\n"
        + "</m2:attribute>\n";
    }

    if (this.subContainer?.selectedCC == "Y") {
      umc_LUStatus = "<m2:attribute>\n"
        + "<m2:name>luStatus</m2:name>\n"
        + "<m2:value>" + this.subContainer?.selectedLUStatus + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      umc_LUStatus = "";
    }

    if (this.umc?.selectedUvOrder == "VS") {
      // var endDate:Date = new Date(DueDate.selectedDate.getFullYear(), DueDate.selectedDate.getMonth(), DueDate.selectedDate.getDate() + 10);
      let endDate = this.selectedDueDate
      vDates = "<m2:attribute>\n"
        + "<m2:name>VSStartDate</m2:name>\n"
        + "<m2:value>" + this.selectedDueDate + "T23:59:59</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>VSEndDate</m2:name>\n"
        + "<m2:value>" + endDate + "T23:59:59</m2:value>\n"
        + "</m2:attribute>\n";
    } else if (this.umc?.selectedUvOrder == "VR") {
      // var startDate:Date = new Date(DueDate.selectedDate.getFullYear(), DueDate.selectedDate.getMonth(), DueDate.selectedDate.getDate() - 10);
      let startDate = this.selectedDueDate
      vDates = "<m2:attribute>\n"
        + "<m2:name>VSStartDate</m2:name>\n"
        + "<m2:value>" + startDate + "T23:59:59</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>VSEndDate</m2:name>\n"
        + "<m2:value>" + this.selectedDueDate + "T23:59:59</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      vDates = "";
    }

    let umcOrderReasonCode;
    if (this.umc.selectedOrderReasonCode == "") {
      umcOrderReasonCode = "<m2:value/>\n"
    } else {
      umcOrderReasonCode = "<m2:value>" + this.umc.selectedOrderReasonCode + "</m2:value>\n"
    }

    let xml = "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.textValue5 + "0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + ((this.selectedReference.charCodeAt(0)) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>orderActionID</m2:name>\n"
      + "<m2:value>" + this.textValue1 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>customerID</m2:name>\n"
      + "<m2:value>101494978</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>serviceID</m2:name>\n"
      + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2107709</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>UVOrderActionType</m2:name>\n"
      + "<m2:value>" + this.umc.selectedUvOrder + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>orderReasonCode</m2:name>\n"
      + umcOrderReasonCode
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>managerOverrideInd</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>100</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssInstallOption</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedInstllType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedInstllType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>technicianDispatchIndicator</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedTechDispatch + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>AMSS_LinkInd</m2:name>\n"
      + "<m2:value>Yahoo_DVR_Link:SDP_Link</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ADPI_isRequired</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableBandwidth</m2:name>\n"
      + "<m2:value>30.86</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>bandwidthSource</m2:name>\n"
      + "<m2:value>E</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>bandwidthUOM</m2:name>\n"
      + "<m2:value>MEGABITS_PER_SECOND</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>chngFrmCsiReason</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>pipeCircuitId</m2:name>\n"
      + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>couponValidationWarning</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>creditCardSecPaid</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>creditCardSecReq</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>NRF_isRequired</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>currentlyUsedBandwidth</m2:name>\n"
      + "<m2:value>0.0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DefaultDisplayOrder</m2:name>\n"
      + "<m2:value>700</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + umc_LUStatus
      + loop
      + "<m2:attribute>\n"
      + "<m2:name>lowProfile</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>orderDispReason</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>originalavailableBandwidth</m2:name>\n"
      + "<m2:value>0.4</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>customerPaidNRF</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isPortOutToCLEC</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>preProvisioningIndicator</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>prepaymentRequired</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProductFamily</m2:name>\n"
      + "<m2:value>LightSpeed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>profileLevel</m2:name>\n"
      + "<m2:value>Med</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>requestedBandwidth</m2:name>\n"
      + "<m2:value>24.6</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>runCreditRules</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>tosIndicator</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>techRequest</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>telegenceId</m2:name>\n"
      + "<m2:value>" + this.textValue4 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>totalBandwidth</m2:name>\n"
      + "<m2:value>" + this.umc?.selectedTotalBandwidth + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>nrfType</m2:name>\n"
      + "<m2:value>RegularNRF</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hideComponent</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>inventoryComponentType</m2:name>\n"
      + "<m2:value>UMC</m2:value>\n"
      + "</m2:attribute>\n"
      + abfIndicator
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>Parent</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>removeComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>completionIndicator</m2:name>\n"
      + "<m2:value>" + umcCompletionIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>supersedeIndicator</m2:name>\n"
      + "<m2:value>" + this.subContainer?.selectedSuperSede + "</m2:value>\n"
      + "</m2:attribute>\n"
      + unifyDeunifyIndicator
      + rpiUvWorkOrdId
      + rpiUvPrevWorkOrdId
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + vDates
      + "</m2:attributeList>\n"
    return xml;
  }

  PLST_NoUverse_Comp() {
    var plstAction: String;
    var plstCompletionIndicator: String;

    if (this.selectedOrder + this.selectedSubType == "PRCA") {
      plstAction = "";
      plstCompletionIndicator = "NA";
    } else if ((this.selectedSubType == "CA") || (this.selectedOrder == "RS") || (this.selectedOrder == "SR") || (this.selectedOrder == "SS") || (this.selectedOrder == "SU")) {
      plstAction = "";
      plstCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CE") {
      plstAction = "<m2:actionIndicator>D</m2:actionIndicator>\n";
      plstCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CH") {
      plstAction = "<m2:actionIndicator>M</m2:actionIndicator>\n";
      plstCompletionIndicator = "CO";
    } else {
      plstAction = "<m2:actionIndicator>I</m2:actionIndicator>\n";
      plstCompletionIndicator = "NA";
    }


    let xml = "<m2:component>\n"
      + "<m2:assignedProductId>" + this.textValue5 + "</m2:assignedProductId>\n"
      + "<m2:serviceType>PLST</m2:serviceType>\n"
      + plstAction
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.textValue5 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + ((this.selectedReference?.charCodeAt(0)) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2000005</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>2800</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sbcAffiliate</m2:name>\n"
      + "<m2:value>LightSpeed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>bandwidthUOM</m2:name>\n"
      + "<m2:value>MEGABITS_PER_SECOND</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>PrimaryIndForBilling</m2:name>\n"
      + "<m2:value>ADL</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>transportTypeGroup</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n"

    return xml;
  }

  PLST_Comp() {
    var plstAction: String;
    var plstCompletionIndicator: String;
    var vpi: String;
    var vci: String;
    var tdmTelcoTn2: String;
    var transportTypeGroup: String;
    var transportType: String;
    var oldtransportType: String;
    var seventeenVectoring: String;
    var oldIpdslamcktid: String;
    var transportCorder: String;
    var iAD: String;

    var gFastDeviceWireTypeAttr: String;

    if (this.plst?.dropdownDisable6 == false && this.plst?.selectedgFastDeviceWireType != "null") {
      gFastDeviceWireTypeAttr = "<m2:attribute>\n"
        + "<m2:name>gFastDeviceWireType</m2:name>\n"
        + "<m2:value>" + this.plst?.selectedgFastDeviceWireType + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      gFastDeviceWireTypeAttr = "";
    }

    // add IAD logic here
    // if ((this.subContainer?.dropdownDisable1 == false) && (bvoip_CheckBox.selected == true)) {
    if ((this.subContainer?.dropdownDisable1 == false)) {
      // iAD = this.IAD(this.banValue.slice(0, 8) + "2", this.selectedReference, this.umc?.selectedInstllType,
      //   this.CircuitIdVal, this.subContainer?.selectedAction);
    } else {
      iAD = "";
    }


    //add new tags in plst component for transport c order when the nti change is from ipdslam/ipdslambp to fttn/fttnbp
    if (this.plst?.textValue1 == "") {
      oldIpdslamcktid = "";
    } else {
      oldIpdslamcktid = "<m2:oldValue>" + this.plst?.textValue1 + "</m2:oldValue>\n";
    }

    if (this.plst?.textValue2 == "") {
      oldtransportType = "";
    } else {
      oldtransportType = "<m2:attribute>\n"
        + "<m2:name>OldTransportType</m2:name>\n"
        + "<m2:value>" + this.plst?.textValue2 + "</m2:value>\n"
        + "</m2:attribute>\n";
    }

    if (this.umc?.selectedUvOrder == "UVCH") {
      transportCorder = "<m2:attribute>\n"
        + "<m2:name>LSCircuitId</m2:name>\n"
        + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
        + oldIpdslamcktid
        + "</m2:attribute>\n";
    } else {
      transportCorder = "<m2:attribute>\n"
        + "<m2:name>LSCircuitId</m2:name>\n"
        + "<m2:value>" + this.CircuitIdVal + "</m2:value>\n"
        + "</m2:attribute>\n";

    }

    //Set TransportType = NA and oldtransportType for UVCA
    if (this.umc?.selectedUvOrder == "UVCA") {
      transportType = "NA";
      oldtransportType = "<m2:attribute>\n"
        + "<m2:name>OldTransportType</m2:name>\n"
        + "<m2:value>" + this.ntiVal + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      transportType = this.ntiVal;
      oldtransportType = "";
    }

    //Set VPI, VCI, and TransportTypeGroup
    if ((this.ntiVal == "IP-CO") || (this.ntiVal == "IP-RT") || (this.ntiVal == "IP-CO-BP") || (this.ntiVal == "IP-RT-BP")) {
      vpi = "0";
      vci = "35";
      transportTypeGroup = "IPDSLAM";
    } else {
      vpi = "16";
      vci = "16";
      transportTypeGroup = "Uverse";
    }

    if (this.selectedOrder + this.selectedSubType == "PRCA") {
      plstAction = "";
      plstCompletionIndicator = "NA";
    } else if ((this.selectedSubType == "CA") || (this.selectedOrder == "RS") || (this.selectedOrder == "SR") || (this.selectedOrder == "SS") || (this.selectedOrder == "SU")) {
      plstAction = "";
      plstCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CE") {
      plstAction = "<m2:actionIndicator>D</m2:actionIndicator>\n";
      plstCompletionIndicator = "CO";
    } else if (this.selectedOrder == "CH") {
      plstAction = "<m2:actionIndicator>M</m2:actionIndicator>\n";
      plstCompletionIndicator = "CO";
    } else {
      plstAction = "<m2:actionIndicator>I</m2:actionIndicator>\n";
      plstCompletionIndicator = "NA";
    }

    if ((this.ntiVal == 'IP-RT-BP') || (this.ntiVal == 'IP-CO-BP')) {
      tdmTelcoTn2 = "<m2:attribute>\n"
        + "<m2:name>tdmTelcoTn2</m2:name>\n"
        + "<m2:value>5" + this.banValue + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      tdmTelcoTn2 = "";
    }

    //17Mhz & Vectoring
    /*if (NTI.text.substr(0, 4) == "FTTN"){*/
    seventeenVectoring = "<m2:attribute>\n"
      + "<m2:name>17MHzFeature</m2:name>\n"
      + "<m2:value>" + this.plst?.selected17MHzFeature + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>original17MHzFeature</m2:name>\n"
      + "<m2:value>" + this.plst?.selectedOriginal17MHzFeature + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>vectoringFeature</m2:name>\n"
      + "<m2:value>" + this.plst?.selectedvectoringFeature + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>originalVectoringFeature</m2:name>\n"
      + "<m2:value>" + this.plst?.selectedOriginalvectoringFeature + "</m2:value>\n"
      + "</m2:attribute>\n";
    /*}
    else{
      seventeenVectoring="";
    }*/

    let xml = "<m2:component>\n"
      + "<m2:assignedProductId>" + this.textValue5 + "1</m2:assignedProductId>\n"
      + "<m2:serviceType>PLST</m2:serviceType>\n"
      + plstAction
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.textValue5 + "1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + ((this.selectedReference?.charCodeAt(0)) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2000005</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>2800</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sbcAffiliate</m2:name>\n"
      + "<m2:value>LightSpeed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>Bandwidth</m2:name>\n"
      + "<m2:value>20</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>bandwidthUOM</m2:name>\n"
      + "<m2:value>MEGABITS_PER_SECOND</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>CLCI</m2:name>\n"
      + "<m2:value>MCXX</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>cingularIndicator</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DefaultDisplayOrder</m2:name>\n"
      + "<m2:value>800</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + transportCorder
      + "<m2:attribute>\n"
      + "<m2:name>NDDRollbackIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>PrimaryIndForBilling</m2:name>\n"
      + "<m2:value>ADL</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProductFamily</m2:name>\n"
      + "<m2:value>LightSpeed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>completionIndicator</m2:name>\n"
      + "<m2:value>" + plstCompletionIndicator + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>telegenceId</m2:name>\n"
      + "<m2:value>" + this.textValue4 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>transportType</m2:name>\n"
      + "<m2:value>" + transportType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + oldtransportType
      + "<m2:attribute>\n"
      + "<m2:name>vpi</m2:name>\n"
      + "<m2:value>" + vpi + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>vci</m2:name>\n"
      + "<m2:value>" + vci + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>tdmTelcoTn</m2:name>\n"
      + "<m2:value>4" + this.banValue + "</m2:value>\n"
      + "</m2:attribute>\n"
      + tdmTelcoTn2
      + "<m2:attribute>\n"
      + "<m2:name>overrideRTIDInd</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>overrideDSLDisconnectTNInd</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>welcomeKit</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hideComponent</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>inventoryComponentType</m2:name>\n"
      + "<m2:value>PLS</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isPortAssigned</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>Child</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>removeComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>transportTypeGroup</m2:name>\n"
      + "<m2:value>" + transportTypeGroup + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>LastNadType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + gFastDeviceWireTypeAttr
      + "<m2:attribute>\n"
      + "<m2:name>LastTransportPath</m2:name>\n"
      + "<m2:value>FTTN</m2:value>\n"
      + "</m2:attribute>\n"
      + seventeenVectoring
      + "<m2:attribute>\n"
      + "<m2:name>isCustomerMigrated</m2:name>\n"
      + "<m2:value>" + this.plst?.selectedIsCustomerMigrated + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "<m2:componentList>\n"
      + this.NAD_component
      + this.NewNAD_component
      + iAD
      + "</m2:componentList>\n"
      + "</m2:component>\n"
    return xml;
  }

  changeVpi(nti) {
    if ((nti == "IP-CO") || (nti == "IP-RT") || (nti == "IP-CO-BP") || (nti == "IP-RT-BP")) {
      this.vpi_CM = "0";
      this.vci_CM = "35";
    } else {
      this.vpi_CM = "16";
      this.vci_CM = "16";
    }
    if ((nti == "IP-CO") || (nti == "IP-RT") || (nti == "IP-CO-BP") || (nti == "IP-RT-BP")) {
      this.vpi_PV = "0";
      this.vci_PV = "35";
    } else {
      this.vpi_PV = "16";
      this.vci_PV = "16";
    }

  }

  changeIr(nti) {
    if ((nti == "IP-CO") || (nti == "IP-RT") || (nti == "IP-CO-BP") || (nti == "IP-RT-BP")) {
      this.ir_CM = "N";
    } else {
      this.ir_CM = "";
    }

    if ((nti == "IP-CO") || (nti == "IP-RT") || (nti == "IP-CO-BP") || (nti == "IP-RT-BP")) {
      this.ir_PV = "N";
    } else {
      this.ir_PV = "";
    }
  }

  dropdownChange(val, title) {
    if (title == "Creation Application") {
      this.selectedCreationApp = val;
    } else if (title == "Order Action Reason Code") {
      this.selectedOrderActionReasonCode = val;
    } else if (title == "Extended Due Date") {
      this.selectedExtendedDueDate = val
    }
  }

  changeHsi(banVal, circuitID, appId, telegenceId) {
    //hsia
    let hsia_Speed = this.subModule.selectedSpeed;
    let hsia_IPType = this.subModule.selectedIpType;
    let hsia_CIDR = this.subModule.selectedCidr;
    let hsia_Action = this.subModule.selectedAction
    var ir: String;
    if (this.subModule?.dropdownDisable11 == false) {
      ir = this.subModule?.selectedIPDSLAMIR;
    } else {
      ir = "";
    }

    // if (hsia_CM.selected == true) {
    //   this.HSIA_component_CM = this.subModule?.HSIA_Comp(banVal, "CM", this.selectedReference, circuitID,
    //     hsia_Speed, "CO", "None", "None", hsia_IPType, hsia_CIDR, this.ir_CM, hsia_Action,
    //     this.subModule?.selectedMove);
    // } else {
    //   this.HSIA_component_CM="";
    // }

    // this.HSIA_component_PV = this.HSIA_component_CM;
    // if (isHsiaDisabled == false) {
    //   this.HSIA_component_PV = this.subModule?.HSIA_Comp(banVal, "PV", this.selectedReference, circuitID,
    //     hsia_Speed, "NA", "Tech", "Install", hsia_IPType, hsia_CIDR, this.ir_PV,
    //     hsia_Action_PV.text, this.subModule?.selectedMove);
    // } else {
    //   this.HSIA_component_PV="";
    // }

    let isHsiaDisabled = this.omsTabs.filter(v => v.title == "HSIA")[0].disabled;
    // var ottGenrePack = new Array(hsiaGenrePack1.text, hsiaGenrePack2.text, hsiaGenrePack3.text,
    //   hsiaGenrePack4.text, hsiaGenrePack5.text, hsiaGenrePack6.text);
    // var actionType = new Array(hsiaOttActionInd1.text, hsiaOttActionInd2.text, hsiaOttActionInd3.text,
    //   hsiaOttActionInd4.text, hsiaOttActionInd5.text, hsiaOttActionInd6.text);

    if (isHsiaDisabled == false) {
      // var ottGenrePackOld = new Array(hsiaGenrePackOld1.text, hsiaGenrePackOld2.text, hsiaGenrePackOld3.text,
      //   hsiaGenrePackOld4.text, hsiaGenrePackOld5.text, hsiaGenrePackOld6.text);
      // var actionTypeOld = new Array(hsiaOttActionIndOld1.text, hsiaOttActionIndOld2.text,
      //   hsiaOttActionIndOld3.text, hsiaOttActionIndOld4.text, hsiaOttActionIndOld5.text,
      //   hsiaOttActionIndOld6.text);
      var ottGenrePackOld, actionTypeOld, insideWire, iWireComp;
      this.HSIA_component = this.HSIA_Comp(banVal, this.selectedOrder, this.selectedReference,
        circuitID, this.subModule?.selectedSpeed, this.subModule?.selectedCompInd, this.umc?.selectedInstllType,
        this.umc?.selectedTechDispatch, this.subModule?.selectedIpType, this.subModule?.selectedCidr, ir,
        this.subModule?.selectedAction, "NA", insideWire, iWireComp, ottGenrePackOld, actionTypeOld,
        this.subModule?.selectedOTTMAction, this.subModule?.selectedOTTServices);
    } else {
      this.HSIA_component = "";
    }

  }

  onInfoChange(value) {
    if (value.indexOf('Related Product Info') != -1) {
      this.configChecked = false
    } else {
      this.configChecked = true;
    }
    this.checkBoxModel.roles = value;
  }

  onNtiChange(value) {
    this.checkBoxModel.roles = value;
  }

  orderActionChange(val) {
    this.selectedOrder = val;
    this.changeUvOrderActionType();
    this.ntiDisabled = false;

    this.store.dispatch({
      type: 'ADD_OMS_VALUE',
      payload: <OmsMessage>{
        orderAction: this.selectedOrder,
      }
    });

    this.changeOrderReasonCode();
    this.setNewCustomerInfo();

  }

  changeUvOrderActionType() {
    if ((this.selectedOrder == 'PR') && (this.selectedSubType == 'NA')) {
      this.uvtypes = ["UVPR", "NA"];
    } else if ((this.selectedOrder == 'PR') && (this.selectedSubType == 'AM')) {
      this.uvtypes = ["UVPR", "UVCA", "NA"];
    } else if ((this.selectedOrder == 'PR') && (this.selectedSubType == 'CA')) {
      this.uvtypes = ["UVCA", "NA"];
    } else if ((this.selectedOrder == 'CH') && (this.selectedSubType == 'NA')) {
      this.uvtypes = ["UVCH", "UVPR", "UVCE", "NA"];
    } else if ((this.selectedOrder == 'CH') && ((this.selectedSubType == 'AM') || (this.selectedSubType == 'CA'))) {
      this.uvtypes = ["UVCH", "UVPR", "UVCE", "UVCA", "NA"];
    } else if (this.selectedOrder == 'CE') {
      this.uvtypes = ["UVCE", "NA"];
    } else if (this.selectedOrder == 'SU') {
      this.uvtypes = ["SU", "NA"];
    } else if (this.selectedOrder == 'RS') {
      this.uvtypes = ["RS", "NA"];
    } else if (this.selectedOrder == 'SS') {
      this.uvtypes = ["SS", "VS", "NA"];
    } else if (this.selectedOrder == 'SR') {
      this.uvtypes = ["SR", "VR", "NA"];
    } else if (this.selectedOrder == 'CW') {
      this.uvtypes = ["UVCH"];
    } else {
      this.uvtypes = ["UVPR", "UVCH", "UVCE", "UVCA", "SS", "SR", "SU", "RS", "VS", "VR", "NA"];
    }
  }

  changeOrderReasonCode() {
    if ((this.selectedOrder == 'PR') && (this.selectedSubType == 'NA')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "NP - Non Payment", value: "NP" },
      { label: "TR - F&T Move", value: "TR" }];
    } else if ((this.selectedOrder == 'PR') && (this.selectedSubType == 'AM')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "IN - Installation Issues", value: "IN" },
      { label: "TR - F&T Move", value: "TR" }];
    } else if ((this.selectedOrder == 'PR') && (this.selectedSubType == 'CA')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "CAN - Competitor Contract", value: "CAN" },
      { label: "CO - Competitive Offer Save", value: "CO" },
      { label: "DM - Decision Maker Disagreement", value: "DM" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "IN - Installation Issues", value: "IN" },
      { label: "NA - No Access", value: "NA" },
      { label: "NO - Customer Never Ordered", value: "NO" },
      { label: "PF - Product Features or Content", value: "PF" },
      { label: "RO - Error Correction", value: "RO" },
      { label: "TR - F&T Move", value: "TR" },
      { label: "YZ - Yellow Zone Issues", value: "YZ" }];
    } else if ((this.selectedOrder == 'CH') && ((this.selectedSubType == 'NA') || (this.selectedSubType == 'AM'))) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "CAN - Competitor Contract", value: "CAN" },
      { label: "CH - Collections Hold", value: "CH" },
      { label: "CO - Competitive Offer Save", value: "CO" },
      { label: "DM - Decision Maker Disagreement", value: "DM" },
      { label: "FD - Fraud (Pending Confirmation)", value: "FD" },
      { label: "NA - No Access", value: "NA" },
      { label: "NO - Customer Never Ordered", value: "NO" },
      { label: "NP - Non Payment", value: "NP" },
      { label: "PE - Product Quality Below Expectation", value: "PE" },
      { label: "PF - Product Features or Content", value: "PF" },
      { label: "PO - Policy (hsia)", value: "PO" },
      { label: "RF - Restore from Fraud Without a Charge", value: "RF" },
      { label: "RO - Error Correction", value: "RO" },
      { label: "RS - Restore With Charge", value: "RS" },
      { label: "RW - Restore Without a Charge", value: "RW" }];
    } else if ((this.selectedOrder == 'CH') && (this.selectedSubType == 'CA')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "CAN - Competitor Contract", value: "CAN" },
      { label: "CO - Competitive Offer Save", value: "CO" },
      { label: "DM - Decision Maker Disagreement", value: "DM" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "IN - Installation Issues", value: "IN" },
      { label: "NA - No Access", value: "NA" },
      { label: "NO - Customer Never Ordered", value: "NO" },
      { label: "PF - Product Features or Content", value: "PF" },
      { label: "RO - Error Correction", value: "RO" }];
    } else if ((this.selectedOrder == 'CW') && ((this.selectedSubType == 'NA') || (this.selectedSubType == 'AM'))) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "AS - Abandoned Service", value: "AS" },
      { label: "DE - Deceased", value: "DE" },
      { label: "FD - Fraud", value: "FD" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "MV - Move", value: "MV" },
      { label: "NP - Non Payment", value: "NP" },
      { label: "RO - Error Correction", value: "RO" }];
    } else if ((this.selectedOrder == 'CW') && (this.selectedSubType == 'CA')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "FD - Fraud", value: "FD" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "IN - Installation Issues", value: "IN" },
      { label: "MV - Move", value: "MV" },
      { label: "NA - No Access", value: "NA" },
      { label: "NO - Customer Never Ordered", value: "NO" },
      { label: "NP - Non Payment", value: "NP" },
      { label: "RO - Error Correction", value: "RO" }];
    } else if ((this.selectedOrder == 'CE') && (this.selectedSubType == 'NA')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "AS - Abandoned Service", value: "AS" },
      { label: "BK - Bankruptcy", value: "BK" },
      { label: "CD - Wireless Disconnect", value: "CD" },
      { label: "CM - Wireless Decombine", value: "CM" },
      { label: "CS - Customer Support Below Expectation", value: "CS" },
      { label: "DE - Deceased", value: "DE" },
      { label: "DR - Disaster", value: "DR" },
      { label: "FD - Fraud", value: "FD" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "MV - Move", value: "MV" },
      { label: "NP - Non Payment", value: "NP" },
      { label: "PE - Product Quality Below Expectation", value: "PE" },
      { label: "PF - Product Features or Content", value: "PF" },
      { label: "RO - Error Correction", value: "RO" },
      { label: "TE - Too Expensive", value: "TE" },
      { label: "TR - F&T Move", value: "TR" }];
    } else if ((this.selectedOrder == 'CE') && (this.selectedSubType == 'AM')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "AS - Abandoned Service", value: "AS" },
      { label: "BK - Bankruptcy", value: "BK" },
      { label: "CS - Customer Support Below Expectation", value: "CS" },
      { label: "DE - Deceased", value: "DE" },
      { label: "DR - Disaster", value: "DR" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "MV - Move", value: "MV" },
      { label: "NO - Customer Never Ordered", value: "NO" },
      { label: "NP - Non Payment", value: "NP" },
      { label: "PE - Product Quality Below Expectation", value: "PE" },
      { label: "PF - Product Features or Content", value: "PF" },
      { label: "RO - Error Correction", value: "RO" },
      { label: "TE - Too Expensive", value: "TE" },
      { label: "TR - F&T Move", value: "TR" }];
    } else if ((this.selectedOrder == 'CE') && (this.selectedSubType == 'CA')) {
      this.dropdownValues1 = [{ label: "", value: "" },
      { label: "CAN - Competitor Contract", value: "CAN" },
      { label: "CO - Competitive Offer Save", value: "CO" },
      { label: "DM - Decision Maker Disagreement", value: "DM" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "IN - Installation Issues", value: "IN" },
      { label: "NA - No Access", value: "NA" },
      { label: "NO - Customer Never Ordered", value: "NO" },
      { label: "PF - Product Features or Content", value: "PF" },
      { label: "RO - Error Correction", value: "RO" },
      { label: "TR - F&T Move", value: "TR" }];
    } else if (((this.selectedOrder == 'SU') || (this.selectedOrder == 'SS')) && (this.selectedSubType == 'NA')) {
      this.dropdownValues1 = [{ label: "CH - Collections Hold", value: "CH" },
      { label: "FD - Fraud (Pending Confirmation)", value: "FD" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "NP - Non-Payment", value: "NP" },
      { label: "PO - Policy (hsia)", value: "PO" },
      { label: "VA - Vacation", value: "VA" },
      { label: "ML - Military", value: "ML" },
      { label: "DR - Disaster", value: "DR" },
      { label: "OT - Other", value: "OT" }];
    } else if (((this.selectedOrder == 'SU') || (this.selectedOrder == 'SS')) && (this.selectedSubType == 'AM')) {
      this.dropdownValues1 = [{ label: "NP - Non-Payment", value: "NP" },
      { label: "PO - Policy (hsia)", value: "PO" },
      { label: "VA - Vacation", value: "VA" },
      { label: "ML - Military", value: "ML" },
      { label: "DR - Disaster", value: "DR" },
      { label: "OT - Other", value: "OT" }];
    } else if (((this.selectedOrder == 'RS') || (this.selectedOrder == 'SR')) && (this.selectedSubType == 'NA')) {
      this.dropdownValues1 = [{ label: "RF - Restore from Fraud (Without a Charge)", value: "RF" },
      { label: "RS - Restore (With Charge)", value: "RS" },
      { label: "RW - Restore (Without a Charge)", value: "RW" },
      { label: "VA - Vacation", value: "VA" },
      { label: "ML - Military", value: "ML" },
      { label: "DR - Disaster", value: "DR" },
      { label: "OT - Other", value: "OT" }];
    } else if (((this.selectedOrder == 'RS') || (this.selectedOrder == 'SR')) && (this.selectedSubType == 'AM')) {
      this.dropdownValues1 = [{ label: "RS - Restore (With Charge)", value: "RS" },
      { label: "RW - Restore (Without a Charge)", value: "RW" },
      { label: "VA - Vacation", value: "VA" },
      { label: "ML - Military", value: "ML" },
      { label: "DR - Disaster", value: "DR" },
      { label: "OT - Other", value: "OT" }];
    } else {
      this.dropdownValues1 = [{ label: "CAN - Competitor Contract", value: "CAN" },
      { label: "CO - Competitive Offer Save", value: "CO" },
      { label: "DM - Decision Maker Disagreement", value: "DM" },
      { label: "ID - Theft of Identity", value: "ID" },
      { label: "IN - Installation Issues", value: "IN" },
      { label: "NA - No Access", value: "NA" },
      { label: "NO - Customer Never Ordered", value: "NO" },
      { label: "PF - Product Features or Content", value: "PF" },
      { label: "RO - Error Correction", value: "RO" }];
    }
  }

  referenceChange(val) {
    this.selectedReference = val;
  }

  subTypeChange(val) {
    this.selectedSubType = val;
    if (this.selectedOrder == "PR") {
      if (this.selectedSubType == "CA") {
        this.GeneratePT = true;
        this.GenerateCPE1 = false;
        this.GeneratePTC = true;
      } else {
        this.GeneratePT = true;
        this.GenerateCPE1 = true;
        this.GeneratePTC = true;
      }
    } else {
      this.GeneratePT = true;
      this.GenerateCPE1 = true;
      this.GeneratePTC = true;
    }

    this.store.dispatch({
      type: 'ADD_OMS_VALUE',
      payload: <OmsMessage>{
        subType: this.selectedSubType,
      }
    });
  }

  onTabChange(value) {
    this.checkBoxModel.roles = value;
    let ind;
    if (value?.length) {
      this.omsTabs.map(val => val.disabled = true)
      value.map((val) => {
        if (value.indexOf(val) != -1) {
          ind = this.filterArrOfObj(this.omsTabs, val.toLowerCase())
          if (this.omsTabs[ind].disabled == true) {
            this.omsTabs[ind].disabled = false;
          }
        }
      });
    } else {
      this.omsTabs.map(val => val.disabled = true)
    }
  }

  filterArrOfObj(array, value) {
    return array.findIndex(x => x.label === value);
  }

  changeTextBox(title, val) {
    if (title == "Order Number") {
      this.textValue1 = val;
      this.textValue2 = parseInt(this.textValue1) + 1;
    } else if (title == "OrigOrderActionId") {
      this.textValue2 = val;
    } else if (title == "dslDisconnectTn") {
      this.textValue3 = val;
    } else if (title == "TelegenceId") {
      this.textValue4 = val;
    } else if (title == "APID") {
      this.textValue5 = val;
    }
  }

  HSIA_Comp(ban: String, orderAction: String, reference: String, circuit: String, speed: String,
    completion: String, install: String, dispatch: String, ipType: String, cidr, ir: String,
    actionInd: String, move: String, iwire: String, iWireComponent: String, ottGenrePack,
    actionType, hsiaOttAction: String, hsiaOttNum: String): String {

    var staticIp: String;
    var reclaimIp: String;
    var action: String;
    var hsia_Component: String;
    var ipdslamIR: String;

    if (actionInd == "") {
      action = "";
    } else {
      action = "<m2:actionIndicator>" + actionInd + "</m2:actionIndicator>\n";
    }

    if (ipType == "Static") {
      staticIp = "<m2:attribute>\n"
        + "<m2:name>cidrBlockSize</m2:name>\n"
        + "<m2:value>" + cidr + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ipAddressFrom</m2:name>\n"
        + "<m2:value>90.30.212.001</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>ipAddressTo</m2:name>\n"
        + "<m2:value>90.30.212.254</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>stickyIpRegistrationNum</m2:name>\n"
        + "<m2:value>" + ban + "</m2:value>\n"
        + "</m2:attribute>\n"
        + "<m2:attribute>\n"
        + "<m2:name>IpQuantity</m2:name>\n"
        + "<m2:value>" + String(Math.pow(2, (32 - parseInt(cidr)))) + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      staticIp = "";
    }

    if ((ipType == "Static") && (orderAction == "CE")) {
      reclaimIp = "<m2:attribute>\n"
        + "<m2:name>reclaimIP</m2:name>\n"
        + "<m2:value>90.30.212.100</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      reclaimIp = "";
    }

    if ((ir == 'Y') || (ir == 'N')) {
      ipdslamIR = "<m2:attribute>\n"
        + "<m2:name>IPDSLAMInterceptRedirect</m2:name>\n"
        + "<m2:value>" + ir + "</m2:value>\n"
        + "</m2:attribute>\n";
    } else {
      ipdslamIR = "";
    }

    var hsia_ott: String;
    var M: number;
    var actiontype: String;
    var HSIA_CPX: String = "";

    if (this.subModule?.ottChecked == true) {
      hsia_ott = "";
      // M = parseInt(hsiaOttNum);

      //add DTV CPE component
      while (M > 0) {
        // if (actionType[M - 1] == "") {
        //   actiontype="";
        // } else {
        //   actiontype="<m2:actionIndicator>" + actionType[M - 1] + "</m2:actionIndicator>\n"
        // }

        hsia_ott = hsia_ott
          + "<m2:component>\n"
          + "<m2:assignedProductId>" + this.textValue5 + M + "</m2:assignedProductId>\n"
          + "<m2:serviceType>OTT</m2:serviceType>\n"
          + actiontype
          + "<m2:attributeList>\n"
          + "<m2:attribute>\n"
          + "<m2:name>APID</m2:name>\n"
          + "<m2:value>" + this.textValue5 + M + "</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>versionID</m2:name>\n"
          + "<m2:value>0</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>relationID</m2:name>\n"
          + "<m2:value>88743077</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>OTTPackage</m2:name>\n"
          + "<m2:value>" + ottGenrePack[M - 1] + "</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>moveIndicator</m2:name>\n"
          + "<m2:value>NA</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>offerSalesMode</m2:name>\n"
          + "<m2:value>Lead</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>ParentProductType</m2:name>\n"
          + "<m2:value>IA</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>completionIndicator</m2:name>\n"
          + "<m2:value>NA</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>isPartOfPackage</m2:name>\n"
          + "<m2:value>No</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>action_type</m2:name>\n"
          + "<m2:value>A</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
          + "<m2:value>N</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>restrictedContent</m2:name>\n"
          + "<m2:value>1</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>isSendToTeLS</m2:name>\n"
          + "<m2:value>Child</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>creditPolicyRestriction</m2:name>\n"
          + "<m2:value>Z</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>availableForSelfInstall</m2:name>\n"
          + "<m2:value>Automatic</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>fulfillmentIndicator</m2:name>\n"
          + "<m2:value>No</m2:value>\n"
          + "</m2:attribute>\n"
          + "</m2:attributeList>\n"
          + "</m2:component>\n";

        M = M - 1;
      }

      if (hsia_ott == "") {
        HSIA_CPX = "";
      } else {
        HSIA_CPX = "<m2:componentList>\n"
          + "<m2:component>\n"
          + "<m2:assignedProductId>" + this.textValue5 + "</m2:assignedProductId>\n"
          + "<m2:serviceType>OTTM</m2:serviceType>\n"
          + "<m2:actionIndicator>" + hsiaOttAction + "</m2:actionIndicator>\n"
          + "<m2:attributeList>\n"
          + "<m2:attribute>\n"
          + "<m2:name>APID</m2:name>\n"
          + "<m2:value>" + this.textValue5 + "</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>versionID</m2:name>\n"
          + "<m2:value>0</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>relationID</m2:name>\n"
          + "<m2:value>88742097</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>ParentProductType</m2:name>\n"
          + "<m2:value>IA</m2:value>\n"
          + "</m2:attribute>\n"
          + "<m2:attribute>\n"
          + "<m2:name>isSendToTeLS</m2:name>\n"
          + "<m2:value>Child</m2:value>\n"
          + "</m2:attribute>\n"
          + "</m2:attributeList>\n"
          + "<m2:componentList>\n"
          + hsia_ott
          + "</m2:componentList>\n"
          + "</m2:component>\n"
          + "</m2:componentList>\n";
      }
    }

    hsia_Component = "<m2:component>\n"
      + "<m2:assignedProductId>" + this.textValue5 + "4</m2:assignedProductId>\n"
      + "<m2:serviceType>HSIA</m2:serviceType>\n"
      + action
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + this.textValue5 + "4</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + (reference?.charCodeAt(0) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2107710</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>200</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DefaultDisplayOrder</m2:name>\n"
      + "<m2:value>200</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>criticalFullfillment</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>compStatus</m2:name>\n"
      + "<m2:value>AC</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>componentBandwidth</m2:name>\n"
      + "<m2:value>1.0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>pipeCircuitId</m2:name>\n"
      + "<m2:value>" + circuit + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>" + install + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ipAddressType</m2:name>\n"
      + "<m2:value>" + ipType + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>eligibleForPrepayment</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sapOrderStatus</m2:name>\n"
      + "<m2:value>Unknown</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>questionCsrCsiShipmentType</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shipmentType</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>completionIndicator</m2:name>\n"
      + "<m2:value>" + completion + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>modifiedIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>SbpValue</m2:name>\n"
      + "<m2:value>0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>RMA</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>purchaseTerms</m2:name>\n"
      + "<m2:value>Purchase</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>removeComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>StandAlone</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>inventoryComponentType</m2:name>\n"
      + "<m2:value>HSIA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hideComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>welcomeKit</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>uverseTechnology</m2:name>\n"
      + "<m2:value>PLS</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>termsAcceptance</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>telegenceId</m2:name>\n"
      + "<m2:value>" + this.textValue4 + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>technicianDispatchIndicator</m2:name>\n"
      + "<m2:value>" + dispatch + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>Speed</m2:name>\n"
      + "<m2:value>" + speed + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shippingIndicator</m2:name>\n"
      + "<m2:value>Tech</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>IA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>walledGarden</m2:name>\n"
      + "<m2:value>" + this.subModule?.selectedWalledGarden + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProductFamily</m2:name>\n"
      + "<m2:value>LightSpeed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>PortalProvider</m2:name>\n"
      + "<m2:value>AT&amp;T Yahoo</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>OMS_QA_COMPONENT_NAME</m2:name>\n"
      + "<m2:value>QHSIA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>memberId</m2:name>\n"
      + "<m2:value>amy.bruhn</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>materialCode</m2:name>\n"
      + "<m2:value>100000290</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>HsiaType</m2:name>\n"
      + "<m2:value>Yahoo</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>AMSSDefaultInd</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sbcAffiliate</m2:name>\n"
      + "<m2:value>LightSpeed</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>AMSS_LinkInd</m2:name>\n"
      + "<m2:value>No_Link</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>" + move + "</m2:value>\n"
      + "</m2:attribute>\n"
      + ipdslamIR
      + staticIp
      + reclaimIp
      // + iwire
      + "</m2:attributeList>\n"
      + HSIA_CPX
      // + iWireComponent
      + "</m2:component>\n";

    return hsia_Component;
  }

  wiringComp() {
    //set actionIndicators
    if (this.textValue1 + this.textValue4 == "PRCA") {
      this.wiringAction = "";
    } else if ((this.textValue4 == "CA") || (this.textValue1 == "RS") || (this.textValue1 == "SR") || (this.textValue1 == "SS") || (this.textValue1 == "SU")) {
      this.wiringAction = "";
    } else {
      this.wiringAction = "<m2:actionIndicator>I</m2:actionIndicator>\n";
    }
  }

  generateConfigProd() {
    const modalRef = this.modalService.open(RelatedProductModalComponent);
    modalRef.componentInstance.title = 'Related Product Info Config';
  }

  getACCS_Comp(action: String, apid, install: String, wapDevice: String, wapModel: String): String {
    var accsAction: String;
    var apComponent: String = "";

    if (action == "") {
      accsAction = "";
    } else {
      accsAction = "<m2:actionIndicator>" + action + "</m2:actionIndicator>\n";
    }

    apComponent = this.AP_Comp(accsAction, (parseInt(apid) + 1).toString(), install, wapDevice, wapModel);

    var accsComponent: String = "<m2:component>\n"
      + "<m2:assignedProductId>" + apid + "</m2:assignedProductId>\n"
      + "<m2:serviceType>ACCS</m2:serviceType>\n"
      + accsAction
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + apid + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>1</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>12345678</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>timedLeasedRemoteCounter</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>timedLeasedRemoteTimestamp</m2:name>\n"
      + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>timedPurchasedRemoteCounter</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>timedPurchasedRemoteTimestamp</m2:name>\n"
      + "<m2:value>2011-02-15T00:00:00</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>totalLeasedRemoteCounter</m2:name>\n"
      + "<m2:value>value</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "<m2:componentList>\n"
      + apComponent
      + "</m2:componentList>\n"
      + "</m2:component>";

    return accsComponent;
  }

  AP_Comp(action: String, apid: String, install: String, manufacturer: String, modelNumber: String): String {
    var ap_Component: String;

    ap_Component = "<m2:component>\n"
      + "<m2:assignedProductId>" + apid + "</m2:assignedProductId>\n"
      + "<m2:serviceType>AP</m2:serviceType>\n"
      + action
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + apid + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>0</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>6900047</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>Optional</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>criticalFullfillment</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sapOrderStatus</m2:name>\n"
      + "<m2:value>Unknown</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>" + install + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>manufacturer</m2:name>\n"
      + "<m2:value>" + manufacturer + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>materialCode</m2:name>\n"
      + "<m2:value>100001091</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>modelNumber</m2:name>\n"
      + "<m2:value>" + modelNumber + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>purchaseTerms</m2:name>\n"
      + "<m2:value>Rent</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>RMA</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reasonCode</m2:name>\n"
      + "<m2:value>Unknown</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reShipInd</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reShipReason</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shipmentType</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";

    return ap_Component;
  }

  IAD(apid: String, reference: String, install: String, circuit: String, IadAction: String): String {
    var iad_Component: String;

    iad_Component = "<m2:component>\n"
      + "<m2:assignedProductId>" + apid + "</m2:assignedProductId>\n"
      + "<m2:serviceType>IAD</m2:serviceType>\n"
      + "<m2:actionIndicator>" + IadAction + "</m2:actionIndicator>\n"
      + "<m2:attributeList>\n"
      + "<m2:attribute>\n"
      + "<m2:name>APID</m2:name>\n"
      + "<m2:value>" + apid + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>versionID</m2:name>\n"
      + "<m2:value>" + (reference.charCodeAt(0) - 64) + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>relationID</m2:name>\n"
      + "<m2:value>2000006</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reShipReason</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>removeComponent</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>NADMakeAndModel</m2:name>\n"
      + "<m2:value>000</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reasonCode</m2:name>\n"
      + "<m2:value>Unknown</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isBYOE</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>recordOnly</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>installationType</m2:name>\n"
      + "<m2:value>" + install + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>inventoryComponentType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>hideComponent</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>actualMaterialCode</m2:name>\n"
      + "<m2:value>100000807</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>manufacturer</m2:name>\n"
      + "<m2:value>2Wire</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>isSendToTeLS</m2:name>\n"
      + "<m2:value>Child</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>reShipInd</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>RMA</m2:name>\n"
      + "<m2:value>Y</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fulfillmentIndicator</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>numAtaPorts</m2:name>\n"
      + "<m2:value>2</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>EligibleForBundleDiscount</m2:name>\n"
      + "<m2:value>N</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>purchaseTerms</m2:name>\n"
      + "<m2:value>Rent</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shipmentType</m2:name>\n"
      + "<m2:value>NotApplicable</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>criticalFullfillment</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>materialCode</m2:name>\n"
      + "<m2:value>100000807</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>ProdType</m2:name>\n"
      + "<m2:value>RG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>fttxInput</m2:name>\n"
      + "<m2:value>FTTX</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>NADExist</m2:name>\n"
      + "<m2:value>UNKNOWN</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>technicianDispatchIndicator</m2:name>\n"
      + "<m2:value>None</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>CPEGFIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>DefaultDisplayOrder</m2:name>\n"
      + "<m2:value>100</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>shippingIndicator</m2:name>\n"
      + "<m2:value>Tech</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>completionIndicator</m2:name>\n"
      + "<m2:value>CO</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>originalInstallationType</m2:name>\n"
      + "<m2:value>Tech</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>availableForSelfInstall</m2:name>\n"
      + "<m2:value>Optional</m2:value>\n"
      + "<m2:oldValue>Automatic</m2:oldValue>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>offerSalesMode</m2:name>\n"
      + "<m2:value>Lead</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>modelNumber</m2:name>\n"
      + "<m2:value>" + this.subContainer?.selectedModel + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>nadType</m2:name>\n"
      + "<m2:value>IG</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>USPIndicator</m2:name>\n"
      + "<m2:value>Yes</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>rgId</m2:name>\n"
      + "<m2:value>" + circuit + "</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>RGReplacementFlag</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssDisplaySequence</m2:name>\n"
      + "<m2:value>2900</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>sapOrderStatus</m2:name>\n"
      + "<m2:value>N/A</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>moveIndicator</m2:name>\n"
      + "<m2:value>NA</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>internalWAPIndicator</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>amssRefresh</m2:name>\n"
      + "<m2:value>No</m2:value>\n"
      + "</m2:attribute>\n"
      + "<m2:attribute>\n"
      + "<m2:name>NADKitType</m2:name>\n"
      + "<m2:value>UNKNOWN</m2:value>\n"
      + "</m2:attribute>\n"
      + "</m2:attributeList>\n"
      + "</m2:component>\n";

    return iad_Component;
  }

  ServiceFSP(fspPrimaryNpanxx: String, fspWireCenter: String, fttbBuilding: String, emt: String, fspCcid: String, fspLivingUnitAddressId: String,
    fspRateCenterCode: String, fspVhoCode: String, fspTarCode: String, fspHouseNumber: String, fspStreetName: String, fspStreetThoroughfare: String,
    fspCity: String, fspState: String, fspPostalCode: String, fspPostalCodePlus4: String, fspFirstName: String, fspLastName: String,
    fspAddressID: String): String {
    var serviceFSP: String;
    var fbsCllis: String;

    // update to accomodate fbs building clli changes
    if ((fttbBuilding.length > 0) && (this.serviceFsp?.textValue12.length == 0)) {
      fbsCllis = "<m2:fttbBuildingClli>" + fttbBuilding + "</m2:fttbBuildingClli>\n"
      //	+"<m2:emtClli>"+emt+"</m2:emtClli>\n";
    } else if ((this.serviceFsp?.textValue12.length > 0) && (fttbBuilding.length == 0)) {
      fbsCllis = "<m2:fttbBuildingClli>" + this.serviceFsp?.textValue12 + "</m2:fttbBuildingClli>\n"
    } else {
      fbsCllis = "";
    }
    let cli8;
    if (fspWireCenter && fspWireCenter.length) {
      cli8 = "<m2:clli8>" + fspWireCenter + "</m2:clli8>\n"
    } else {
      cli8 = "<m2:clli8/>\n"
    }

    serviceFSP = "<m2:addressInfo>\n"
      + "<m2:addressType>ServiceFSP</m2:addressType>\n"
      + "<m2:primaryNpanxx>" + fspPrimaryNpanxx + "</m2:primaryNpanxx>\n"
      + cli8
      + fbsCllis
      + "<m2:region>southeast</m2:region>\n"
      // + fspCcid
      + "<m2:livingUnitAddressId>" + fspLivingUnitAddressId + "</m2:livingUnitAddressId>\n"
      + "<m2:rateCenterCode>" + fspRateCenterCode + "</m2:rateCenterCode>\n"
      + "<m2:vhoCode>" + fspVhoCode + "</m2:vhoCode>\n"
      + fspTarCode
      + "<m2:fieldedAddress>\n"
      + "<m2:houseNumber>" + fspHouseNumber + "</m2:houseNumber>\n"
      + "<m2:streetName>" + fspStreetName + "</m2:streetName>\n"
      + "<m2:streetThoroughfare>" + fspStreetThoroughfare + "</m2:streetThoroughfare>\n"
      + "<m2:city>" + fspCity + "</m2:city>\n"
      + "<m2:state>" + fspState + "</m2:state>\n"
      + "<m2:postalCode>" + fspPostalCode + "</m2:postalCode>\n"
      + "<m2:postalCodePlus4>" + fspPostalCodePlus4 + "</m2:postalCodePlus4>\n"
      + "<m2:county>Fulton</m2:county>\n"
      + "<m2:country>USA</m2:country>\n"
      + "<m2:structureType>BLDG</m2:structureType>\n"
      + "<m2:structureValue>2</m2:structureValue>\n"
      + "<m2:levelType>FLR</m2:levelType>\n"
      + "<m2:levelValue>1</m2:levelValue>\n"
      + "<m2:unitType>APT</m2:unitType>\n"
      + "<m2:unitValue>1123</m2:unitValue>\n"
      + "<m2:originalStreetDirection>South</m2:originalStreetDirection>\n"
      + "<m2:originalStreetNameSuffix>suffix</m2:originalStreetNameSuffix>\n"
      + "<m2:cassAddressLines>\n"
      + "<m2:addressLine>" + fspFirstName + " " + fspLastName + "</m2:addressLine>\n"
      + "<m2:addressLine>" + fspHouseNumber + " " + fspStreetName + " " + fspStreetThoroughfare + "</m2:addressLine>\n"
      + "<m2:addressLine>" + fspCity + " " + fspState + "  " + fspPostalCode + "-" + fspPostalCodePlus4 + "</m2:addressLine>\n"
      + "</m2:cassAddressLines>\n"
      + "<m2:cassAdditionalInfo>String</m2:cassAdditionalInfo>\n"
      + "<m2:additionalInfo>String</m2:additionalInfo>\n"
      + "<m2:countryCode>String</m2:countryCode>\n"
      + "<m2:cityCode>String</m2:cityCode>\n"
      + "<m2:serviceLocationName>String</m2:serviceLocationName>\n"
      + "<m2:addressId>" + fspAddressID + "</m2:addressId>\n"
      + "<m2:aliasName>String</m2:aliasName>\n"
      + "<m2:attention>String</m2:attention>\n"
      + "</m2:fieldedAddress>\n"
      + "</m2:addressInfo>\n";

    return serviceFSP;
  }

  textChange() { }

  //gen Pub RG Function
  PublishNAD_CMS() {
    let modelNo1, modelNo2, year, month, day, hour, minute, second, mSecond, nadDeviceId;
    if (this.selectedOrder == 'CH' && this.subContainer?.selectedNadSwap == true) {
      modelNo1 = this.subContainer?.selectedModelData1;
      modelNo2 = this.subContainer?.selectedModelData3;
    } else {
      modelNo1 = this.subContainer?.selectedModelData1;
      modelNo2 = this.subContainer?.selectedModelData3;
    }

    let date: Date = new Date();

    nadDeviceId = this.CreateNadDeviceId(this.textValue1, modelNo1, modelNo2);
    let deviceId: String = nadDeviceId[0];
    let vendor: String = nadDeviceId[1];

    year = date.getFullYear().toString();
    month = (date.getMonth() + 1).toString();
    day = date.getDate().toString();
    hour = date.getHours().toString();
    minute = date.getMinutes().toString();
    second = date.getSeconds().toString();
    mSecond = date.getMilliseconds().toString();

    let header = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:rul="http://att.com/websim/dynamicrule/rules">\n`
      + `<soapenv:Header/>\n`
      + `<soapenv:Body>\n`
      + `<rul:requestInitiatorRequest>\n`
      + `<rul:environment>${this.enviornmentVal}</rul:environment>\n`
      + `<rul:requestBridgeName>CMS Notification WL (CMSNotificationService_http)</rul:requestBridgeName>\n`
      + `<!--Optional:-->\n`
      + `<rul:delayTime>1</rul:delayTime>\n`
      + `<rul:requestXml><![CDATA[\n`;

    let footer = `\n]]></rul:requestXml>\n`
      + `<!--Optional:-->\n`
      + `<rul:jmsProperties>\n`
      + `<!--Optional: -->\n`
      + `<rul:jmsCorrelationId>?</rul:jmsCorrelationId>\n`
      + `<!--1 or more repetitions: -->\n`
      + `<rul:addProperty>\n`
      + `<!--Optional: -->\n`
      + `<rul:name>?</rul:name>\n`
      + `<!--Optional : -->\n`
      + `<rul:value>?</rul:value>\n`
      + `</rul:addProperty>\n`
      + `</rul:jmsProperties>\n`
      + `</rul:requestInitiatorRequest>\n`
      + `</soapenv:Body>\n`
      + `</soapenv:Envelope>\n`;

    let content = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
      + "<soapenv:Header>\n"
      + "<ns1:MessageHeader xmlns:ns1=\"urn:soap.embus.sbc.com\">\n"
      + "<ns1:MessageTag>com.sbc.eia.idl.rm.PublishRGActivationReturn \n"
      + "com.sbc.eia.idl.rm.RmFacadePackage.publishRGActivation(com.sbc.eia.idl.bis_types.BisContext,\n"
      + "com.sbc.eia .idl.types.StringOpt,\n"
      + "com.sbc.eia.idl.types.CompositeObjectKey, \n"
      + "com.sbc.eia.idl.rm_ls_types.DSLAMTransportOpt,\n"
      + "com.sbc.eia.idl.rm_ls_types.ResidentialGateway, \n"
      + "com.sbc.eia.idl.types.Time, \n"
      + "com.sbc.eia.idl.rm_ls_types.OrderAction,\n"
      + "com.sbc.eia.idl.types.ObjectPropertySeqOpt)\n"
      + "</ns1:MessageTag>\n"
      + "<ns1:ApplicationID>M18846</ns1:ApplicationID>\n"
      + "<ns1:LoggingKey>NONE</ns1:LoggingKey>\n"
      + "</ns1:MessageHeader>\n"
      + "</soapenv:Header>\n"
      + "<soapenv:Body>\n"
      + "<com.sbc.eia.idl.rm.RmFacadePackage._publishRGActivationRequestBISMsg xmlns=\"urn:RmFacadePackage.rm.idl.eia.sbc.com\">\n"
      + "<context xmlns=\"\">\n"
      + "<properties>\n"
      + "<item>\n"
      + "<tag>Application</tag>\n"
      + "<value>CMS</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>BusinessUnit</tag>\n"
      + "<value>SBCLightSpeed</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>CustomerName</tag>\n"
      + "<value>GeneratedSBC</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>USER_ID</tag>\n"
      + "<value>vsethia@2wire.com</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>REQUEST_ID</tag>\n"
      + "<value>1</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>LOGICAL_SERVER</tag>\n"
      + "<value>dd.2wire.com</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>INTERFACE_NAME</tag>\n"
      + "<value>localnoc</value>\n"
      + "</item>\n"
      + "</properties>\n"
      + "</context>\n"
      + "<customerTransportId xmlns=\"\">" + this.CircuitIdVal + "</customerTransportId>\n"
      + "<billingAccountNumber xmlns=\"\">\n"
      + "<keys>\n"
      + "<item>\n"
      + "<value>" + this.banValue + "</value>\n"
      + "<kind>com.sbc.eia.bis.BillingAccountNumber</kind>\n"
      + "</item>\n"
      + "</keys>\n"
      + "</billingAccountNumber>\n"
      + "<dSLAM xmlns=\"\">\n"
      + "<id>DLLSTXRNOL9010101011</id>\n"
      + "<physicalPort>1-1-1-1-2-2-3</physicalPort>\n"
      + "</dSLAM>\n"
      + "<rG xmlns=\"\">\n"
      + "<deviceId>" + deviceId + "</deviceId>\n"
      + "<serialNumber>" + this.banValue + "</serialNumber>\n"
      + "<firmwareVersionNumber>5.29.135.47</firmwareVersionNumber>\n"
      + "<modelNumber>" + modelNo1 + "</modelNumber>\n"
      + "<iPAddress>\n"
      + "<networkAddress>\n"
      + "<value>12.70.52.196</value>\n"
      + "<kind>com.sbc.eia.idl.nam_types.NetworkAddress</kind>\n"
      + "</networkAddress>\n"
      + "<networkAddressType>NetworkAddressType</networkAddressType>\n"
      + "</iPAddress>\n"
      + "<mACAddress>\n"
      + "<networkAddress>\n"
      + "<value>00:1e:c7:33:37:20</value>\n"
      + "<kind>com.sbc.eia.idl.nam_types.NetworkAddress</kind>\n"
      + "</networkAddress>\n"
      + "<networkAddressType>NetworkAddressType</networkAddressType>\n"
      + "</mACAddress>\n"
      + "<vendor>" + vendor + "</vendor>\n"
      + "</rG>\n"
      + "<activationTime xmlns=\"\">\n"
      + "<eiaDate>\n"
      + "<year>" + year + "</year>\n"
      + "<month>" + month + "</month>\n"
      + "<day>" + day + "</day>\n"
      + "</eiaDate>\n"
      + "<hour>" + hour + "</hour>\n"
      + "<minute>" + minute + "</minute>\n"
      + "<second>" + second + "</second>\n"
      + "<milliSeconds>" + mSecond + "</milliSeconds>\n"
      + "<tCOffset>-5</tCOffset>\n"
      + "</activationTime>\n"
      + "<orderAction xmlns=\"\">\n"
      + "<order>" + this.textValue1 + "</order>\n"
      + "<orderActionId>" + this.textValue1 + "</orderActionId>\n"
      + "<orderActionType>" + this.selectedOrder + "</orderActionType>\n"
      + "</orderAction>\n"
      + "<properties xmlns=\"\">\n"
      + "<item>\n"
      + "<tag>Application</tag>\n"
      + "<value>CMS</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>BusinessUnit</tag>\n"
      + "<value>SBCLightSpeed</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>CustomerName</tag>\n"
      + "<value>GeneratedSBC</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>USER_ID</tag>\n"
      + "<value>vsethia@2wire.com</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>REQUEST_ID</tag>\n"
      + "<value>1</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>LOGICAL_SERVER</tag>\n"
      + "<value>dd.2wire.com</value>\n"
      + "</item>\n"
      + "<item>\n"
      + "<tag>INTERFACE_NAME</tag>\n"
      + "<value>localnoc</value>\n"
      + "</item>\n"
      + "</properties>\n"
      + "</com.sbc.eia.idl.rm.RmFacadePackage._publishRGActivationRequestBISMsg>\n"
      + "</soapenv:Body>\n"
      + "</soapenv:Envelope>";


    const modalRef = this.modalService.open(ModelBoxComponent);
    modalRef.componentInstance.title = "Complete XML Generation";
    modalRef.componentInstance.type = "template2";
    modalRef.componentInstance.fileName = "655142452_Publish_NAD.xml";
    modalRef.componentInstance.btnType = "genPubRg"
    modalRef.componentInstance.content = content;
  }

  CreateNadDeviceId(orderNumber: String, modelNumber: String, NAD_modelNumber: String) {
    var deviceId: String = "";
    var vendor: String = "";

    if ((modelNumber == "2210-02-1ATT") || (modelNumber == "2310-51") || (modelNumber.substr(0, 3) == "NVG") || (modelNumber.substr(0, 3) == "NM5")) {
      deviceId = "001E46-" + orderNumber + "000";
      vendor = "Motorola";
    } else if ((modelNumber == "BGW210-700") && (NAD_modelNumber == "Motorola")) {
      deviceId = "001E46-" + orderNumber + "000";
      vendor = "Motorola";
    } else if ((modelNumber == "BGW210-700") && (NAD_modelNumber == "ARRIS")) {
      deviceId = "001E46-" + orderNumber + "000";
      vendor = "ARRIS";
    } else {
      deviceId = "00D09E-" + orderNumber + "000";
      vendor = "2Wire";
    }

    var result = new Array(deviceId, vendor);
    return result;
  }

}
