
import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable()
export class OmsMessageService {
    constructor(private http: HttpClient) { }

    handleError(error: HttpErrorResponse) {
        let errorMessage = 'Unknown error!';
        if (error.error instanceof ErrorEvent) {
            // Client-side errors
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Server-side errors
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        window.alert(errorMessage);
        return throwError(errorMessage);
    }

    public sendOrderXml(data: any): Observable<any> {
        const httpOptions = {
            headers: new HttpHeaders({
                // 'Content-Type': 'text/xml; charset=UTF-8', //<- To SEND XML
                'Content-Type': 'text/xml',
                'Accept': 'text/xml',       //<- To ask for XML
                // 'Access-Control-Allow-Origin': '*',
                // 'Access-Control-Allow-Headers': 'Content-Type',
                // 'responseType': 'text',
                // 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, PATCH, DELETE',
                // 'withCredentials': 'true'
                // 'Allow-Origin-With-Credentials': 'true',
                // 'Access-Control-Allow-Credentials': 'true',
                // 'Access-Control-Allow-Headers': 'X-Requested-With, content-type, token, language',
                // "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept, x-client-key, x-client-token, x-client-secret, Authorization"
            })
        };

        let headers = new HttpHeaders();
        headers = headers.append('Content-Type', 'text/xml');
        headers = headers.append('Accept', 'text/xml');
        headers = headers.append('Access-Control-Allow-Origin', '*');

        let url = "/messageloaderWS/MessageSender"
        return this.http.post(url, data, { headers: headers, responseType: 'text' })
            .pipe(catchError(this.handleError))
    }

    public genPubRgXml(data: any): Observable<any> {
        let headers = new HttpHeaders();
        headers = headers.append('Content-Type', 'text/xml');
        headers = headers.append('Accept', 'text/xml');
        headers = headers.append('Access-Control-Allow-Origin', '*');
        headers = headers.append('Access-Control-Allow-Headers', 'origin');
        headers = headers.append('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');

        // let url = "/sim/services/dynamicRequestInitiatorService/dynamicRequestInitiator.wsdl"
        // let url = "/rm-ws-war/RmFacade?wsdl";
        let url = "/vsim-dev1/sim/sdprep/udas/Testing"
        return this.http.post(url, data, { headers: headers, responseType: 'text' })
        // .pipe(catchError(this.handleError))
    }

    public getTnNumber(data: any): Observable<any> {
        let headers = new HttpHeaders();
        headers = headers.append('Content-Type', 'text/xml');
        headers = headers.append('Accept', 'text/xml');
        let url = "/dngen/services/dynamicNumberGeneratorService/wireCenterRetrieval.wsdl"
        return this.http.post(url, data, { headers, responseType: 'text' })
    }
}