export interface OmsMessage {
    orderNumber: string,
    orderAction: string,
    subType: string,
    reference: string
}