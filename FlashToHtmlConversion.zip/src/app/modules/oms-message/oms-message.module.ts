import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OmsMessageRoutingModule } from './oms-message-routing.module';
import { OmsMessageComponent } from './oms-message.component';
import { FormsModule } from '@angular/forms';
import { OmsMessageService } from './oms-message.service';
import { SharedModule } from 'app/shared/shared.module';
import { UmcComponent } from './component/umc/umc.component';
import { PlstComponent } from './component/plst/plst.component';
import { HeaderService } from 'app/components/header/header.service';

@NgModule({
    declarations: [
        OmsMessageComponent,
        UmcComponent,
        PlstComponent,
    ],
    imports: [
        NgbModule,
        OmsMessageRoutingModule,
        CommonModule,
        FormsModule,
        SharedModule
    ],
    providers: [
        HeaderService,
        OmsMessageService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class OmsMessageModule { }