import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { uspIndicatorDropdown, sevenTeenMHzFeature } from 'app/constants/global.constant';

@Component({
  selector: 'app-plst',
  templateUrl: './plst.component.html',
  styleUrls: ['./plst.component.css']
})
export class PlstComponent implements OnInit {
  dropdownValues1: any[] = uspIndicatorDropdown;
  dropdownValues2: any[] = sevenTeenMHzFeature;
  dropdownValues3: any[] = sevenTeenMHzFeature;
  dropdownValues4: any[] = sevenTeenMHzFeature;
  dropdownValues5: any[] = sevenTeenMHzFeature;
  dropdownValues6: any[] = sevenTeenMHzFeature;
  dropdownTitle1: string = "isCustomerMigrated"
  dropdownTitle2: string = "17MHzFeature"
  dropdownTitle3: string = "vectoringFeature"
  dropdownTitle4: string = "original17MHzFeature"
  dropdownTitle5: string = "originalVectoringFeature"
  dropdownTitle6: string = "gFastDeviceWireType"

  dropdownDisable6: boolean = true;

  selected17MHzFeature: any;
  selectedvectoringFeature: any;
  selectedOriginalvectoringFeature: any;
  selectedIsCustomerMigrated: any;
  selectedOriginal17MHzFeature: any;
  selectedgFastDeviceWireType: any;

  changedIndexDropdown1: any;
  changedIndexDropdown2: any;
  changedIndexDropdown3: any;
  changedIndexDropdown4: any;
  changedIndexDropdown5: any;
  changedIndexDropdown6: any;

  textValue1: string = "";
  textValue2: string = "";
  textTitle1: string = "Old IPDSL Circuit ID";
  textTitle2: string = "Old Transport Type";

  disableText1: boolean = true;
  disableText2: boolean = true;

  constructor() { }

  ngOnInit() {
    this.changedIndexDropdown1 = this.dropdownValues1[1].label;
    this.changedIndexDropdown2 = this.dropdownValues2[1].label;
    this.changedIndexDropdown3 = this.dropdownValues3[1].label;
    this.changedIndexDropdown4 = this.dropdownValues4[1].label;
    this.changedIndexDropdown5 = this.dropdownValues5[1].label;
    this.changedIndexDropdown6 = this.dropdownValues6[0].label;

    this.selectedIsCustomerMigrated = this.changedIndexDropdown1;
    this.selected17MHzFeature = this.changedIndexDropdown2;
    this.selectedvectoringFeature = this.changedIndexDropdown3;
    this.selectedOriginal17MHzFeature = this.changedIndexDropdown4;
    this.selectedOriginalvectoringFeature = this.changedIndexDropdown5;
    this.selectedgFastDeviceWireType = this.changedIndexDropdown6;
  }

  dropDownChange(val, title) {
    if (title == "isCustomerMigrated") {
      this.selectedIsCustomerMigrated = val;
    } else if (title == "17MHzFeature") {
      this.selected17MHzFeature = val;
    } else if (title == "vectoringFeature") {
      this.selectedvectoringFeature = val;
    } else if (title == "original17MHzFeature") {
      this.selectedOriginal17MHzFeature = val;
    } else if (title == "originalVectoringFeature") {
      this.selectedOriginalvectoringFeature = val;
    } else if (title == "gFastDeviceWireType") {
      this.selectedgFastDeviceWireType = val;
    }
  }

}

