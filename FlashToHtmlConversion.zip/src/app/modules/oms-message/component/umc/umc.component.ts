import { Component, Input, OnInit, SimpleChange } from '@angular/core';
import {
  uvOrderActionTypeDropdown,
  VhoDropdownValues,
  TotalBandwidthDropdownValues,
  installTypeDropdownValues,
  techDispatchDropdownValues,
  loopIndicationDropdownValues,
  unifydeunifyIndDropdown
} from '../../../../constants/omsMessage.constant';
import { shortToggleDropdown, trueFalseDropdownValue } from '../../../../constants/global.constant';
import { HeaderState } from 'app/components/header/header.state';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-umc',
  templateUrl: './umc.component.html',
  styleUrls: ['./umc.component.css']
})
export class UmcComponent implements OnInit {
  @Input() data: any;

  dropdownValues1: any[] = uvOrderActionTypeDropdown;
  dropdownValues2: any[] = installTypeDropdownValues;
  dropdownValues3: any[] = techDispatchDropdownValues;
  dropdownValues4: any[] = TotalBandwidthDropdownValues;
  dropdownValues5: any[];
  dropdownValues6: any[] = loopIndicationDropdownValues;
  dropdownValues7: any[] = trueFalseDropdownValue;
  dropdownValues8: any[] = unifydeunifyIndDropdown;
  dropdownTitle1: string = "UVOrderActionType"
  dropdownTitle2: string = "Install Type"
  dropdownTitle3: string = "Tech Dispatch"
  dropdownTitle4: string = "TotalBandwidth"
  dropdownTitle5: string = "Order Reason Code"
  dropdownTitle6: string = "Loop Indication"
  dropdownTitle7: string = "Abf Ind"
  dropdownTitle8: string = "unifydeunifyInd"

  dropdownDisable7: boolean = true;
  dropdownDisable8: boolean = true;

  selectedUvOrder: any;
  selectedTechDispatch: any;
  selectedTotalBandwidth: any;
  selectedLoopIndication: any;
  selectedInstllType: any;
  selectedOrderReasonCode: any;
  selectedAbfInd: any;
  selctedunifydeunifyInd: any;

  isAbfCheck: boolean = true;
  isWorkOrderId: boolean = true;
  isPrevWorkOrderId: boolean = true;

  workOrderId: any;
  prevWorkOrderId: any;

  workOrderIdCheck: any;
  abfCheck: any;
  prevWorkOrderIdCheck: any;

  omsOrderAction: any;
  omsSubType: any;

  changedDropdownValues2: any;
  changedDropdownValues3: any;
  constructor(private store: Store<HeaderState>) { }

  ngOnInit() {
    this.dropdownValues7.reverse();

    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.omsOrderAction = storeObj['orderAction'];
        this.omsSubType = storeObj['subType'];
      });

    this.selectedUvOrder = this.dropdownValues1[0].label;
    this.selectedInstllType = this.dropdownValues2[0].label;
    this.selectedTechDispatch = this.dropdownValues3[0].label;
    this.selectedTotalBandwidth = this.dropdownValues4[0].label;
    this.selectedLoopIndication = this.dropdownValues6[0].label;
    this.selectedAbfInd = this.dropdownValues7[0].label;
    this.selctedunifydeunifyInd = this.dropdownValues8[0].value;
  }

  ngOnChanges(changes: { [property: string]: SimpleChange }) {
    // Extract changes to the input property by its name
    let change: SimpleChange = changes['data'];
    let UpdatedUVOrderActionType = change?.currentValue;
    if (UpdatedUVOrderActionType != undefined) {
      this.dropdownValues1 = UpdatedUVOrderActionType?.map((val) => {
        return { label: val, value: val }
      });
      this.orderActionChange();
    }
    this.selectedUvOrder = this.dropdownValues1[0].label;
    if (this.dropdownValues1 && this.dropdownValues1?.length) {
      this.dropdownValues5 = this.getOrderReasonCode();
      this.selectedOrderReasonCode = this.dropdownValues5[0].label;
    }
    // Whenever the data in the parent changes, this method gets triggered. You 
    // can act on the changes here. You will have both the previous value and the 
    // current value here.
  }

  orderActionChange() {
    if (this.omsOrderAction == "CH") {
      this.changedDropdownValues2 = this.dropdownValues2[1].label;
      this.changedDropdownValues3 = this.dropdownValues3[2].label;
      this.dropdownDisable8 = false;
    } else {
      this.changedDropdownValues2 = this.dropdownValues2[0].label;
      this.changedDropdownValues3 = this.dropdownValues3[0].label;
      this.dropdownDisable8 = true;
    }
    console.log("this.changedDropdownValues2", this.changedDropdownValues2);

    this.selectedInstllType = this.changedDropdownValues2;
    this.selectedTechDispatch = this.changedDropdownValues3;
  }

  onCheckBoxChange() {
    //input field disable on basis of checkbox
    if (this.workOrderIdCheck) {
      this.isWorkOrderId = false;
    } else {
      this.isWorkOrderId = true;
    }

    if (this.prevWorkOrderIdCheck) {
      this.isPrevWorkOrderId = false;
    } else {
      this.isPrevWorkOrderId = true;
    }
  }

  dropDownChange(val, title) {
    if (title == "UVOrderActionType") {
      this.selectedUvOrder = val;
      this.dropdownValues5 = this.getOrderReasonCode();
      this.selectedOrderReasonCode = this.dropdownValues5[0].label;
    } else if (title == "Install Type") {
      this.selectedInstllType = val;
    } else if (title == "Tech Dispatch") {
      this.selectedTechDispatch = val;
    } else if (title == "TotalBandwidth") {
      this.selectedTotalBandwidth = val;
    } else if (title == "Order Reason Code") {
      this.selectedOrderReasonCode = val;
    } else if (title == "Loop Indication") {
      this.selectedLoopIndication = val;
    } else if (title == "Abf Ind") {
      this.selectedAbfInd = val;
    } else if (title == "unifydeunifyInd") {
      this.selctedunifydeunifyInd = this.dropdownValues8.map(value => {
        if (value.label == val) {
          return value.value;
        }
      })
    }
  }

  exhaustHoldIndicator() {
    //exhaustHoldIndicator
    if (this.selectedLoopIndication == "") {
      return "";
    } else {
      return "<bbnmsOrder:exhaustHoldIndicator>" + this.selectedLoopIndication + "</bbnmsOrder:exhaustHoldIndicator>\n";
    }
  }

  getOrderReasonCode() {
    let codes;
    if ((this.selectedUvOrder == 'VS') || (this.selectedUvOrder == 'VR')) {
      codes = [{ label: "VA - Vacation", data: "VA" },
      { label: "ML - Military", data: "ML" },
      { label: "DR - Disaster", data: "DR" },
      { label: "OT - Other", data: "OT" }];
    } else if (this.selectedUvOrder == 'SR') {
      codes = [{ label: "", data: "" },
      { label: "VA - Vacation", data: "VA" },
      { label: "ML - Military", data: "ML" },
      { label: "DR - Disaster", data: "DR" },
      { label: "OT - Other", data: "OT" }];
    } else {
      codes = [{ label: "", data: "" }];
    }

    return codes;
  }

}

