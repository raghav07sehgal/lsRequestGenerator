import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inside-move',
  templateUrl: './inside-move.component.html',
  styleUrls: ['./inside-move.component.css']
})
export class InsideMoveComponent implements OnInit {
  textTitle1: string = "StructureType Value";
  textTitle2: string = "StructureType Old Value";
  textTitle3: string = "StructureValue Value";
  textTitle4: string = "StructureValue Old Value";
  textTitle5: string = "UnitType Value"
  textTitle6: string = "UnitType Old Value"
  textTitle7: string = "UnitValue Value"
  textTitle8: string = "UnitValue Old Value"
  textTitle9: string = "Leveltype Value"
  textTitle10: string = "Leveltype Old Value"
  textTitle11: string = "LevelValue Value"
  textTitle12: string = "LevelValue Old Value"
  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';
  textValue6: any = '';
  textValue7: any = '';
  textValue8: any = '';
  textValue9: any = '';
  textValue10: any = '';
  textValue11: any = '';
  textValue12: any = '';

  constructor() { }

  ngOnInit(): void {
  }

}
