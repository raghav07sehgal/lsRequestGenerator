import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-related-move',
  templateUrl: './related-move.component.html',
  styleUrls: ['./related-move.component.css']
})
export class RelatedMoveComponent implements OnInit {
  textTitle1: string = "BAN";
  textTitle2: string = "CircuitId";
  textTitle3: string = "ExactOrderNumber";
  textTitle4: string = "ProjectOrderNumber";
  textTitle5: string = "ProjectOrderNumberSuffix"
  textValue1: any = '';
  textValue2: any = 'A6/MCXX/<ban>//SB';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';

  constructor() { }

  ngOnInit(): void {
  }

}
