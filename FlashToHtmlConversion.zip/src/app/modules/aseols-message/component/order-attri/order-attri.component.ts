import { Component, OnInit } from '@angular/core';
import { OrderActionDropdown, OrderActionReasonCodeDropdown } from 'app/constants/omsMessage.constant';

@Component({
  selector: 'app-order-attri',
  templateUrl: './order-attri.component.html',
  styleUrls: ['./order-attri.component.css']
})
export class OrderAttriComponent implements OnInit {
  dropdownTitle1: string = "BandwidthUOM";
  dropdownValues1: any[] = OrderActionReasonCodeDropdown;

  textTitle1: string = "TSP Value";
  textTitle2: string = "TSP Old Value";
  textTitle3: string = "Network CH Code";
  textTitle4: string = "Network CH Code Old";
  textTitle5: string = "PSAN Value"
  textTitle6: string = "PSAN Old Value"
  textTitle7: string = "ConsumptionBW Value"
  textTitle8: string = "ConsumptionBW Old Value"
  textTitle9: string = "DnUpBw Value"
  textTitle10: string = "DnUpBw Old Value"
  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';
  textValue6: any = '';
  textValue7: any = '';
  textValue8: any = '';
  textValue9: any = '';
  textValue10: any = '';

  constructor() { }

  ngOnInit(): void {
  }
  orderActionChange(val) { }

}
