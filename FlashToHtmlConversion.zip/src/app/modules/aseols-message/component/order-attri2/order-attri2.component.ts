import { Component, OnInit } from '@angular/core';
import { OrderActionReasonCodeDropdown } from 'app/constants/omsMessage.constant';

@Component({
  selector: 'app-order-attri2',
  templateUrl: './order-attri2.component.html',
  styleUrls: ['./order-attri2.component.css']
})
export class OrderAttri2Component implements OnInit {
  dropdownTitle1: string = "Port Config";
  dropdownTitle2: string = "Exhaust Indic";
  dropdownTitle3: string = "Model";
  dropdownTitle4: string = "17 Mhz";
  dropdownTitle5: string = "Vectoring";
  dropdownValues1: any[] = OrderActionReasonCodeDropdown;
  dropdownValues2: any[] = OrderActionReasonCodeDropdown;
  dropdownValues3: any[] = OrderActionReasonCodeDropdown;
  dropdownValues4: any[] = OrderActionReasonCodeDropdown;
  dropdownValues5: any[] = OrderActionReasonCodeDropdown;

  constructor() { }

  ngOnInit(): void {
  }
  orderActionChange(val) { }
}
