import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aseols-message',
  templateUrl: './aseols-message.component.html',
  styleUrls: ['./aseols-message.component.css']
})
export class AseolsMessageComponent implements OnInit {
  tabType: any = "aseolsMessage";
  contClass1: string = "h1"
  title1: string = "Customer Info";
  tabContent: string = "wh1";
  ServicFspTitle: string = "Service Fsp ASEoLS";


  orderInfoTitle: string = "OrderInfo";
  // wllHt: string = "h380"
  scrollHt: string = "h1"

  constructor() { }

  ngOnInit(): void {
  }

}