import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AseolsMessageRoutingModule } from './aseols-message-routing.module';
import { AseolsMessageComponent } from './aseols-message.component';
import { SharedModule } from 'app/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { OrderAttriComponent } from './component/order-attri/order-attri.component';
import { OrderAttri2Component } from './component/order-attri2/order-attri2.component';
import { InsideMoveComponent } from './component/inside-move/inside-move.component';
import { RelatedMoveComponent } from './component/related-move/related-move.component';

@NgModule({
  declarations: [
    AseolsMessageComponent,
    OrderAttriComponent,
    OrderAttri2Component,
    InsideMoveComponent,
    RelatedMoveComponent,
  ],
  imports: [
    AseolsMessageRoutingModule,
    NgbModule,
    CommonModule,
    FormsModule,
    SharedModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AseolsMessageModule { }
