import { formatDate } from '@angular/common';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import {
  OrderActionDropdown,
  OrderActionReasonCodeDropdown,
  SubTypeDropdown,
  ReferenceDropdown,
  CreationAppDropdown,
  infoValue,
  ntiValue
} from 'app/constants/omsMessage.constant';
import { omsTabSelection, tabValue1 } from 'app/constants/tab.constant';
import { CheckboxItem } from 'app/shared/checkBox-value/checkBox-value.component';
import { FntService } from './fnt.service';
import { Injector } from '@angular/core';
import { shortToggleDropdown } from 'app/constants/global.constant';


@Component({
  selector: 'app-fnt',
  templateUrl: './fnt.component.html',
  styleUrls: ['./fnt.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class FntComponent implements OnInit {
  omsUrl: string = "/Fnt";

  model: NgbDateStruct;
  textTitle1: string = "Order Number";
  textTitle2: string = "OrigOrderActionId";
  textTitle3: string = "dslDisconnectTn";
  textTitle4: string = "TelegenceId";
  textTitle5: string = "APID"
  textValue1: any = '';
  textValue2: any = '';
  textValue3: any = '';
  textValue4: any = '';
  textValue5: any = '';
  textValue6: any = '';

  dropdownTitle1: string = "Order Action Reason Code";
  dropdownTitle2: string = "Order Action";
  dropdownTitle3: string = "Extended Due Date";
  dropdownTitle4: string = "SubType";
  dropdownTitle5: string = "Reference";
  dropdownTitle6: string = "Creation Application";
  dropdownValues1: any[] = OrderActionReasonCodeDropdown;
  dropdownValues2: any[] = OrderActionDropdown;
  dropdownValues3: any[] = shortToggleDropdown;
  dropdownValues4: any[] = SubTypeDropdown;
  dropdownValues5: any[] = ReferenceDropdown;
  dropdownValues6: any[] = CreationAppDropdown;

  omsTabs: any[] = omsTabSelection;
  myDate: any;
  tabType: string = "fnt"
  contClass1: string = "wh5";
  title1: string = "Customer Info";
  containerClass: string = "w1";

  cmTitle: string = "CM";
  pvTitle: string = "PV";
  retaineService: string = "retained ServicesProviderIndicator";
  configChecked: boolean = true;
  GeneratePT: boolean = true;
  GeneratePTC: boolean = true;
  GenerateCPE1: boolean = true;

  wiringAction: string;
  selectedOrder: any;
  selectedSubType: any;
  headerData: any;

  telegenceId_PV: string;
  telegenceId_CM: string;

  labelTooltip: string = "Enter the BAN, select your environment, and click the 'Load CM from Subscription' Button. Then, populate any missing fields in the CM section (in iptv the Basic Service Level, STBs, and GBs are not stored in the subscription and are not retrieved). Click the 'Copy CM to PV' button. Populate any remaining fields in the PV section and add any new components."

  public checkBoxModel = {
    id: 0,
    name: "",
    roles: []
  };

  infoValueOptions = new Array<any>();
  NtiValueOptions = new Array<any>();
  tabCheckOption1 = new Array<any>();

  constructor(private router: Router,
    public omsService: FntService,
    private injector: Injector) {
    this.myDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');;
    this.infoValueOptions = infoValue.map(x => new CheckboxItem(x.id, x.name, false));
    this.NtiValueOptions = ntiValue.map(x => new CheckboxItem(x.id, x.name, false));
    this.tabCheckOption1 = tabValue1.map(x => new CheckboxItem(x.id, x.name, false));
  }

  ngOnInit() { }


  selectedTab(id, tabSelection): any {
    //call your service which makes http call to get content for your selected tab
    let indexNo = id.nextId.replace(/[^0-9]/g, '');

    if (tabSelection[indexNo].label === "hsia") {
      this.router.navigateByUrl(this.omsUrl + '/hsia');
    } else if (tabSelection[indexNo].label === "wifi") {
      this.router.navigateByUrl(this.omsUrl + '/wifi');
    } else if (tabSelection[indexNo].label === "voip") {
      this.router.navigateByUrl(this.omsUrl + '/voip');
    } else if (tabSelection[indexNo].label === "iptv") {
      this.router.navigateByUrl(this.omsUrl + '/ipTv');
    } else if (tabSelection[indexNo].label === "wireless") {
      this.router.navigateByUrl(this.omsUrl + '/wireless');
    } else if (tabSelection[indexNo].label === "direcTv") {
      this.router.navigateByUrl(this.omsUrl + '/direcTv');
    } else if (tabSelection[indexNo].label === "wire") {
      this.router.navigateByUrl(this.omsUrl + '/wire');
    } else if (tabSelection[indexNo].label === "wap") {
      this.router.navigateByUrl(this.omsUrl + '/wap');
    } else if (tabSelection[indexNo].label === "ott") {
      this.router.navigateByUrl(this.omsUrl + '/ott');
    }
  }

  onInfoChange(value) {
    if (value.indexOf('Related Product Info') != -1) {
      this.configChecked = false
    } else {
      this.configChecked = true;
    }
    this.checkBoxModel.roles = value;
  }

  onNtiChange(value) {
    this.checkBoxModel.roles = value;
  }

  orderActionChange(val) {
    this.selectedOrder = val;
  }

  subTypeChange(val) {
    this.selectedSubType = val;
    if (this.selectedOrder == "PR") {
      if (this.selectedSubType == "CA") {
        this.GeneratePT = true;
        this.GenerateCPE1 = false;
        this.GeneratePTC = true;
      } else {
        this.GeneratePT = true;
        this.GenerateCPE1 = true;
        this.GeneratePTC = true;
      }
    } else {
      this.GeneratePT = true;
      this.GenerateCPE1 = true;
      this.GeneratePTC = true;
    }

  }

  onTabChange(value) {
    this.checkBoxModel.roles = value;
  }

  changedTextValue1(val) {
    this.textValue1 = val;
    this.textValue2 = parseInt(this.textValue1) + 1;
  }

  changedTextValue2(val) {
    this.textValue2 = val;
  }

  changedTextValue4(val) {
    this.textValue4 = val;
  }

  changedTextValue5(val) {
    this.textValue5 = val;
  }

  wiringComp() {
    //set actionIndicators
    if (this.textValue1 + this.textValue4 == "PRCA") {
      this.wiringAction = "";
    } else if ((this.textValue4 == "CA") || (this.textValue1 == "RS") || (this.textValue1 == "SR") || (this.textValue1 == "SS") || (this.textValue1 == "SU")) {
      this.wiringAction = "";
    } else {
      this.wiringAction = "<bbnmsOrder:actionIndicator>I</bbnmsOrder:actionIndicator>\n";
    }
  }

}
