
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FntComponent } from './fnt.component';

const routes: Routes = [
  { path: '', component: FntComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FntRoutingModule { }
