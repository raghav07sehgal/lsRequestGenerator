import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FntRoutingModule } from './fnt-routing.module';
import { FntComponent } from './fnt.component';
import { FormsModule } from '@angular/forms';
import { FntService } from './fnt.service';
import { SharedModule } from 'app/shared/shared.module';

@NgModule({
    declarations: [
        FntComponent,
    ],
    imports: [
        NgbModule,
        FntRoutingModule,
        CommonModule,
        FormsModule,
        SharedModule
    ],
    providers: [
        FntService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class FntModule { }