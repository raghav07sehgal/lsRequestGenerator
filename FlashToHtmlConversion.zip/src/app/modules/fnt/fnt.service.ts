
import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
// import { Cacheable } from 'ngx-cacheable';
// import { environment } from '../../configs/environments/environment';
// import { MenuData } from '../../core/constants/global-staticmenu.constants';

@Injectable()
export class FntService {
    constructor(private _http: HttpClient) {
    }
    // private projectStatusFrmSearch = new BehaviorSubject('draft');
    // public projectStatusGetFrmSearch = this.projectStatusFrmSearch.asObservable();

    // public projectStatus(value: any): any {
    //   this.projectStatusFrmSearch.next(value);
    // }
    // public getPaymentLandingMenu(data: any): Observable<any> {
    //   //return this._http.get('data/projectManagmentLanding.json');
    //   return this._http.post('/static/lpsLandingPage', data);
    // }
    // public discardProject(data: any): Observable<any> {
    //   return this._http.post('/projectmanagement/discardProject', data);
    // }
    private options = { headers: new HttpHeaders().set('Content-Type', 'text/xml') };
    public sendOrderXml(data: any): Observable<any> {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/xml', //<- To SEND XML
                'Accept': 'application/xml',       //<- To ask for XML
                'Response-Type': 'text',
                'Access-Control-Allow-Origin': 'localhost:4200',           //<- b/c Angular understands text
            })
        };
        const postedData = `
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://ws.sender.bbnms.att.com/">
        <soapenv:Header/>
        <soapenv:Body>
        <ws:sendMessageToQueue>
        <MessageSenderRequest_V2>
        <environment>ST3</environment>
        <queue>OMS</queue>
        <message><![CDATA[]]></message>
        </MessageSenderRequest_V2>
        </ws:sendMessageToQueue>
        </soapenv:Body>
        </soapenv:Envelope>`;
        const preUrl = "https://cors-anywhere.herokuapp.com/"
        let url = "http://nmssimtl1.snt.bst.bls.com:9058/messageloaderWS/MessageSender"
        return this._http.post(url, data, httpOptions)
        // .subscribe(
        // result => {
        //     console.log(result);  //<- XML response is in here *as plain text*
        // },
        // error => console.log('There was an error: ', error));
    }
}