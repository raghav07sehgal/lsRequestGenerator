
import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
// import { Cacheable } from 'ngx-cacheable';
// import { environment } from '../../configs/environments/environment';
// import { MenuData } from '../../core/constants/global-staticmenu.constants';

@Injectable()
export class MpcEricsonService {
    constructor(private _http: HttpClient) {
    }
    // private projectStatusFrmSearch = new BehaviorSubject('draft');
    // public projectStatusGetFrmSearch = this.projectStatusFrmSearch.asObservable();

    // public projectStatus(value: any): any {
    //   this.projectStatusFrmSearch.next(value);
    // }
    // public getPaymentLandingMenu(data: any): Observable<any> {
    //   //return this._http.get('data/projectManagmentLanding.json');
    //   return this._http.post('/static/lpsLandingPage', data);
    // }
    // public discardProject(data: any): Observable<any> {
    //   return this._http.post('/projectmanagement/discardProject', data);
    // }
}