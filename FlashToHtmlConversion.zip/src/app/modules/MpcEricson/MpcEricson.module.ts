import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MpcEricsonComponent } from './MpcEricson.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { MpcEricsonRoutingModule } from './MpcEricson-routing.module'

@NgModule({
    declarations: [
        MpcEricsonComponent,
    ],
    imports: [
        NgbModule,
        CommonModule,
        FormsModule,
        SharedModule,
        MpcEricsonRoutingModule
    ],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class MpcEricsonModule { }