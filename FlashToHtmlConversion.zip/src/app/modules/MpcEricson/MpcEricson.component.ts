import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';

@Component({
  selector: 'mpc-ericson',
  templateUrl: './MpcEricson.component.html',
  styleUrls: ['./MpcEricson.component.css']
})
export class MpcEricsonComponent implements OnInit {
  title1: string = "FTTP-EGPON";
  title2: string = "FTTC-EGPON";

  contClass1: string = "wh9"
  contClass2: string = "wh9"

  tabSelect: string = "mpcEricson";
  ntiValue: any;

  isNtiValid1: boolean;
  isNtiValid2: boolean;

  constructor(private store: Store<HeaderState>) { }

  ngOnInit() {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.ntiValue = storeObj['nti'];
        if (this.ntiValue?.length) {
          this.isNtiValid1 = true;
          this.isNtiValid2 = true;
          if (this.ntiValue == "FTTP-EGPON") {
            this.isNtiValid1 = false;
          } else if (this.ntiValue == "FTTC-EGPON") {
            this.isNtiValid2 = false;
          }
        }
      })
  }

}
