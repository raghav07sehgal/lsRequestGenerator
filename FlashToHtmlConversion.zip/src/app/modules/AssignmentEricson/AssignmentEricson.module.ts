import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AssignmentEricsonComponent } from './AssignmentEricson.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { AssignmentEricsonRoutingModule } from './AssignmentEricson-routing.module'

@NgModule({
    declarations: [
        AssignmentEricsonComponent,
    ],
    imports: [
        NgbModule,
        CommonModule,
        FormsModule,
        SharedModule,
        AssignmentEricsonRoutingModule
    ],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class AssignmentEricsonModule { }