import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';

@Component({
  selector: 'assign-ericson',
  templateUrl: './AssignmentEricson.component.html',
  styleUrls: ['./AssignmentEricson.component.css']
})
export class AssignmentEricsonComponent implements OnInit {
  textTitle1: string = "Name/ID used in the WebSim Response file";
  textValue1: any = '';

  title1: string = "FTTP-EGPON";
  title2: string = "FTTC-EGPON";

  contClass1: string = "wh1"
  contClass2: string = "wh1"

  isNtiValid1: boolean;
  isNtiValid2: boolean;

  ntiValue: any;

  constructor(private store: Store<HeaderState>) { }

  ngOnInit() {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.ntiValue = storeObj['nti'];
        if (this.ntiValue?.length) {
          this.isNtiValid1 = true;
          this.isNtiValid2 = true;
          if (this.ntiValue == "FTTP-EGPON") {
            this.isNtiValid1 = false;
          } else if (this.ntiValue == "FTTC-EGPON") {
            this.isNtiValid2 = false;
          }
        }
      });
  }
}