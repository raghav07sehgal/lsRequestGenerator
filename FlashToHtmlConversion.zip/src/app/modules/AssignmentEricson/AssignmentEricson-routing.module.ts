
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentEricsonComponent } from './AssignmentEricson.component';

const routes: Routes = [
  { path: '', component: AssignmentEricsonComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssignmentEricsonRoutingModule { }
