import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AssignmentAlcatelComponent } from './AssignmentAlcatel.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { AssignmentAlcatelRoutingModule } from './AssignmentAlcatel-routing.module'

@NgModule({
    declarations: [
        AssignmentAlcatelComponent,
    ],
    imports: [
        NgbModule,
        CommonModule,
        FormsModule,
        SharedModule,
        AssignmentAlcatelRoutingModule
    ],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class AssignmentAlcatelModule { }