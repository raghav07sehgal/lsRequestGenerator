import { Component, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { HeaderState } from 'app/components/header/header.state';
import { AlcatelEricsonComponent } from 'app/shared/alcatelEricson/alcatelEricson.component';

@Component({
  selector: 'assign-alcatel',
  templateUrl: './AssignmentAlcatel.component.html',
  styleUrls: ['./AssignmentAlcatel.component.css']
})
export class AssignmentAlcatelComponent implements OnInit {
  textTitle1: string = "Name/ID used in the WebSim Response file";
  textValue1: any = '';

  title1: string = "FTTC-GPON";
  title2: string = "FTTNBP CO DSLAM";
  title3: string = "FTTN-BP Remote DSLAM/IP-RT";
  title4: string = "FTTN CO DSLAM/IP-CO";
  title5: string = "FTTN Remote DSLAM/IP-RT";
  title6: string = "FTTP-GPON";
  title7: string = "FTTPIP";
  title8: string = "FX TO GPON";
  title9: string = "IP-CO-BP";
  title10: string = "QNI g.Fast";
  title11: string = "RGPON";

  contClass1: string = "wh1"
  contClass2: string = "wh7"
  contClass3: string = "wh4"
  contClass4: string = "wh5"
  contClass5: string = "wh5"
  contClass6: string = "wh1"
  contClass7: string = "wh1"
  contClass9: string = "wh5"
  contClass8: string = "wh6"
  contClass10: string = "wh2"
  contClass11: string = "wh3"

  isNtiValid1: boolean;
  isNtiValid2: boolean;
  isNtiValid3: boolean;
  isNtiValid4: boolean;
  isNtiValid5: boolean;
  isNtiValid6: boolean;
  isNtiValid7: boolean;
  isNtiValid9: boolean;
  isNtiValid11: boolean;

  ntiValue: any;
  circuitId: any;

  @ViewChild(AlcatelEricsonComponent) l1Alcatel: AlcatelEricsonComponent;

  constructor(private store: Store<HeaderState>) { }

  ngOnInit() {
    this.store.select(state => state['header'])
      .subscribe((data) => {
        let storeObj = data.reduce(((r, c) => Object.assign(r, c)), {})
        this.ntiValue = storeObj['nti'];
        this.circuitId = storeObj['circuitId'];
        if (this.ntiValue?.length) {
          this.isNtiValid1 = true;
          this.isNtiValid2 = true;
          this.isNtiValid3 = true;
          this.isNtiValid4 = true;
          this.isNtiValid5 = true;
          this.isNtiValid6 = true;
          this.isNtiValid7 = true;
          this.isNtiValid9 = true;
          this.isNtiValid11 = true;
          if (this.ntiValue == "FTTN (RT)" || this.ntiValue == "IP-RT") {
            this.isNtiValid5 = false;
          } else if (this.ntiValue == "FTTN (CO)" || this.ntiValue == "IP-CO") {
            this.isNtiValid4 = false;
          } else if (this.ntiValue == "FTTN-BP (RT)" || this.ntiValue == "IP-RT-BP") {
            this.isNtiValid3 = false;
          } else if (this.ntiValue == "FTTN-BP (CO)") {
            this.isNtiValid2 = false;
          } else if (this.ntiValue == "FTTPIP") {
            this.isNtiValid7 = false;
          } else if (this.ntiValue == "FTTP-GPON") {
            this.isNtiValid6 = false;
          } else if (this.ntiValue == "RGPON") {
            this.isNtiValid11 = false;
          } else if (this.ntiValue == "IP-CO-BP") {
            this.isNtiValid9 = false;
          } else if (this.ntiValue == "FTTC-GPON") {
            this.isNtiValid1 = false;
          }
        }
      })
  }

}