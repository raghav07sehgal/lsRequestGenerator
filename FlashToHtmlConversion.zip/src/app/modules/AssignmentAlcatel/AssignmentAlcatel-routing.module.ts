
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentAlcatelComponent } from './AssignmentAlcatel.component';

const routes: Routes = [
  { path: '', component: AssignmentAlcatelComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssignmentAlcatelRoutingModule { }
