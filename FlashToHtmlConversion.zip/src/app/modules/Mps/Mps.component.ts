import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mps',
  templateUrl: './Mps.component.html',
  styleUrls: ['./Mps.component.css']
})
export class MpsComponent implements OnInit {
  textTitle1: string = "Order Number";
  textValue1: any = '';

  constructor() { }

  ngOnInit() {
  }

}
