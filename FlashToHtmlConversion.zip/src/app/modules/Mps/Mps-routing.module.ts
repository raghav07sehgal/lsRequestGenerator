
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MpsComponent } from './Mps.component';

const routes: Routes = [
  { path: '', component: MpsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MpsRoutingModule { }
