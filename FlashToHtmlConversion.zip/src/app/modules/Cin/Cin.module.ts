import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { CinComponent } from './Cin.component';
import { CinRoutingModule } from './Cin-routing.module';

@NgModule({
    declarations: [
        CinComponent,
    ],
    imports: [
        NgbModule,
        CommonModule,
        FormsModule,
        SharedModule,
        CinRoutingModule
    ],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class CinModule { }