import { Component, OnInit } from '@angular/core';
import { shortToggleDropdown } from 'app/constants/global.constant';

@Component({
  selector: 'app-cin',
  templateUrl: './Cin.component.html',
  styleUrls: ['./Cin.component.css']
})
export class CinComponent implements OnInit {
  textTitle1: string = "TransactionId";
  textTitle2: string = "Ban";
  textValue1: any = '';
  textValue2: any = '';

  dropdownValue1: any[] = shortToggleDropdown;
  dropdownTitle1: string = "TreatmantFlag"

  constructor() { }

  ngOnInit() {
    // this.dropdownValue1.reverse()
  }

  // updateCINRequest() {
  //   // XML.ignoreProcessingInstructions = false;

  //   var cinRequest;

  //   cinRequest = `<cin:UpdateCopyrightInfringementNotificationRequest xsi:schemaLocation="http://bbnms.att.com/updatecin UpdateCIN.xsd" xmlns:cin="http://bbnms.att.com/updatecin" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">`
  //     + `<cin:TransactionId>{cinTransactionId.text}</cin:TransactionId>`
  //     + `<cin:Ban>{cinBAN.text}</cin:Ban>`
  //     + `<cin:TreatmentFlag>{cinTreatmentFlag.selectedItem.data}</cin:TreatmentFlag>`
  //     + `</cin:UpdateCopyrightInfringementNotificationRequest>;`

  //   writeLog("Sending CIN Request: " + cinRequest);

  //   if (env.text == 'ST3') {
  //     cinST3.UpdateCopyrightInfringementNotification.send(cinRequest);
  //   }
  //   else if (env.text == 'ST4') {
  //     cinST4.UpdateCopyrightInfringementNotification.send(cinRequest);
  //   }
  //   else if (env.text == 'ST6') {
  //     cinST6.UpdateCopyrightInfringementNotification.send(cinRequest);
  //   }
  //   else {
  //     rPopup.setResult("Only ST3, ST4 and ST6 are supported");
  //     rPopup.open(this, false);
  //   }
  // }

}
