
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CinComponent } from './Cin.component';

const routes: Routes = [
  { path: '', component: CinComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CinRoutingModule { }
