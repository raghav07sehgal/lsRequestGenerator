import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WllComponent } from './wll.component';

const routes: Routes = [
  { path: '', component: WllComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WllRoutingModule { }
