import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WllRoutingModule } from './wll-routing.module';
import { WllComponent } from './wll.component';
import { SharedModule } from 'app/shared/shared.module';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [WllComponent],
  imports: [
    CommonModule,
    WllRoutingModule,
    SharedModule,
    FormsModule,
    NgbModule
  ]
})
export class WllModule { }
