import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { RadioOptionsValues2 } from 'app/constants/header.constant';
import { OrderActionReasonCodeDropdown } from 'app/constants/omsMessage.constant';
import { wllTabArr, wllTabSelected } from 'app/constants/tab.constant';

@Component({
  selector: 'app-wll',
  templateUrl: './wll.component.html',
  styleUrls: ['./wll.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class WllComponent implements OnInit {
  radioValues: any[] = RadioOptionsValues2;
  wllftOptions: any[] = [
    { label: "MI JBBOS", value: "miJbbos" }
  ];
  suspendOptions: any[] = [
    { label: "Involuntary Suspend Resume", value: "involuntarySuspendResume" }
  ]
  stackDataOptions: any[] = [
    { label: "Stack Order-Data", value: "stackOrderData" }
  ];
  stackVoiceOptions: any[] = [
    { label: "Stack Order-Voice", value: "stackOrderVoice" }
  ];
  relatedOptions: any[] = [
    { label: "Related Product Info", value: "relatedProdInfo" }
  ];

  dropdownTitle1: string = "Order Action Reason Code";
  dropdownTitle2: string = "Supercede";
  dropdownTitle3: string = "RemovalType";
  dropdownTitle4: string = "unifydeunifyInd";
  dropdownTitle5: string = "Reference";
  dropdownTitle6: string = "Creation Application";
  dropdownValues1: any[] = OrderActionReasonCodeDropdown;
  dropdownValues2: any[] = OrderActionReasonCodeDropdown;
  dropdownValues3: any[] = OrderActionReasonCodeDropdown;
  dropdownValues4: any[] = OrderActionReasonCodeDropdown;

  DataTitle: string = "OrderInfo - Data";
  VoiceTitle: string = "OrderInfo - Voice";

  tabSelect: string = "wll";
  wllHt: string = "h380"
  scrollHt: string = "h450"
  checkBoxClass: string = "d-inline-flex";

  tabType1: string = "wllLSBilling";
  tabType2: string = "wllServiceFsp";
  serviceTitle1: string = "Address Type - LSBilling";
  serviceTitle2: string = "Address Type - ServiceFsp";

  wllTabs: any[] = wllTabSelected;
  wllTabArr: any[] = wllTabArr;
  inputCss: string = "ht1";
  tabCss: string = "h1";

  title1: string = "Customer Info";
  title2: string = "New Customer Info";
  tabContent: string = "wh1";
  tabClass: string = "wh6"
  contClass1: string = "h4";

  configOrderChecked1: boolean = false;
  configOrderChecked2: boolean = false;
  configProductChecked: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  radioValueChange(value) { }

  onWllftChange(val) { }

  onCheckChange(evt) {
    if (evt.indexOf('Stack Order-Data') != -1) {
      this.configOrderChecked1 = true;
    } else if (evt.indexOf('Stack Order-Voice') != -1) {
      this.configOrderChecked2 = true;
    } else if (evt.indexOf('Related Product Info') != -1) {
      this.configProductChecked = true;
    } else {
      this.configOrderChecked1 = false;
      this.configOrderChecked2 = false;
      this.configProductChecked = false;
    }
  }

}
